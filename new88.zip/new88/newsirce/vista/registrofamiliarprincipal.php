<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

//$id = $_GET['id'];
//$usuarios = "SELECT * FROM persona WHERE idpersona = '$id'";

session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="estiloregistropersona.css" rel="stylesheet" type="text/css"/>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
   <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>


    <style>

      @font-face{
  font-family: opensan;
  src: url(fonts/googlesansnormal.woff2);

}

body{
  font-family: opensan;
}

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }
      .linka{
        color: black;
      }

      .inputcedulaestilo{
        display: none;
      }

.formu-control.success input {
  border-color: #2ecc71;
}

.formu-control.error input {
  border-color: #e74c3c;
}

.formu-control.success select {
  border-color: #2ecc71;
}

.formu-control.error select {
  border-color: #e74c3c;
}

.formu-control .fas {
  visibility: hidden;
  /*position: absolute;
  top: 40px;
  right: 10px;*/
}

.formu-control.success .fas.fa-check-circle {
  color: #2ecc71;
  visibility: visible;
}

.formu-control.error .fas.fa-exclamation-circle {
  color: #e74c3c;
  visibility: visible;
}

.formu-control small {
  color: #e74c3c;
  /*position: absolute;
  bottom: 0;
  left: 0;*/
  visibility: hidden;
}

.formu-control.error small {
  visibility: visible;
  
}

   #iconomunero1{
position: relative;
    width: 5%;
    top: -118px;
    left: 10%;
    cursor: pointer;
}

      #iconomunero2{
position: relative;
    width: 5%;
    top: -118px;
    left: 27%;
    cursor: pointer;
}

      #iconomunero3{
position: relative;
    width: 5%;
    top: -118px;
    left: 47%;
    cursor: pointer;
}

      #iconomunero4{
position: relative;
    width: 5%;
    top: -118px;
    left: 67%;
    cursor: pointer;
}

#linea{
      position: relative;
    top: -78px;
}

      #letranumero1{
    position: relative;
    width: 5%;
    top: -114px;
    left: 10%;
}

      #letranumero2{
position: relative;
    width: 5%;
    top: -178px;
    left: 30%;
}

      #letranumero3{
    position: relative;
    width: 5%;
    top: -215px;
    left: 57%;
}

      #letranumero4{
    position: relative;
    width: 5%;
    top: -254px;
    left: 82%;
}

#multiregister{
margin: 0px 0px -262px;
}

#moverdivmultiregister{
      position: relative;
    top: -47px;
}


#botonterminarregistro{
  position: relative;
    left: 8%;
}

#botonregistrarfamiliar{
  z-index: 2;
}
    </style>
  
</head>
<body class="bg-light">
<?php include"componentes/nav.php" ?>


    <div class="container rounded border py-3 bg-white" style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;
        ">

    <!--  CONTENIDO  -->

   
      <!-- TAB-FAMILIARES  -->
      <div class="articulo tab-pane " id="nav-familiares" role="tabpanel" aria-labelledby="nav-familiares-tab">

         <div class="row mb-5">

      </div>

      <div id="moverdivmultiregister">

                  <div id="multiregister" class="col col-sm-12">
          
          <hr id="linea" ></hr>
          <img id="iconomunero1" src="../iconos/numero-1inicio.png">
          <img id="iconomunero2" src="../iconos/numero-2inicio.png">
          <img id="iconomunero3" src="../iconos/numero-3inicio.png">
          <img id="iconomunero4" src="../iconos/numero-cuatro.png">


          <p id="letranumero1" >datos basicos</p>
          <p id="letranumero2">documentos</p>
          <p id="letranumero3">historico</p>
          <p id="letranumero4">familiares</p>

        </div>
        
      </div>

        <div class="col col-sm-12 d-block justify-content-center">


                
                        <table class="table">
                        <thead>
                          <tr>
                            
                            <th scope="col">Parentesco</th>
                            <th scope="col">Nombres</th>
                            <th scope="col">Apellidos</th>
                            <th scope="col">Edad</th>
                            <th scope="col"><img src="../icons/buscar.png" width="20px"></th>
                            
                          </tr>
                        </thead>
                        <tbody id='cuerpo'>

                        </tbody>
                      </table>

        </div>


        <div class="col col-sm-12 d-flex justify-content-end">

          <div class="col-sm-12">
            <button type="button" id="botonterminarregistro" class="btn btn-primary justify-content-center" >
              terminar registro
              </button>
                 <!-- <button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" >
              
              </button>-->

              </div>
            
            <button id="botonregistrarfamiliar" type="button" class="btn btn-primary d-flex justify-content-center" data-bs-toggle="modal" data-bs-target="#registro-familiar">
              Registrar Familiar
            </button>

        </div>

        <!-- Modal -->
          <div class="modal fade " id="registro-familiar" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl">
              <div class="modal-content">
                <div class="modal-header" style="background-color: #e3f2fd;">
                  <h5 class="modal-title" id="exampleModalLabel">Registrar Nuevo Familiar</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                  <form id="formufee" method="post" enctype="multipart/form-data">


                  <div class="row mb-4">

                     <div class="col col-sm-6" id="inputcedula">
                     <!--<label for="cedula" class="form-label">Cedula</label>
                      <input type="number" class="form-control" id="cedula" name="Cedulapersonaf">-->
                      </div>
                    
                    <div class="col col-sm-6">
                      <div  class="form-check d-flex justify-content-center mt-4 formu-control">
                        <input class="form-check-input" type="checkbox" name="checkcedufami" id="checkcedufami" onclick="ischecked()">
                        <small>Error message</small>
                        <label class="form-check-label" for="flexCheckDefault">
                          No posee Cédula
                        </label>
                      </div>
                    </div>
                    <div class="col col-sm-6 formu-control">
                      <label for="parentesco" class="form-label">Parentesco</label>
                          <select name="parentesco" class="form-select" style="text-transform: uppercase;" id="parentesco">
                            <option selected disabled value="">Seleccione un parentesco</option>
                            <option value="hijo">hijo</option>
                            <option value="esposa">esposa</option>
                            <option value="esposo">esposo</option>
                            <option value="sobrino">sobrino</option>
                          </select>
                          <small>Error message</small>
                    </div>

                  </div>


                  <!--  CEDULA - NOMBRE Y APELLIDO</!--->

                    <div class="row mb-4">

                      <div id="campocedulaa" class="col col-sm-4 formu-control">
                        <label for="cedula" class="form-label">Cédula</label>
                        <input type="number" name="cedulafam" class="form-control" id="cedulafam">
                        <small>Error message</small>
                      </div>

                       <div class="col col-sm-4 formu-control">
                        <label for="nombres" class="form-label">Nombres</label>
                        <input type="text" name="nombrefam" class="form-control" style="text-transform: uppercase;" id="nombrefam">
                        <small>Error message</small>
                      </div>

                       <div class="col col-sm-4 formu-control">
                        <label for="apellidos" class="form-label">Apellidos</label>
                        <input type="text" name="apellidofam" class="form-control" style="text-transform: uppercase;" id="apellidofam">
                        <small>Error message</small>
                      </div>

                    </div>

                  <!--  CEDULA - ESTADO CIVIL</!--->

                  <!-- FECHA - SEXO</!--->

                    <div class="row mb-4">

                      <div class="col col-sm-4 formu-control">
                        <label for="fecha-nac" class="form-label">Fecha de Nacimiento</label>
                        <input type="date" name="fechanacimientofam" class="form-control" id="fechanacimientofam">
                        <small>Error message</small>
                      </div>

                      <div class="col col-sm-4 formu-control">
                         <label for="sexo" class="form-label">Sexo</label>
                        <select name="sexofam" class="form-select" style="text-transform: uppercase;" id="sexofam">
                          <option selected disabled value="">Seleccione un documento</option>
                          <option value="m">Masculino</option>
                          <option value="f">Femenino</option>
                          <option value="o">Otro</option>
                        </select>
                        <small>Error message</small>
                      </div>

                      <div id="campoestadocivil" class="col col-sm-4 formu-control">
                         <label for="std-civil" class="form-label">Estado Civil</label>
                          <select name="estadocivilfam" class="form-select" style="text-transform: uppercase;" id="estadocivilfam">
                            <option selected disabled value="">Seleccione un documento</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                          </select>
                          <small>Error message</small>
                      </div>

                    </div>

                  <!-- FECHA - SEXO</!--->
                  <!--  NUMEROS TELEFONICOS </!--->

                    <div id="campostelefonicos" class="row mb-4">
                      <div class="col sm-6 formu-control">
                        <label for="n-principal" class="form-label">Numero Principal</label>
                        <input type="number" name="telefonoprincipalfam" class="form-control" id="telefonoprincipalfam">
                        <small>Error message</small>
                      </div>
                      <div class="col sm-6 formu-control">
                        <label for="n-habitacion" class="form-label">Numero Habitación</label>
                        <input type="number" name="telefonohabitacionfam" class="form-control" id="telefonohabitacionfam">
                        <small>Error message</small>
                      </div>
                    </div>

                    <!--  NUMEROS TELEFONICOS </!--->


                    <!-- LOCALIDAD</!--->

                      <div class="row mb-4">
                        
                        <div class="col col-sm-12 formu-control">
                          <label for="direccion" class="form-label">Dirección</label>
                          <input type="text" name="direccionfam" class="form-control form-control-lg" style="text-transform: uppercase;" id="direccionfam">
                          <small>Error message</small>
                        </div>

                      </div>

                    <!-- LOCALIDAD</!--->

                    <!--  PESO Y ESTATURA </!--->

                    <div class="row mb-4">
                      <div class="col sm-6 formu-control">
                        <label for="peso" class="form-label">Peso</label>
                        <input type="text" name="pesofam" class="form-control" style="text-transform: uppercase;" id="pesofam">
                        <small>Error message</small>
                      </div>
                      <div class="col sm-6 formu-control">
                        <label for="estatura" class="form-label">Estatura</label>
                        <input type="text" name="estaturafam" class="form-control" id="estaturafam">
                        <small>Error message</small>
                      </div>
                    </div>

                    <!--  PESO Y ESTATURA </!--->

                    <!--  TALLAS</!--->

                      <div class="row mb-4">
                        
                        <div class="col sm-4 formu-control">
                          <label for="camisa" class="form-label">Talla Camisa</label>
                          <input type="text" name="tallacamisafam" class="form-control" style="text-transform: uppercase;" id="tallacamisafam">
                          <small>Error message</small>
                        </div>

                        <div class="col sm-4 formu-control">
                          <label for="pantalon" class="form-label">Talla Pantalón</label>
                          <input type="text" name="tallapantalonfam" class="form-control" style="text-transform: uppercase;" id="tallapantalonfam">
                          <small>Error message</small>
                        </div>

                        <div class="col sm-4 formu-control">
                          <label for="calzado" class="form-label">Talla Calzado</label>
                          <input type="text" name="tallacalzadofam" class="form-control" style="text-transform: uppercase;" id="tallacalzadofam">
                          <small>Error message</small>
                        </div>

                      </div>

                    <!--  TALLAS</!--->

                  </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                  <button type="submit" name="Guardarfamilia" class="btn btn-primary">Guardar</button>

                </div>
                
              </div>
              </form>
            </div>

          </div>


      </div>
     
      <!-- TAB-FAMILIARES  -->

    </div>







    <div class="modal fade" id="modalregistrarrellenecampos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>rellener todos los campos</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" name="Guardard" class="btn btn-primary">Guardar</button>

                  </div>
                </div>
              </div>
            </div>


                              <div class="modal fade" id="modalregistrarexitoso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>Familiar registrado con existo</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                   <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="botonrecargarhistoricos">Cerrar</button>

                  </div>
                </div>
              </div>
            </div>


                      <div class="modal fade" id="modalmensajeagregueundocumento" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>Agregue un Familiar</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

                  </div>
                </div>
              </div>
            </div>

    <!--  CONTENIDO  -->
  
              <script src="jquery.min.js"></script>
  <script src="registrofamiliar.js"></script>
   <script type="text/javascript">
    const botonirpersona = document.getElementById("iconomunero1");
    const botonirdocumento = document.getElementById("iconomunero2");
    const botonirhistorico = document.getElementById("iconomunero3");
    const botonirfamiliar = document.getElementById("iconomunero4");
    
    botonirpersona.onclick = function() {

        window.location.href ='registro-persona.php';
      

      }

    botonirdocumento.onclick = function() {

        window.location.href ='registrodocumentosprincipal.php';
      

      }

    botonirhistorico.onclick = function() {

        window.location.href ='registrohistoricoprincipal.php';
      

      }

    botonirfamiliar.onclick = function() {

        window.location.href ='registrofamiliarprincipal.php';
      

      }


 </script>
 
  </body>
  </html>