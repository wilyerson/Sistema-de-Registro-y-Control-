<?php

session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}


?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }
    </style>
  
</head>
<body>



  <nav class="navbar bg-body-tertiary fixed-top">
      <div class="container-fluid menumenu">
        <a class="navbar-brand" href="#"><H4>S.I.R.C.E</H4></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Nombre Usuario</h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#">Inicio</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Cambiar Nombre de Usuario</a></li>
                <li><a class="dropdown-item" href="#">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <!--<a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>-->
              <!--<ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="#">Añadir Instituciones</a></li>
              </ul>-->
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="../controlador/cierre.php">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

  <div class="container-md articulo">
    <div class="input-group input-group-sm mb-3">
      <span class="input-group-text" id="inputGroup-sizing-sm">Buscar</span>
      <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" name="campo" id="campo">
      
      <button class="btn btn-primary" id="botonbuscar">buscar</button>

      
    </div>
    <!--<button type="button" class="btn btn-success" ><a class="nuevo-trb" href="registro-persona.php">Añadir Nuevo Trabajador</a></button>-->
    <table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Cedula</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellido</th>
      <th scope="col">Estado civil</th>
      <th scope="col"><img src="../icons/buscar.png" width="20px"></th>
    </tr>
  </thead>
  <tbody id="content">
   
  </tbody>
</table>
    
  </div>




  <script>

const botonbuscar = document.getElementById('botonbuscar');
 botonbuscar.onclick = function(){

 // document.getElementById("campo").addEventListener("keyup", getData)



  getData();
  }

function getData(){
 let input = document.getElementById("campo").value
 let content = document.getElementById("content")
 let url = "../controlador/loadusuarioconsulta.php"
 let formaData = new FormData()
 formaData.append('campo', input)

fetch(url, {
  method: "POST",
  body: formaData
}).then(response => response.json())
.then(data => {
  content.innerHTML = data
}).catch(err => console.log(err))

}


    </script>

</body>
</html>