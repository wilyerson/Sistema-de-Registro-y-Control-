<style type="text/css">
    

   #navestilo{
     box-shadow: rgb(0 154 255 / 47%) 0.3981px -0.6019px 14.562989px 1.0625px, rgba(9, 172, 255, 0.49) 1.20725px 1.20725px 1.70731px -1.875px, rgba(9, 172, 255, 0.42) 3.19133px 3.19133px 4.51322px -2.8125px, rgba(9, 172, 255, 0.176) 10px 10px 14.1421px -3.75px;

   } 

#bottonhamburguesa{

    border-style: none;

    background: linear-gradient(102deg, rgb(255 242 0) 0%, rgb(255 247 0) 100%);
    height: 70%;
    width: 5.9%;
    border-radius: 12px;
    box-shadow: rgba(9, 172, 255, 0.518) 0.3981px 0.3981px 0.56299px -0.9375px, rgba(9, 172, 255, 0.49) 1.20725px 1.20725px 1.70731px -1.875px, rgba(9, 172, 255, 0.42) 3.19133px 3.19133px 4.51322px -2.8125px, rgba(9, 172, 255, 0.176) 10px 10px 14.1421px -3.75px;

            box-shadow: 0 5px 10px 0px rgba(0 0 0 / 49%);
    -moz-box-shadow: 0 5px 10px 0px rgba(0 0 0 / 49%);

    transition: box-shadow 0.2s linear 0.1s;
  }

    #bottonhamburguesa:hover {
 
      box-shadow: 0 5px 17px 0px rgb(238 255 102 / 75%);
  
}

a{
  text-align: 10px;
}

    a:hover {
  background-color: #008CBA; 
 /* border-radius: 100px;*/
  color: white;
 
}







  </style>

 <nav id="navestilo" class="navbar fixed-top" style="background-color: #009aff;">
      <div class="container p-0" style="width: 900px; height: 65px;">
        <a class="navbar-brand d-flex align-baseline" href="bienvenida.php"><img src="../icons/inicio-blanco.png" style="color: white; height: 30px;"><H4 style="color:white; margin-bottom: 0px;" >S I R C E</H4></a>
        <button id="bottonhamburguesa"  type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end " tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Usuario : <?php echo $_SESSION['usuarioad'];?></h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Buscar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="registro-persona.php">Registrar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="control-usuarios-sistema.php">gestion de Usuarios del Sistema</a>
            </li>
            <li class="nav-item" >
              <a class="nav-link" aria-current="page" href="modificar-contrasena-usuario.php">cambiar contraseña</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="registro-cargos.php">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="registro-institucion.php">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="../controlador/cierre.php">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
</nav>