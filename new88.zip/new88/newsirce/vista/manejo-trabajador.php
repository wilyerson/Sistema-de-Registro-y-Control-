<?php 

session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}


$conn = mysqli_connect("localhost","root","","newsirce"); 

$id = $_GET['id'];
$usuarios = "SELECT * FROM persona WHERE Cedulapersona = '$id'";
$documentos = "SELECT * FROM documento   WHERE Cedulapersona = '$id'";
$historicos = "SELECT * FROM historico WHERE Cedulapersona = '$id'";
$familias = "SELECT * FROM familia WHERE Cedulapersona = '$id'";



?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Inicio Sirce</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="estilomanejotrabajador.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }
      .linka{
        color: black;
      }


      .inputcedulaestilo{
        display: none;
      }

      .imagregistrodocumento{
        width: 100px;
      }

      .formu-control.success input {
  border-color: #2ecc71;
}

.formu-control.error input {
  border-color: #e74c3c;
}

.formu-control.success select {
  border-color: #2ecc71;
}

.formu-control.error select {
  border-color: #e74c3c;
}

.formu-control .fas {
  visibility: hidden;
  /*position: absolute;
  top: 40px;
  right: 10px;*/
}

.formu-control.success .fas.fa-check-circle {
  color: #2ecc71;
  visibility: visible;
}

.formu-control.error .fas.fa-exclamation-circle {
  color: #e74c3c;
  visibility: visible;
}

.formu-control small {
  color: #e74c3c;
  /*position: absolute;
  bottom: 0;
  left: 0;*/
  visibility: hidden;
}

.formu-control.error small {
  visibility: visible;
  
}

input{
  text-transform: uppercase;
}

select{
  text-transform: uppercase;
}
    </style>
  
</head>
<body>

  	<nav class="navbar navbar-light fixed-top" style="background-color: #0d6efd; ">
      <div class="container-fluid menumenu">

        <nav>
          <div class="nav nav-tabs" role="tablist">
            
            <button class="nav-link active" id="nav-perfil-tab" type="button" data-bs-toggle="tab" data-bs-target="#nav-perfil" role="tab" aria-controls="nav-perfil" aria-selected="false" style="color: black;" >Perfil Trabajador</button>

            <button class="nav-link" id="nav-documentos-tab" type="button" data-bs-toggle="tab" data-bs-target="#nav-documentos" role="tab" aria-controls="nav-documentos" aria-selected="false" style="color: black;">Documentos</button>

            <button class="nav-link" id="nav-historico-tab" type="button" data-bs-toggle="tab" data-bs-target="#nav-historico" role="tab" aria-controls="nav-historico" aria-selected="false" style="color: black;">Histórico</button>

            <button class="nav-link" id="nav-familiares-tab" type="button" data-bs-toggle="tab" data-bs-target="#nav-familiares" role="tab" aria-controls="nav-familiares" aria-selected="false" style="color: black;">Familiares</button>


          </div>
        </nav>

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Nombre Usuario</h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Buscar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="registro-persona.php">Registrar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="control-usuarios-sistema.php">Control de Usuarios del Sistema</a>
            </li>
            <li class="nav-item" >
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="modificar-contrasena-usuario.php">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="registro-cargos.php">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="registro-institucion.php">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="../controlador/cierre.php">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!--  CONTENIDO  -->

    <div class="tab-content" id="pills-tabContent">
      <!-- TAB-PERFIL  -->
      <div class="articulo tab-pane fade show active" id="nav-perfil" role="tabpanel" aria-labelledby="nav-perfil-tab">

         <?php $resultado = mysqli_query($conn, $usuarios);

          while ($row=mysqli_fetch_assoc($resultado)) { ?>
        
        <div class="row mt-2 mb-2">
          
          <div class="col col-sm-6">
            <img class="rounded mx-auto d-block" id="img-perfil" src="../controlador/imagenes/<?php echo $row['Fotopersona']; ?>" width="200px">
          </div>

        
          <?php  

          $fechapersona = date('Y', strtotime($row['Fechanacimiento']));
          $fechactual = date('Y');
          $edad = $fechactual - $fechapersona;
          //$fechaa = $row['fechanacimientopersona'];
         

            ?>

          <input type="hidden" value="<?php echo $row['Cedulapersona']; ?>" name="id" id="idcedula" >

          <div class="col sm-6">
            <div class="row mb-0"><h4>Trabajador : <?php echo strtoupper($row['Nombres']); ?> <?php echo strtoupper($row['Apellidos']); ?></h4></div>
            <div class="row mb-0 p-0 b-0"><p class="mb-2">Cedula de Identidad: <?php echo $row['Cedulapersona']; ?></p></div>
            <div class="row mb-0 p-0 b-0"><p class="mb-2">Edad: <?php echo $edad; ?></p></div>
            <div class="row mb-0 p-0 b-0"><p class="mb-2">Cargo Actual: </p></div>
            <div class="row mb-0 p-0 b-0"><p class="mb-2">Dirección: <?php echo strtoupper($row['direccion']); ?></p></div>

          </div>

        </div>

        

          <form id="formupersonamodificar"  method="post"  enctype="multipart/form-data"  novalidate>

           <input type="hidden" value="<?php echo $row['Cedulapersona']; ?>" name="idpersona" id="idpersona" >

        <div class="row mt-2 mb-2">
          
          <div class="col col-sm-12 d-flex justify-content-center">
            <!-- LANZAR MODAL PARA EDITAR -->
            <button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-editar-trabajador">
              Modificar Datos
            </button>

            <!-- MODAL EDITAR -->
            <div class="modal fade" id="modal-editar-trabajador" tabindex="-1" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-xl">
                <div class="modal-content">

                  <div class="modal-header" style="background-color: #e3f2fd;">
                    <h5 class="modal-title" id="exampleModalLabel">Editar Datos del Trabajador</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>

                  <div class="modal-body">


                  <!--  CEDULA - NOMBRE Y APELLIDO</!--->

                    <div class="row mb-4">

                      <div class="col col-sm-4 formu-control">
                        <label for="cedula" class="form-label">Cédula</label>
                        <input type="number" class="form-control" id="Cedulapersona" name="Cedulapersona" value="<?php echo $row['Cedulapersona']; ?>">
                        <small>Error message</small>
                      </div>

                       <div class="col col-sm-4 formu-control">
                        <label for="nombres" class="form-label">Nombres</label>
                        <input type="text" class="form-control" id="Nombres" name="Nombres" value="<?php echo strtoupper($row['Nombres']) ; ?>">
                        <small>Error message</small>
                      </div>

                       <div class="col col-sm-4 formu-control">
                        <label for="apellidos" class="form-label">Apellidos</label>
                        <input type="text" class="form-control" id="Apellidos" name="Apellidos" value="<?php echo strtoupper($row['Apellidos']); ?>">
                        <small>Error message</small>
                      </div>

                    </div>

                  <!--  CEDULA - ESTADO CIVIL</!--->

                  <!-- FECHA - SEXO</!--->

                    <div class="row mb-4">

                      <div class="col col-sm-4 formu-control">
                        <label for="fecha-nac" class="form-label">Fecha de Nacimiento</label>
                        <input type="date" class="form-control" id="Fechanacimiento" name="Fechanacimiento" value="<?php echo $row['Fechanacimiento']; ?>">
                        <small>Error message</small>
                      </div>

                      <div class="col col-sm-4 formu-control">
                         <label for="sexo" class="form-label">Sexo</label>
                        <select name="sexo" class="form-select" id="sexo">
                          <option value="<?php echo $row['sexo']; ?>" selected ><?php echo $row['sexo']; ?></option>
                          <option value="m">Masculino</option>
                          <option value="f">Femenino</option>
                          <option value="o">Otro</option>
                        </select>
                        <small>Error message</small>
                      </div>

                      <div class="col col-sm-4 formu-control">
                         <label for="std-civil" class="form-label">Estado Civil</label>
                        <select name="estadocivil" class="form-select" id="estadocivil">
                          <option value="<?php echo $row['estadocivil']; ?>" selected ><?php echo $row['estadocivil']; ?></option>
                          <option value="casado">casado</option>
                          <option value="soltero">soltero</option>
                         
                        </select>
                        <small>Error message</small>
                      </div>

                    </div>

                  <!-- FECHA - SEXO</!--->
                  <!-- IMAGEN</!--->

                    <div class="row mb-4 formu-control">
                      <div class="col col-sm-12">
                        <label for="img-trb" class="form-label">Seleccione una imagen de Perfil</label>
                        <input type="file" class="form-control" id="Fotopersona" name="Fotopersona" value="<?php echo $row['Fotopersona']; ?>" >
                        <small>Error message</small>
                      </div>
                    </div>

                  <!-- IMAGEN</!--->
                  <!--  NUMEROS TELEFONICOS </!--->

                    <div class="row mb-4 ">
                      <div class="col sm-6 formu-control">
                        <label for="n-principal" class="form-label">Numero Principal</label>
                        <input type="number" class="form-control" id="Telefonoprincipal" name="Telefonoprincipal" value="<?php echo $row['Telefonoprincipal']; ?>" >
                        <small>Error message</small>
                      </div>
                      <div class="col sm-6 formu-control">
                        <label for="n-habitacion" class="form-label">Numero Habitación</label>
                        <input type="number" class="form-control" id="Telefonohabitacion" name="Telefonohabitacion" value="<?php echo $row['Telefonohabitacion']; ?>">
                        <small>Error message</small>
                      </div>
                    </div>

                    <!--  NUMEROS TELEFONICOS </!--->


                    <!-- LOCALIDAD</!--->

                      <div class="row mb-4">

                        <div class="col col-sm-4 formu-control">
                          <label for="municipio" class="form-label">Municipio</label>
                          <select class="form-select" id="municipio" aria-label="Default select example">
                            <option selected>Seleccione</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                          </select>
                          <small>Error message</small>
                        </div>

                        <div class="col col-sm-4 formu-control">
                          <label for="parroquia" class="form-label">Parroquia</label>
                          <select class="form-select" id="parroquia" aria-label="Default select example">
                            <option selected>Seleccione</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                          </select>
                          <small>Error message</small>
                        </div>

                        <div class="col col-sm-4 formu-control">
                          <label for="sector" class="form-label">Sector</label>
                          <input type="text" class="form-control form-control-lg" id="sector" name="sector" value="<?php echo $row['sector']; ?>">
                          <small>Error message</small>
                        </div>
                        
                        <div class="col col-sm-12 mt-4 formu-control">
                          <label for="direccion" class="form-label">Dirección</label>
                          <input type="text" class="form-control form-control-lg" id="direccion" name="direccion" value="<?php echo $row['direccion']; ?>">
                          <small>Error message</small>
                        </div>

                      </div>

                    <!-- LOCALIDAD</!--->

                    <!--  PESO Y ESTATURA </!--->

                    <div class="row mb-4">
                      <div class="col sm-6 formu-control">
                        <label for="peso" class="form-label">Peso</label>
                        <input type="text" class="form-control" id="peso" name="peso" value="<?php echo $row['peso']; ?>">
                      </div>
                      <div class="col sm-6 formu-control">
                        <label for="estatura" class="form-label">Estatura</label>
                        <input type="text" class="form-control" id="estatura" name="estatura" value="<?php echo $row['estatura']; ?>">
                        <small>Error message</small>
                      </div>
                    </div>

                    <!--  PESO Y ESTATURA </!--->

                    <!--  TALLAS</!--->

                      <div class="row mb-4">
                        
                        <div class="col sm-4 formu-control">
                          <label for="camisa" class="form-label">Talla Camisa</label>
                          <input type="text" class="form-control" id="tallacamisa" name="tallacamisa" value="<?php echo $row['tallacamisa']; ?>">
                          <small>Error message</small>
                        </div>

                        <div class="col sm-4 formu-control">
                          <label for="pantalon" class="form-label">Talla Pantalón</label>
                          <input type="text" class="form-control" id="tallapantalon" name="tallapantalon" value="<?php echo $row['tallapantalon']; ?>">
                          <small>Error message</small>
                        </div>

                        <div class="col sm-4 formu-control">
                          <label for="calzado" class="form-label">Talla Calzado</label>
                          <input type="text" class="form-control" id="tallacalzado" name="tallacalzado" value="<?php echo $row['tallacalzado']; ?>">
                          <small>Error message</small>
                        </div>

                      </div>

                    <!--  TALLAS</!--->


                  </div>

                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-primary" name="modificar">Guardar Cambios</button>
                  </div>

                </div>
              </div>
            </div>
          </div>

        </div>

        </form>

         <?php } mysqli_free_result($resultado); ?>

      </div>
      <!-- TAB-PERFIL  -->
      <!-- TAB-DOCUMENTOS  -->
      <div class="articulo tab-pane fade" id="nav-documentos" role="tabpanel" aria-labelledby="nav-documentos-tab">
        
          <div class="row">
            
            <div class="col col-sm-12 d-block justify-content-center">
                
               <table class="table">
                   <tr>
                     <td>nombre documento</td>
                     <td>fotodocumento</td>
                   </tr>


             <?php $resultado2 = mysqli_query($conn, $documentos);

              while ($row=mysqli_fetch_assoc($resultado2)) { ?>

                <input type="hidden" value="<?php echo $row['Cedulapersona']; ?>" name="id">

                <tr>
                  <td><?php echo $row['Nombredocumento']; ?></td>
                  <td> <img class="documentosimages" src="../controlador/imagenes/<?php echo $row['fotodocumento']; ?>"> </td>
                </tr>

                <?php } mysqli_free_result($resultado2); ?>
                </table>

            </div>

          </div>

          <div class="row">
            
            <div class="col d-flex justify-content-end col-sm-12">

             <button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-registrar-documentos">
              Añadir Documentos
            </button>

           </div>

          </div>

            <!-- Modal -->
            <div class="modal fade" id="modal-registrar-documentos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-xl">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Registro de Documento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">
                      

                      <div class="col col-sm-6">

                        <select class="form-select" aria-label="Default select example">
                          <option selected>Seleccione el Tipo de Documento</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </select>
                      </div>

                      <div class="col col-sm-6">

                        <div class="mb-3">
                          <input class="form-control" type="file" id="formFileMultiple" multiple>
                        </div>

                      </div>

                    </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-primary">Guardar</button>
                  </div>
                </div>
              </div>
            </div>

            <a href="../controlador/reportes.php?id=<?php echo $id = $_GET['id']; ?>">descargar todos los documentos</a>
            <!--<a href="../vista/manejo-trabajador.php?id='. $row['Cedulapersona'] .' ">ver</a>-->

      </div>
       
      <!-- TAB-DOCUMENTOS  -->
      <!-- TAB-HISTORICO  -->
      <div class="articulo tab-pane fade" id="nav-historico" role="tabpanel" aria-labelledby="nav-historico-tab">
       
        <div class="col col-sm-12 d-block justify-content-center">
                
              <table class="table">
                   <tr>
                     <td>institucion</td>
                     <td>cargo</td>
                     <td>fecha inicio</td>
                     <td>fecha culminacion</td>
                   </tr>


             <?php $resultado4 = mysqli_query($conn, $historicos);

              while ($row=mysqli_fetch_assoc($resultado4)) { ?>

                <input type="hidden" value="<?php echo $row['Cedulapersona']; ?>" name="id">

                <tr>
                  <td><?php echo $row['institucionhistorico']; ?></td>
                  <td><?php echo $row['cargohistorico']; ?></td>
                  <td><?php echo $row['fechainiciohistorico']; ?></td>
                  <td><?php echo $row['fechaculminacionhistotico']; ?></td>
                </tr>

                <?php } mysqli_free_result($resultado4); ?>
                </table>

        </div> 

        <!-- Button de modal -->
          <div class="col col-sm-12 d-flex justify-content-end">
            
            <button type="button" class="btn btn-primary d-flex justify-content-center" data-bs-toggle="modal" data-bs-target="#registro-historico">
              Registrar Historial
            </button>

          </div>

          <!-- Modal -->
          <div class="modal fade " id="registro-historico" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl">
              <div class="modal-content">
                <div class="modal-header" style="background-color: #e3f2fd;">
                  <h5 class="modal-title" id="exampleModalLabel">Nuevo Registro Historico</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  
                  <div class="row mb-4">
                    
                    <div class="col col-sm-6">
                      <label for="institucion" class="form-label">Institución</label>
                        <select class="form-select" id="institucion" aria-label="Seleccione">
                          <option selected>Seleccione</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </select>
                    </div>

                    <div class="col col-sm-6">
                      <label for="cargo" class="form-label">Cargo</label>
                        <select class="form-select" id="cargo" aria-label="Seleccione">
                          <option selected>Seleccione</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </select>
                    </div>

                  </div>
                  <div class="row mb-4">
                    
                    <div class="col col-sm-6">
                      <label for="fecha-inicio" class="form-label">Fecha de Inicio</label>
                      <input type="date" class="form-control" id="fecha-inicio">
                    </div>
                    <div class="col col-sm-6">
                      <label for="fecha-culminacion" class="form-label">Fecha de Culminación</label>
                      <input type="date" class="form-control" id="fecha-culminacion">
                    </div>

                  </div>
                   <div class="col col-sm-12 mt-4">
                    <label for="observacion" class="form-label">Observación</label>
                    <input type="text" class="form-control form-control-lg" id="observacion">
                  </div>  

                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                  <button type="button" class="btn btn-primary">Guardar</button>
                </div>
              </div>
            </div>
          </div>

      </div>
      <!-- TAB-HISTORICO  -->
      <!-- TAB-FAMILIARES  -->
      <div class="articulo tab-pane fade" id="nav-familiares" role="tabpanel" aria-labelledby="nav-familiares-tab">

        <div class="col col-sm-12 d-block justify-content-center">
                
                             <table class="table">
                   <tr>
                     <td>parentesci</td>
                     <td>nombre</td>
                   </tr>


             <?php $resultado3 = mysqli_query($conn, $familias);

              while ($row=mysqli_fetch_assoc($resultado3)) { ?>

                <input type="hidden" value="<?php echo $row['Cedulapersona']; ?>" name="id">

                <tr>
                  <td><?php echo $row['parentesco']; ?></td>
                  <td><?php echo $row['nombrefam']; ?></td>
                </tr>

                <?php } mysqli_free_result($resultado3); ?>
                </table>

        </div>

        <div class="col col-sm-12 d-flex justify-content-end">
            
            <button type="button" class="btn btn-primary d-flex justify-content-center" data-bs-toggle="modal" data-bs-target="#registro-familiar">
              Registrar Familiar
            </button>

        </div>

        <!-- Modal -->
          <div class="modal fade " id="registro-familiar" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl">
              <div class="modal-content">
                <div class="modal-header" style="background-color: #e3f2fd;">
                  <h5 class="modal-title" id="exampleModalLabel">Registrar Nuevo Familiar</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                  <div class="row mb-4">
                    
                    <div class="col col-sm-6">
                      <div class="form-check d-flex justify-content-center mt-4">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                          No posee Cédula
                        </label>
                      </div>
                    </div>
                    <div class="col col-sm-6">
                      <label for="parentesco" class="form-label">Parentesco</label>
                          <select name="parentesco" class="form-select" id="parentesco">
                            <option selected disabled="">Seleccione</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                          </select>
                    </div>

                  </div>


                  <!--  CEDULA - NOMBRE Y APELLIDO</!--->

                    <div class="row mb-4">

                      <div class="col col-sm-4">
                        <label for="cedula" class="form-label">Cédula</label>
                        <input type="number" class="form-control" id="cedula">
                      </div>

                       <div class="col col-sm-4">
                        <label for="nombres" class="form-label">Nombres</label>
                        <input type="text" class="form-control" id="nombres">
                      </div>

                       <div class="col col-sm-4">
                        <label for="apellidos" class="form-label">Apellidos</label>
                        <input type="text" class="form-control" id="apellidos">
                      </div>

                    </div>

                  <!--  CEDULA - ESTADO CIVIL</!--->

                  <!-- FECHA - SEXO</!--->

                    <div class="row mb-4">

                      <div class="col col-sm-4">
                        <label for="fecha-nac" class="form-label">Fecha de Nacimiento</label>
                        <input type="date" class="form-control" id="fecha-nac">
                      </div>

                      <div class="col col-sm-4">
                         <label for="sexo" class="form-label">Sexo</label>
                        <select name="sexo" class="form-select" id="sexo">
                          <option selected disabled="">Seleccione</option>
                          <option value="m">Masculino</option>
                          <option value="f">Fsemenino</option>
                          <option value="o">Otro</option>
                        </select>
                      </div>

                      <div class="col col-sm-4">
                         <label for="std-civil" class="form-label">Estado Civil</label>
                          <select name="std-civil" class="form-select" id="std-civil">
                            <option selected disabled="">Seleccione</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                          </select>
                      </div>

                    </div>

                  <!-- FECHA - SEXO</!--->
                  <!--  NUMEROS TELEFONICOS </!--->

                    <div class="row mb-4">
                      <div class="col sm-6">
                        <label for="n-principal" class="form-label">Numero Principal</label>
                        <input type="number" class="form-control" id="n-principal">
                      </div>
                      <div class="col sm-6">
                        <label for="n-habitacion" class="form-label">Numero Habitación</label>
                        <input type="number" class="form-control" id="n-habitacion">
                      </div>
                    </div>

                    <!--  NUMEROS TELEFONICOS </!--->


                    <!-- LOCALIDAD</!--->

                      <div class="row mb-4">
                        
                        <div class="col col-sm-12 ">
                          <label for="direccion" class="form-label">Dirección</label>
                          <input type="text" class="form-control form-control-lg" id="direccion">
                        </div>

                      </div>

                    <!-- LOCALIDAD</!--->

                    <!--  PESO Y ESTATURA </!--->

                    <div class="row mb-4">
                      <div class="col sm-6">
                        <label for="peso" class="form-label">Peso</label>
                        <input type="text" class="form-control" id="peso">
                      </div>
                      <div class="col sm-6">
                        <label for="estatura" class="form-label">Estatura</label>
                        <input type="text" class="form-control" id="estatura">
                      </div>
                    </div>

                    <!--  PESO Y ESTATURA </!--->

                    <!--  TALLAS</!--->

                      <div class="row mb-4">
                        
                        <div class="col sm-4">
                          <label for="camisa" class="form-label">Talla Camisa</label>
                          <input type="text" class="form-control" id="camisa">
                        </div>

                        <div class="col sm-4">
                          <label for="pantalon" class="form-label">Talla Pantalón</label>
                          <input type="text" class="form-control" id="pantalon">
                        </div>

                        <div class="col sm-4">
                          <label for="calzado" class="form-label">Talla Calzado</label>
                          <input type="text" class="form-control" id="calzado">
                        </div>

                      </div>

                    <!--  TALLAS</!--->

                  </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                  <button type="button" class="btn btn-primary">Guardar</button>
                </div>
              </div>
            </div>
          </div>

      </div>
      <!-- TAB-FAMILIARES  -->
    </div>

    <!--  CONTENIDO  -->


            <div class="modal fade" id="modalregistrarexitoso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>registro existoso</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                   

                  </div>
                </div>
              </div>
            </div>


<!-- modal seguir  -->

<div class="modal fade" id="modalregistrarrellenecampos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>rellener todos los campos</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" name="Guardard" class="btn btn-primary">Guardar</button>

                  </div>
                </div>
              </div>
            </div>


<div class="modal fade" id="modaledad" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>no se puede registrar menores de edad, debe tener 18 anios</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" name="Guardard" class="btn btn-primary">Guardar</button>

                  </div>
                </div>
              </div>
            </div>

<!-- modal seguir  -->

<!-- modal registro exitoso  -->

<div class="modal fade" id="modalregistrexitosopersona" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>registro actualizado exitoso</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="submit" name="Guardard" class="btn btn-primary">registrar documentos</button>-->
                    
                  </div>
                </div>
              </div>
            </div>



        
        <script src="jquery.min.js"></script>
 <script src="manejotrabajador.js"></script>



  </body>

  </html>