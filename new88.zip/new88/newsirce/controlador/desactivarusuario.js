jQuery(document).on('submit','#formdesactivarusuario', function(event){
	event.preventDefault();

	
	let cedulauser = localStorage.getItem("localstorcedulausuario");
	//console.log(cedulauser);

	document.getElementById("idoffuser").value = cedulauser;

jQuery.ajax({
	url: '../controlador/desactivarusuario.php',
	type: 'POST',
	dataType: 'json',
	data: $(this).serialize(),
	beforeSend: function () {
		// body...

	}
})
.done(function (respuesta) {
	// body...
	console.log(respuesta);


$('#modaloffuser').modal("show");

	



})
.fail(function (resp) {
	// body...
	//console.log(resp.responseText);
	
	
})
.always(function () {
	// body...
	console.log("complete");
});



});


