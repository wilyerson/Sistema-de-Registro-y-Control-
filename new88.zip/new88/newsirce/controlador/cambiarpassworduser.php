<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

   
    $nameuserr = $_SESSION["usuarioad"];
    $cambiarpass = $_POST['passuser'];
   
    


    

         $actualizar = "UPDATE usuarios SET passwordusuario='$cambiarpass' WHERE nombreusuario ='$nameuserr' ";


         $resultado = mysqli_query($conn,$actualizar);
         if($resultado == 1){
               

             //$query = "INSERT INTO documento(Nombredocumento) values('$datosp[15]')";
              echo "Registrado";
             //$resultado2 = mysqli_query($conn,$query);

         }else{
          echo "error error";
            // $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
             //$_SESSION['tipo'] = 'danger';
         }


       
    

?>