jQuery(document).on('submit','#buscarformulariomodificaruser', function(event){
	event.preventDefault();

	

jQuery.ajax({
	url: '../controlador/buscarmodificarusuario.php',
	type: 'POST',
	dataType: 'json',
	data: $(this).serialize(),
	beforeSend: function () {
		// body...
checkInputs2222();
	}
})
.done(function (respuesta) {
	// body...
	console.log(respuesta);


	if (!respuesta.error) {
	
			//location.href = 'vista/bienvenida.php';
			//alert("usuario esta activo");
			$('#modalmodificaruser').modal("show");
			console.log("sirve");
		
	}else {
		
		if (respuesta.error === true && checkInputs2222() === 5) {
			$('#modalusuarionoesta').modal("show");
		}
		
		}
})
.fail(function (resp) {
	// body...
	//console.log(resp.responseText);
	
	
})
.always(function () {
	// body...
	console.log("complete");
});



});


function checkInputs2222() {

const form = document.getElementById('buscarformulariomodificaruser');
const usuario = document.getElementById('buscarmodificarcedula');


  let prueba;
  let prueba2;
  let checkcedula = 2;
  let checknombre = 2;
  let checkdireccion = 2;
  // trim to remove the whitespaces
  //const cedulaValue = cedula.value.trim();
  const usuarioValue = usuario.value.trim();
  

  //const passwordValue = password.value.trim();
  // password2Value = password2.value.trim();
  
  if(usuarioValue === '') {
    
    setErrorFor(usuario, 'No puede dejar la cedula en blanco');
  } else {
    
    setSuccessFor(usuario);
  }


if (usuarioValue === '' ) 
{

//alert("campos vacios");
	$('#modalregistrarrellenecampos2').modal("show");
	/*var myModal = new bootstrap.Modal(document.getElementById('modalregistrarrellenecampos'), {
  keyboard: false
})

	myModal.show();*/
prueba = 2;

return 2;
}else{

	//$('#modalregistrarrellenecampos').modal("hidden");

  //todos los campos llenos
  prueba = 5;
  return 5;
}

/*if (checkcedula === 5 && checknombre  === 5 && checkdireccion === 5) {

 //todo esta validado
prueba2 = 5;

}else{
  //algo no esta validado

  prueba2 = 2;

}*/

//console.log(prueba2);

/*if (prueba === 5) {
  return 5;
}else{
  return 2;
}*/

}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector('small');
  formControl.className = 'formu-control error';
  small.innerText = message;
  prueba = 2;
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.className = 'formu-control success';
  //prueba = 12;
}
