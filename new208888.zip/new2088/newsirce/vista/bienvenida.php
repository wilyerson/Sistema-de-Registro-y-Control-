<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bienvenido(a)</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
  

   <style>

      #zonanombreusuario{
        box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
    -moz-box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
  }

    </style>


</head>
<body class="bg-light">

    <?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>

 <?php include"componentes/nav.php" ?>

  <div class="container rounded border py-3 bg-white" id="zonanombreusuario" 
        style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;">

    <h5>Bienvenido(a): <?php echo strtoupper($_SESSION['usuarioad']);?> </h5>      

  </div>

</body>
</html>