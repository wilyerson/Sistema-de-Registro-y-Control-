jQuery(document).on('submit','#formbusqueda', function(event){
	event.preventDefault();

	

jQuery.ajax({
	url: '../controlador/controlusuariosistema.php',
	type: 'POST',
	dataType: 'json',
	data: $(this).serialize(),
	beforeSend: function () {
		// body...
checkInputs();
	}
})
.done(function (respuesta) {
	// body...
	console.log(respuesta);
	if (!respuesta.error) {
			console.log("hola");
			$('#asignar-rol').modal("show");

							guardarusuario_localstorage();

function guardarusuario_localstorage(){

  let nombreusuario = respuesta.tipo;

localStorage.setItem('nombreusuariostorage', nombreusuario);
  
}


	}else {
		
		console.log("no esta usuario")

			$('#modalusuarionoesta').modal("show");
		
		 localStorage.removeItem('nombreusuariostorage');
		}
})
.fail(function (resp) {
	// body...
	//console.log(resp.responseText);
	
	
})
.always(function () {
	// body...
	console.log("complete");
});



});




          function checkInputs() {

const form = document.getElementById('formulogine');
const buscar = document.getElementById('buscarcedu');


  let prueba;
  let prueba2;
  let checkcedula = 2;
  let checknombre = 2;
  let checkdireccion = 2;

  const buscarValue = buscar.value.trim();
  //const passwordValue = password.value.trim();

  
  if(buscarValue === '') {
    
    setErrorFor(buscar, 'No puede dejar la talla de pantalon en blanco');
  } else {
    
    setSuccessFor(buscar);
  }



if (buscarValue === '' ) 
{


  $('#modalregistrarrellenecampos').modal("show");

prueba = 2;

return 2;
}else{

  //todos los campos llenos
  prueba = 5;
  return 5;
}


}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector('small');
  formControl.className = 'input-group formu-control error';
  small.innerText = message;
  prueba = 2;
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.className = 'input-group formu-control success';
  //prueba = 12;
}