jQuery(document).on('submit','#formulariomodificarusuario', function(event){
	event.preventDefault();

	
	let cedulamodificaruser = localStorage.getItem("usercedulakey");
	console.log(cedulamodificaruser);

	document.getElementById("usercedulauser").value = cedulamodificaruser;

jQuery.ajax({
	url: '../controlador/modificarusuario.php',
	type: 'POST',
	dataType: 'json',
	data: $(this).serialize(),
	beforeSend: function () {
		// body...

	}
})
.done(function (respuesta) {
	// body...
	console.log(respuesta);


//$('#modaloffuser').modal("show");

	



})
.fail(function (resp) {
	// body...
	//console.log(resp.responseText);
	
	
})
.always(function () {
	// body...
	console.log("completemodificar");
});



});
