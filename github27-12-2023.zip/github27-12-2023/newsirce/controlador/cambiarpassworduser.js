jQuery(document).on('submit','#formcambiarcontraseñauser', function(event){
	event.preventDefault();

	
	let nameuserr = localStorage.getItem("nameusuario");
	//console.log(cedulauser);

	document.getElementById("nameuser").value = nameuserr;

	console.log(nameuserr);
jQuery.ajax({
	url: '../controlador/cambiarpassworduser.php',
	type: 'POST',
	dataType: 'json',
	data: $(this).serialize(),
	beforeSend: function () {
		// body...

	}
})
.done(function (respuesta) {
	// body...
	console.log(respuesta);


//$('#modaloffuser').modal("show");

	



})
.fail(function (resp) {
	// body...
	//console.log(resp.responseText);
	
	
})
.always(function () {
	// body...
	console.log("complete");
});



});
