<?php

  $conn = mysqli_connect("localhost","root","","newsirce");

  $pass = @$_POST['passwordusuario'];

$query = ("SELECT * FROM usuarios WHERE nombreusuario = '".@$_POST['nombreusuario']."'  ");


$result = mysqli_query($conn,$query);
echo "";

if (mysqli_num_rows($result) == 1){
 
  //$_SESSION["passuser"]=$_POST["passwordusuario"];
  
  $datos = $result->fetch_assoc();


if (password_verify($pass, $datos['passwordusuario'])) {
  // code...

//-------------------
 session_start();
  $_SESSION["usuarioad"]=$_POST["nombreusuario"];
  

  echo json_encode(array('error' => false, 'tipo' => $datos['rolusuario'], 'estatus' => $datos['estatususuario']));
//-----------------------------

}else{
  echo json_encode(array('error' => true));
}



}else{

   echo json_encode(array('error' => true));
}
   
 

  //$mysqli->close();
  // code...





?>