const form = document.getElementById('formuh');
const cedula = document.getElementById('Cedulapersona');
const institucionhistorico = document.getElementById('institucionhistorico');
const cargohistorico = document.getElementById('cargohistorico');
const fechainiciohistorico = document.getElementById('fechainiciohistorico');
const fechaculminacionhistotico = document.getElementById('fechaculminacionhistotico');
const observacionhistorico = document.getElementById('observacionhistorico');
const botonrecargarhistoricos = document.getElementById('botonrecargarhistoricos');
const estatuscargo = document.getElementById('estatuscargo');

obtener_localstorage();



function obtener_localstorage(){

  let cedulapersona = localStorage.getItem('cedulapersonastorage');

//console.log(cedulapersona);

return cedulapersona;
  
}

console.log(obtener_localstorage());

const inputcedula = document.getElementById("inputcedula");


inputcedula.innerHTML = '<input type="number" class="form-control inputcedulaestilo" value="'+ obtener_localstorage() +'" id="Cedulapersona" name="Cedulapersonaf">';
//inputcedula.innerHTML = obtener_localstorage();




form.addEventListener('submit', e => {
  e.preventDefault();

  


//lef frm = document.getElementById('formp');

let data = new FormData(e.currentTarget);

let request;

if (window.XMLHttpRequest) request = new XMLHttpRequest();
      else request = new ActiveXObject('Microsoft.XMLHTTP');


      request.addEventListener('load', () => {

       //console.log(data.get('Cedulapersona'));
         
        prueba = 1;
        //alert("registro exitoso");
        //window.location.href ='../registrodocumentosprincipal.php';

        document.querySelector('#institucion').value = '';
        document.querySelector('#cargohistorico').value = '';
        document.querySelector('#fechainiciohistorico').value = '';
        document.querySelector('#fechaculminacionhistotico').value = '';
        document.querySelector('#observacionhistorico').value = '';
        document.querySelector('#estatuscargo').value = '';


      });


       request.open(
        'POST',
        '../controlador/registrarhistorico.php',
        true,
        request.responseType = 'json'
      );

       if(checkInputs() === 5){
        //alert(" registra");
        $('#modalregistrarexitoso').modal("show");
        $('#registro-historico').modal("hide");
      request.send(data);
       prueba = 5;
     //window.location.href ='registrodocumentosprincipal.php';
        



     }else{
      //alert("no registra");
      $('#modalregistrarrellenecampos').modal("show");
      prueba = 5;
     }
     
checkInputs();
console.log(checkInputs());
});


function checkInputs() {
  let prueba;
  let prueba2;
  let checkcedula = 2;
  let checknombre = 2;
  let checkdireccion = 2;
  // trim to remove the whitespaces
  //const cedulaValue = cedula.value.trim();
  const institucionhistoricoValue = institucionhistorico.value.trim();
  const cargohistoricoValue = cargohistorico.value.trim();
  const fechainiciohistoricoValue = fechainiciohistorico.value.trim();
 // const fechaculminacionhistoticoValue = fechaculminacionhistotico.value.trim();
  const observacionhistoricoValue = observacionhistorico.value.trim();

  const estatuscargoValue = estatuscargo.value.trim();

  //const passwordValue = password.value.trim();
  // password2Value = password2.value.trim();
  
  if(institucionhistoricoValue === '') {
    
    setErrorFor(institucionhistorico, 'tienes que escojer una institucion');
  } else {
    
    setSuccessFor(institucionhistorico);
  }

  if(cargohistoricoValue === '') {
    
    setErrorFor(cargohistorico, 'tienes que escojer un cargo');
  } else {
    
    setSuccessFor(cargohistorico);
  }

    if(fechainiciohistoricoValue === '') {
    
    setErrorFor(fechainiciohistorico, 'tienes que escojer una fecha de inicio');
  } else {
    
    setSuccessFor(fechainiciohistorico);
  }

    /*if(fechaculminacionhistoticoValue === '') {
    
    setErrorFor(fechaculminacionhistotico, 'tienes que escojer una fecha de culminacion');
  } else {
    
    setSuccessFor(fechaculminacionhistotico);
  }*/

    if(observacionhistoricoValue === '') {
    
    setErrorFor(observacionhistorico, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(observacionhistorico);
  }

      if(estatuscargoValue === '') {
    
    setErrorFor(estatuscargo, 'no puedes dejar en blanco el estatus');
  } else {
    
    setSuccessFor(estatuscargo);
  }


if (estatuscargoValue === '' || institucionhistoricoValue === '' || cargohistoricoValue === '' || fechainiciohistoricoValue  === '' || observacionhistoricoValue === '') 
{

//alert("campos vacios");
prueba = 2;

}else{

  //todos los campos llenos
  prueba = 5;
}

if (checkcedula === 5 && checknombre  === 5 && checkdireccion === 5) {

 //todo esta validado
prueba2 = 5;

}else{
  //algo no esta validado

  prueba2 = 2;

}

//console.log(prueba2);

if (prueba === 5) {
  return 5;
}else{
  return 2;
}

}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector('small');
  formControl.className = 'col-6 col-sm-6 formu-control error';
  small.innerText = message;
  prueba = 2;
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.className = 'col-6 col-sm-6 formu-control success';
  //prueba = 12;
}


traerdatos();

          function traerdatos(){

            console.log('dentro de funcion');

            const xhttp = new XMLHttpRequest();

          xhttp.open(
          'POST',
           '../controlador/mostrarhistoricos.php',
             true
               );


          xhttp.send();

          xhttp.onreadystatechange = function()
            {

              if(this.readyState == 4 && this.status == 200)
              {

                //console.log(this.responseText);
                let datos = JSON.parse(this.responseText);
                //console.log(datos);

                
                let cuerpo = document.querySelector('#cuerpo');
                cuerpo.innerHTML ='';


                 let cedu = obtener_localstorage();

                 let pequeños = datos.filter(function(pdatos){
                  return pdatos.Cedulapersona === cedu;
                  
                });

        const botonhistorico = document.getElementById('botonirafamiliar');
        let vacioboton;

        botonhistorico.onclick = function() {

          /*if (pequeños.length === 0) 
          {
            //alert("vacio");
            $('#modalmensajeagregueundocumento').modal("show");
          }else{*/
            //alert("lleno");
            window.location.href ='registrofamiliarprincipal.php';
        /*  }*/

        }


        console.log(pequeños.length);
                
              for (let item of pequeños) {
                //console.log(item.Nombredocumento);

                cuerpo.innerHTML += `
                <tr>
                  
                  <td>${item.institucionhistorico}</td>
                  <td>${item.cargohistorico}</td>
                  <td>${item.fechainiciohistorico}</td>
                  <td>${item.fechaculminacionhistotico}</td>
                  
                </tr>
                `

              }

                

              }

            }

          }



      botonrecargarhistoricos.onclick = function() {

        window.location.href ='registrohistoricoprincipal.php';
      

      }


// Get the modal
var modal2 = document.getElementById("myModal2");

// Get the button that opens the modal
var btn2 = document.getElementById("myBtn2");

// Get the <span> element that closes the modal
var span2= document.getElementsByClassName("close2")[0];

// When the user clicks the button, open the modal 
btn2.onclick = function() {
  modal2.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span2.onclick = function() {
  modal2.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal2) {
    modal2.style.display = "none";
  }
}

