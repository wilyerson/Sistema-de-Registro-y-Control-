-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-02-2023 a las 17:20:09
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `newsirce`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documento`
--

CREATE TABLE `documento` (
  `coddocumento` int(11) NOT NULL,
  `Cedulapersona` int(15) NOT NULL,
  `Nombredocumento` text NOT NULL,
  `fotodocumento` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `documento`
--

INSERT INTO `documento` (`coddocumento`, `Cedulapersona`, `Nombredocumento`, `fotodocumento`) VALUES
(1, 5, 'd2', 'Screenshot8888.jpg'),
(2, 5, 'd3', 'copy.jpg'),
(3, 5, 'd1', 'Screenshot8888.jpg'),
(4, 238887878, 'd1', '6aofsvaglm_Medium_WW226365.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `familia`
--

CREATE TABLE `familia` (
  `codfamilia` int(11) NOT NULL,
  `Cedulapersona` int(11) NOT NULL,
  `checkcedufami` varchar(5) NOT NULL,
  `parentesco` varchar(30) NOT NULL,
  `cedulafam` int(15) NOT NULL,
  `nombrefam` varchar(30) NOT NULL,
  `apellidofam` varchar(30) NOT NULL,
  `fechanacimientofam` date NOT NULL,
  `sexofam` varchar(15) NOT NULL,
  `estadocivilfam` varchar(30) NOT NULL,
  `telefonoprincipalfam` varchar(30) NOT NULL,
  `telefonohabitacionfam` varchar(30) NOT NULL,
  `direccionfam` text NOT NULL,
  `pesofam` double NOT NULL,
  `estaturafam` double NOT NULL,
  `tallacamisafam` varchar(15) NOT NULL,
  `tallapantalonfam` varchar(15) NOT NULL,
  `tallacalzadofam` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `familia`
--

INSERT INTO `familia` (`codfamilia`, `Cedulapersona`, `checkcedufami`, `parentesco`, `cedulafam`, `nombrefam`, `apellidofam`, `fechanacimientofam`, `sexofam`, `estadocivilfam`, `telefonoprincipalfam`, `telefonohabitacionfam`, `direccionfam`, `pesofam`, `estaturafam`, `tallacamisafam`, `tallapantalonfam`, `tallacalzadofam`) VALUES
(6, 5, '', 'hijo', 24574, '', '', '0000-00-00', '', '', '', '', '', 0, 0, '', '', ''),
(14, 5, '', 'esposa', 6767, '', '', '0000-00-00', '', '', '', '', '', 0, 0, '', '', ''),
(15, 5, '', 'hijo', 2222, '', '', '0000-00-00', '', '', '', '', '', 0, 0, '', '', ''),
(16, 5, 'on', 'hijo', 0, '', '', '0000-00-00', '', '', '', '', '', 0, 0, '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historico`
--

CREATE TABLE `historico` (
  `codhistorico` int(11) NOT NULL,
  `Cedulapersona` int(15) NOT NULL,
  `institucionhistorico` varchar(30) NOT NULL,
  `cargohistorico` varchar(30) NOT NULL,
  `fechainiciohistorico` date NOT NULL,
  `fechaculminacionhistotico` date NOT NULL,
  `observacionhistorico` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `historico`
--

INSERT INTO `historico` (`codhistorico`, `Cedulapersona`, `institucionhistorico`, `cargohistorico`, `fechainiciohistorico`, `fechaculminacionhistotico`, `observacionhistorico`) VALUES
(1, 5, '2', '2', '2023-02-02', '2023-02-08', 'wiiiiiiiiiiiiiiii'),
(2, 5, '1', '3', '2023-02-02', '2023-02-14', 'weeeeee'),
(3, 5, '2', '2', '2023-02-01', '2023-02-08', 'kk');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `Cedulapersona` int(15) NOT NULL,
  `estadocivil` varchar(30) NOT NULL,
  `Fotopersona` text NOT NULL,
  `Nombres` varchar(30) NOT NULL,
  `Apellidos` varchar(30) NOT NULL,
  `Fechanacimiento` date NOT NULL,
  `sexo` varchar(15) NOT NULL,
  `Telefonoprincipal` varchar(30) NOT NULL,
  `Telefonohabitacion` varchar(30) NOT NULL,
  `direccion` text NOT NULL,
  `peso` double NOT NULL,
  `estatura` double NOT NULL,
  `tallacamisa` varchar(15) NOT NULL,
  `tallapantalon` varchar(15) NOT NULL,
  `tallacalzado` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`Cedulapersona`, `estadocivil`, `Fotopersona`, `Nombres`, `Apellidos`, `Fechanacimiento`, `sexo`, `Telefonoprincipal`, `Telefonohabitacion`, `direccion`, `peso`, `estatura`, `tallacamisa`, `tallapantalon`, `tallacalzado`) VALUES
(2, '', 'wild-lion-face-chadi-el-hanchi.jpg', '', '', '0000-00-00', '', '', '', '', 0, 0, '', '', ''),
(5, '1', 'Screenshot8888.jpg', '', '', '0000-00-00', '', '', '', '', 0, 0, '', '', ''),
(12345678, 'casado', '6aofsvaglm_Medium_WW226365.jpg', 'ertert', 'ertertert', '2007-05-04', 'm', '756756756', '756756756', 'ertwerrtwertwer', 7, 7, '7', '7', '7'),
(238887878, '1', 'Screenshot8888.jpg', 'juan', 'lilis', '2023-02-08', '', '545787', '878484', 'miami', 7, 7, '7', '7', '7');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `documento`
--
ALTER TABLE `documento`
  ADD PRIMARY KEY (`coddocumento`),
  ADD KEY `Cedulapersona` (`Cedulapersona`);

--
-- Indices de la tabla `familia`
--
ALTER TABLE `familia`
  ADD PRIMARY KEY (`codfamilia`),
  ADD KEY `Cedulapersona` (`Cedulapersona`);

--
-- Indices de la tabla `historico`
--
ALTER TABLE `historico`
  ADD PRIMARY KEY (`codhistorico`),
  ADD KEY `Cedulapersona` (`Cedulapersona`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`Cedulapersona`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `documento`
--
ALTER TABLE `documento`
  MODIFY `coddocumento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `familia`
--
ALTER TABLE `familia`
  MODIFY `codfamilia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `historico`
--
ALTER TABLE `historico`
  MODIFY `codhistorico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `documento`
--
ALTER TABLE `documento`
  ADD CONSTRAINT `documento_ibfk_1` FOREIGN KEY (`Cedulapersona`) REFERENCES `persona` (`Cedulapersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `familia`
--
ALTER TABLE `familia`
  ADD CONSTRAINT `familia_ibfk_1` FOREIGN KEY (`Cedulapersona`) REFERENCES `persona` (`Cedulapersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `historico`
--
ALTER TABLE `historico`
  ADD CONSTRAINT `historico_ibfk_1` FOREIGN KEY (`Cedulapersona`) REFERENCES `persona` (`Cedulapersona`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
