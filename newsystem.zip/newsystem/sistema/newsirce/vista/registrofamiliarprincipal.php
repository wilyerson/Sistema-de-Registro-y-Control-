<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

//$id = $_GET['id'];
//$usuarios = "SELECT * FROM persona WHERE idpersona = '$id'";


?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="estiloregistropersona.css" rel="stylesheet" type="text/css"/>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }
      .linka{
        color: black;
      }
    </style>
  
</head>
<body>

<form action="../controlador/controladorregistratrabajador.php" method="post" enctype="multipart/form-data">

    <nav class="navbar navbar-light fixed-top" style="background-color: #e3f2fd;">
      <div class="container-fluid menumenu">

         <button  id="botoninicio" > <a id="textatras" href="inicio.php">Atras</a>  </button>

 

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Nombre Usuario</h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Inicio</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Cambiar Nombre de Usuario</a></li>
                <li><a class="dropdown-item" href="#">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="#">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!--  CONTENIDO  -->

   
      <!-- TAB-FAMILIARES  -->
      <div class="articulo tab-pane " id="nav-familiares" role="tabpanel" aria-labelledby="nav-familiares-tab">

        <div class="col col-sm-12 d-block justify-content-center">
                
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Parentesco</th>
                    <th scope="col">Nombres</th>
                    <th scope="col">Apellidos</th>
                    <th scope="col">Edad</th>
                    <th scope="col"><img src="../icons/buscar.png" width="20px"></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Mark</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                  <tr>
                    <td>Jacob</td>
                    <td>@fat</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                  <tr>
                    <td>Larry the Bird</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                </tbody>
              </table>

        </div>

        <div class="col col-sm-12 d-flex justify-content-end">
            
            <button type="button" class="btn btn-primary d-flex justify-content-center" data-bs-toggle="modal" data-bs-target="#registro-familiar">
              Registrar Familiar
            </button>

        </div>

        <!-- Modal -->
          <div class="modal fade " id="registro-familiar" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl">
              <div class="modal-content">
                <div class="modal-header" style="background-color: #e3f2fd;">
                  <h5 class="modal-title" id="exampleModalLabel">Registrar Nuevo Familiar</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                  <form action="../controlador/registrofamiliar.php" method="post" enctype="multipart/form-data">


                  <div class="row mb-4">

                     <div class="col col-sm-6">
                     <label for="cedula" class="form-label">Cedula</label>
                      <input type="number" class="form-control" id="cedula" name="Cedulapersonaf">
                      </div>
                    
                    <div class="col col-sm-6">
                      <div class="form-check d-flex justify-content-center mt-4">
                        <input class="form-check-input" type="checkbox" name="checkcedufami" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                          No posee Cédula
                        </label>
                      </div>
                    </div>
                    <div class="col col-sm-6">
                      <label for="parentesco" class="form-label">Parentesco</label>
                          <select name="parentesco" class="form-select" id="parentesco">
                            <option selected disabled="">Seleccione</option>
                            <option value="hijo">hijo</option>
                            <option value="esposa">esposa</option>
                            <option value="esposo">esposo</option>
                            <option value="sobrino">sobrino</option>
                          </select>
                    </div>

                  </div>


                  <!--  CEDULA - NOMBRE Y APELLIDO</!--->

                    <div class="row mb-4">

                      <div class="col col-sm-4">
                        <label for="cedula" class="form-label">Cédula</label>
                        <input type="number" name="cedulafam" class="form-control" id="cedula">
                      </div>

                       <div class="col col-sm-4">
                        <label for="nombres" class="form-label">Nombres</label>
                        <input type="text" name="nombrefam" class="form-control" id="nombres">
                      </div>

                       <div class="col col-sm-4">
                        <label for="apellidos" class="form-label">Apellidos</label>
                        <input type="text" name="apellidofam" class="form-control" id="apellidos">
                      </div>

                    </div>

                  <!--  CEDULA - ESTADO CIVIL</!--->

                  <!-- FECHA - SEXO</!--->

                    <div class="row mb-4">

                      <div class="col col-sm-4">
                        <label for="fecha-nac" class="form-label">Fecha de Nacimiento</label>
                        <input type="date" name="fechanacimientofam" class="form-control" id="fecha-nac">
                      </div>

                      <div class="col col-sm-4">
                         <label for="sexo" class="form-label">Sexo</label>
                        <select name="sexofam" class="form-select" id="sexo">
                          <option selected disabled="">Seleccione</option>
                          <option value="m">Masculino</option>
                          <option value="f">Fsemenino</option>
                          <option value="o">Otro</option>
                        </select>
                      </div>

                      <div class="col col-sm-4">
                         <label for="std-civil" class="form-label">Estado Civil</label>
                          <select name="estadocivilfam" class="form-select" id="std-civil">
                            <option selected disabled="">Seleccione</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                          </select>
                      </div>

                    </div>

                  <!-- FECHA - SEXO</!--->
                  <!--  NUMEROS TELEFONICOS </!--->

                    <div class="row mb-4">
                      <div class="col sm-6">
                        <label for="n-principal" class="form-label">Numero Principal</label>
                        <input type="number" name="telefonoprincipalfam" class="form-control" id="n-principal">
                      </div>
                      <div class="col sm-6">
                        <label for="n-habitacion" class="form-label">Numero Habitación</label>
                        <input type="number" name="telefonohabitacionfam" class="form-control" id="n-habitacion">
                      </div>
                    </div>

                    <!--  NUMEROS TELEFONICOS </!--->


                    <!-- LOCALIDAD</!--->

                      <div class="row mb-4">
                        
                        <div class="col col-sm-12 ">
                          <label for="direccion" class="form-label">Dirección</label>
                          <input type="text" name="direccionfam" class="form-control form-control-lg" id="direccion">
                        </div>

                      </div>

                    <!-- LOCALIDAD</!--->

                    <!--  PESO Y ESTATURA </!--->

                    <div class="row mb-4">
                      <div class="col sm-6">
                        <label for="peso" class="form-label">Peso</label>
                        <input type="text" name="pesofam" class="form-control" id="peso">
                      </div>
                      <div class="col sm-6">
                        <label for="estatura" class="form-label">Estatura</label>
                        <input type="text" name="estaturafam" class="form-control" id="estatura">
                      </div>
                    </div>

                    <!--  PESO Y ESTATURA </!--->

                    <!--  TALLAS</!--->

                      <div class="row mb-4">
                        
                        <div class="col sm-4">
                          <label for="camisa" class="form-label">Talla Camisa</label>
                          <input type="text" name="tallacamisafam" class="form-control" id="camisa">
                        </div>

                        <div class="col sm-4">
                          <label for="pantalon" class="form-label">Talla Pantalón</label>
                          <input type="text" name=" tallapantalonfam" class="form-control" id="pantalon">
                        </div>

                        <div class="col sm-4">
                          <label for="calzado" class="form-label">Talla Calzado</label>
                          <input type="text" name="tallacalzadofam" class="form-control" id="calzado">
                        </div>

                      </div>

                    <!--  TALLAS</!--->

                  </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                  <button type="submit" name="Guardarfamilia" class="btn btn-primary">Guardar</button>

                </div>
                </form>
              </div>

            </div>

          </div>


      </div>
     
      <!-- TAB-FAMILIARES  -->

    </div>

    <!--  CONTENIDO  -->
 
  </body>
  </html>