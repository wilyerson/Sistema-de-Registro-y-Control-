<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

//$id = $_GET['id'];
//$usuarios = "SELECT * FROM persona WHERE idpersona = '$id'";


session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="estiloregistropersona.css" rel="stylesheet" type="text/css"/>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }
      .linka{
        color: black;
      }
    </style>
  
</head>
<body>

    <nav class="navbar navbar-light fixed-top" style="background-color: #e3f2fd;">
      <div class="container-fluid menumenu">

         <button  id="botoninicio" > <a id="textatras" href="inicio.php">Atras</a>  </button>

 

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Nombre Usuario</h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Inicio</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Cambiar Nombre de Usuario</a></li>
                <li><a class="dropdown-item" href="#">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="#">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!--  CONTENIDO  -->


      <!-- TAB-PERFIL  -->
      <!-- TAB-DOCUMENTOS  -->
      <div class="articulo tab-pane " id="nav-documentos" role="tabpanel" aria-labelledby="nav-documentos-tab">

        <form action="../controlador/registrardocumento.php" method="post" enctype="multipart/form-data">

        
          <div class="row">
            
            <div class="col col-sm-12 d-block justify-content-center">

              
                
              <table class="table">

              </table>

            </div>

          </div>

          <div class="row">
            
            <div class="col d-flex justify-content-end col-sm-12">

              <div class="col-sm-12">
                <a href="registrohistoricoprincipal.php">ir a historico</a>
                 <!-- <button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" >
              
              </button>-->

              </div>


             <button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-registrar-documentos">
              Añadir Documentos
            </button>

           </div>
           

          </div>

            <!-- Modal -->
            <div class="modal fade" id="modal-registrar-documentos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-xl">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Registro de Documento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                       <div class="col col-sm-6">
                     <label for="cedula" class="form-label">Cedula</label>
                      <input type="number" class="form-control" id="cedula" name="Cedulapersonad">
                      </div>
                      

                      <div class="col col-sm-6">

                        <select name="Nombredocumento" class="form-select" aria-label="Default select example">
                          <option selected>Seleccione el Tipo de Documento</option>
                          <option value="d1">d1</option>
                          <option value="d2">d2</option>
                          <option value="d3">d3</option>
                        </select>
                      </div>

                      <div class="col col-sm-6">

                        <div class="mb-3">
                          <input class="form-control" name="fotodocumento" type="file" id="formFileMultiple" multiple>
                        </div>

                      </div>

                    </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" name="Guardard" class="btn btn-primary">Guardar</button>

                  </div>
                </div>
              </div>
            </div>
            </form>
      </div>
      <!-- TAB-DOCUMENTOS  -->
      <!-- TAB-HISTORICO  -->
     

    <!--  CONTENIDO  -->
 
  </body>
  </html>