<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

//$id = $_GET['id'];
//$usuarios = "SELECT * FROM persona WHERE idpersona = '$id'";


?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="estiloregistropersona.css" rel="stylesheet" type="text/css"/>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }
      .linka{
        color: black;
      }
    </style>
  
</head>
<body>



    <nav class="navbar navbar-light fixed-top" style="background-color: #e3f2fd;">
      <div class="container-fluid menumenu">

         <button  id="botoninicio" > <a id="textatras" href="inicio.php">Atras</a>  </button>

 

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Nombre Usuario</h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Inicio</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Cambiar Nombre de Usuario</a></li>
                <li><a class="dropdown-item" href="#">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="#">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!--  CONTENIDO  -->

    
      <!-- TAB-PERFIL  -->
      
       
      <!-- TAB-DOCUMENTOS  -->
      <!-- TAB-HISTORICO  -->
      <div class="articulo tab-pane " id="nav-historico" role="tabpanel" aria-labelledby="nav-historico-tab">
       
        <div class="col col-sm-12 d-block justify-content-center">
                
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Institución</th>
                    <th scope="col">Cargo</th>
                    <th scope="col">Fecha Ingreso</th>
                    <th scope="col">Fecha Culminación</th>
                    <th scope="col"><img src="../icons/buscar.png" width="20px"></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Mark</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                  <tr>
                    <td>Jacob</td>
                    <td>@fat</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                  <tr>
                    <td>Larry the Bird</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                </tbody>
              </table>

        </div> 

        <!-- Button de modal -->
          <div class="col col-sm-12 d-flex justify-content-end">

            <div class="col-sm-12">
                <a href="registrofamiliarprincipal.php">ir a familiar</a>
                 <!-- <button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" >
              
              </button>-->

              </div>
            
            <button type="button" class="btn btn-primary d-flex justify-content-center" data-bs-toggle="modal" data-bs-target="#registro-historico">
              Registrar Historial
            </button>

          </div>

          <!-- Modal -->
          <div class="modal fade " id="registro-historico" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl">
              <div class="modal-content">
                <div class="modal-header" style="background-color: #e3f2fd;">
                  <h5 class="modal-title" id="exampleModalLabel">Nuevo Registro Historico</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                   <form action="../controlador/registrarhistorico.php" method="post" enctype="multipart/form-data">


                    <div class="col col-sm-6">
                     <label for="cedula" class="form-label">Cedula</label>
                      <input type="number" class="form-control" id="cedula" name="Cedulapersonaf">
                      </div>
                  
                  <div class="row mb-4">
                    
                    <div class="col col-sm-6">
                      <label for="institucion" class="form-label">Institución</label>
                        <select name="institucionhistorico" class="form-select" id="institucion" aria-label="Seleccione">
                          <option selected>Seleccione</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </select>
                    </div>

                    <div class="col col-sm-6">
                      <label for="cargo" class="form-label">Cargo</label>
                        <select name="cargohistorico" class="form-select" id="cargo" aria-label="Seleccione">
                          <option selected>Seleccione</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </select>
                    </div>

                  </div>
                  <div class="row mb-4">
                    
                    <div class="col col-sm-6">
                      <label for="fecha-inicio" class="form-label">Fecha de Inicio</label>
                      <input type="date" name="fechainiciohistorico" class="form-control" id="fecha-inicio">
                    </div>
                    <div class="col col-sm-6">
                      <label for="fecha-culminacion" class="form-label">Fecha de Culminación</label>
                      <input type="date" name="fechaculminacionhistotico" class="form-control" id="fecha-culminacion">
                    </div>

                  </div>
                   <div class="col col-sm-12 mt-4">
                    <label for="observacion" class="form-label">Observación</label>
                    <input type="text" name="observacionhistorico" class="form-control form-control-lg" id="observacion">
                  </div> 



                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                  <button type="submit" name="Guardarhistorico" class="btn btn-primary">Guardar</button>
                </div>
              </div>
               </form> 
            </div>
          </div>

      </div>

      <!-- TAB-HISTORICO  -->
      <!-- TAB-FAMILIARES  -->
      

    <!--  CONTENIDO  -->
 
  </body>
  </html>