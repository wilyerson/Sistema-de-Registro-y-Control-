const form = document.getElementById('formup');
const cedula = document.getElementById('Cedulapersona');
const nombre = document.getElementById('Nombres');
const estadocivil = document.getElementById('Estadocivil');
const imagenperfil = document.getElementById('Fotopersona');
const apellidos = document.getElementById('Apellidos');
const fechanacimiento = document.getElementById('Fechanacimiento');
const idsexo = document.getElementById('sexo');
const nprincipal = document.getElementById('Telefonoprincipal');
const nhabitacion = document.getElementById('Telefonohabitacion');
const direccion = document.getElementById('direccion');
const peso = document.getElementById('peso');
const estatura = document.getElementById('estatura');
const tallacamisa = document.getElementById('tallacamisa');
const tallapantalon = document.getElementById('tallapantalon');
const tallacalzado = document.getElementById('tallacalzado');
let prueba = 7;

//const password = document.getElementById('password');
//const password2 = document.getElementById('password2');





form.addEventListener('submit', e => {
  e.preventDefault();

  checkInputs();


//lef frm = document.getElementById('formp');

let data = new FormData(event.currentTarget);

let request;

if (window.XMLHttpRequest) request = new XMLHttpRequest();
      else request = new ActiveXObject('Microsoft.XMLHTTP');


      request.addEventListener('load', () => {

       //console.log(data.get('Cedulapersona'));
         
        prueba = 1;
        //alert("registro exitoso");
        

        document.querySelector('#Cedulapersona').value = '';
        document.querySelector('#Fotopersona').value = '';
        document.querySelector('#Estadocivil').value = '';
        document.querySelector('#Nombres').value = '';
        document.querySelector('#Apellidos').value = '';
        document.querySelector('#Fechanacimiento').value = '';
        document.querySelector('#sexo').value = '';
        document.querySelector('#Telefonoprincipal').value = '';
        document.querySelector('#Telefonohabitacion').value = '';
        document.querySelector('#direccion').value = '';
        document.querySelector('#peso').value = '';
        document.querySelector('#estatura').value = '';
        document.querySelector('#tallacamisa').value = '';
        document.querySelector('#tallapantalon').value = '';
        document.querySelector('#tallacalzado').value = '';

      });


       request.open(
        'POST',
        '../controlador/controladorregistratrabajador.php',
        true,
        request.responseType = 'json'
      );

       if(prueba == 12){
        //alert(" registra");
        $('#modalregistrarexitoso').modal("show");
      request.send(data);
       prueba = 5;

       setInterval(() => {
        window.location.replace('registrodocumentosprincipal.php');
        //window.location.href ='registrodocumentosprincipal.php';
      }, 3000);

     }else{
      //alert("no registra");
      $('#modalregistrarrellenecampos').modal("show");
      prueba = 5;
     }
     

});

function checkInputs() {
  // trim to remove the whitespaces
  const cedulaValue = cedula.value.trim();
  const nombreValue = nombre.value.trim();
  const estadocivilValue = estadocivil.value.trim();
  const imagenperfilValue = imagenperfil.value.trim();
  const apellidosValue = apellidos.value.trim();
  const fechanacimientoValue = fechanacimiento.value.trim();
  const idsexoValue = idsexo.value.trim();
  const nprincipalValue = nprincipal.value.trim();
  const nhabitacionValue = nhabitacion.value.trim();
  const direccionValue = direccion.value.trim();
  const pesoValue = peso.value.trim();
  const estaturaValue = estatura.value.trim();
  const tallacamisaValue = tallacamisa.value.trim();
  const tallapantalonValue = tallapantalon.value.trim();
  const tallacalzadoValue = tallacalzado.value.trim();
  //const passwordValue = password.value.trim();
  // password2Value = password2.value.trim();
  
  if(cedulaValue === '') {
    
    setErrorFor(cedula, 'No puede dejar la cedula en blanco');
  } else if (!iscedula(cedulaValue)) {
    setErrorFor(cedula, 'No ingrese simbolos ni letras ni cedula menor a 7 letras ');
  } else {
     
    setSuccessFor(cedula);
  }
  
  if(nombreValue === '') {
    
    setErrorFor(nombre, 'No puede dejar el Nombre en blanco');
  } else if (!isnombre(nombreValue)) {
    setErrorFor(nombre, 'No ingrese numeros o simbolos ni nombres nemores a 4 letras ');
  } else {
    
    setSuccessFor(nombre);
  }

  if(estadocivilValue === '') {
    
    setErrorFor(estadocivil, 'No puede dejar el estado civil en blanco');
  } else {
    
    setSuccessFor(estadocivil);
  }

  if(imagenperfilValue === '') {
    
    setErrorFor(imagenperfil, 'tienes que escojer una imagen de perfil');
  } else {
    
    setSuccessFor(imagenperfil);
  }

  if(apellidosValue === '') {
    
    setErrorFor(apellidos, 'No puede dejar el apellido en blanco');
  } else {
    
    setSuccessFor(apellidos);
  }

  if(fechanacimientoValue === '') {
    
    setErrorFor(fechanacimiento, 'No puede dejar la fecha de nacimiento en blanco');
  } else {
    
    setSuccessFor(fechanacimiento);
  }

  if(idsexoValue === '') {
    
    setErrorFor(idsexo, 'seleccione el sexo');
  } else {
    
    setSuccessFor(idsexo);
  }

  if(nprincipalValue === '') {
    
    setErrorFor(nprincipal, 'No puede dejar el telefon principal en blanco');
  } else {
    
    setSuccessFor(nprincipal);
  }

  if(nhabitacionValue === '') {
    
    setErrorFor(nhabitacion, 'No puede dejar el telefon de habitacion en blanco');
  } else {
    
    setSuccessFor(nhabitacion);
  }
  
  if(direccionValue === '') {
    
    setErrorFor(direccion, 'No puede dejar la direccion en blanco');
  } else if (!isdireccion(direccionValue)) {
    setErrorFor(direccion, 'No ingrese numeros o simbolos ni nombres nemores a 4 letras ');
  } else {
    
    setSuccessFor(direccion);
  }

  if(pesoValue === '') {
    
    setErrorFor(peso, 'No puede dejar el peso en blanco');
  } else {
    
    setSuccessFor(peso);
  }

  if(estaturaValue === '') {
    
    setErrorFor(estatura, 'No puede dejar la estatura en blanco');
  } else {
    
    setSuccessFor(estatura);
  }

  if(tallacamisaValue === '') {
    
    setErrorFor(tallacamisa, 'No puede dejar la talla de camisa en blanco');
  } else {
    
    setSuccessFor(tallacamisa);
  }

  if(tallapantalonValue === '') {
    
    setErrorFor(tallapantalon, 'No puede dejar la talla de pantalon en blanco');
  } else {
    
    setSuccessFor(tallapantalon);
  }

  if(tallacalzadoValue === '') {
    
    setErrorFor(tallacalzado, 'No puede dejar la talla de calzado en blanco');
  } else {
    
    setSuccessFor(tallacalzado);
  }
  /*if(passwordValue === '') {
    setErrorFor(password, 'Password no debe ingresar en blanco.');
  } else {
    setSuccessFor(password);
  }
  
  if(password2Value === '') {
    setErrorFor(password2, 'Password2 no debe ngresar en blanco');
  } else if(passwordValue !== password2Value) {
    setErrorFor(password2, 'Passwords no coinciden');
  } else{
    setSuccessFor(password2);
  }*/
}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector('small');
  formControl.className = 'col-6 col-sm-6 formu-control error';
  small.innerText = message;
  prueba = 2;
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.className = 'col-6 col-sm-6 formu-control success';
  prueba = 12;
}


function iscedula(cedula) {
  return /^[0-9]{7,10}$/.test(cedula);
}

function isnombre(nombre) {
  return /^[a-zA-Z\ ]{4,15}$/.test(nombre);
}

function isdireccion(direccion) {
  return /^[a-zA-Z\ ]{10,30}$/.test(direccion);
}

