<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

//$id = $_GET['id'];
//$usuarios = "SELECT * FROM persona WHERE idpersona = '$id'";


?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="estiloregistropersona.css" rel="stylesheet" type="text/css"/>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
  <link href="estilosrepersona.css" rel="stylesheet">
  

    <style>

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }
      .linka{
        color: black;
      }
    </style>
  
</head>
<body>



    <nav class="navbar navbar-light fixed-top" style="background-color: #e3f2fd;">
      <div class="container-fluid menumenu">

         <button  id="botoninicio" > <a id="textatras" href="inicio.php">Atras</a>  </button>

 

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Nombre Usuario</h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Inicio</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Cambiar Nombre de Usuario</a></li>
                <li><a class="dropdown-item" href="#">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="#">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!--  CONTENIDO  -->

    <div class="tab-content" id="pills-tabContent">
      <!-- TAB-PERFIL  -->

      
        <div class="articulo tab-pane  active" id="nav-perfil" role="tabpanel" aria-labelledby="nav-perfil-tab" >

      
        <form id="formup" class="row needs-validation"  method="post" enctype="multipart/form-data"  novalidate>
          <!--TITULO DE NUEVO TRABAJADOR</!-->
      <div class="row mb-5">
        <div class="col col-sm-12">
          <h4>Registro de Nuevo Trabajador</h4>
        </div>
      </div>


      <!--TITULO DE NUEVO TRABAJADOR</!-->

      <!--  CEDULA - ESTADO CIVIL</!--->

        <div class="row mb-4">

          <div class="col-6 col-sm-6 formu-control">
            <label for="cedula" class="form-label " for="Cedulapersona">Cedula</label>
            <input minlength="7" maxlength="9" type="number" class="form-control inputss" id="Cedulapersona" name="Cedulapersona" placeholder="ingrese la cedula" >
            <img class="fas fa-check-circle" src="../iconos/circle-check-solid.svg" style="width: 25px;">
            <img class="fas fa-exclamation-circle" src="../iconos/circle-exclamation-solid.svg" style="width: 25px;">
            <small>Error message</small>
          </div>

          <div class="col col-sm-6 formu-control">
             <label for="std-civil" class="form-label" for="Estadocivil">Estado Civil</label>
            <select name="Estadocivil" class="form-select selectee inputss" id="Estadocivil">
              <option selected disabled value="">Seleccione</option>
              <option value="casado">casado</option>
              <option value="soltero">soltero</option>
            </select>
           <small>Error message</small>
          </div>

        </div>

      <!--  CEDULA - ESTADO CIVIL</!--->

      <!-- IMAGEN</!--->

        <div class="row mb-4">
          <div class="col col-sm-12 formu-control">
            <label for="img-trb" class="form-label" for="Fotopersona">Seleccione una imagen</label>
            <input type="file" class="form-control inputss" id="Fotopersona" name="Fotopersona">
            <small>Error message</small>
          </div>
        </div>

      <!-- IMAGEN</!--->

      <!-- NOMRBES Y APELLIDOS</!--->

        <div class="row mb-4">

          <div class="col col-sm-6 formu-control">
            <label for="nombres" class="form-label inputss" for="Nombres" >Nombres</label>
            <input minlength="4" maxlength="20" type="text" class="form-control" id="Nombres" name="Nombres">
            <small>Error message</small>
          </div>

          <div class="col col-sm-6 formu-control">
            <label for="apellidos" class="form-label inputss" for="Apellidos" >Apellidos</label>
            <input minlength="4" maxlength="25" type="text" class="form-control" id="Apellidos" name="Apellidos">
            <small>Error message</small>
          </div>

        </div>

      <!-- NOMRBES Y APELLIDOS</!--->

      <!-- FECHA - SEXO</!--->

        <div class="row mb-4">

          <div class="col col-sm-6 formu-control">
            <label for="fecha-nac" class="form-label" for="Fechanacimiento" >Fecha de Nacimiento</label>
            <input type="date" class="form-control inputss" id="Fechanacimiento" name="Fechanacimiento">
            <small>Error message</small>
          </div>

          <div class="col col-sm-6 formu-control">
             <label for="sexo" class="form-label" for="sexo" >Sexo</label>
            <select name="sexo" class="form-select inputss" id="sexo">
              <option selected disabled value="">Seleccione</option>
              <option value="m">Masculino</option>
              <option value="f">Fsemenino</option>
              <option value="o">Otro</option>
            </select>
            <small>Error message</small>
          </div>

        </div>

      <!-- FECHA - SEXO</!--->

      <!--  NUMEROS TELEFONICOS </!--->

      <div class="row mb-4">
        <div class="col sm-6 formu-control">
          <label for="n-principal" class="form-label">Numero telefonico Principal</label>
          <input min="11" max="20" type="number" class="form-control inputss" id="Telefonoprincipal" name="Telefonoprincipal">
          <small>Error message</small>
        </div>
        <div class="col sm-6 formu-control">
          <label for="n-habitacion" class="form-label">Numero telefonico Habitacion</label>
          <input min="11" max="20" type="number" class="form-control inputss" id="Telefonohabitacion" name="Telefonohabitacion">
          <small>Error message</small>
        </div>
      </div>

      <!--  NUMEROS TELEFONICOS </!--->


      <!-- LOCALIDAD</!--->

        <div class="row mb-4">

          <!--<div class="col col-sm-4">
            <label for="municipio" class="form-label">Municipio</label>
            <select name="nombremunicipio" class="form-select" id="municipio" aria-label="Default select example">
              <option selected>Seleccione</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </div>

          <div class="col col-sm-4">
            <label for="parroquia" class="form-label">Parroquia</label>
            <select name="nombreparroquia" class="form-select" id="parroquia" aria-label="Default select example">
              <option selected>Seleccione</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </div>

          <div class="col col-sm-4">
            <label for="sector" class="form-label">Sector</label>
            <select name="nombresector" class="form-select" sector="sector" aria-label="Default select example">
              <option selected>Seleccione</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </div>-->
          
          <div class="col col-sm-12 mt-4 formu-control">
            <label for="direccion" class="form-label">Dirección</label>
            <input minlength="10" maxlength="40" type="text" class="form-control form-control-lg inputss" id="direccion" name="direccion">
            <small>Error message</small>
          </div>

        </div>

      <!-- LOCALIDAD</!--->

      <!--  PESO Y ESTATURA </!--->

      <div class="row mb-4">
        <div class="col sm-6 formu-control">
          <label for="peso" class="form-label">Peso</label>
          <input minlength="1" maxlength="7" type="text" class="form-control inputss" id="peso" name="peso">
          <small>Error message</small>
        </div>
        <div class="col sm-6 formu-control">
          <label for="estatura" class="form-label">Estatura</label>
          <input type="text" class="form-control inputss" id="estatura" name="estatura">
          <small>Error message</small>
        </div>
      </div>

      <!--  PESO Y ESTATURA </!--->

      <!--  TALLAS</!--->

        <div class="row mb-4">
          
          <div class="col sm-4 formu-control">
            <label for="camisa" class="form-label">Talla Camisa</label>
            <input minlength="1" maxlength="12" type="text" class="form-control inputss" id="tallacamisa" name="tallacamisa">
            <small>Error message</small>
          </div>

          <div class="col sm-4 formu-control">
            <label for="pantalon" class="form-label">Talla Pantalón</label>
            <input minlength="1" maxlength="12" type="text" class="form-control inputss" id="tallapantalon" name="tallapantalon">
            <small>Error message</small>
          </div>

          <div class="col sm-4 formu-control">
            <label for="calzado" class="form-label">Talla Calzado</label>
            <input minlength="1" maxlength="12" type="text" class="form-control inputss" id="tallacalzado" name="tallacalzado">
            <small>Error message</small>
          </div>


           

        </div>

      <!--  TALLAS</!--->
      <div class="row text-center">
        <div class="col col-sm-12">
         <button class="btn btn-primary" id="Guardarp"  type="submit" name="Guardarp">Ir a Documentos</button>        
        </div>
        <div class="col col-sm-12">
             
        </div>
      </div>


<!--  modal seguir -->

<!-- Modal -->
<!-- Button trigger modal -->
<!-- Button trigger modal -->
 <!--<button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modalregistrardocumentos">
              Añadir Documentos
            </button>-->

           
           

          </div>

            <!-- Modal -->
            <div class="modal fade" id="modalregistrarexitoso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>
                    
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>registro existoso</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                   

                  </div>
                </div>
              </div>
            </div>


<!-- modal seguir  -->


<div class="modal fade" id="modalregistrarrellenecampos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>rellener todos los campos</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" name="Guardard" class="btn btn-primary">Guardar</button>

                  </div>
                </div>
              </div>
            </div>



<!-- modal seguir  -->





 </form>

    </div>

    <!-- TAB-PERFIL  -->

    <!-- TAB-PERFIL  -->
      
      <!-- TAB-PERFIL  -->
    


    <!--  CONTENIDO  -->
<!--<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>-->
<script src="jquery.min.js"></script>
 <script src="registropersona.js"></script>
 <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
 <!--<script src="jquery.min.js"></script>-->
 <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>-->
  </body>
  </html>