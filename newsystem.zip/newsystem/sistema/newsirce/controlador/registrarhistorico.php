<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

class Historico
{

 
  //public $Nombredocumento;
  //public $fotodocumento;

  
 

 public function registrar($datoshisto){

  $conn = mysqli_connect("localhost","root","","newsirce"); 

//$this->imagen = $imagen;

if(isset($_POST['Guardarhistorico'])){


 $query = "INSERT INTO historico(Cedulapersona,institucionhistorico,cargohistorico,fechainiciohistorico,fechaculminacionhistotico,observacionhistorico) values('$datoshisto[0]','$datoshisto[1]','$datoshisto[2]','$datoshisto[3]','$datoshisto[4]','$datoshisto[5]')";


         $resultado = mysqli_query($conn,$query);
         if($resultado == 1){
              

             //$query = "INSERT INTO documento(Nombredocumento) values('$datosp[15]')";

            //resultado2 = mysqli_query($conn,$query);

         }else{
            // $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
             //$_SESSION['tipo'] = 'danger';
         }


}


  }


}
     $Cedulapersona = @$_POST['Cedulapersonaf'];
     $institucionhistorico = @$_POST['institucionhistorico'];
     $cargohistorico = @$_POST['cargohistorico'];
     $fechainiciohistorico = @$_POST['fechainiciohistorico'];
     $fechaculminacionhistotico = @$_POST['fechaculminacionhistotico'];
     $observacionhistorico = @$_POST['observacionhistorico'];
    
    
    $datoshisto = array($Cedulapersona, $institucionhistorico, $cargohistorico, $fechainiciohistorico, $fechaculminacionhistotico, $observacionhistorico);


 $objetohistorico = new Historico();
 
 if (!($objetohistorico->registrar($datoshisto))) {
   
   //header('location:../vista/ingreso.php');
    //@header('location:../vista/inicio.php');
 }else{ 
 
//echo "jodiste";

 }


?>