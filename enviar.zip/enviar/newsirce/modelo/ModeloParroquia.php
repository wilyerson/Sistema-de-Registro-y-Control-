<?php 
	require_once "ModeloConeccion.php";

	class parroquia{

		public function obtener_parroquia_select($municipioinstitucion){
			$db = new coneccion();
			$query = "SELECT CodigoParroquia, NombreParroquia from parroquia where MunicipioParroquia = $municipioinstitucion";
			$resultado = $db->query($query);
			$datos=[];
			if ($resultado->num_rows) {
				while ($row = $resultado->fetch_assoc()) {
					$datos[] = [
						'NombreParroquia' => $row['NombreParroquia'],
						'CodigoParroquia' => $row['CodigoParroquia'],
					];				
				}			
			}
			return $datos;
		}

	}


 ?>