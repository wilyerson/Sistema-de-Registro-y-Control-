<?php 

	require_once "ModeloConeccion.php";

	class Persona{
		public $imagen;
		public $cedula;
		public $estadocivilpersona;
		public $nombrespersona;
		public $apellidospersona;
		public $fechanacimientopersona;
		public $sexopersona;
		public $numerotelefonoprincipalpersona;
		public $numerotelefonicohabitacionpersona;
		public $direccionpersona;
		public $pesopersona;
		public $estaturapersona;
		public $tallacamisapersona;
		public $tallapantalonpersona;
		public $tallacalzadopersona;
		public $nombremunicipio;
		public $nombreparroquia;
		public $nombresector;


		public function registrar_persona($datosp){

		}


	}

 ?>