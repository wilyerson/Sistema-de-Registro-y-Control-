<?php

  $conn = mysqli_connect("localhost","root","","sirceop");



$query = ("SELECT Cedulapersona FROM persona WHERE Cedulapersona = '".@$_POST['buscarcedu']."' ");

$result = mysqli_query($conn,$query);

if (mysqli_num_rows($result) == 1):
  
  $datos = $result->fetch_assoc();
  echo json_encode(array('error' => false, 'tipo' => $datos['Cedulapersona']));
else:
    echo json_encode(array('error' => true));
  endif;

  //$mysqli->close();
  // code...


?>