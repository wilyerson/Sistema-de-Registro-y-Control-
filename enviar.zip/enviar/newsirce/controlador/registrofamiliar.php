<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

class Familias
{

 
  //public $Nombredocumento;
  //public $fotodocumento;

  
 

 public function registrar($datosfam){

  $conn = mysqli_connect("localhost","root","","newsirce"); 

//$this->imagen = $imagen;




 $query = "INSERT INTO familia(CodigoPersona,checkcedufami,parentesco,cedulafam,nombrefam,apellidofam,fechanacimientofam,sexofam,estadocivilfam,telefonoprincipalfam,telefonohabitacionfam,direccionfam,pesofam,estaturafam,tallacamisafam,tallapantalonfam,tallacalzadofam) values('$datosfam[0]','$datosfam[1]','$datosfam[2]','$datosfam[3]','$datosfam[4]','$datosfam[5]','$datosfam[6]','$datosfam[7]','$datosfam[8]','$datosfam[9]','$datosfam[10]','$datosfam[11]','$datosfam[12]','$datosfam[13]','$datosfam[14]','$datosfam[15]','$datosfam[16]')";


         $resultado = mysqli_query($conn,$query);
         if($resultado == 1){
              

             //$query = "INSERT INTO documento(Nombredocumento) values('$datosp[15]')";

            //resultado2 = mysqli_query($conn,$query);

         }else{
            // $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
             //$_SESSION['tipo'] = 'danger';
         }





  }


}
     $Cedulapersona = @$_POST['Cedulapersonaf'];
     $checkcedufami = @$_POST['checkcedufami'];
     $parentesco = @$_POST['parentesco'];
     $cedulafam = @$_POST['cedulafam'];
     $nombrefam = @$_POST['nombrefam'];
     $apellidofam = @$_POST['apellidofam'];
     $fechanacimientofam = @$_POST['fechanacimientofam'];
     $sexofam = @$_POST['sexofam'];
     $estadocivilfam = @$_POST['estadocivilfam'];
     $telefonoprincipalfam = @$_POST['telefonoprincipalfam'];
     $telefonohabitacionfam = @$_POST['telefonohabitacionfam'];
     $direccionfam = @$_POST['direccionfam'];
     $pesofam = @$_POST['pesofam'];
     $estaturafam = @$_POST['estaturafam'];
     $tallacamisafam = @$_POST['tallacamisafam'];
     $tallapantalonfam = @$_POST['tallapantalonfam'];
     $tallacalzadofam = @$_POST['tallacalzadofam'];
    

    
    
    $datosfam = array($Cedulapersona, $checkcedufami, $parentesco, $cedulafam, $nombrefam, $apellidofam, $fechanacimientofam, $sexofam, $estadocivilfam, $telefonoprincipalfam, $telefonohabitacionfam, $direccionfam, $pesofam, $estaturafam, $tallacamisafam, $tallapantalonfam, $tallacalzadofam);


 $objetofamilias = new Familias();
 
 if (!($objetofamilias->registrar($datosfam))) {
   
   //header('location:../vista/ingreso.php');
    //@header('location:../vista/inicio.php');
 }else{ 
 
//echo "jodiste";

 }


?>