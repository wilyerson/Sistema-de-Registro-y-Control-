<?php 


	require_once "../modelo/ModeloParroquia.php";

	$parroquias = [];
	if (isset($_GET['municipioinstitucion'])) {
		$tabla_parroquia = new parroquia();
		$parroquias = $tabla_parroquia->obtener_parroquia_select($_GET['municipioinstitucion']);
	}
		echo json_encode(['data' => $parroquias] );

		
 ?>