<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

   
    $idoffsuerr = $_POST['usercedulauser'];
    $userrolusuario = $_POST['userrolusuario'];
    $usernombre = $_POST['usernombre'];
    $userpasswordusuario = $_POST['userpasswordusuario'];
    $uuserstatus = $_POST['uuserstatus'];

   
    


    

         $actualizar = "UPDATE usuarios SET cedulapersona='$idoffsuerr', rolusuario='$userrolusuario', nombreusuario='$usernombre', passwordusuario='$userpasswordusuario', estatususuario='$uuserstatus'   WHERE cedulapersona ='$idoffsuerr' ";


         $resultado = mysqli_query($conn,$actualizar);
         if($resultado == 1){
               

             //$query = "INSERT INTO documento(Nombredocumento) values('$datosp[15]')";
              echo "Registrado";
             //$resultado2 = mysqli_query($conn,$query);

         }else{
          echo "error error";
            // $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
             //$_SESSION['tipo'] = 'danger';
         }


       
    

?>