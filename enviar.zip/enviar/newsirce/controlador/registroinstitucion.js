let formulario = document.getElementById("formulario");
let nombre = document.getElementById("nombre");
let codigo = document.getElementById("codigo");
let enviar = document.getElementById("enviar");
let mensaje = document.getElementById("mensaje");


formulario.addEventListener("submit", function (e) {
	e.preventDefault();
	let datos = new FormData(formulario);
	fetch("registro.php", {
		method: "POST",
		body: datos
	})
	.then(function (response) {
		return response.text();
	})
	.then(function (text) {
		mensaje.textContent = text;
	})
	.catch(function (error) {
		console.error(error);
	});
});