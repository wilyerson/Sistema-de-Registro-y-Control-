<?php 
	include "../modelo/ModeloInstituciones.php";

	$institucion = $_POST["nombreinstitucion"];
	$codigoregistro =$_POST[""];
	$municipio =$_POST[""];
	$parroquia =$_POST[""];
	$sector =$_POST[""];
	$direccion =$_POST[""];

	$inst = new Instituciones();

	

 ?>