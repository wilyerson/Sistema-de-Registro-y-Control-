const form = document.getElementById('formulariosuario');
const Cedulapersona = document.getElementById('Cedulapersona');
const cedulausuario = document.getElementById('cedulausuario');
const rolusuario = document.getElementById('rolusuario');
const nombreusuario = document.getElementById('nombreusuario');
const passwordusuario = document.getElementById('passwordusuario');
const passwordusuario2 = document.getElementById('passwordusuario2');

const botonresetlocal = document.getElementById('botonresetlocal');
const botonasignarrol = document.getElementById('botonasignarrol');


/*obteneruser_localstorage();

function obteneruser_localstorage(){

  let nomreuser = localStorage.getItem('nombreusuariostorage');

//console.log(cedulapersona);

return nomreuser;
  
}

console.log(obteneruser_localstorage());

const inputcedula = document.getElementById("inputcedula");


inputcedula.innerHTML = '<input type="hidden" class="form-control inputcedulaestilo" value="'+ obteneruser_localstorage() +'" id="Cedulapersona" name="Cedulapersonad">';
//inputcedula.innerHTML = obtener_localstorage();

*/


form.addEventListener('submit', e => {
  e.preventDefault();

  


//lef frm = document.getElementById('formp');

let data = new FormData(e.currentTarget);

let request;

if (window.XMLHttpRequest) request = new XMLHttpRequest();
      else request = new ActiveXObject('Microsoft.XMLHTTP');


      request.addEventListener('load', () => {

       //console.log(data.get('Cedulapersona'));
         
        //prueba = 1;
        //alert("registro exitoso");
        //window.location.href ='../registrodocumentosprincipal.php';

        document.querySelector('#cedulausuario').value = '';
        document.querySelector('#nombreusuario').value = '';
        document.querySelector('#rolusuario').value = '';
        document.querySelector('#passwordusuario').value = '';
        document.querySelector('#passwordusuario2').value = '';


      });


       request.open(
        'POST',
        '../controlador/registrarusuario.php',
        true,
        request.responseType = 'json'
      );


       

       if(checkInputs2() === 5){
        //alert(" registra");
        $('#modalregistrarexitoso').modal("show");
        //$('#modal-registrar-documentos').modal("hide");
      request.send(data);
    prueba = 5;
     //window.location.href ='registrodocumentosprincipal.php';
        



     }else{
      //alert("no registra");
      $('#modalregistrarrellenecampos').modal("show");
     prueba = 5;
     }

  
     
 checkInputs2();
console.log(checkInputs2());
});


function checkInputs2() {
  let prueba;
  let prueba2;
  let checkcedula = 2;
  let checknombre = 2;
  let checkdireccion = 2;
  //const cedulaValue = cedula.value.trim();
  const cedulausuarioValue = cedulausuario.value.trim();
  const rolusuarioValue = rolusuario.value.trim();
  const nombreusuarioValue = nombreusuario.value.trim();

  const passwordusuarioValue = passwordusuario.value.trim();
  const passwordusuario2Value = passwordusuario2.value.trim();
  // password2Value = password2.value.trim();

    if(cedulausuarioValue === '') {
    
    setErrorFor(cedulausuario, 'No puede dejar la ceduala en blanco');
  } else {
    
    setSuccessFor(cedulausuario);
  }
  
  if(rolusuarioValue === '') {
    
    setErrorFor(rolusuario, 'No puede dejar el nombre en blanco');
  } else {
    
    setSuccessFor(rolusuario);
  }

  if(nombreusuarioValue === '') {
    
    setErrorFor(nombreusuario, 'No puede dejar la contraseña en blanco');
  } else {
    
    setSuccessFor(nombreusuario);
  }

  
  if(passwordusuarioValue === '') {
    setErrorFor(passwordusuario, 'Password no debe ingresar en blanco.');
  } else {
    setSuccessFor(passwordusuario);
  }
  
  if(passwordusuario2Value === '') {
    setErrorFor(passwordusuario2, 'Password2 no debe ngresar en blanco');
  } else if(passwordusuarioValue !== passwordusuario2Value) {
    setErrorFor(passwordusuario2, 'Passwords no coinciden');
  } else{
    setSuccessFor(passwordusuario2);
  }


if (cedulausuarioValue === '' || rolusuarioValue === '' || nombreusuarioValue === '' || passwordusuarioValue === '' || passwordusuario2Value === '') 
{

//alert("campos vacios");
prueba = 2;

}else{

  //todos los campos llenos
  prueba = 5;
}

console.log(prueba);
console.log("hola me ves");
if (prueba === 5) {
  return 5;
}else{
  return 2;
}
 

}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector('small');
  formControl.className = 'col-6 col-sm-6 formu-control error';
  small.innerText = message;
  prueba = 2;
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.className = 'col-6 col-sm-6 formu-control success';
 // prueba = 12;
}




     /* botonrecargardocumentos.onclick = function() {

        window.location.href ='registrodocumentosprincipal.php';
      

      }*/

          