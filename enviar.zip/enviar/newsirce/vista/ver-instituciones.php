<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SIRCE</title>	
	<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

	<style type="text/css">

		@font-face{
			font-family: opensan;
			src: url(fonts/googlesansnormal.woff2);

		}

		body{
			font-family: opensan;
		}

	    .btn-ver-campos{
	    	width:90px;
	    	padding
	    }

	    #btndeacciones{
	    	width: 100%;
	    }

	    #tdbotones{
	    	width: 100px;
	    	padding: 8px 3px;
	    }

	</style>
		
</head>
	
<body class="bg-gray">
	<?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>

	 <?php include"componentes/nav.php" ?>

	<div class="container py-3 bg-white" style="max-width: 1000px; margin-top: 100px; ">

		<div class="row p-2 text-center">
			<h4>Listado de Instituciones</h4>
		</div>

		<div>
			<hr>
		</div>
			
		<div class="row justify-content-md-center table-responsive px-3 py-3">
			<table class="table table-bordered table-hover" >
			  	<thead>
				    <tr>
				      <th scope="col" class="text-center">Nombre de la Institución</th>
				      <th scope="col" class="text-center">Código de Registro</th>
				      <th scope="col" class="text-center">Ver Datos</th>
				      <th scope="col" colspan="2" class="text-center">Acción</th>
				    </tr>
			  	</thead>
				  <tbody>
				    <tr>
				      <td class="text-center">Samuel Perez</td>
				      <td class="text-center">Analista</td>
				      <td class="text-center" id="tdbotones">
				      	<button type="button" data-bs-toggle="modal" data-bs-target="#modaldedatos" id="btndeacciones" class="btn-ver-campos btn btn-info btn-sm">Ver</button>
				      </td>				      
				      <td id="tdbotones" class="text-center">
				      	<button type="button" data-bs-toggle="modal" data-bs-target="#modaldedatos" id="btndeacciones" class="btn-ver-campos btn btn-success btn-sm">Modificar</button>
				      </td>
				      <td id="tdbotones" class="text-center">
				      	<button type="button" data-bs-toggle="modal" data-bs-target="#modaldedatos" id="btndeacciones" class="btn-ver-campos btn btn-danger btn-sm">Eliminar</button>
				      </td>
				    </tr>
				    <tr>
				      <td class="text-center">Wilyerson Malave</td>
				      <td class="text-center">Consulta</td>
				      <td id="tdbotones" class="text-center">
				      	<button type="button" data-bs-toggle="modal" data-bs-target="#modaldedatos" id="btndeacciones" class="btn-ver-campos btn btn-info btn-sm">Ver</button>
				      </td>
				      <td id="tdbotones" class="text-center">
				      	<button type="button" data-bs-toggle="modal" data-bs-target="#modaldedatos" id="btndeacciones" class="btn-ver-campos btn btn-success btn-sm">Modificar</button>
				      </td>
				      <td id="tdbotones" class="text-center">
				      	<button type="button" data-bs-toggle="modal" data-bs-target="#modaldedatos" id="btndeacciones" class="btn-ver-campos btn btn-danger btn-sm">Eliminar</button>
				      </td>
				    </tr>

				  </tbody>
			</table>
		</div>

	</div>

</body>

</html>