
const formue = document.getElementById('formufee');
const cedula = document.getElementById('Cedulapersona');
const checkcedufami = document.getElementById('checkcedufami');
const parentesco = document.getElementById('parentesco');
const cedulafam = document.getElementById('cedulafam');
const nombrefam = document.getElementById('nombrefam');
const apellidofam = document.getElementById('apellidofam');
const fechanacimientofam = document.getElementById('fechanacimientofam');

const sexofam = document.getElementById('sexofam');
const estadocivilfam = document.getElementById('estadocivilfam');
const telefonoprincipalfam = document.getElementById('telefonoprincipalfam');
const telefonohabitacionfam = document.getElementById('telefonohabitacionfam');
const direccionfam = document.getElementById('direccionfam');
const pesofam = document.getElementById('pesofam');
const estaturafam = document.getElementById('estaturafam');
const tallacamisafam = document.getElementById('tallacamisafam');
const tallapantalonfam = document.getElementById('tallapantalonfam');
const tallacalzadofam = document.getElementById('tallacalzadofam');


obtener_localstorage();


function obtener_localstorage(){

  let cedulapersona = localStorage.getItem('cedulapersonastorage');

//console.log(cedulapersona);

return cedulapersona;
  
}

console.log(obtener_localstorage());

const inputcedula = document.getElementById("inputcedula");


inputcedula.innerHTML = '<input type="number" class="form-control inputcedulaestilo" value="'+ obtener_localstorage() +'" id="Cedulapersona" name="Cedulapersonaf">';
//inputcedula.innerHTML = obtener_localstorage();




formue.addEventListener('submit', e => {
  e.preventDefault();

  


//lef frm = document.getElementById('formp');

let data = new FormData(e.currentTarget);

let request;

if (window.XMLHttpRequest) request = new XMLHttpRequest();
      else request = new ActiveXObject('Microsoft.XMLHTTP');


      request.addEventListener('load', () => {

       //console.log(data.get('Cedulapersona'));
         
        prueba = 1;
        //alert("registro exitoso");
        //window.location.href ='../registrodocumentosprincipal.php';

        document.querySelector('#checkcedufami').value = '';
        document.querySelector('#parentesco').value = '';
        document.querySelector('#cedulafam').value = '';
        document.querySelector('#nombrefam').value = '';
        document.querySelector('#apellidofam').value = '';
        document.querySelector('#fechanacimientofam').value = '';

        document.querySelector('#sexofam').value = '';
        document.querySelector('#estadocivilfam').value = '';
        document.querySelector('#telefonoprincipalfam').value = '';
        document.querySelector('#telefonohabitacionfam').value = '';
        document.querySelector('#direccionfam').value = '';
        document.querySelector('#pesofam').value = '';
        document.querySelector('#estaturafam').value = '';
        document.querySelector('#tallacamisafam').value = '';
        document.querySelector('#tallapantalonfam').value = '';
        document.querySelector('#tallacalzadofam').value = '';



      });


       request.open(
        'POST',
        '../controlador/registrofamiliar.php',
        true,
        request.responseType = 'json'
      );

       if(checkInputs() === 5){
        //alert(" registra");
        $('#modalregistrarexitoso').modal("show");
        $('#registro-historico').modal("hide");
      request.send(data);
       prueba = 5;
     //window.location.href ='registrodocumentosprincipal.php';
        



     }else{
      //alert("no registra");
      $('#modalregistrarrellenecampos').modal("show");
      prueba = 5;
     }
     
checkInputs();
console.log(checkInputs());
});


function checkInputs() {
  let prueba;
  let prueba2;
  let checkcedula = 2;
  let checknombre = 2;
  let checkdireccion = 2;
  // trim to remove the whitespaces
  //const cedulaValue = cedula.value.trim();
  const checkcedufamiValue = checkcedufami.value.trim();
  const parentescoValue = parentesco.value.trim();
  const cedulafamValue = cedulafam.value.trim();
  const nombrefamValue = nombrefam.value.trim();
  const apellidofamValue = apellidofam.value.trim();

  const fechanacimientofamValue = fechanacimientofam.value.trim();
  const sexofamValue = sexofam.value.trim();
  const estadocivilfamValue = estadocivilfam.value.trim();
  const telefonoprincipalfamValue = telefonoprincipalfam.value.trim();
  const telefonohabitacionfamValue = telefonohabitacionfam.value.trim();
  const direccionfamValue = direccionfam.value.trim();
  const pesofamValue = pesofam.value.trim();
  const estaturafamValue = estaturafam.value.trim();
  const tallacamisafamValue = tallacamisafam.value.trim();
  const tallapantalonfamValue = tallapantalonfam.value.trim();
  const tallacalzadofamValue = tallacalzadofam.value.trim();


  //const passwordValue = password.value.trim();
  // password2Value = password2.value.trim();
  
  if(checkcedufamiValue === '') {
    
    setErrorFor(checkcedufami, 'tienes que escojer una institucion');
  } else {
    
    setSuccessFor(checkcedufami);
  }

  if(parentescoValue === '') {
    
    setErrorFor(parentesco, 'tienes que escojer un cargo');
  } else {
    
    setSuccessFor(parentesco);
  }

    if(cedulafamValue === '') {
    
    setErrorFor(cedulafam, 'tienes que escojer una fecha de inicio');
  } else {
    
    setSuccessFor(cedulafam);
  }

    if(nombrefamValue === '') {
    
    setErrorFor(nombrefam, 'tienes que escojer una fecha de culminacion');
  } else {
    
    setSuccessFor(nombrefam);
  }

    if(apellidofamValue === '') {
    
    setErrorFor(apellidofam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(apellidofam);
  }

  if(fechanacimientofamValue === '') {
    
    setErrorFor(fechanacimientofam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(fechanacimientofam);
  }

  if(sexofamValue === '') {
    
    setErrorFor(sexofam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(sexofam);
  }

    if(estadocivilfamValue === '') {
    
    setErrorFor(estadocivilfam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(estadocivilfam);
  }

    if(telefonoprincipalfamValue === '') {
    
    setErrorFor(telefonoprincipalfam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(telefonoprincipalfam);
  }

    if(telefonohabitacionfamValue === '') {
    
    setErrorFor(telefonohabitacionfam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(telefonohabitacionfam);
  }

    if(direccionfamValue === '') {
    
    setErrorFor(direccionfam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(direccionfam);
  }

    if(pesofamValue === '') {
    
    setErrorFor(pesofam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(pesofam);
  }

      if(estaturafamValue === '') {
    
    setErrorFor(estaturafam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(estaturafam);
  }

      if(tallacamisafamValue === '') {
    
    setErrorFor(tallacamisafam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(tallacamisafam);
  }

      if(tallapantalonfamValue === '') {
    
    setErrorFor(tallapantalonfam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(tallapantalonfam);
  }

      if(tallacalzadofamValue === '') {
    
    setErrorFor(tallacalzadofam, 'no puedes dejar en blanco la observacion');
  } else {
    
    setSuccessFor(tallacalzadofam);
  }


if (checkcedufamiValue === '' || parentescoValue === '' || cedulafamValue === '' || nombrefamValue === '' || apellidofamValue === '' || fechanacimientofamValue === '' || sexofamValue === '' || estadocivilfamValue === '' || telefonoprincipalfamValue === '' || telefonohabitacionfamValue === '' || direccionfamValue === '' || pesofamValue === '' || estaturafamValue === '' || tallacamisafamValue === '' || tallapantalonfamValue === '' || tallacalzadofamValue === '') 
{

//alert("campos vacios");
prueba = 2;

}else{

  //todos los campos llenos
  prueba = 5;
}

if (checkcedula === 5 && checknombre  === 5 && checkdireccion === 5) {

 //todo esta validado
prueba2 = 5;

}else{
  //algo no esta validado

  prueba2 = 2;

}

//console.log(prueba2);

if (prueba === 5) {
  return 5;
}else{
  return 2;
}

}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector('small');
  formControl.className = 'col-6 col-sm-6 formu-control error';
  small.innerText = message;
  prueba = 2;
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.className = 'col-6 col-sm-6 formu-control success';
  //prueba = 12;
}


traerdatos();

          function traerdatos(){

            console.log('dentro de funcion');

            const xhttp = new XMLHttpRequest();

          xhttp.open(
          'POST',
           '../controlador/mostrarfamiliar.php',
             true
               );


          xhttp.send();

          xhttp.onreadystatechange = function()
            {

              if(this.readyState == 4 && this.status == 200)
              {

                //console.log(this.responseText);
                let datos = JSON.parse(this.responseText);
                //console.log(datos);

                
                let cuerpo = document.querySelector('#cuerpo');
                cuerpo.innerHTML ='';


                 let cedu = obtener_localstorage();

                 let pequeños = datos.filter(function(pdatos){
                  return pdatos.Cedulapersona === cedu;
                  
                });

        const botonterminarregistro = document.getElementById('botonterminarregistro');
        let vacioboton;

        botonterminarregistro.onclick = function() {

          if (pequeños.length === 0) 
          {
            //alert("vacio");
            $('#modalmensajeagregueundocumento').modal("show");
          }else{
            //alert("lleno");
            window.location.href ='inicio.php';
          }

        }


        console.log(pequeños.length);
                
              for (let item of pequeños) {
                //console.log(item.Nombredocumento);

                cuerpo.innerHTML += `
                <tr>
                  
                  <td>${item.parentesco}</td>
                  <td>${item.nombrefam}</td>
                  <td>${item.apellidofam}</td>
                  
                  
                </tr>
                `

              }

                

              }

            }

          }



      botonrecargarhistoricos.onclick = function() {

        window.location.href ='registrofamiliarprincipal.php';
      

      }

