<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

//$id = $_GET['id'];
//$usuarios = "SELECT * FROM persona WHERE idpersona = '$id'";

session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="estiloregistropersona.css" rel="stylesheet" type="text/css"/>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>

      /* The Modal (background) */
.modal2 {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content2 {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close2 {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close2:hover,
.close2:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }
      .linka{
        color: black;
      }

            .inputcedulaestilo{
        display: none;
      }

.formu-control.success input {
  border-color: #2ecc71;
}

.formu-control.error input {
  border-color: #e74c3c;
}

.formu-control.success select {
  border-color: #2ecc71;
}

.formu-control.error select {
  border-color: #e74c3c;
}

.formu-control .fas {
  visibility: hidden;
  /*position: absolute;
  top: 40px;
  right: 10px;*/
}

.formu-control.success .fas.fa-check-circle {
  color: #2ecc71;
  visibility: visible;
}

.formu-control.error .fas.fa-exclamation-circle {
  color: #e74c3c;
  visibility: visible;
}

.formu-control small {
  color: #e74c3c;
  /*position: absolute;
  bottom: 0;
  left: 0;*/
  visibility: hidden;
}

.formu-control.error small {
  visibility: visible;
  
}

    </style>
  
</head>
<body class="bg-light">
<nav class="navbar fixed-top" style="background-color: #950014FF;">
      <div class="container p-0" style="width: 900px;">
        <a class="navbar-brand d-flex align-baseline" href="bienvenida.php"><img src="../icons/inicio-blanco.png" style="color: white; height: 30px;"><H4 style="color:white; margin-bottom: 0px;" >S I R C E</H4></a>
        <button class="navbar-toggler bg-p bg-light" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end " tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Usuario : <?php echo $_SESSION['usuarioad'];?></h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Buscar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="registro-persona.php">Registrar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="control-usuarios-sistema.php">Control de Usuarios del Sistema</a>
            </li>
            <li class="nav-item" >
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="modificar-contrasena-usuario.php">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="registro-cargos.php">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="registro-institucion.php">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="../controlador/cierre.php">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
</nav>


    <div class="container rounded border py-3 bg-white" style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;
        ">

    <!--  CONTENIDO  -->

    
      <!-- TAB-PERFIL  -->
      
       
      <!-- TAB-DOCUMENTOS  -->
      <!-- TAB-HISTORICO  -->
      <div class="articulo tab-pane " id="nav-historico" role="tabpanel" aria-labelledby="nav-historico-tab">
       
        <div class="col col-sm-12 d-block justify-content-center">
                
                    <table class="table">
                        <thead>
                          <tr>
                            
                            <th scope="col">Institución</th>
                            <th scope="col">Cargo</th>
                            <th scope="col">Fecha Ingreso</th>
                            <th scope="col">Fecha Culminación</th>
                            <th scope="col"><img src="../icons/buscar.png" width="20px"></th>
                            
                          </tr>
                        </thead>
                        <tbody id='cuerpo'>

                        </tbody>
                      </table>

        </div> 

        <!-- Button de modal -->
          <div class="col col-sm-12 d-flex justify-content-end">

            <div class="col-sm-12">
            <button type="button" id="botonirafamiliar" class="btn btn-primary justify-content-center" style="position: relative; left: 10%;">
              ir a Familiar
              </button>
                 <!-- <button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" >
              
              </button>-->

              </div>
            
            <button type="button" class="btn btn-primary d-flex justify-content-center" data-bs-toggle="modal" data-bs-target="#registro-historico">
              Registrar Historial
            </button>

          </div>

          <!-- Modal -->
          <div class="modal fade " id="registro-historico" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl">
              <div class="modal-content">
                <div class="modal-header" style="background-color: #e3f2fd;">
                  <h5 class="modal-title" id="exampleModalLabel">Nuevo Registro Historico</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                   <form id="formuh" method="post" enctype="multipart/form-data">


                    <div class="col col-sm-6" id="inputcedula">
                     <!--<label for="cedula" class="form-label">Cedula</label>
                      <input type="number" class="form-control" id="cedula" name="Cedulapersonaf">-->
                      </div>

                      <div class="col col-sm-2 formu-control">
                         <select name="estatuscargo" class="form-select" id="estatuscargo" aria-label="Seleccione">
                          <option selected disabled value="">Seleccione el estatus</option>
                          <option value="1">activo</option>
                          <option value="2">inactivo</option>               
                        </select>
                        <small>Error message</small>
                      </div>
                  
                  <div class="row mb-4">



<!-- Trigger/Open The Modal -->
<a id="myBtn2" class="btn btn-info col-sm-2" style="position: relative;
    height: 40px;
    top: 50px;">Añadir institucion</a>

<!-- The Modal -->
<div id="myModal2" class="modal2">

  <!-- Modal content -->
  <div class="modal-content2">
    <span class="close2">&times;</span>
     
        <div class="container border rounded py-3 bg-white" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px; ">
      
      <div class="row mb-4 mt-2">       
        <div class="col col-sm-12"><h5 class="text-right">Registro de Institución</h5></div>
      </div>

      
        
        <div class="row mb-4 align-baseline">

          <div class="col col-sm-3 ">
            <p class="text-end">Nombre de la Institución</p>
          </div>

          <div class="col col-sm-9">
            <input type="text" class="form-control" placeholder="Nombre de la Institución" aria-label="Nombre de la Institución" aria-describedby="basic-addon1">
          </div>
 
        </div>

        <div class="row mb-4 align-baseline">

          <div class="col col-sm-3 ">
            <p class="text-end">Código de registro</p>
          </div>

          <div class="col col-sm-9">
            <input type="text" class="form-control" placeholder="Ingrese Código" aria-label="Ingrese Código" aria-describedby="basic-addon1">
          </div>
 
        </div>

       <!-- <div class="row mb-4 align-baseline">

          <div class="col col-sm-3 ">
            <p class="text-end">Municipio</p>
          </div>

          <div class="col col-sm-9">
          <select class="form-select" aria-label="Default select example">
            <option selected>Seleccione Municipio</option>
            <option value="1">Uno</option>
            <option value="2">Dos</option>
            <option value="3">Tres</option>
          </select>
          </div>
 
        </div>

        <div class="row mb-4 align-baseline">

          <div class="col col-sm-3 ">
            <p class="text-end">Parroquia</p>
          </div>

          <div class="col col-sm-9">
          <select class="form-select" aria-label="Default select example">
            <option selected>seleccione Parroquia</option>
            <option value="1">Uno</option>
            <option value="2">Dos</option>
            <option value="3">Tres</option>
          </select>
          </div>
 
        </div>

        <div class="row mb-4 align-baseline">

          <div class="col col-sm-3 ">
            <p class="text-end">Sector</p>
          </div>

          <div class="col col-sm-9">
          <select class="form-select" aria-label="Default select example">
            <option selected>Seleccione Sector</option>
            <option value="1">Uno</option>
            <option value="2">Dos</option>
            <option value="3">Tres</option>
          </select>
          </div>
 
        </div>fin-->

        <div class="row mb-4 align-baseline">

          <div class="col col-sm-3 ">
            <p class="text-end">Dirección</p>
          </div>

          <div class="col col-sm-9">
            <input type="text" class="form-control" placeholder="Ingrese la Dirección" aria-label="Ingrese la Dirección" aria-describedby="basic-addon1">
          </div>
 
        </div>

        <div class="row mb-4">
          <div class="col col-sm-6 d-flex justify-content-end">
            <button class="btn btn-secondary" type="reset">Limpiar</button>
          </div>
          <div class="col col-sm-6">
            <button class="btn btn-info ml" >Registrar Institución</button>            
          </div>
        </div>


            

    </div>

  </div>

</div>


                    
                    <div class="col col-sm-6 formu-control">
                      <label for="institucion" class="form-label">Institución</label>
                        <select name="institucionhistorico" class="form-select" id="institucionhistorico" aria-label="Seleccione">
                          <option selected disabled value="">Seleccione una institucion</option>
                          <option value="1">pdvsa</option>
                          <option value="2">colegio</option>
                          <option value="3">saime</option>
                        </select>
                        <small>Error message</small>
                    </div>

                    <div class="col col-sm-6 formu-control">
                      <label for="cargo" class="form-label">Cargo</label>
                        <select name="cargohistorico" class="form-select" id="cargohistorico" aria-label="Seleccione">
                          <option selected disabled value="">Seleccione un cargo</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </select>
                        <small>Error message</small>
                    </div>

                    <div class="col col-sm-6 formu-control">
                      <label for="cargo" class="form-label">tipo de trabajador</label>
                        <select name="cargohistorico" class="form-select" id="cargohistorico" aria-label="Seleccione">
                          <option selected disabled value="">Seleccione un tipo de trabajador</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </select>
                        <small>Error message</small>
                    </div>

                  </div>
                  <div class="row mb-4">
                    
                    <div class="col col-sm-6 formu-control">
                      <label for="fecha-inicio" class="form-label">Fecha de Inicio</label>
                      <input type="date" name="fechainiciohistorico" class="form-control" id="fechainiciohistorico">
                      <small>Error message</small>
                    </div>
                    <div class="col-6 col-sm-6 formu-control">
                      <label for="fecha-culminacion" class="form-label">Fecha de Culminación</label>
                      <input type="date" name="fechaculminacionhistotico" class="form-control" id="fechaculminacionhistotico">
                     <small>Error message</small>
                    </div>

                  </div>
                   <div class="col col-sm-12 mt-4 formu-control">
                    <label for="observacion" class="form-label">Observación</label>
                    <input type="text" name="observacionhistorico" class="form-control form-control-lg" id="observacionhistorico">
                    <small>Error message</small>
                  </div> 

                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                  <button type="submit" id="Guardarhistorico" name="Guardarhistorico" class="btn btn-primary">Guardar</button>
                </div>
              </div>
               </form> 
            </div>
          </div>

      </div>



            <div class="modal fade" id="modalregistrarrellenecampos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>rellener todos los campos</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                   <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

                  </div>
                </div>
              </div>
            </div>


                              <div class="modal fade" id="modalregistrarexitoso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>historico registrado con existo</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                   <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="botonrecargarhistoricos">Cerrar</button>

                  </div>
                </div>
              </div>
            </div>

            <div class="modal fade" id="modalagregarinstitucion" tabindex="-1" aria-labelledby="ModalLabelagregarinstitucion" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>historico registrado con existo</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                   <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="botonrecargarhistoricos">Cerrar</button>

                  </div>
                </div>
              </div>
            </div>


                      <div class="modal fade" id="modalmensajeagregueundocumento" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">
                        <p>agregue un historial de trabajo</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

                  </div>
                </div>
              </div>
            </div>

      <!-- TAB-HISTORICO  -->
      <!-- TAB-FAMILIARES  -->
      

    <!--  CONTENIDO  -->

        <script src="jquery.min.js"></script>
    <script src="registrohistorico.js"></script>
 
  </body>
  </html>