<!DOCTYPE html>
<html lang="es">
<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
  <style type="text/css">
    
     @font-face{
  font-family: opensan;
  src: url(fonts/googlesansnormal.woff2);

}

  body{
  font-family: opensan;
}

  </style>
  
</head>

<body class="bg-gray">

  <?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php");} ?>
  
 <?php include"componentes/nav.php" ?>
  
  <div class="container border bg-white border-1" style="max-width: 1000px; padding: 10px; margin-top: 100px; margin-bottom: 20px;">
    
    
    <div class="row d-flex justify-content-center" style="margin: 5px auto 5px;">
      
      <div class="col col-sm-6" style="width: 35%;">
        <img class="rounded mx-auto d-block rounded-circle" id="img-perfil" src="../icons/perfil_usuario.png" width="150px">
        <p class="text-center"><?php echo strtoupper($_SESSION['usuarioad']); ?></p>
        <!--<p class="text-center"></p>-->
      </div>

      <div class="col col-sm-6" style="width: 65%;">
      


        <div class="row p-3">
          <h5 >Nombre de Usuario: <?php echo strtoupper($_SESSION['usuarioad']); ?></h5>
        </div>

        <form id="formcambiarcontraseñauser" method="post" class="campos formu-control" >

        <div class="row">
          <div class="input-group flex-nowrap pb-4">

             <input type="hidden" name="nameuser" id="nameuser" value="">
            
            <input type="text" class="form-control" id="passuser" name="passuser" placeholder="Nueva Contraseña" aria-label="Nombre de usuario" aria-describedby="addon-wrapping">
          </div>
        </div>



        <div class="row">
          <div class="col col-sm-12 d-flex justify-content-center">
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
          </div>
        </div>

        </form>

      </div>

    </div>

    
   
  </div>
<script src="jquery.min.js"></script>
<script src="../controlador/cambiarpassworduser.js"></script>

</body>
</html>