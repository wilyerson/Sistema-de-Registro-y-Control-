jQuery(document).on('submit','#formbusqueda', function(event){
	event.preventDefault();

	let cedulainput = document.getElementById("buscarcedu").value;
	//console.log(cedulainput);

	localStorage.setItem('cedulainputuser', cedulainput);

///////////

	let cedulauserget = localStorage.getItem("cedulainputuser");
	

	document.getElementById("cedulausuario").value = cedulauserget;



	jQuery.ajax({
		url: '../controlador/controlusuariosistema.php',
		type: 'POST',
		dataType: 'json',
		data: $(this).serialize(),
		beforeSend: function () {
		// body...
			checkInputs();
		}
	})
	.done(function (respuesta) {
	// body...



		console.log(respuesta);
		if (!respuesta.error) {

			$('#asignar-rol').modal("show");

		}
		else {
			
			$('#asignar-rol').modal("show");
		}
	})
	.fail(function (resp) {
	// body...
	//console.log(resp.responseText);
		
		
	})
	.always(function () {
	// body...
		console.log("complete");
	});



});

function checkInputs() {

	const form = document.getElementById('formulogine');
	const buscar = document.getElementById('buscarcedu');


	let prueba;
	let prueba2;
	let checkcedula = 2;
	let checknombre = 2;
	let checkdireccion = 2;

	const buscarValue = buscar.value.trim();
  //const passwordValue = password.value.trim();

	
	if(buscarValue === '') {
		
		setErrorFor(buscar, 'No puede dejar la cedula en blanco');
	} else {
		
		setSuccessFor(buscar);
	}



	if (buscarValue === '' ) 
	{


		$('#modalregistrarrellenecampos').modal("show");
		$('#asignar-rol').modal("hidden");

		prueba = 2;

		return 2;
	}else{

  //todos los campos llenos
		prueba = 5;
		return 5;
	}


}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.className = 'input-group formu-control error';
	small.innerText = message;
	prueba = 2;
}

function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.className = 'input-group formu-control success';
  //prueba = 12;
}