setInterval(() => {

jQuery(document).on('submit','#formup', function(event){
	event.preventDefault();




jQuery.ajax({
	url: '../controlador/capturaridpersona.php',
	type: 'POST',
	dataType: 'json',
	data: $(this).serialize(),
	beforeSend: function () {
		// body...

//checkInputs2222();
	}
})
.done(function (respuesta) {
	// body...
	console.log(respuesta);
	console.log(respuesta[0].CodigoPersona);

	let cedulauser = respuesta[0].CodigoPersona;
	//console.log(cedulauser);
	localStorage.setItem("useridkey", cedulauser);
 //console.log();
	//let idcedulauser = localStorage.getItem("localstormodificarcedulausuario");
	//console.log(cedulauser);

	
	console.log(cedulauser);

	let div = document.getElementById("ponerid");
      div.innerHTML = '<a id="iramanejotrabajador" href="manejo-trabajador.php?id='+ cedulauser +'">Continuar</a>';

	//document.getElementById("iramanejotrabajador").href = +"manejo-trabajador.php?id="+respuesta[0].Cedulapersona;

	//document.getElementById("usercedulausuario").value = respuesta[0].Cedulapersona;
	/*document.getElementById("userrolusuario").value = respuesta[0].rolusuario ;
	document.getElementById("usernombre").value = respuesta[0].nombreusuario ;*/
	
	//document.getElementById("userpasswordusuario").value = respuesta[0].passwordusuario ;
	//document.getElementById("userpasswordusuario2").value = respuesta[0].passwordusuario ;

	//document.getElementById("uuserstatus").value = respuesta[0].estatususuario;

	//document.getElementById("idcedulauser").value = idcedulauser;

	if (!respuesta.error) {
	
			//location.href = 'vista/bienvenida.php';
			//alert("usuario esta activo");
			//$('#modalmodificaruser').modal("show");
			console.log("sirve");
		
	}else {
		

		
		}
})
.fail(function (resp) {
	// body...
	//console.log(resp.responseText);
	
	
})
.always(function () {
	// body...
	console.log("complete");
});



});

 }, 1000);