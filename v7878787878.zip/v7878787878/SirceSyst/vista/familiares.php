<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>MenuPrincipal</title>
	<link rel="shortcut icon" href="../Sirce.svg">
	<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="familiares.css">
</head>
<body>
		
<div class="main">
	<input type="checkbox" id="check" value="1">
	<div class="headd">

		<header>

			<div class="head">

				<div class="titulo">

					<div class="btn-men1">	
						<label for="check" class="btn-men"><img src="../icons/menu.png" alt=""></label>	
					</div>

					<h3>Sirce</h3>

				</div>

				<div class="img-logout">
					<img src="../icons/sesion-off.png" alt="">
				</div>

			</div>

		</header>

	</div>
		<!-- INICIO DEL MENU-->
		<div class="barra-menu">

			<div class="menu-cont">

				<div class="btn-menu2">
					<label for="check"><img src="../icons/menu-open.png" alt="" ></label>
				</div>

				<h3>Sirce</h3>
				
			</div>

			<div class="user-box">	
				<div class="user-info">
					<p>Usuario Apellido</p>
					<p>Tipo Usuario</p>
				</div>
			</div>

			<div class="menu-content">
				<ul>
					<li>
						<a href="menu-principal.php">
							<img src="../icons/inicio.png" alt="" class="icon">
							<p>Inicio</p>
						</a>
					</li>
					<li>
						<a href="#	">						
							<img src="../icons/persona.png" alt="" class="icon ">
							<p>Perfil Trabajador</p>
						</a>
					</li>
					<li>
						<a href="#">
							<img src="../icons/familiares.png" alt="" class="icon ">
							<p>Familiares</p>
						</a>
					</li>
					<li><a href="#">						
							<img src="../icons/docs.png" alt="" class="icon ">
							<p>Documentos</p>
						</a>
					</li>
					<li><a href="#">
							<img src="../icons/historico.png" alt="" class="icon ">
							<p>Historico Laboral</p>
						</a>
					</li>
					<li><a href="#">						
							<img src="../icons/hombre-tool.png" alt="" class="icon ">
							<p>Gestion de Usuario</p>
						</a>
					</li>
					<li><a href="#">						
							<img src="../icons/control-user.png" alt="" class="icon ">
							<p>Control de Usuario</p>
						</a>
					</li>
					<li class="sess-off"><a href="#">						
							<img src="../icons/sesion-off.png" alt="" class="icon ">
							<p>Cerrar Sesión</p>
						</a>
					</li>
				</ul>
			</div>
		</div>
		<!-- FIN DEL MENU-->

		<div class="articulo">
			<div class="botonagg">
				<div class="boton-modal">
					<label for="btn-modal">
						Agregar Nuevo Familiar	
					</label>
				</div>
			</div>

			<div class="tabla">
				<table>
					<thead>
						<tr>
							<th class="numero" >Cedula</th>
							<th class="documento" >Nombres</th>
							<th class="fechaing">Apellido</th>
							<th class="fechaculm">Edad</th>
							<th class="accion" >Editar</th>
							<th class="accion" >Eliminar</th>
							<th class="docs">Documentos</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>12.123.123</td>
							<td>Nombres123</td>
							<td>Apelidos123</td>
							<td>xx</td>
							<td><button class="editar">Edit</button></td>
							<td><button class="eliminar">Elim</button></td>
							<td><button class="docss">Ver</button></td>
						</tr>
					</tbody>
				</table>			
		</div>

		<input type="checkbox" id="btn-modal" >

		</div>

			<div class="container-modal">

			<div class="contenido-modal">

				<form action="post" id="reg-hist">

					<div class="tituloagregar">

						<div class="titulo11">
							<h2>Registrar Nuevo Familiar</h2>
						</div>

						<div class="btn-cerrar">
							<label for="btn-modal">Cerrar</label>
						</div>

					</div>
						
					<!--CONTENIDO DEL REGISTRO DE NUEVOS FAMILIARES-->

					<div class="secc-princ">
						
						<img src="../perfil_usuario.png">
						<input type="file" value="Buscar Imagen">

					</div>

					<div class="seccion seccion-ch">
						<div class="pt">
							<p><input type="checkbox" id="chch"> &nbsp; No Posee Cédula de Identidad</p>
						</div>
					</div>

					<div class="seccion seccion-1">

						<div class="pt">
							<p>Cédula</p>
							<select>
								<option value="vnzl">V</option>
								<option value="extr">E</option>
							</select>
							<input type="number" id="cici">
						</div>
						<div class="pt" >
							<p>Estado Civil</p>
							<select name="edo-civil" id="edo-civil">
								<option value="none">Seleccione</option>
								<option value="1">1</option>
								<option value="2">2</option>
							</select>
						</div>
					</div>
					<div class="seccion seccion-2">
						<div class="pt">
							<p>Nombres</p>
							<input type="text" placeholder="Ingrese sus Nombres">
						</div>
						<div class="pt">
							<p>Apellidos</p>
							<input type="text" placeholder="Ingrese sus Apellidos">
						</div>
					</div>
					<div class="seccion seccion-3">
						<div class="pt">
							<p>Número Principal</p>
							<input type="number" placeholder="Ingrese su Número Principal">
						</div>
						<div class="pt">
							<p>Número de habitacións</p>
							<input type="number" placeholder="Ingrese su Número de habitacións">
						</div>
					</div>
					<div class="seccion seccion-4">
						<div class="pt">
							<p>Municipio</p>
							<select name="" id="">
								<option value="none">Seleccione</option>
								<option value="1">1</option>
								<option value="2">2</option>
							</select>
						</div>
						<div class="pt">
							<p>Parroquia</p>
							<select name="" id="">
								<option value="none">Seleccione</option>
								<option value="1">1</option>
								<option value="2">2</option>
							</select>
						</div>
					</div>
					<div class=" seccion seccion-8">
						<div class="pt">
							<p>Sector</p>
							<select name="" id="">
								<option value="none">Seleccione</option>
								<option value="1">1</option>
								<option value="2">2</option>
							</select>
						</div>
					</div>
					<div class="seccion seccion-5">
						<div class="pt-dir">
							<p>Dirección</p>
							<input type="text" placeholder="Ingrese la Dirección">
						</div>
					</div>
					<div class="seccion seccion-6">
						<div class="pt">
							<p>Peso</p>
							<input type="text" placeholder="">
						</div>
						<div class="pt">
							<p>Estatura</p>
							<input type="text" placeholder="">
						</div>
					</div>
					<div class="seccion seccion-7">
						<div class="pt">
							<p>Talla Calzado</p>
							<input type="number">
						</div>
						<div class="pt">
							<p>Talla Camisa</p>
							<input type="text">
						</div>
						<div class="pt">
							<p>Talla Pantalón</p>
							<input type="number">
						</div>
					</div>	

					<div class="btnguardar">
						<input type="submit" value="Guardar"> 
					</div>

				</form>

			</div>
		</div>

</div>
</body>
</html>