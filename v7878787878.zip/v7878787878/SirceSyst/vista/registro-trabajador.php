<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>MenuPrincipal</title>
	<link rel="shortcut icon" href="../Sirce.svg">
	<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="registro-trabajador.css">
</head>
<body>
		
<div class="main">
	<input type="checkbox" id="check">
	<div class="headd">

		<header>

			<div class="head">

				<div class="titulo">

					<div class="btn-men1">	
						<label for="check" class="btn-men"><img src="../icons/menu.png" alt=""></label>	
					</div>

					<h3>Sirce</h3>

				</div>

				<div class="img-logout">
					<img src="../icons/sesion-off.png" alt="">
				</div>

			</div>

		</header>

	</div>
		<!-- INICIO DEL MENU-->
		<div class="barra-menu">

			<div class="menu-cont">

				<div class="btn-menu2">
					<label for="check"><img src="../icons/menu-open.png" alt="" ></label>
				</div>

				<h3>Sirce</h3>
				
			</div>

			<div class="user-box">	
				<div class="user-info">
					<p>Usuario Apellido</p>
					<p>Tipo Usuario</p>
				</div>
			</div>

			<div class="menu-content">
				<ul>
					<li>
						<a href="#">
							<img src="../icons/inicio.png" alt="" class="icon">
							<p>Inicio</p>
						</a>
					</li>
					<li>
						<a href="perfil-trabajador.php">						
							<img src="../icons/persona.png" alt="" class="icon ">
							<p>Perfil Trabajador</p>
						</a>
					</li>
					<li>
						<a href="familiares.php">
							<img src="../icons/familiares.png" alt="" class="icon ">
							<p>Familiares</p>
						</a>
					</li>
					<li><a href="documentos-trabajador.php">						
							<img src="../icons/docs.png" alt="" class="icon ">
							<p>Documentos</p>
						</a>
					</li>
					<li><a href="#">
							<img src="../icons/historico.png" alt="" class="icon ">
							<p>Historico Laboral</p>
						</a>
					</li>
					<li><a href="#">						
							<img src="../icons/hombre-tool.png" alt="" class="icon ">
							<p>Gestion de Usuario</p>
						</a>
					</li>
					<li><a href="#">						
							<img src="../icons/control-user.png" alt="" class="icon ">
							<p>Control de Usuario</p>
						</a>
					</li>
					<li class="sess-off"><a href="#">						
							<img src="../icons/sesion-off.png" alt="" class="icon ">
							<p>Cerrar Sesión</p>
						</a>
					</li>
				</ul>
			</div>
		</div>
		<!-- FIN DEL MENU-->

	