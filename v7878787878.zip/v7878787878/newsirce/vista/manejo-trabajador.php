<?php 


$conn = mysqli_connect("localhost","root","","sirce"); 

$id = $_GET['id'];
$usuarios = "SELECT * FROM persona WHERE idpersona = '$id'";


?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Inicio Sirce</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }
      .linka{
        color: black;
      }
    </style>
  
</head>
<body>

  	<nav class="navbar navbar-light fixed-top" style="background-color: #e3f2fd;">
      <div class="container-fluid menumenu">

        <nav>
          <div class="nav nav-tabs" role="tablist">
            
            <button class="nav-link active" id="nav-perfil-tab" type="button" data-bs-toggle="tab" data-bs-target="#nav-perfil" role="tab" aria-controls="nav-perfil" aria-selected="false">Perfil Trabajador</button>

            <button class="nav-link" id="nav-documentos-tab" type="button" data-bs-toggle="tab" data-bs-target="#nav-documentos" role="tab" aria-controls="nav-documentos" aria-selected="false">Documentos</button>

            <button class="nav-link" id="nav-historico-tab" type="button" data-bs-toggle="tab" data-bs-target="#nav-historico" role="tab" aria-controls="nav-historico" aria-selected="false">Histórico</button>

            <button class="nav-link" id="nav-familiares-tab" type="button" data-bs-toggle="tab" data-bs-target="#nav-familiares" role="tab" aria-controls="nav-familiares" aria-selected="false">Familiares</button>


          </div>
        </nav>

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Nombre Usuario</h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Inicio</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Cambiar Nombre de Usuario</a></li>
                <li><a class="dropdown-item" href="#">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="#">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <!--  CONTENIDO  -->

    <div class="tab-content" id="pills-tabContent">
      <!-- TAB-PERFIL  -->
      <div class="articulo tab-pane fade show active" id="nav-perfil" role="tabpanel" aria-labelledby="nav-perfil-tab">
        
        <div class="row mt-2 mb-2">
          
          <div class="col col-sm-6">
            <img class="rounded mx-auto d-block" id="img-perfil" src="../icons/perfil_usuario.png" width="200px">
          </div>

          <?php $resultado = mysqli_query($conn, $usuarios);


          
          while ($row=mysqli_fetch_assoc($resultado)) { ?>

          <?php  

          $fecha_nacimiento = $row['fechanacimientopersona'];

            function obtener_edad_segun_fecha($fecha_nacimiento)
            {
               //$fecha_nacimiento = $row['fechanacimientopersona'];

                $nacimiento = new DateTime($fecha_nacimiento = $row['fechanacimientopersona']);
                $ahora = new DateTime(date("d-m-Y"));
                $diferencia = $ahora->diff($nacimiento);
                return $diferencia->format("%y");
            } ?>

          <input type="hidden" value="<?php echo $row['idpersona']; ?>" name="id">

          <div class="col sm-6">
            <div class="row mb-0"><h4>Nombre Persona Apellidos</h4></div>
            <div class="row mb-0 p-0 b-0"><p class="mb-2">Cedula de Identidad: <?php echo $row['cedulapersona']; ?></p></div>
            <div class="row mb-0 p-0 b-0"><p class="mb-2">Edad: <?php echo obtener_edad_segun_fecha($fecha); ?></p></div>
            <div class="row mb-0 p-0 b-0"><p class="mb-2">Cargo Actual: xxxxxxxxxxxxxxxx</p></div>
            <div class="row mb-0 p-0 b-0"><p class="mb-2">Dirección: Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus voluptates quia modi, reiciendis voluptatem magni sequi in incidunt</p></div>

          </div>

          <?php } mysqli_free_result($resultado); ?>




        </div>

        <div class="row mt-2 mb-2">
          
          <div class="col col-sm-12 d-flex justify-content-center">
            <!-- LANZAR MODAL PARA EDITAR -->
            <button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-editar-trabajador">
              Modificar Datos
            </button>

            <!-- MODAL EDITAR -->
            <div class="modal fade" id="modal-editar-trabajador" tabindex="-1" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-xl">
                <div class="modal-content">

                  <div class="modal-header" style="background-color: #e3f2fd;">
                    <h5 class="modal-title" id="exampleModalLabel">Editar Datos del Trabajador</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>

                  <div class="modal-body">


                  <!--  CEDULA - NOMBRE Y APELLIDO</!--->

                    <div class="row mb-4">

                      <div class="col col-sm-4">
                        <label for="cedula" class="form-label">Cédula</label>
                        <input type="number" class="form-control" id="cedula">
                      </div>

                       <div class="col col-sm-4">
                        <label for="nombres" class="form-label">Nombres</label>
                        <input type="text" class="form-control" id="nombres">
                      </div>

                       <div class="col col-sm-4">
                        <label for="apellidos" class="form-label">Apellidos</label>
                        <input type="text" class="form-control" id="apellidos">
                      </div>

                    </div>

                  <!--  CEDULA - ESTADO CIVIL</!--->

                  <!-- FECHA - SEXO</!--->

                    <div class="row mb-4">

                      <div class="col col-sm-4">
                        <label for="fecha-nac" class="form-label">Fecha de Nacimiento</label>
                        <input type="date" class="form-control" id="fecha-nac">
                      </div>

                      <div class="col col-sm-4">
                         <label for="sexo" class="form-label">Sexo</label>
                        <select name="sexo" class="form-select" id="sexo">
                          <option selected disabled="">Seleccione</option>
                          <option value="m">Masculino</option>
                          <option value="f">Fsemenino</option>
                          <option value="o">Otro</option>
                        </select>
                      </div>

                      <div class="col col-sm-4">
                         <label for="std-civil" class="form-label">Estado Civil</label>
                        <select name="std-civil" class="form-select" id="std-civil">
                          <option selected disabled="">Seleccione</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                        </select>
                      </div>

                    </div>

                  <!-- FECHA - SEXO</!--->
                  <!-- IMAGEN</!--->

                    <div class="row mb-4">
                      <div class="col col-sm-12">
                        <label for="img-trb" class="form-label">Seleccione una imagen de Perfil</label>
                        <input type="file" class="form-control" id="img-trb">
                      </div>
                    </div>

                  <!-- IMAGEN</!--->
                  <!--  NUMEROS TELEFONICOS </!--->

                    <div class="row mb-4">
                      <div class="col sm-6">
                        <label for="n-principal" class="form-label">Numero Principal</label>
                        <input type="number" class="form-control" id="n-principal">
                      </div>
                      <div class="col sm-6">
                        <label for="n-habitacion" class="form-label">Numero Habitación</label>
                        <input type="number" class="form-control" id="n-habitacion">
                      </div>
                    </div>

                    <!--  NUMEROS TELEFONICOS </!--->


                    <!-- LOCALIDAD</!--->

                      <div class="row mb-4">

                        <div class="col col-sm-4">
                          <label for="municipio" class="form-label">Municipio</label>
                          <select class="form-select" id="municipio" aria-label="Default select example">
                            <option selected>Seleccione</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                          </select>
                        </div>

                        <div class="col col-sm-4">
                          <label for="parroquia" class="form-label">Parroquia</label>
                          <select class="form-select" id="parroquia" aria-label="Default select example">
                            <option selected>Seleccione</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                          </select>
                        </div>

                        <div class="col col-sm-4">
                          <label for="sector" class="form-label">Sector</label>
                          <select class="form-select" sector="sector" aria-label="Default select example">
                            <option selected>Seleccione</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                          </select>
                        </div>
                        
                        <div class="col col-sm-12 mt-4">
                          <label for="direccion" class="form-label">Dirección</label>
                          <input type="text" class="form-control form-control-lg" id="direccion">
                        </div>

                      </div>

                    <!-- LOCALIDAD</!--->

                    <!--  PESO Y ESTATURA </!--->

                    <div class="row mb-4">
                      <div class="col sm-6">
                        <label for="peso" class="form-label">Peso</label>
                        <input type="text" class="form-control" id="peso">
                      </div>
                      <div class="col sm-6">
                        <label for="estatura" class="form-label">Estatura</label>
                        <input type="text" class="form-control" id="estatura">
                      </div>
                    </div>

                    <!--  PESO Y ESTATURA </!--->

                    <!--  TALLAS</!--->

                      <div class="row mb-4">
                        
                        <div class="col sm-4">
                          <label for="camisa" class="form-label">Talla Camisa</label>
                          <input type="text" class="form-control" id="camisa">
                        </div>

                        <div class="col sm-4">
                          <label for="pantalon" class="form-label">Talla Pantalón</label>
                          <input type="text" class="form-control" id="pantalon">
                        </div>

                        <div class="col sm-4">
                          <label for="calzado" class="form-label">Talla Calzado</label>
                          <input type="text" class="form-control" id="calzado">
                        </div>

                      </div>

                    <!--  TALLAS</!--->


                  </div>

                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-primary">Guardar Cambios</button>
                  </div>

                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
      <!-- TAB-PERFIL  -->
      <!-- TAB-DOCUMENTOS  -->
      <div class="articulo tab-pane fade" id="nav-documentos" role="tabpanel" aria-labelledby="nav-documentos-tab">
        
          <div class="row">
            
            <div class="col col-sm-12 d-block justify-content-center">
                
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Nombre del Documento</th>
                    <th scope="col">Fecha de Registro</th>
                    <th scope="col"><img src="../icons/buscar.png" width="20px"></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Mark</td>
                    <td>@mdo</td>
                    <td><button type="button" class="btn btn-light justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-ver-documentos">Editar
                        </button></td>
                  </tr>
                  <tr>
                    <td>Jacob</td>
                    <td>@fat</td>
                    <td><button type="button" class="btn btn-light justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-ver-documentos">Editar
                        </button></td>
                  </tr>
                  <tr>
                    <td>Larry the Bird</td>
                    <td>@mdo</td>
                   <td><button type="button" class="btn btn-light justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-ver-documentos">Editar
                        </button></td>
                  </tr>
                </tbody>
              </table>

            </div>

          </div>

          <div class="row">
            
            <div class="col d-flex justify-content-end col-sm-12">

             <button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-registrar-documentos">
              Añadir Documentos
            </button>

           </div>

          </div>

            <!-- Modal -->
            <div class="modal fade" id="modal-registrar-documentos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-xl">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Registro de Documento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">
                      

                      <div class="col col-sm-6">

                        <select class="form-select" aria-label="Default select example">
                          <option selected>Seleccione el Tipo de Documento</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </select>
                      </div>

                      <div class="col col-sm-6">

                        <div class="mb-3">
                          <input class="form-control" type="file" id="formFileMultiple" multiple>
                        </div>

                      </div>

                    </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" class="btn btn-primary">Guardar</button>
                  </div>
                </div>
              </div>
            </div>

      </div>
      <!-- TAB-DOCUMENTOS  -->
      <!-- TAB-HISTORICO  -->
      <div class="articulo tab-pane fade" id="nav-historico" role="tabpanel" aria-labelledby="nav-historico-tab">
       
        <div class="col col-sm-12 d-block justify-content-center">
                
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Institución</th>
                    <th scope="col">Cargo</th>
                    <th scope="col">Fecha Ingreso</th>
                    <th scope="col">Fecha Culminación</th>
                    <th scope="col"><img src="../icons/buscar.png" width="20px"></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Mark</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                  <tr>
                    <td>Jacob</td>
                    <td>@fat</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                  <tr>
                    <td>Larry the Bird</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                </tbody>
              </table>

        </div> 

        <!-- Button de modal -->
          <div class="col col-sm-12 d-flex justify-content-end">
            
            <button type="button" class="btn btn-primary d-flex justify-content-center" data-bs-toggle="modal" data-bs-target="#registro-historico">
              Registrar Historial
            </button>

          </div>

          <!-- Modal -->
          <div class="modal fade " id="registro-historico" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl">
              <div class="modal-content">
                <div class="modal-header" style="background-color: #e3f2fd;">
                  <h5 class="modal-title" id="exampleModalLabel">Nuevo Registro Historico</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  
                  <div class="row mb-4">
                    
                    <div class="col col-sm-6">
                      <label for="institucion" class="form-label">Institución</label>
                        <select class="form-select" id="institucion" aria-label="Seleccione">
                          <option selected>Seleccione</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </select>
                    </div>

                    <div class="col col-sm-6">
                      <label for="cargo" class="form-label">Cargo</label>
                        <select class="form-select" id="cargo" aria-label="Seleccione">
                          <option selected>Seleccione</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </select>
                    </div>

                  </div>
                  <div class="row mb-4">
                    
                    <div class="col col-sm-6">
                      <label for="fecha-inicio" class="form-label">Fecha de Inicio</label>
                      <input type="date" class="form-control" id="fecha-inicio">
                    </div>
                    <div class="col col-sm-6">
                      <label for="fecha-culminacion" class="form-label">Fecha de Culminación</label>
                      <input type="date" class="form-control" id="fecha-culminacion">
                    </div>

                  </div>
                   <div class="col col-sm-12 mt-4">
                    <label for="observacion" class="form-label">Observación</label>
                    <input type="text" class="form-control form-control-lg" id="observacion">
                  </div>  

                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                  <button type="button" class="btn btn-primary">Guardar</button>
                </div>
              </div>
            </div>
          </div>

      </div>
      <!-- TAB-HISTORICO  -->
      <!-- TAB-FAMILIARES  -->
      <div class="articulo tab-pane fade" id="nav-familiares" role="tabpanel" aria-labelledby="nav-familiares-tab">

        <div class="col col-sm-12 d-block justify-content-center">
                
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Parentesco</th>
                    <th scope="col">Nombres</th>
                    <th scope="col">Apellidos</th>
                    <th scope="col">Edad</th>
                    <th scope="col"><img src="../icons/buscar.png" width="20px"></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Mark</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                  <tr>
                    <td>Jacob</td>
                    <td>@fat</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                  <tr>
                    <td>Larry the Bird</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td>@mdo</td>
                    <td><a href="manejo-trabajador.php">ver</a></td>
                  </tr>
                </tbody>
              </table>

        </div>

        <div class="col col-sm-12 d-flex justify-content-end">
            
            <button type="button" class="btn btn-primary d-flex justify-content-center" data-bs-toggle="modal" data-bs-target="#registro-familiar">
              Registrar Familiar
            </button>

        </div>

        <!-- Modal -->
          <div class="modal fade " id="registro-familiar" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl">
              <div class="modal-content">
                <div class="modal-header" style="background-color: #e3f2fd;">
                  <h5 class="modal-title" id="exampleModalLabel">Registrar Nuevo Familiar</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                  <div class="row mb-4">
                    
                    <div class="col col-sm-6">
                      <div class="form-check d-flex justify-content-center mt-4">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                          No posee Cédula
                        </label>
                      </div>
                    </div>
                    <div class="col col-sm-6">
                      <label for="parentesco" class="form-label">Parentesco</label>
                          <select name="parentesco" class="form-select" id="parentesco">
                            <option selected disabled="">Seleccione</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                          </select>
                    </div>

                  </div>


                  <!--  CEDULA - NOMBRE Y APELLIDO</!--->

                    <div class="row mb-4">

                      <div class="col col-sm-4">
                        <label for="cedula" class="form-label">Cédula</label>
                        <input type="number" class="form-control" id="cedula">
                      </div>

                       <div class="col col-sm-4">
                        <label for="nombres" class="form-label">Nombres</label>
                        <input type="text" class="form-control" id="nombres">
                      </div>

                       <div class="col col-sm-4">
                        <label for="apellidos" class="form-label">Apellidos</label>
                        <input type="text" class="form-control" id="apellidos">
                      </div>

                    </div>

                  <!--  CEDULA - ESTADO CIVIL</!--->

                  <!-- FECHA - SEXO</!--->

                    <div class="row mb-4">

                      <div class="col col-sm-4">
                        <label for="fecha-nac" class="form-label">Fecha de Nacimiento</label>
                        <input type="date" class="form-control" id="fecha-nac">
                      </div>

                      <div class="col col-sm-4">
                         <label for="sexo" class="form-label">Sexo</label>
                        <select name="sexo" class="form-select" id="sexo">
                          <option selected disabled="">Seleccione</option>
                          <option value="m">Masculino</option>
                          <option value="f">Fsemenino</option>
                          <option value="o">Otro</option>
                        </select>
                      </div>

                      <div class="col col-sm-4">
                         <label for="std-civil" class="form-label">Estado Civil</label>
                          <select name="std-civil" class="form-select" id="std-civil">
                            <option selected disabled="">Seleccione</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                          </select>
                      </div>

                    </div>

                  <!-- FECHA - SEXO</!--->
                  <!--  NUMEROS TELEFONICOS </!--->

                    <div class="row mb-4">
                      <div class="col sm-6">
                        <label for="n-principal" class="form-label">Numero Principal</label>
                        <input type="number" class="form-control" id="n-principal">
                      </div>
                      <div class="col sm-6">
                        <label for="n-habitacion" class="form-label">Numero Habitación</label>
                        <input type="number" class="form-control" id="n-habitacion">
                      </div>
                    </div>

                    <!--  NUMEROS TELEFONICOS </!--->


                    <!-- LOCALIDAD</!--->

                      <div class="row mb-4">
                        
                        <div class="col col-sm-12 ">
                          <label for="direccion" class="form-label">Dirección</label>
                          <input type="text" class="form-control form-control-lg" id="direccion">
                        </div>

                      </div>

                    <!-- LOCALIDAD</!--->

                    <!--  PESO Y ESTATURA </!--->

                    <div class="row mb-4">
                      <div class="col sm-6">
                        <label for="peso" class="form-label">Peso</label>
                        <input type="text" class="form-control" id="peso">
                      </div>
                      <div class="col sm-6">
                        <label for="estatura" class="form-label">Estatura</label>
                        <input type="text" class="form-control" id="estatura">
                      </div>
                    </div>

                    <!--  PESO Y ESTATURA </!--->

                    <!--  TALLAS</!--->

                      <div class="row mb-4">
                        
                        <div class="col sm-4">
                          <label for="camisa" class="form-label">Talla Camisa</label>
                          <input type="text" class="form-control" id="camisa">
                        </div>

                        <div class="col sm-4">
                          <label for="pantalon" class="form-label">Talla Pantalón</label>
                          <input type="text" class="form-control" id="pantalon">
                        </div>

                        <div class="col sm-4">
                          <label for="calzado" class="form-label">Talla Calzado</label>
                          <input type="text" class="form-control" id="calzado">
                        </div>

                      </div>

                    <!--  TALLAS</!--->

                  </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                  <button type="button" class="btn btn-primary">Guardar</button>
                </div>
              </div>
            </div>
          </div>

      </div>
      <!-- TAB-FAMILIARES  -->
    </div>
    <!--  CONTENIDO  -->

  </body>