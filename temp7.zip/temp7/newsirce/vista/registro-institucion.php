<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Instituciones</title>	
	<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</head>
	
    <?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>

<body class="bg-light">

	<?php include"componentes/nav.php" ?>

  	<div class="container border rounded py-3 bg-white" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px; ">
  		
  		<div class="row mb-4 mt-2">  			
  			<div class="col col-sm-12"><h5 class="text-right">Registro de Institución</h5></div>
  		</div>

  		<form action="#" method="POST">
  			
  			<div class="row mb-4 align-baseline">

  				<div class="col col-sm-3 ">
  					<p class="text-end">Nombre de la Institución</p>
  				</div>

  				<div class="col col-sm-9">
  					<input type="text" class="form-control" placeholder="Nombre de la Institución" aria-label="Nombre de la Institución" aria-describedby="basic-addon1">
  				</div>
 
  			</div>

  			<div class="row mb-4 align-baseline">

  				<div class="col col-sm-3 ">
  					<p class="text-end">Código de registro</p>
  				</div>

  				<div class="col col-sm-9">
  					<input type="text" class="form-control" placeholder="Ingrese Código" aria-label="Ingrese Código" aria-describedby="basic-addon1">
  				</div>
 
  			</div>

  			<div class="row mb-4 align-baseline">

  				<div class="col col-sm-3 ">
  					<p class="text-end">Municipio</p>
  				</div>

  				<div class="col col-sm-9">
					<select class="form-select" aria-label="Default select example">
					  <option selected>Seleccione Municipio</option>
					  <option value="1">Uno</option>
					  <option value="2">Dos</option>
					  <option value="3">Tres</option>
					</select>
  				</div>
 
  			</div>

  			<div class="row mb-4 align-baseline">

  				<div class="col col-sm-3 ">
  					<p class="text-end">Parroquia</p>
  				</div>

  				<div class="col col-sm-9">
					<select class="form-select" aria-label="Default select example">
					  <option selected>seleccione Parroquia</option>
					  <option value="1">Uno</option>
					  <option value="2">Dos</option>
					  <option value="3">Tres</option>
					</select>
  				</div>
 
  			</div>

  			<div class="row mb-4 align-baseline">

  				<div class="col col-sm-3 ">
  					<p class="text-end">Sector</p>
  				</div>

  				<div class="col col-sm-9">
					<select class="form-select" aria-label="Default select example">
					  <option selected>Seleccione Sector</option>
					  <option value="1">Uno</option>
					  <option value="2">Dos</option>
					  <option value="3">Tres</option>
					</select>
  				</div>
 
  			</div>

  			<div class="row mb-4 align-baseline">

  				<div class="col col-sm-3 ">
  					<p class="text-end">Dirección</p>
  				</div>

  				<div class="col col-sm-9">
  					<input type="text" class="form-control" placeholder="Ingrese la Dirección" aria-label="Ingrese la Dirección" aria-describedby="basic-addon1">
  				</div>
 
  			</div>

  			<div class="row mb-4">
  				<div class="col col-sm-6 d-flex justify-content-end">
  					<button class="btn btn-secondary" type="reset">Limpiar</button>
  				</div>
  				<div class="col col-sm-6">
  					<button class="btn btn-primary ml" type="submmit">Registrar Institución</button>  					
  				</div>
  			</div>


  		</form>					

  	</div>

</body>
</html>