<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cargos</title>	
	<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</head>
	
    <?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>

<body class="bg-light">

	<?php include"componentes/nav.php" ?>


  	<div class="container border rounded py-3 bg-white" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px; ">
  		
  		<div class="row mb-4 mt-2">  			
  			<div class="col col-sm-12"><h5 class="text-right">Registro de Cargos</h5></div>
  		</div>

  		<form action="#" method="POST">
  			
  			<div class="row mb-4">
	  			<div class="col col-sm-6">
	  				<select class="form-select">
					  <option selected>Seleccione el Tipo de Cargo</option>
					  <option value="1">Administrativo</option>
					  <option value="2">Obrero</option>
					  <option value="3">Otro</option>
					</select>
				</div>

	  			<div class="col col-sm-6">
	  				<div class="input-group mb-3">
					  <input type="text" class="form-control" placeholder="Función (Cargo)" aria-label="cargos" aria-describedby="basic-addon1">
					</div>
	  			</div>

  			</div>

  			<div class="row mb-4">
  				<div class="col col-sm-6 d-flex justify-content-end">
  					<button class="btn btn-secondary" type="reset">Limpiar</button>
  				</div>
  				<div class="col col-sm-6">
  					<button class="btn btn-primary ml" type="submmit">Registrar Cargo</button>  					
  				</div>
  			</div>	

  		</form>					

  	</div>

</body>
</html>