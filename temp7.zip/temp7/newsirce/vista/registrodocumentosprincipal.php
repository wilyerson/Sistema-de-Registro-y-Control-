<?php 

$conn = mysqli_connect("localhost","root","","newsirce"); 



session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="estiloregistropersona.css" rel="stylesheet" type="text/css"/>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }
      .linka{
        color: black;
      }

      .inputcedulaestilo{
        display: none;
      }

      .imagregistrodocumento{
        width: 100px;
      }

      .formu-control.success input {
  border-color: #2ecc71;
}

.formu-control.error input {
  border-color: #e74c3c;
}

.formu-control.success select {
  border-color: #2ecc71;
}

.formu-control.error select {
  border-color: #e74c3c;
}

.formu-control .fas {
  visibility: hidden;
  /*position: absolute;
  top: 40px;
  right: 10px;*/
}

.formu-control.success .fas.fa-check-circle {
  color: #2ecc71;
  visibility: visible;
}

.formu-control.error .fas.fa-exclamation-circle {
  color: #e74c3c;
  visibility: visible;
}

.formu-control small {
  color: #e74c3c;
  /*position: absolute;
  bottom: 0;
  left: 0;*/
  visibility: hidden;
}

.formu-control.error small {
  visibility: visible;
  
}

      #iconomunero1{
position: relative;
    width: 5%;
    top: -52%;
    left: 10%;
}

      #iconomunero2{
position: relative;
    width: 5%;
    top: -52%;
    left: 27%;
}

      #iconomunero3{
position: relative;
    width: 5%;
    top: -52%;
    left: 47%;
}

      #iconomunero4{
position: relative;
    width: 5%;
    top: -52%;
    left: 67%;
}

#linea{
      position: relative;
    top: -91px;
}

      #letranumero1{
    position: relative;
    width: 5%;
    top: -50%;
    left: 10%;
}

      #letranumero2{
position: relative;
    width: 5%;
    top: -59px;
    left: 30%;
}

      #letranumero3{
    position: relative;
    width: 5%;
    top: -97px;
    left: 57%;
}

      #letranumero4{
    position: relative;
    width: 5%;
    top: -138px;
    left: 82%;
}

#multiregister{
margin: 0px 0px -198px;
}
    </style>
  
</head>
<body class="bg-light">
<?php include"componentes/nav.php" ?>




    <div class="container rounded border py-3 bg-white" style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;
        ">

    <!--  CONTENIDO  -->

     


      <!-- TAB-PERFIL  -->
      <!-- TAB-DOCUMENTOS  -->
      <div class="articulo tab-pane " id="nav-documentos" role="tabpanel" aria-labelledby="nav-documentos-tab">


        <form id="formud" method="post" enctype="multipart/form-data" novalidate>

        
          <div class="row">
            
            <div class="col col-sm-12 d-block justify-content-center">

              
    <!-- tabla -->



          <div class="col-md-12">
            <div id="multiregister" class="col col-sm-12">
          
          <hr id="linea" ></hr>
          <div style=" position: relative; top: -130px;">
          <img id="iconomunero1" src="../iconos/numero-1inicio.png">
          <img id="iconomunero2" src="../iconos/numero-2.png">
          <img id="iconomunero3" src="../iconos/numero-3inicio.png">
          <img id="iconomunero4" src="../iconos/numero-4inicio.png">


          <p id="letranumero1">datos basicos</p>
          <p id="letranumero2">documentos</p>
          <p id="letranumero3">historico</p>
          <p id="letranumero4">familiares</p>
          </div>
                      
          


        </div>
                    <table class="table">
                        <thead>
                          <tr>
                            
                            <th scope="col">Nombre del documento</th>
                            <th scope="col">imagen del documento</th>
                            
                          </tr>
                        </thead>
                        <tbody id='cuerpo'>

                        </tbody>
                      </table>
                </div>


    <!-- tabla -->                


            </div>

          </div>

          <div class="row">
            
            <div class="col d-flex justify-content-end col-sm-12">

              <div class="col-sm-12">

            <button type="button" id="botonirahistorico" class="btn btn-primary justify-content-center" style="
                    position: relative;
                    left: 15%;
            ">
              ir a historico
            </button>

                <!-- <a href="registrohistoricoprincipal.php">ir a historico</a>
                 <button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" >
              
              </button>-->

              </div>


             <button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-registrar-documentos">
              Añadir Documentos
            </button>

           </div>
           

          </div>

            <!-- Modal -->
            <div class="modal fade" id="modal-registrar-documentos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-xl">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Registro de Documento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                       <div class="col col-sm-6" id="inputcedula">
                      <!-- inpuu que contiene cedula -->
                      <!--<input type="number" class="form-control" value="" id="cedula" name="Cedulapersonad">-->
                      </div>
                      

                      <div class="col col-sm-6 formu-control">

                        <select name="Nombredocumento" id="Nombredocumento" class="form-select" aria-label="Default select example">
                          <option selected disabled value="">Seleccione un documento</option>
                          <option value="cedula">cedula</option>
                          <option value="curriculum">curriculum</option>
                          <option value="partidanacimiento">partida de nacimiento</option>
                          <option value="rif">R.I.F.</option>
                          <option value="cuentabancaria">cuenta bancaria</option>
                          <option value="tituloobtenido">titulo obtenido</option>
                          <option value="asignaciondetrabajado">asignacion de trabajado</option>
                          <option value="boletadevacaciones">boleta de vacaciones</option>
                          <option value="cartadeculminacion">carta de culminacion</option>
                          <option value="cartaderenuncia">carta de renuncia</option>
                        </select>
                        <small>Error message</small>
                      </div>

                      <div class="col col-sm-6">

                        <div class="mb-3 formu-control">
                          <input class="form-control" name="fotodocumento" type="file" id="fotodocumento" multiple>
                          <small>Error message</small>
                        </div>

                      </div>

                    </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" name="Guardard" class="btn btn-primary">Guardar</button>

                  </div>
                </div>
              </div>
            </div>
            </form>
      </div>


                  <div class="modal fade" id="modalregistrarexitoso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>documento registrado con existo</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                   <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="botonrecargarpaginadocumentos">Cerrar</button>

                  </div>
                </div>
              </div>
            </div>


      <div class="modal fade" id="modalregistrarrellenecampos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>rellener todos los campos</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="button" name="Guardard" class="btn btn-primary">Guardar</button>

                  </div>
                </div>
              </div>
            </div>




          <div class="modal fade" id="modalmensajeagregueundocumento" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>agregue un documento</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

                  </div>
                </div>
              </div>
            </div>
      <!-- TAB-DOCUMENTOS  -->
      <!-- TAB-HISTORICO  -->
     

    <!--  CONTENIDO  -->



    <script src="jquery.min.js"></script>
    <script src="registrodocumentos.js"></script>
 
  </body>
  </html>