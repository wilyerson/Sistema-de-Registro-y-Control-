<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bienvenido(a)</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
  
</head>
<body class="bg-light">

    <?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>

 <?php include"componentes/nav.php" ?>

  <div class="container rounded border py-3 bg-white" 
        style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;">

    <h5>Bienvenido(a): <?php echo strtoupper($_SESSION['usuarioad']);?> </h5>      

  </div>

</body>
</html>