<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

   
    $idpersona = $_POST['idpersona'];
    $nombrespersona = $_POST['Nombres'];
    $Cedulapersona = $_POST['Cedulapersona'];
    $estadocivil = $_POST['estadocivil'];
    $Fotopersona = $_FILES['Fotopersona']['name'];
    $Apellidos = $_POST['Apellidos'];
    $Fechanacimiento = $_POST['Fechanacimiento'];
    $sexo = $_POST['sexo'];
    $Telefonoprincipal = $_POST['Telefonoprincipal'];
    $Telefonohabitacion = $_POST['Telefonohabitacion'];
   // $direccionpersona = $_POST['direccionpersona'];
    $direccion = $_POST['direccion'];
    $peso = $_POST['peso'];
    $estatura = $_POST['estatura'];
    $tallacamisa = $_POST['tallacamisa'];
    $tallapantalon = $_POST['tallapantalon'];
    $tallacalzado = $_POST['tallacalzado'];
    


    if(isset($Fotopersona) && $Fotopersona != ""){
        $tipo = $_FILES['Fotopersona']['type'];
        $temp  = $_FILES['Fotopersona']['tmp_name'];

       if( !((strpos($tipo,'gif') || strpos($tipo,'jpeg') || strpos($tipo,'webp')))){
         // $_SESSION['mensaje'] = 'solo se permite archivos jpeg, gif, webp';
          
       }else{
         $actualizar = "UPDATE persona SET Fotopersona='$Fotopersona', Cedulapersona='$Cedulapersona', estadocivil='$estadocivil', Nombres='$nombrespersona', Apellidos='$Apellidos',  Fechanacimiento='$Fechanacimiento', sexo='$sexo', Telefonoprincipal='$Telefonoprincipal',  Telefonohabitacion='$Telefonohabitacion', direccion='$direccion', peso='$peso', estatura='$estatura',  tallacamisa='$tallacamisa', tallapantalon='$tallapantalon',  tallacalzado='$tallacalzado' WHERE Cedulapersona ='$idpersona' ";


         $resultado = mysqli_query($conn,$actualizar);
         if($resultado == 1){
              move_uploaded_file($temp,'imagenes/'.$Fotopersona);   

             //$query = "INSERT INTO documento(Nombredocumento) values('$datosp[15]')";
              echo "Registrado";
             //$resultado2 = mysqli_query($conn,$query);

         }else{
          echo "error error";
            // $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
             //$_SESSION['tipo'] = 'danger';
         }


       }
    }

?>