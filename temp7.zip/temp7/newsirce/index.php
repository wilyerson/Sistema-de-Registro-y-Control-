<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="index.css">
	<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

	<style type="text/css">
		

		 .inputcedulaestilo{
        display: none;
      }

      .imagregistrodocumento{
        width: 100px;
      }

      .formu-control.success input {
  border-color: #2ecc71;
}

.formu-control.error input {
  border-color: #e74c3c;
}

.formu-control.success select {
  border-color: #2ecc71;
}

.formu-control.error select {
  border-color: #e74c3c;
}

.formu-control .fas {
  visibility: hidden;
  /*position: absolute;
  top: 40px;
  right: 10px;*/
}

.formu-control.success .fas.fa-check-circle {
  color: #2ecc71;
  visibility: visible;
}

.formu-control.error .fas.fa-exclamation-circle {
  color: #e74c3c;
  visibility: visible;
}

.formu-control small {
  color: #e74c3c;
  /*position: absolute;
  bottom: 0;
  left: 0;*/
  visibility: hidden;
}

.formu-control.error small {
  visibility: visible;
  
}


	</style>
</head>
<body>

<div class="body">
	
	<div class="caja-sesion">


		<div class="logo-sistema">

		</div>


		<div class="caja-login">
			<h2>Inicio de Sesión</h2>

			<div class="formulario-login">
				<form id="formulogine" method="post"  class="campos formu-control">

					<div class="formu-control">
						<input type="text"  placeholder="Usuario"  class="texto" id="nombreusuario" name="nombreusuario">
					<small>Error message</small>
					</div>
					
					<div class="formu-control">
						<input type="password"  placeholder="contraseña"  class="texto" id="passwordusuario" name="passwordusuario">
					<small>Error message</small>

					</div>
					
					
					<button type="submit" class="btn-submit">Iniciar Sesión</button>
				</form>
			</div>



			<p class="fotg-pass">¿Olvidó la contraseña?</p>
		</div>


	</div>
</div>

      <div class="modal fade" id="modalregistrarrellenecampos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>rellener todos los campos</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

                  </div>
                </div>
              </div>
            </div>


          <div class="modal fade" id="modalusuarionoesta" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>este usuario no esta registrado</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

                  </div>
                </div>
              </div>
            </div>


 <script src="vista/jquery.min.js"></script>       
 <script src="controlador/login.js"></script>
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>