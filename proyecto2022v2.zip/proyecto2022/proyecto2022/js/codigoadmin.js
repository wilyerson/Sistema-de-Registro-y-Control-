

var divdatospersonales = document.getElementById("divdatospersonales");

var divcargafamiliar = document.getElementById("divdatoscargafamiliar");

var btncargafamiliar = document.getElementById("botoncargafamiliar");

var btndatospersonales = document.getElementById("botondatospersonales");




var span = document.getElementsByClassName("close")[0];

var btnregistro = document.getElementById("btnregistrohtml");

var menunavegacion = document.getElementById("zonaregistro");


btncargafamiliar.onclick = function() {
  divdatospersonales.style.display = "none";
  divcargafamiliar.style.display = "block";
}

btndatospersonales.onclick = function() {
  divdatospersonales.style.display = "block";
  divcargafamiliar.style.display = "none";
}



//mostar registro
btnregistro.onclick = function() {
  divdatospersonales.style.display = "block";
  menunavegacion.style.display = "block";
}






// span.onclick = function() {
//   modal.style.display = "none";
// }


// window.onclick = function(event) {
//   if (event.target == modal) {
//     modal.style.display = "none";
//   }
// }




// alert("Mi primer alert");