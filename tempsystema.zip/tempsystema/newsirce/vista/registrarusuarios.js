const form = document.getElementById('formulariosuario');
const Cedulapersona = document.getElementById('Cedulapersona');
const rolusuario = document.getElementById('rolusuario');
const nombreusuario = document.getElementById('nombreusuario');
const passwordusuario = document.getElementById('passwordusuario');
const passwordusuario2 = document.getElementById('passwordusuario2');

const botonresetlocal = document.getElementById('botonresetlocal');
const botonasignarrol = document.getElementById('botonasignarrol');


obteneruser_localstorage();

function obteneruser_localstorage(){

  let nomreuser = localStorage.getItem('nombreusuariostorage');

//console.log(cedulapersona);

return nomreuser;
  
}

console.log(obteneruser_localstorage());

const inputcedula = document.getElementById("inputcedula");


inputcedula.innerHTML = '<input type="hidden" class="form-control inputcedulaestilo" value="'+ obteneruser_localstorage() +'" id="Cedulapersona" name="Cedulapersonad">';
//inputcedula.innerHTML = obtener_localstorage();




form.addEventListener('submit', e => {
  e.preventDefault();

  


//lef frm = document.getElementById('formp');

let data = new FormData(e.currentTarget);

let request;

if (window.XMLHttpRequest) request = new XMLHttpRequest();
      else request = new ActiveXObject('Microsoft.XMLHTTP');


      request.addEventListener('load', () => {

       //console.log(data.get('Cedulapersona'));
         
        prueba = 1;
        //alert("registro exitoso");
        //window.location.href ='../registrodocumentosprincipal.php';

        document.querySelector('#rolusuario').value = '';
        document.querySelector('#nombreusuario').value = '';
        document.querySelector('#passwordusuario').value = '';
        document.querySelector('#passwordusuario2').value = '';


      });


       request.open(
        'POST',
        '../controlador/registrarusuario.php',
        true,
        request.responseType = 'json'
      );

       if(checkInputs() === 5){
        //alert(" registra");
        $('#modalregistrarexitoso').modal("show");
        //$('#modal-registrar-documentos').modal("hide");
      request.send(data);
       prueba = 5;
     //window.location.href ='registrodocumentosprincipal.php';
        



     }else{
      //alert("no registra");
      $('#modalregistrarrellenecampos').modal("show");
      prueba = 5;
     }
     
checkInputs();
console.log(checkInputs());
});


function checkInputs() {
  let prueba;
  let prueba2;
  let checkcedula = 2;
  let checknombre = 2;
  let checkdireccion = 2;
  // trim to remove the whitespaces
  //const cedulaValue = cedula.value.trim();
  const rolusuarioValue = rolusuario.value.trim();
  const nombreusuarioValue = nombreusuario.value.trim();

  const passwordusuarioValue = passwordusuario.value.trim();
  passwordusuario2Value = passwordusuario2.value.trim();
  // password2Value = password2.value.trim();
  
  if(rolusuarioValue === '') {
    
    setErrorFor(nombre, 'No puede dejar la talla de pantalon en blanco');
  } else {
    
    setSuccessFor(nombre);
  }

  if(nombreusuarioValue === '') {
    
    setErrorFor(documentos, 'No puede dejar la talla de calzado en blanco');
  } else {
    
    setSuccessFor(documentos);
  }

  
  if(passwordusuarioValue === '') {
    setErrorFor(passwordusuario, 'Password no debe ingresar en blanco.');
  } else {
    setSuccessFor(passwordusuario);
  }
  
  if(passwordusuario2Value === '') {
    setErrorFor(passwordusuario2, 'Password2 no debe ngresar en blanco');
  } else if(passwordusuarioValue !== passwordusuarioValue) {
    setErrorFor(passwordusuario2, 'Passwords no coinciden');
  } else{
    setSuccessFor(passwordusuario2);
  }


if (nombreValue === '' || documentosValue === '') 
{

//alert("campos vacios");
prueba = 2;

}else{

  //todos los campos llenos
  prueba = 5;
}

if (checkcedula === 5 && checknombre  === 5 && checkdireccion === 5) {

 //todo esta validado
prueba2 = 5;

}else{
  //algo no esta validado

  prueba2 = 2;

}

//console.log(prueba2);

if (prueba === 5) {
  return 5;
}else{
  return 2;
}

}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector('small');
  formControl.className = 'col-6 col-sm-6 formu-control error';
  small.innerText = message;
  prueba = 2;
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.className = 'col-6 col-sm-6 formu-control success';
  //prueba = 12;
}


traerdatos();

          function traerdatos(){

            console.log('dentro de funcion');

            const xhttp = new XMLHttpRequest();

          xhttp.open(
          'POST',
           '../controlador/mostranombreusuario.php',
             true
               );


          xhttp.send();

          xhttp.onreadystatechange = function()
            {
              if(this.readyState == 4 && this.status == 200)
            {
                //console.log(this.responseText);
                let datos = JSON.parse(this.responseText);
                //console.log(datos);

                
                let cuerpo = document.querySelector('#camposnombreapellido');
                cuerpo.innerHTML ='';


                 let username = obteneruser_localstorage();

                 let pequeños = datos.filter(function(pdatos){
                  return pdatos.Cedulapersona === username;
                  
                });

        console.log(pequeños.length);
                
              for (let item of pequeños) 
              {
                //console.log(item.Nombredocumento);

                cuerpo.innerHTML += `
<div class="col col-sm-3"><p class="text-end">Nombre : ${item.Nombres}</p></div>
              <div class="col col-sm-9 ">
                <p>apellidos : ${item.Apellidos}</p>
              </div>


                `

              }

                

              }

            }

          }

      botonresetlocal.onclick = function() {

        localStorage.removeItem('nombreusuariostorage');
        window.location.href ='../vista/control-usuarios-sistema.php';

      }

     botonasignarrol.onclick = function() {

      traerdatos();

      }

     /* botonrecargardocumentos.onclick = function() {

        window.location.href ='registrodocumentosprincipal.php';
      

      }*/

          