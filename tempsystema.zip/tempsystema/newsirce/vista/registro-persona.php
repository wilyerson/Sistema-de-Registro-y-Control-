<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

//$id = $_GET['id'];
//$usuarios = "SELECT * FROM persona WHERE idpersona = '$id'";


?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="estiloregistropersona.css" rel="stylesheet" type="text/css"/>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
  <link href="estilosrepersona.css" rel="stylesheet">
  

    <style>

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }
      .linka{
        color: black;
      }

      #iconomunero1{
position: relative;
    width: 5%;
    top: -52%;
    left: 10%;
}

      #iconomunero2{
position: relative;
    width: 5%;
    top: -52%;
    left: 27%;
}

      #iconomunero3{
position: relative;
    width: 5%;
    top: -52%;
    left: 47%;
}

      #iconomunero4{
position: relative;
    width: 5%;
    top: -52%;
    left: 67%;
}

#linea{
      position: relative;
    top: -35%;
}

      #letranumero1{
    position: relative;
    width: 5%;
    top: -50%;
    left: 10%;
}

      #letranumero2{
position: relative;
    width: 5%;
    top: -74%;
    left: 30%;
}

      #letranumero3{
    position: relative;
    width: 5%;
    top: -88%;
    left: 57%;
}

      #letranumero4{
    position: relative;
    width: 5%;
    top: -104%;
    left: 82%;
}

#multiregister{
margin: 0px 0px -198px;
}




    </style>
  
</head>
<?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>
<body class="bg-light">
<nav class="navbar fixed-top" style="background-color: #950014FF;">
      <div class="container p-0" style="width: 900px;">
        <a class="navbar-brand d-flex align-baseline" href="bienvenida.php"><img src="../icons/inicio-blanco.png" style="color: white; height: 30px;"><H4 style="color:white; margin-bottom: 0px;" >S I R C E</H4></a>
        <button class="navbar-toggler bg-p bg-light" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end " tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Usuario : <?php echo $_SESSION['usuarioad'];?></h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Buscar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="registro-persona.php">Registrar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="control-usuarios-sistema.php">Control de Usuarios del Sistema</a>
            </li>
            <li class="nav-item" >
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="modificar-contrasena-usuario.php">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="registro-cargos.php">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="registro-institucion.php">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="../controlador/cierre.php">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
</nav>


    <div class="container rounded border py-3 bg-white" style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;
        ">

    <!--  CONTENIDO  -->

    <div class="tab-content" id="pills-tabContent">
      <!-- TAB-PERFIL  -->

      
        <div class="articulo tab-pane  active" id="nav-perfil" role="tabpanel" aria-labelledby="nav-perfil-tab" >

      
        <form id="formup" name="formulario1" class="row needs-validation"  method="post" enctype="multipart/form-data"  novalidate>

      
        <div id="multiregister" class="col col-sm-12">
          
          <hr id="linea" ></hr>
          <img id="iconomunero1" src="../iconos/numero-uno.png">
          <img id="iconomunero2" src="../iconos/numero-2inicio.png">
          <img id="iconomunero3" src="../iconos/numero-3inicio.png">
          <img id="iconomunero4" src="../iconos/numero-4inicio.png">


          <p id="letranumero1" >datos basicos</p>
          <p id="letranumero2">documentos</p>
          <p id="letranumero3">historico</p>
          <p id="letranumero4">familiares</p>

        </div>
     
          <!--TITULO DE NUEVO TRABAJADOR</!-->
      <div class="row mb-2">
        <div class="col col-sm-12">
          <h4>Registro de Nuevo Trabajador</h4>
        </div>
      </div>


      <!--TITULO DE NUEVO TRABAJADOR</!-->

      <!--  CEDULA - ESTADO CIVIL</!--->

        <div class="row mb-4">

          <div class="col-6 col-sm-6 formu-control">
            <label for="cedula" class="form-label " for="Cedulapersona">Cedula</label>
            <input minlength="7" maxlength="9" type="number" class="form-control inputss" id="Cedulapersona" name="Cedulapersona" placeholder="ingrese la cedula" >
            <img class="fas fa-check-circle" src="../iconos/circle-check-solid.svg" style="width: 25px;">
            <img class="fas fa-exclamation-circle" src="../iconos/circle-exclamation-solid.svg" style="width: 25px;">
            <small>Error message</small>
          </div>

          <div class="col col-sm-6 formu-control">
             <label for="std-civil" class="form-label" for="Estadocivil">Estado Civil</label>
            <select name="Estadocivil" class="form-select selectee inputss" id="Estadocivil">
              <option selected disabled value="">Seleccione</option>
              <option value="casado">casado</option>
              <option value="soltero">soltero</option>
              <option value="soltero">viudo</option>
            </select>
           <small>Error message</small>
          </div>

        </div>

      <!--  CEDULA - ESTADO CIVIL</!--->

      <!-- IMAGEN</!--->

        <div class="row mb-4">
          <div class="col col-sm-12 formu-control">
            <label for="img-trb" class="form-label" for="Fotopersona">Seleccione una imagen</label>
            <input type="file" class="form-control inputss" id="Fotopersona" name="Fotopersona">
            <small>Error message</small>
          </div>
        </div>

      <!-- IMAGEN</!--->

      <!-- NOMRBES Y APELLIDOS</!--->

        <div class="row mb-4">

          <div class="col col-sm-6 formu-control">
            <label for="nombres" class="form-label inputss" for="Nombres" >Nombres</label>
            <input minlength="4" maxlength="20" type="text" class="form-control" id="Nombres" name="Nombres">
            <small>Error message</small>
          </div>

          <div class="col col-sm-6 formu-control">
            <label for="apellidos" class="form-label inputss" for="Apellidos" >Apellidos</label>
            <input minlength="4" maxlength="25" type="text" class="form-control" id="Apellidos" name="Apellidos">
            <small>Error message</small>
          </div>

        </div>

      <!-- NOMRBES Y APELLIDOS</!--->

      <!-- FECHA - SEXO</!--->

        <div class="row mb-4">

          <div class="col col-sm-6 formu-control">
            <label for="fecha-nac" class="form-label" for="Fechanacimiento" >Fecha de Nacimiento</label>
            


            <input type="date" class="form-control inputss" id="Fechanacimiento" name="Fechanacimiento">
            <small>Error message</small>

             <div id="mostraredad" >
              
            </div>
          </div>

          <div class="col col-sm-6 formu-control">
             <label for="sexo" class="form-label" for="sexo" >Sexo</label>
            <select name="sexo" class="form-select inputss" id="sexo">
              <option selected disabled value="">Seleccione</option>
              <option value="m">Masculino</option>
              <option value="f">Femenino</option>
              <option value="o">Otro</option>
            </select>
            <small>Error message</small>
          </div>

        </div>

      <!-- FECHA - SEXO</!--->

      <!--  NUMEROS TELEFONICOS </!--->

      <div class="row mb-4">
        <div class="col sm-6 formu-control">
          <label for="n-principal" class="form-label">Numero telefonico Principal</label>
          <input min="11" max="20" type="number" class="form-control inputss" id="Telefonoprincipal" name="Telefonoprincipal">
          <small>Error message</small>
        </div>
        <div class="col sm-6 formu-control">
          <label for="n-habitacion" class="form-label">Numero telefonico Habitacion</label>
          <input min="11" max="20" type="number" class="form-control inputss" id="Telefonohabitacion" name="Telefonohabitacion">
          <small>Error message</small>
        </div>
      </div>

      <!--  NUMEROS TELEFONICOS </!--->


      <!-- LOCALIDAD</!--->

        <div class="row mb-4">

          <div class="col col-sm-4">
            <label for="municipio" class="form-label">Municipio</label>
            <select name="cosa" class="form-select" id="municipio" aria-label="Default select example" onchange="cambia()">
              <option selected>Seleccione</option>
              <option value="1">Andrés Eloy Blanco</option>
              <option value="2">Andrés Mata</option>
              <option value="3">Arismendi</option>
              <option value="4">Benítez</option>
              <option value="5">Bermúdez</option>
              <option value="6">Bolívar</option>
              <option value="7">Cajigal</option>
              <option value="8">Cruz Salmerón Acosta</option>
              <option value="9">Libertador</option>
              <option value="10">Mariño</option>
              <option value="11">Mejía</option>
              <option value="12">Montes</option>
              <option value="13">Ribero</option>
              <option value="14">Sucre</option>
              <option value="15">Valdez</option>
            </select>


          </div>

          <div class="col col-sm-4">
            <label for="parroquia" class="form-label">Parroquia</label>
            <select name="opt" class="form-select">
              <option value="-">-
            </select>
            </div>
          <!--<div class="col col-sm-4">
            <label for="parroquia" class="form-label">Parroquia</label>
            <select name="nombreparroquia" class="form-select" id="parroquia" aria-label="Default select example">
              <option selected>Seleccione</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </div>-->

          <div class="row mb-2" style="padding: 10px;">
          <div class="col col-sm-12">
            <label for="sector" class="form-label">Sector</label>
            <input minlength="10" maxlength="40" type="text" class="form-control form-control-lg inputss" id="sector" name="nombresector">
   
          </div>
          </div>
          
          <div class="col col-sm-12 mt-4 formu-control">
            <label for="direccion" class="form-label">Dirección</label>
            <input minlength="10" maxlength="40" type="text" class="form-control form-control-lg inputss" id="direccion" name="direccion">
            <small>Error message</small>
          </div>

        </div>


      <!-- LOCALIDAD</!--->

      <!--  PESO Y ESTATURA </!--->

      <div class="row mb-4">
        <div class="col sm-6 formu-control">
          <label for="peso" class="form-label">Peso (Kg)</label>
          <input minlength="1" maxlength="7" type="text" class="form-control inputss" id="peso" name="peso">
          <small>Error message</small>
        </div>
        <div class="col sm-6 formu-control">
          <label for="estatura" class="form-label">Estatura (Metros)</label>
          <input type="text" class="form-control inputss" id="estatura" name="estatura">
          <small>Error message</small>
        </div>
      </div>

      <!--  PESO Y ESTATURA </!--->

      <!--  TALLAS</!--->

        <div class="row mb-4">
          
          <div class="col sm-4 formu-control">
            <label for="camisa" class="form-label">Talla Camisa</label>
            <input minlength="1" maxlength="12" type="text" class="form-control inputss" id="tallacamisa" name="tallacamisa">
            <small>Error message</small>
          </div>

          <div class="col sm-4 formu-control">
            <label for="pantalon" class="form-label">Talla Pantalón</label>
            <input minlength="1" maxlength="12" type="text" class="form-control inputss" id="tallapantalon" name="tallapantalon">
            <small>Error message</small>
          </div>

          <div class="col sm-4 formu-control">
            <label for="calzado" class="form-label">Talla Calzado</label>
            <input minlength="1" maxlength="12" type="text" class="form-control inputss" id="tallacalzado" name="tallacalzado">
            <small>Error message</small>
          </div>


           

        </div>

      <!--  TALLAS</!--->
      <div class="row text-center">
        <div class="col col-sm-12">
          <button class="btn btn-secondary" type="reset">Limpiar</button> 
         <button class="btn btn-primary" id="Guardarp"  type="submit" name="Guardarp">Registrar</button>      
        </div>
        <div class="col col-sm-12">
             
        </div>
      </div>


<!--  modal seguir -->

<!-- Modal -->
<!-- Button trigger modal -->
<!-- Button trigger modal -->
 <!--<button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modalregistrardocumentos">
              Añadir Documentos
            </button>-->

           
           

          </div>

            <!-- Modal -->
            <div class="modal fade" id="modalregistrarexitoso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>registro existoso</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                   

                  </div>
                </div>
              </div>
            </div>


<!-- modal seguir  -->

<div class="modal fade" id="modalregistrarrellenecampos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row" style="position: relative; left: 27%;">


                                        
                      <div class="col col-sm-6">

                        <svg class="checkmarkerror" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52"><circle class="checkmark_circle_error" cx="26" cy="26" r="25" fill="none"/><path class="checkmark_checkerror" stroke-linecap="round" fill="none" d="M16 16 36 36 M36 16 16 36
"/></svg>

                        <p>rellener todos los campos</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    

                  </div>
                </div>
              </div>
            </div>


<div class="modal fade" id="modaledad" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row" >

                                        
                      <div class="col col-sm-6">

                        <p>no se puede registrar menores de edad, debe tener 18 anios</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                   

                  </div>
                </div>
              </div>
            </div>

<!-- modal seguir  -->

<!-- modal registro exitoso  -->

<div class="modal fade" id="modalregistrexitosopersona" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row" style="position: relative; left: 27%;" >

                                        
                      <div class="col col-sm-6">


 <svg width="100" height="100" class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52" style=" position: relative; left: -8%;">
    <g stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10">
      <circle class="checkmark__circle" cx="26" cy="26" r="26" fill="none"/>
      <path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
    </g>
  </svg>


                        <p style="position: relative;left: 19%;">registro exitoso</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="submit" name="Guardard" class="btn btn-primary">registrar documentos</button>-->
                    <a href="registrodocumentosprincipal.php?htmlcedulap=">Continuar</a>
                  </div>
                </div>
              </div>
            </div>

<!-- modal registro exitoso  -->





 </form>

    </div>

    <!-- TAB-PERFIL  -->

    <!-- TAB-PERFIL  -->
      
      <!-- TAB-PERFIL  -->
    


    <!--  CONTENIDO  -->
<!--<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>-->
<script src="jquery.min.js"></script>
 <script src="registropersona.js"></script>
 <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
 
 <!--<script src="jquery.min.js"></script>-->
 <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>-->
  </body>
  </html>