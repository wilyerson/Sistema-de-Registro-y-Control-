<?php
	require_once "../modelo/ModeloMunicipio.php";

	$tabla_municipio = new municipio();
	$municipiopersona = $tabla_municipio->obtener_municipios_select();

	// Convertir el resultado a JSON
	echo json_encode($municipiopersona);
?>