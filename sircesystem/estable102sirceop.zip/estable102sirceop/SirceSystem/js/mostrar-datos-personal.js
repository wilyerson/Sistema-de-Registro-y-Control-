document.addEventListener('DOMContentLoaded', async function() {
    let params = new URLSearchParams(window.location.search);
    let id = params.get('id');

    localStorage.setItem("idpesonaid", id);

    let idper = localStorage.getItem("idpesonaid");
    console.log(idper);

    document.getElementById("idper").value = idper;



    // Realizamos la solicitud POST para obtener el JSON
    try {
        const url = "../controlador/ctr-personas.php?op=editar";
       const datos = new FormData(document.getElementById("fomrcapturarid"));

        const response = await fetch(url, {
            method: "POST",
            body: datos, // Convierte los datos a formato JSON
            
        });

        if (!response.ok) {
            throw new Error(`Error al obtener los datos. Código de estado: ${response.status}`);
        }

        const responseData = await response.json();
        console.log(responseData); // Aquí puedes manejar los datos JSON recibidos
        console.log(responseData[0].Nombres);
        

        /*let divdatorpersona = document.querySelector("#zonadatospersona");*/

        var cedulaOriginal = responseData[0].CedulaPersona;
        localStorage.setItem("cedulaoriginalpersona", cedulaOriginal);


        const fechaOriginal = responseData[0].FechaNacimiento; // Cambia esto a la fecha correcta

        function calcularEdadEnAnos(fechaNacimiento) {
		    if (typeof fechaNacimiento !== 'string' || !fechaNacimiento || isNaN(new Date(fechaNacimiento).getTime())) {
		        return 'Fecha de nacimiento inválida';
		    }

		    const [ano, mes, dia] = fechaNacimiento.split('-').map(Number);
		    const hoy = new Date();
		    const ahoraAno = hoy.getFullYear();
		    const ahoraMes = hoy.getMonth() + 1;
		    const ahoraDia = hoy.getDate();

		    let edad = ahoraAno - ano;

		    if (ahoraMes < mes || (ahoraMes === mes && ahoraDia < dia)) {
		        edad--; // Ajuste si aún no ha cumplido años este año
		    }

		    return `${edad} años`;
		}

		const edadEnAnos = calcularEdadEnAnos(fechaOriginal);
		



		// Formatea la fecha al estilo "DD-MM-YYYY"
		function cambiarFormatoFecha(fecha) {
		    const partes = fecha.split('-'); // Divide la fecha en partes: año, mes, día
		    const nuevaFecha = `${partes[2]}-${partes[1]}-${partes[0]}`; // Reorganiza las partes en el nuevo formato
		    return nuevaFecha;
		}

		const fechaFormateada = cambiarFormatoFecha(fechaOriginal);
		



        //--------------asignamos los valores del json a los inputs y selects de html----

        /*divdatorpersona.innerHTML = `
							<div class="row mb-0 p-0 b-0"><p class="mb-2">Cedula de Identidad:${responseData[0].CedulaPersona}</p></div>
							<div class="row mb-0"><h6>Personal:  ${responseData[0].Nombres}</h6></div>
							<div class="row mb-0 p-0 b-0"><p class="mb-2">Edad: ${edadEnAnos}</p></div>
							<div class="row mb-0 p-0 b-0"><p class="mb-2">Cargo Actual: </p></div>
							<div class="row mb-0 p-0 b-0"><p class="mb-2">Dirección: ${responseData[0].Direccion}</p></div>
         `;*/

        //-------------------------------------------------------------------------------



        //----------------------asignamos los valores del json a la modal editar datos persona-----
        
        document.getElementById("CedulaPersona").value = responseData[0].CedulaPersona;
        document.getElementById("Nombrespersona").value = responseData[0].Nombres;
        document.getElementById("Apellidospersona").value = responseData[0].Apellidos;
        document.getElementById("FechaNacimientopersona").value = responseData[0].FechaNacimiento;
        document.getElementById("sexopersona").value = responseData[0].Sexo;
        document.getElementById("estadocivilpersona").value = responseData[0].EstadoCivil;
        document.getElementById("TelefonoPrincipalpersona").value = responseData[0].TelefonoPrincipal;
        document.getElementById("TelefonoHabitacionpersona").value = responseData[0].TelefonoHabitacion;
        document.getElementById("editmunicipio").value = responseData[0].CodigoMunicipio;
        document.getElementById("editparroquiareg").value = responseData[0].ParroquiaPersona;
        document.getElementById("sectorpersona").value = responseData[0].Sector;
        document.getElementById("direccionpersona").value = responseData[0].Direccion;
        document.getElementById("estatuspersonaeditar").value = responseData[0].EstatusTrabajador;
        document.getElementById("pesopersona").value = responseData[0].Peso;
        document.getElementById("estaturapersona").value = responseData[0].Estatura;
        document.getElementById("TallaCamisapersona").value = responseData[0].TallaCamisa;
        document.getElementById("TallaPantalonpersona").value = responseData[0].TallaPantalon;
        document.getElementById("TallaCalzadopersona").value = responseData[0].TallaCalzado;

        let ParroquiaPersonanumero = responseData[0].ParroquiaPersona;
        let ParroquiaPersonanombre = responseData[0].NombreParroquia;
  
        localStorage.setItem("ParroquiaPersonanumero", ParroquiaPersonanumero);
        localStorage.setItem("ParroquiaPersonanombre", ParroquiaPersonanombre);

        //-------------------------------------------------------------------------------------

        //-----------------------------asignamos los valores json a la modal ver datos---------
        /*document.getElementById("CedulaPersonaver").value = responseData[0].CedulaPersona;
        document.getElementById("Nombrespersonaver").value = responseData[0].Nombres;
        document.getElementById("Apellidospersonaver").value = responseData[0].Apellidos;
        document.getElementById("FechaNacimientopersonaver").value = responseData[0].FechaNacimiento;
        document.getElementById("sexopersonaver").value = responseData[0].Sexo;
        document.getElementById("estadocivilpersonaver").value = responseData[0].EstadoCivil;
        document.getElementById("TelefonoPrincipalpersonaver").value = responseData[0].TelefonoPrincipal;
        document.getElementById("TelefonoHabitacionpersonaver").value = responseData[0].TelefonoHabitacion;
        document.getElementById("vermunicipiopersona").value = responseData[0].NombreMunicipio;
        document.getElementById("verparroquiapersona").value = responseData[0].NombreParroquia;
        document.getElementById("sectorpersonaver").value = responseData[0].Sector;
        document.getElementById("direccionpersonaver").value = responseData[0].Direccion;
        document.getElementById("pesopersonaver").value = responseData[0].Peso;
        document.getElementById("estaturapersonaver").value = responseData[0].Estatura;
        document.getElementById("TallaCamisapersonaver").value = responseData[0].TallaCamisa;
        document.getElementById("TallaPantalonpersonaver").value = responseData[0].TallaPantalon;
        document.getElementById("TallaCalzadopersonaver").value = responseData[0].TallaCalzado;*/

        //---------------------------------------------------------------------------------------
    


    } catch (error) {
        console.error(`Error en la solicitud: ${error.message}`);
    }
});