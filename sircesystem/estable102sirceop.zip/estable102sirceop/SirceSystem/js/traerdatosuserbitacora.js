document.addEventListener('DOMContentLoaded', async function() {
    let paramsuser = new URLSearchParams(window.location.search);
    let iduser = paramsuser.get('id');

    localStorage.setItem("iduserid", iduser);

    let idusuariobit = localStorage.getItem("iduserid");
    console.log(idusuariobit);

    document.getElementById("usersistema").value = idusuariobit;

    // Realizamos la solicitud POST para obtener el JSON
    try {
        const url = "../controlador/traerdatosuserbitacora.php";
       const datos = new FormData(document.getElementById("fomriduser"));

        const response = await fetch(url, {
            method: "POST",
            body: datos, // Convierte los datos a formato JSON
            
        });

        if (!response.ok) {
            throw new Error(`Error al obtener los datos. Código de estado: ${response.status}`);
        }

        let responseData = await response.json();
        responseData = responseData.reverse();

        //console.log(responseData); // Aquí puedes manejar los datos JSON recibidos
       // console.log(responseData[0].NombreUsuario);
        
    let nombredelusuario = document.querySelector("#nombredeusuario");
    nombredelusuario.innerHTML = "";
      if (responseData.length > 0) {
      for (let registro of responseData) {
        nombredelusuario.innerHTML = `
  
        <h5>${registro.NombreUsuario}</h5>
  
       `;
      }
    }

let selectmodificar = document.getElementById("selectfilterbitacora").value;

      let mostrarregistrobitacora = responseData.filter(responseData => responseData.ActividadRealizada.includes('Se Registro'));
    let mostrarmodificacionesbitacora = responseData.filter(responseData => responseData.ActividadRealizada.includes('Se Modifico'));
    let mostrarsesionesbitacora = responseData.filter(responseData => responseData.ActividadRealizada.includes('Sesion'));

      let tbody = document.querySelector("#mismovimientosusuario");

      let limite = 15;
    let desde = 0;
    let paginaActiva = 1;
    let arreglo = [];
    let paginas = 0;

    const cargarBitacora = () => {
      var tbody = document.querySelector("#mismovimientosusuario");
      tbody.innerHTML = "";
      if (arreglo.length > 0) {
        for (let registro of arreglo) {
          tbody.innerHTML += `
             <tr>
             <th class="text-center">${registro.CodigoBitacora}</th>
             <td class="text-center">${registro.CodigoPersona}</td>
             <td class="text-center">${registro.Fecha}</td>
             <td class="text-center">${registro.ActividadRealizada}</td>
             <td class="text-center">${registro.InformacionActual}</td>
             </tr>
             `;
        }
      } else {
        tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.</th>
            </td>
            </tr>
            `;
      }
      cargarItemPaginacion();
    };

    const cargarItemPaginacion = () => {
      document.querySelector("#items").innerHTML = "";

      let inicio = Math.max(0, paginaActiva - 5);
      let fin = Math.min(paginas, inicio + 10);

      for (let index = inicio; index < fin; index++) {
        const item = document.createElement("li");
        item.classList = `page-item ${paginaActiva == index + 1 ? "active" : ""}`;
        const enlace = `<button class="page-link" onclick="pasarPagina(${index})">${index + 1}</button>`;
        item.innerHTML = enlace;
        document.querySelector("#items").append(item);
      }
    };

    const modificarArregloBitacora = () => {
      arreglo = data.slice(desde, limite * paginaActiva);
      cargarBitacora();
    };

    window.pasarPagina = (pagina)=>{
      paginaActiva = pagina + 1;
      desde = limite * pagina;

      if (desde <= data.length) {
        modificarArregloBitacora();
      }
    };

    window.nextPage = () => {
      if (paginaActiva < paginas) {
        desde += 15;
        paginaActiva++;
        modificarArregloBitacora();
      }
    };

    window.previusPage = () => {
      if (desde > 0) {
        paginaActiva--;
        desde -= 15;
        modificarArregloBitacora();
      }
    };

      data = responseData;
      desde = 0;
      paginaActiva = 1;
      paginas = data.length / limite;
      modificarArregloBitacora();

    $('#selectfilterbitacora').on('change', function() {
      var selecthtml = $(this).find("option:selected").text();
      data = [];

      switch(selecthtml) {
        case "Registro":
          data = mostrarregistrobitacora;
          break;
        case "Modificacion":
          data = mostrarmodificacionesbitacora;
          break;
        case "Sesiones":
          data = mostrarsesionesbitacora;
          break;
        case "Todos":
          data = responseData;
          break;
      }

      desde = 0;
      paginaActiva = 1;
      paginas = data.length / limite;
      modificarArregloBitacora();
    });//fin del oncharge

    //---------------------

    //----------------------

    //////////////////////------------------buscardor-----------------------------///////////////////////////////

    $('#buscardatobitacorauser').on('keyup', function(){
      let search = $('#buscardatobitacorauser').val()

      data = responseData.filter(responseData => {
        let valores = Object.values(responseData).join(" ").toLowerCase();
        return valores.includes(search);
      });

      desde = 0;
      paginaActiva = 1;
      paginas = data.length / limite;

      if (search == "") {
        modificarArregloBitacora();
      } else {
        if (data.length > 0) {
          modificarArregloBitacora();
        } else {
          tbody.innerHTML = `
            <tr>
              <th class="text-center" colspan="5" >No hay Registros de movimientos.</th>
            </td>
            </tr>
          `;
        }
      }
    });//fin buscar idbitacora

    ///////////////////---------------------finbuscador----------------------------/////////////////////////////////    

    } catch (error) {
        console.error(`Error en la solicitud: ${error.message}`);
    }
});