function camposVacios(datos) {

   

    let institucionhistoricoedit = document.getElementById('hiddenInputeditar');
    let cargohistoricoedit = document.getElementById('cargohistoricoedit');
    let fechainiciohistorialedit = document.getElementById('fecha-iniciohistorialedit');
    let fechaculminacionhistorialedit = document.getElementById('fecha-culminacionhistorialedit');
    

    const institucionhistoricovalue = institucionhistoricoedit.value.trim();
    const cargohistoricovalue = cargohistoricoedit.value.trim();
    const fechainiciohistorialvalue = fechainiciohistorialedit.value.trim();
    const fechaculminacionhistorialvalue = fechaculminacionhistorialedit.value.trim();

    let hayCamposVacios = false;

	//--------------------validando los inputs

    if (institucionhistoricovalue == "") {
		setErrorFor(institucionhistoricoedit, 'Ingrese la Intitucion');
		hayCamposVacios = true;
	} else {
		setSuccessFor(institucionhistoricoedit);
	}

    if (cargohistoricovalue == "") {
		setErrorFor(cargohistoricoedit, 'Ingrese el Cargo');
		hayCamposVacios = true;
	} else {
		setSuccessFor(cargohistoricoedit);
	}

    if (fechainiciohistorialvalue == "") {
		setErrorFor(fechainiciohistorialedit, 'Ingrese Fecha de Inicio');
		hayCamposVacios = true;
	} else {
		setSuccessFor(fechainiciohistorialedit);
	}

    // Agrega más condiciones aquí para los otros campos

    return hayCamposVacios;
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.classList.add('errorinput'); // Agrega la clase 'errorinput'
	small.innerText = message;
  }
  
  function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.classList.remove('errorinput');
	formControl.classList.add('successinput');
  
  }

  

  const formdatahii = document.querySelector("#formeditarhistorial");
  formdatahii.addEventListener("submit", (e) => {
      e.preventDefault();

      document.getElementById('hiddenInputeditar').value = document.getElementById('institucionhistoricoedit').dataset.value;
      
      let idpersondaupdate = localStorage.getItem("idpesonaid");
      console.log(idpersondaupdate);
  
      document.getElementById("idpersonahistorialedit").value = idpersondaupdate;
  
      const datos = new FormData(document.getElementById("formeditarhistorial"));

          //validar campos vacios
    if (camposVacios(datos)) {
		//console.log('Hay campos vacíos');
		return;
	}
  
      let url = "../controlador/ctr-historial.php?op=update";
  
      fetch(url, {
          method: 'POST',
          body: datos
      })
      .then(response => response.json())
      .then(respuesta => {
          console.log(respuesta);

            var status = respuesta.status;
            var datos = respuesta.data;

            switch (status){
            case 'fechaculm_es_menor_afechainicio':
               
                swal.fire({
                    title: "¡Fecha de Culminacion es Menor a Fecha de Inicio!",
                    icon: "error",
                });
                break;

            case 'modificacion_historico_exitoso':
               
               formdatahii.reset();
                mostrarHistorialLaboral();
                $('#modal-editar-historial').modal("hide");
                swal.fire({
                    title: "¡Modificacion de Historial Exitoso!",
                    icon: "success",
                });
                break;
            }

      })
      .catch(error => {
          console.log(error);
      });
  });


var modal2editar = document.getElementById("myModal2editar");
var btn2editar = document.getElementById("myBtn2editar");
var span2editar= document.getElementsByClassName("close2editar")[0];
var backgroundeditar = document.getElementById("backgroundeditar");


btn2editar.onclick = function() {
  modal2editar.style.display = "block";
  backgroundeditar.style.display = "block";
  
  // Agrega la animación fadeIneditar a backgroundeditar
  backgroundeditar.style.animationName = "fadeIneditar";
  backgroundeditar.style.animationDuration = "0.18s";
  
  modal2editar.style.animationName = "bounceIneditar";
}

span2editar.onclick = function() {
  // Elimina la animación bounceOuteditar
  //modal2editar.style.animationName = "";
  modal2editar.style.animationName = "bounceOuteditar";
  modal2editar.style.animationDuration = "0.20s";
  
  
  // Oculta el modal inmediatamente
 // modal2editar.style.display = "none";
    backgroundeditar.style.animationName = "fadeOuteditar";
  backgroundeditar.style.animationDuration = "0.18s";

    modal2editar.addEventListener('animationend', function() {
    modal2editar.style.display = "none";
  }, {once: true}); // El evento se eliminará después de que se ejecute una vez

  backgroundeditar.addEventListener('animationend', function() {
    backgroundeditar.style.display = "none"; // Oculta el fondo después de que la animación haya terminado
  }, {once: true});
  
  // Agrega la animación fadeOut al backgroundeditar
  /*backgroundeditar.style.animationName = "fadeOuteditar";
  backgroundeditar.style.animationDuration = "0.18s";
   backgroundeditar.style.display = "none";*/
}
