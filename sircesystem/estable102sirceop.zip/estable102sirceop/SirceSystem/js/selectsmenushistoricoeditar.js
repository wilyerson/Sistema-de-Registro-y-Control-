    fetch('../controlador/institucionesfetch.php')
        .then(response => response.json())
        .then(data => {

            const wrappereditar = document.querySelector(".wrappereditar"),
selectBtneditar = wrappereditar.querySelector(".select-btneditar"),
searchInpeditar = wrappereditar.querySelector(".searcheditar input"),
optionseditar = wrappereditar.querySelector(".optionseditar");



function addCountryEditar(selectedCountry) {
    optionseditar.innerHTML = "";
    data.forEach(institucion => {
        let isSelected = institucion.NombreInstitucion == selectedCountry ? "selected" : "";
        let li = `<li onclick="updateNameEditar(this)" class="${isSelected}" data-value="${institucion.CodigoInstituciones}" >${institucion.NombreInstitucion}</li>`;
        optionseditar.insertAdjacentHTML("beforeend", li);
    });
}
addCountryEditar();

window.updateNameEditar = (selectedLi) => {
    
  
    wrappereditar.classList.remove("active");
    selectBtneditar.firstElementChild.innerText = selectedLi.innerText;
    selectBtneditar.firstElementChild.dataset.value = selectedLi.dataset.value; 
};

/*searchInpeditar.addEventListener("keyup", () => {
    let arr = [];
    let searchWord = searchInpeditar.value.toLowerCase();
    arr = data.filter(institucion => {
        return institucion.NombreInstitucion.toLowerCase().startsWith(searchWord);
    }).map(institucion => {
        let isSelected = institucion.NombreInstitucion == selectBtneditar.firstElementChild.innerText ? "selected" : "";
        return `<li onclick="updateNameEditar(this)" class="${isSelected}" data-value="${institucion.CodigoInstituciones}">${institucion.NombreInstitucion}</li>`;
    }).join("");
    optionseditar.innerHTML = arr ? arr : `<p style="margin-top: 10px;">No esta Registrada esa Institucion</p>`;
});*/

selectBtneditar.addEventListener("click", () => wrappereditar.classList.toggle("active"));

        })
        .catch(error => console.error('Error:', error));

// Variable para rastrear si #contentlista está mostrándose
let isContentlistaVisibleeditar = false;

// Muestra el elemento #contentlista cuando se hace clic en .select-btn, a menos que ya esté visible
$('.select-btneditar').click(function(event) {
    event.stopPropagation();
    if (isContentlistaVisibleeditar) {
        $('#contentlistaeditar').hide();
        isContentlistaVisibleeditar = false;
    } else {
        $('#contentlistaeditar').show();
        isContentlistaVisibleeditar = true;
    }
});

// Oculta el elemento #contentlista cuando se hace clic en cualquier parte de la página que no sea .select-btn o .search
$(document).click(function(event) {
    var target = $(event.target);
    if (!target.closest('.select-btneditar').length && !target.closest('.searcheditar').length && !target.closest('#contentlistaeditar').length) {
        $('#contentlistaeditar').hide();
        isContentlistaVisibleeditar = false;
    }
});

$('.optionseditar').click(function(event) {
    event.stopPropagation();
    $('#contentlistaeditar').hide();
    isContentlistaVisibleeditar = false;
});

