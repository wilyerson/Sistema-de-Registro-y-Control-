<?php
 
	require_once "../modelo/ModeloInstitucionselect.php";

	$tabla_instituciones = new institucion();
	$instituciones = $tabla_instituciones->obtener_instituciones_select();

	echo json_encode($instituciones);
 ?>