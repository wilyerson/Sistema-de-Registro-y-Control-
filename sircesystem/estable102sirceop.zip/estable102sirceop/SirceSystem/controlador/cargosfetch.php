<?php
 
	require_once "../modelo/ModeloCargosselect.php";

	$tabla_cargos = new Cargo();
	$cargos = $tabla_cargos->obtener_cargos_select();


 ?>