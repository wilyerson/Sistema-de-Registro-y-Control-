-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 29, 2024 at 10:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sirceop`
--
CREATE DATABASE sirceop;
USE sirceop;
-- --------------------------------------------------------

--
-- Table structure for table `archivos`
--

CREATE TABLE `archivos` (
  `ArchivoRegistro` int(10) NOT NULL,
  `CodigoDocumento` int(10) NOT NULL,
  `idperarchivos` int(10) NOT NULL,
  `archivosjpg` text NOT NULL,
  `idusuario` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `archivos`
--

INSERT INTO `archivos` (`ArchivoRegistro`, `CodigoDocumento`, `idperarchivos`, `archivosjpg`, `idusuario`) VALUES
(1, 8, 1, 'imagenes/590054c0-dc7e-4cd8-9ce6-41da51435347.jpg', 0),
(2, 1, 1, 'imagenes/8aa4ff22-5857-4aee-95e0-672c472c87c8.jpg', 0),
(3, 1, 9, 'imagenes/leon.jpg', 0),
(4, 8, 9, 'imagenes/9/leon1.jpg', 0),
(5, 14, 9, 'imagenes/9/422145271_349365321327281_3848567651902845081_n.jpg', 0),
(6, 1, 5, 'imagenes/5/Capture001.jpg', 0),
(7, 2, 9, 'imagenes/9/Capture001.jpg', 0),
(8, 14, 5, 'imagenes/5/leon1.jpg', 0),
(9, 2, 5, 'imagenes/5/leon.jpg', 0),
(10, 5, 5, 'imagenes/5/422145271_349365321327281_3848567651902845081_n.jpg', 0),
(14, 7, 44, 'imagenes/44/leon1.jpg', 2),
(15, 1, 44, 'imagenes/44/leon.jpg', 2),
(16, 8, 44, 'imagenes/44/Capture001.jpg', 2),
(17, 1, 59, 'imagenes/59/leon1.jpg', 2),
(18, 8, 67, 'imagenes/67/2560_3000.jpg', 2),
(19, 13, 5, 'imagenes/5/documento.jpg', 2),
(27, 8, 68, 'imagenes/68/leon.jpg', 2),
(28, 11, 9, 'imagenes/9/4444.JPG', 2),
(29, 1, 68, 'imagenes/68/leon1.jpg', 2),
(30, 10, 9, 'imagenes/9/Capturaerror8.JPG', 2);

--
-- Triggers `archivos`
--
DELIMITER $$
CREATE TRIGGER `ArchivoInsert` AFTER INSERT ON `archivos` FOR EACH ROW BEGIN
   DECLARE trabajador_cedula VARCHAR(55);
   DECLARE doc_nombre VARCHAR(55);

   SELECT CedulaPersona INTO trabajador_cedula FROM persona WHERE CodigoPersona = NEW.idperarchivos;   
   SELECT NombreDocumento INTO doc_nombre FROM documento WHERE CodigoDocumento = NEW.CodigoDocumento;

   INSERT INTO bitacora (CodigoPersona, Fecha, idUsuario, ActividadRealizada, InformacionActual) 
   VALUES (trabajador_cedula, NOW(), NEW.idusuario, 'Se Registro nuevo Documento', CONCAT('Tipo de Documento: ', doc_nombre));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `bitacora`
--

CREATE TABLE `bitacora` (
  `CodigoBitacora` int(11) NOT NULL,
  `CodigoPersona` varchar(11) NOT NULL,
  `Fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `idUsuario` int(11) NOT NULL,
  `ActividadRealizada` varchar(70) NOT NULL,
  `InformacionActual` text DEFAULT NULL,
  `InformacionAnterior` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bitacora`
--

INSERT INTO `bitacora` (`CodigoBitacora`, `CodigoPersona`, `Fecha`, `idUsuario`, `ActividadRealizada`, `InformacionActual`, `InformacionAnterior`) VALUES
(1, '1', '2024-02-27 10:02:08', 1, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 1 Usuario: APOLOENDYS', NULL),
(2, '1', '2024-02-27 10:02:18', 1, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 1 Usuario: APOLOENDYS', NULL),
(3, '1', '2024-02-27 10:02:43', 1, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 1 Usuario: APOLOENDYS', NULL),
(4, '7847', '2024-02-27 10:41:10', 1, 'Se Registro nuevo Usuario', 'Datos del Usuario: 7847 weruser analista', NULL),
(5, '34234237', '2024-02-27 15:06:58', 1, 'Se Registro nuevo Usuario', 'Datos del Usuario: 34234237 rter analista', NULL),
(6, '34234237', '2024-02-27 15:12:00', 1, 'Se Registro nuevo Usuario', 'Datos del Usuario: 34234237 rtrt analista', NULL),
(7, '1', '2024-02-27 15:12:11', 1, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 1 Usuario: APOLOENDYS', NULL),
(18, '34234237', '2024-02-27 15:13:12', 1, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 34234237 rtrt administrador', NULL),
(19, '34234237', '2024-02-27 15:13:22', 1, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 34234237 rt administrador', NULL),
(20, '34234237', '2024-02-27 15:13:28', 1, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 34234237 rt administrador', NULL),
(21, '34234237', '2024-02-27 15:14:00', 1, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 34234237 mysql administrador', NULL),
(22, '7', '2024-02-27 15:14:04', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: rtrt', NULL),
(23, '7', '2024-02-27 15:14:10', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(24, '7847', '2024-02-27 15:45:26', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 7847 weruser analista', NULL),
(25, '7847', '2024-02-27 15:47:24', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 7847 werr analista', NULL),
(26, '7847', '2024-02-27 15:51:07', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 7847 wer analista', NULL),
(27, '7847', '2024-02-27 17:13:32', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 7847 weruser analista', NULL),
(28, '7', '2024-02-27 17:49:15', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(29, '2', '2024-02-27 17:52:22', 2, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 2 Usuario: msql', NULL),
(30, '7', '2024-02-27 17:52:28', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(31, '7847', '2024-02-27 17:53:49', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 7847 weruser analista', NULL),
(32, '7', '2024-02-27 17:54:19', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(33, '7', '2024-02-27 17:59:31', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(34, '7847', '2024-02-27 18:00:04', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 7847 eeee analista', NULL),
(35, '7847', '2024-02-27 18:02:16', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 7847 1111 analista', NULL),
(36, '7', '2024-02-27 18:02:20', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(38, '7', '2024-02-27 18:32:01', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(39, '7', '2024-02-27 18:32:52', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(40, '7', '2024-02-27 18:37:15', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(41, '7', '2024-02-27 18:37:40', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(42, '7', '2024-02-27 18:41:28', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(43, '7', '2024-02-27 18:46:27', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(44, '7', '2024-02-28 09:23:41', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(45, '234324', '2024-02-28 09:26:36', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 eeee analista', NULL),
(46, '7', '2024-02-28 09:26:52', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(47, '7', '2024-02-28 09:32:11', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(48, '7', '2024-02-28 09:32:30', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(49, '7', '2024-02-28 09:33:04', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(50, '234324', '2024-02-28 09:33:55', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(51, '234324', '2024-02-28 09:35:18', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(52, '234324', '2024-02-28 09:36:27', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(53, '234324', '2024-02-28 09:38:45', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(54, '234324', '2024-02-28 09:41:17', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(55, '7', '2024-02-28 09:42:21', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(56, '234324', '2024-02-28 11:19:09', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(57, '234324', '2024-02-28 11:19:13', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(58, '234324', '2024-02-28 11:19:15', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(59, '234324', '2024-02-28 11:19:16', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(60, '234324', '2024-02-28 11:19:22', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(61, '234324', '2024-02-28 11:19:26', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(62, '234324', '2024-02-28 11:19:51', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(63, '234324', '2024-02-28 11:19:51', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(64, '234324', '2024-02-28 11:19:55', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(65, '7', '2024-02-28 11:35:23', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(66, '234324', '2024-02-28 11:35:31', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(67, '234324', '2024-02-28 11:35:31', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(68, '234324', '2024-02-28 11:35:33', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(69, '234324', '2024-02-28 11:35:33', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 234324 rrrr analista', NULL),
(70, '234324', '2024-02-28 11:36:28', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 eeee analista', NULL),
(71, '234324', '2024-02-28 11:44:17', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 eeee analista', NULL),
(72, '234324', '2024-02-28 11:49:52', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 eeee analista', NULL),
(73, '234324', '2024-02-28 11:53:03', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 eeee analista', NULL),
(74, '7', '2024-02-28 11:54:51', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(77, '7', '2024-02-28 12:05:51', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(78, '234324', '2024-02-28 12:14:08', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 eeee analista', NULL),
(79, '234324', '2024-02-28 12:15:45', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 eeee analista', NULL),
(80, '234324', '2024-02-28 12:16:28', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 eeee analista', NULL),
(81, '234324', '2024-02-28 12:17:31', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 eeee consulta', NULL),
(82, '234324', '2024-02-28 12:26:38', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 234324 eeee analista', NULL),
(83, '7', '2024-02-28 13:21:16', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(85, '7457', '2024-02-28 17:43:32', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 7457 react analista', NULL),
(86, '7457', '2024-02-28 17:44:25', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 7457 react analista', NULL),
(87, '7457', '2024-02-28 17:45:32', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 7457 reacte analista', NULL),
(88, '7457', '2024-02-28 17:45:47', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 7457 react analista', NULL),
(89, '7', '2024-02-28 17:53:32', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(90, '7', '2024-02-28 17:54:56', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(91, '7', '2024-02-28 18:02:19', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(92, '7', '2024-02-28 18:23:06', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(93, '23423', '2024-02-28 18:50:07', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 23423 tttt analista', NULL),
(94, '23423', '2024-02-28 18:51:09', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 23423 tttt analista', NULL),
(95, '23423', '2024-02-28 18:51:43', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 23423 tttt analista', NULL),
(96, '23423', '2024-02-28 18:53:45', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 23423 tttt analista', NULL),
(97, '23423', '2024-02-28 18:56:22', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 23423 tttt analista', NULL),
(98, '23423', '2024-02-28 19:06:56', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 23423 tttt consulta', NULL),
(99, '23423', '2024-02-28 19:16:28', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 23423 rrrr analista', NULL),
(100, '123', '2024-02-28 20:11:25', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 123 erer erer', NULL),
(101, '234324', '2024-02-28 20:11:25', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Hijo 123', NULL),
(102, '23423', '2024-02-28 20:15:54', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 23423 reactt analista', NULL),
(103, '23423', '2024-02-28 20:17:09', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 23423 reactt analista', NULL),
(104, '23423', '2024-02-28 20:25:04', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 23423 reactt consulta', NULL),
(105, '23423', '2024-02-28 20:27:45', 7, 'Se Registro nuevo Usuario', 'Datos del Usuario: 23423 reactvs analista', NULL),
(106, '23423', '2024-02-28 20:30:52', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 23423 reactvs analista', NULL),
(107, '23423', '2024-02-28 20:37:13', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 23423 reactvs analista', NULL),
(108, '23423', '2024-02-28 20:37:31', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 23423 reactvs analista', NULL),
(109, '23423', '2024-02-28 20:37:38', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 23423 reac analista', NULL),
(110, '232', '2024-02-28 20:39:20', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 232 msql analista', NULL),
(111, '232', '2024-02-28 20:39:24', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 232 msql analista', NULL),
(112, '7', '2024-02-28 20:56:25', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(113, '7', '2024-02-28 21:41:48', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(114, '7', '2024-02-28 21:56:38', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(115, '7', '2024-02-29 08:41:48', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(121, '4545783', '2024-02-29 09:11:42', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 4545783 nieto er nieto ape', NULL),
(122, '234324', '2024-02-29 09:11:42', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Nieto 4545783', NULL),
(123, '565555', '2024-02-29 09:14:53', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 565555 rtrt rtrt', NULL),
(124, '234324', '2024-02-29 09:14:53', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Abuelo 565555', NULL),
(125, '565577', '2024-02-29 09:16:25', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 565577 rtrt rtrt', NULL),
(126, '234324', '2024-02-29 09:16:25', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Abuelo 565577', NULL),
(127, '556677', '2024-02-29 09:19:11', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 556677 ttyy ttyy e', NULL),
(128, '234324', '2024-02-29 09:19:11', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Nieto 556677', NULL),
(129, '5566776', '2024-02-29 09:19:42', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 5566776 ttyy ttyy e', NULL),
(130, '234324', '2024-02-29 09:19:42', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Nieto 5566776', NULL),
(131, '556677623', '2024-02-29 09:20:09', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 556677623 ttyy ttyy e', NULL),
(132, '234324', '2024-02-29 09:20:09', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Nieto 556677623', NULL),
(133, '556677', '2024-02-29 09:21:40', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 556677 ttyy ttyy y', NULL),
(134, '234324', '2024-02-29 09:21:40', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Abuela 556677', NULL),
(135, '12345', '2024-02-29 09:31:11', 7, 'Se Modifico una Persona', 'Datos de la Persona: 12345 erer erer', NULL),
(136, '234324', '2024-02-29 09:31:11', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Nieto 12345', NULL),
(137, '12345', '2024-02-29 09:31:18', 7, 'Se Modifico una Persona', 'Datos de la Persona: 12345 erer erer', NULL),
(138, '234324', '2024-02-29 09:31:18', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Nieto 12345', NULL),
(139, '12345', '2024-02-29 09:31:23', 7, 'Se Modifico una Persona', 'Datos de la Persona: 12345 erer erer', NULL),
(140, '234324', '2024-02-29 09:31:23', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Hijo 12345', NULL),
(141, '12345', '2024-02-29 09:40:41', 7, 'Se Modifico una Persona', 'Datos de la Persona: 12345 erer erer', NULL),
(142, '234324', '2024-02-29 09:40:41', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Abuelo 12345', NULL),
(143, '34', '2024-02-29 09:41:15', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 34 rr rr', NULL),
(144, '234324', '2024-02-29 09:41:15', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Nieto 34', NULL),
(145, '232344', '2024-02-29 10:05:56', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 232344 rrtt ttrr', NULL),
(146, '234324', '2024-02-29 10:05:57', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Nieto 232344', NULL),
(147, '2323445', '2024-02-29 10:06:39', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 2323445 rrttt ttrre', NULL),
(148, '234324', '2024-02-29 10:06:39', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Nieto 2323445', NULL),
(149, '23235', '2024-02-29 10:13:10', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 23235 ertert erterter', NULL),
(150, '234324', '2024-02-29 10:13:10', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Hija 23235', NULL),
(151, '778855', '2024-02-29 10:23:32', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 778855 tt tt', NULL),
(152, '234324', '2024-02-29 10:23:32', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Nieto 778855', NULL),
(153, '7788553', '2024-02-29 10:24:13', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 7788553 tt tt', NULL),
(154, '234324', '2024-02-29 10:24:14', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Nieto 7788553', NULL),
(155, '7733', '2024-02-29 10:24:52', 7, 'Se Registro nueva Persona', 'Datos de la Persona: 7733 kk kk', NULL),
(156, '234324', '2024-02-29 10:24:52', 7, 'Se Registro nuevo Familiar', 'Datos del Familiar: Hijo 7733', NULL),
(157, '7733', '2024-02-29 10:32:13', 7, 'Se Modifico una Persona', 'Datos de la Persona: 7733 kk kk', NULL),
(158, '234324', '2024-02-29 10:32:14', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Hijo 7733', NULL),
(159, '7733', '2024-02-29 10:32:19', 7, 'Se Modifico una Persona', 'Datos de la Persona: 7733 kk kk', NULL),
(160, '234324', '2024-02-29 10:32:19', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Hijo 7733', NULL),
(161, '7733', '2024-02-29 10:57:45', 7, 'Se Modifico una Persona', 'Datos de la Persona: 7733 kk kk', NULL),
(162, '234324', '2024-02-29 10:57:45', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Hijo 7733', NULL),
(163, '7788553', '2024-02-29 10:57:51', 7, 'Se Modifico una Persona', 'Datos de la Persona: 7788553 tt tt', NULL),
(164, '234324', '2024-02-29 10:57:52', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Nieto 7788553', NULL),
(165, '778855', '2024-02-29 10:57:56', 7, 'Se Modifico una Persona', 'Datos de la Persona: 778855 tt tt', NULL),
(166, '234324', '2024-02-29 10:57:56', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Nieto 778855', NULL),
(167, '', '2024-02-29 10:58:23', 7, 'Se Modifico una Persona', 'Datos de la Persona:  tt tt', NULL),
(168, '234324', '2024-02-29 10:58:23', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Nieto ', NULL),
(169, '778855', '2024-02-29 10:58:34', 7, 'Se Modifico una Persona', 'Datos de la Persona: 778855 tt tt', NULL),
(170, '234324', '2024-02-29 10:58:34', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Nieto 778855', NULL),
(171, '778855', '2024-02-29 11:05:13', 7, 'Se Modifico una Persona', 'Datos de la Persona: 778855 tt tt', NULL),
(172, '234324', '2024-02-29 11:05:13', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Nieto 778855', NULL),
(173, '7733', '2024-02-29 11:05:49', 7, 'Se Modifico una Persona', 'Datos de la Persona: 7733 kk kk', NULL),
(174, '234324', '2024-02-29 11:05:50', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Hijo 7733', NULL),
(175, '7733', '2024-02-29 11:06:02', 7, 'Se Modifico una Persona', 'Datos de la Persona: 7733 kk kk', NULL),
(176, '234324', '2024-02-29 11:06:02', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Hermano 7733', NULL),
(177, '7733', '2024-02-29 11:06:09', 7, 'Se Modifico una Persona', 'Datos de la Persona: 7733 kk kk', NULL),
(178, '234324', '2024-02-29 11:06:09', 7, 'Se Modifico un Familiar', 'Datos del Familiar: Hijo 7733', NULL),
(179, '7', '2024-02-29 11:25:30', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(180, '7', '2024-02-29 14:28:00', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(181, '7', '2024-02-29 14:28:07', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(182, '7', '2024-02-29 14:28:49', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(183, '232', '2024-02-29 14:29:43', 7, 'Se Modifico nuevo Usuario', 'Datos del Usuario: 232 msql analista', NULL),
(184, '7', '2024-02-29 15:29:27', 7, 'Cierre de Sesion', 'Datos de Cierre de sesion Id: 7 Usuario: mysql', NULL),
(185, '7', '2024-02-29 15:29:32', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL),
(186, '7', '2024-02-29 17:06:22', 7, 'Inicio de Sesion', 'Datos de inicio de sesion Id: 7 Usuario: mysql', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cargos`
--

CREATE TABLE `cargos` (
  `CodigoCargo` int(10) NOT NULL,
  `NombreCargo` varchar(40) NOT NULL,
  `TipoCargo` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cargos`
--

INSERT INTO `cargos` (`CodigoCargo`, `NombreCargo`, `TipoCargo`) VALUES
(1, 'Bachiller I', 1),
(2, 'Bachiller II', 1),
(3, 'Bachiller III', 1),
(4, 'TSU I', 1),
(5, 'TSU II', 1),
(6, 'Profesional I', 1),
(7, 'Profesional II', 1),
(8, 'Profesional III', 1),
(9, 'Obrero Grado  1', 11),
(10, 'Obrero Grado  2', 11),
(11, 'Obrero Grado  3', 11),
(12, 'Obrero Grado  4', 11),
(13, 'Obrero Grado  5', 11),
(14, 'Obrero Grado  6', 11),
(15, 'Obrero Grado  7', 11),
(16, 'Obrero Grado  8', 11),
(17, 'Obrero Grado  9', 11),
(18, 'Obrero Grado  10', 11),
(19, 'Jefe de Departamento', 10),
(20, 'Jefe de División', 10),
(21, 'Director de Linea', 10),
(22, 'Director General', 10),
(23, 'Secretario General de gobierno', 10),
(24, 'Gobernador', 10);

-- --------------------------------------------------------

--
-- Table structure for table `documento`
--

CREATE TABLE `documento` (
  `CodigoDocumento` int(10) NOT NULL,
  `NombreDocumento` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `documento`
--

INSERT INTO `documento` (`CodigoDocumento`, `NombreDocumento`) VALUES
(7, 'asignacion de trabajado'),
(8, 'boleta de vacaciones'),
(9, 'carta de renuncia'),
(1, 'cedula'),
(10, 'comision de servicio asignado'),
(5, 'cuenta bancaria'),
(2, 'curriculum'),
(14, 'decreto de ascenso'),
(15, 'decreto de jubilacion'),
(13, 'decreto de nombramiento'),
(3, 'partida de nacimiento'),
(12, 'permiso no remunerado'),
(11, 'permiso remunerado'),
(4, 'r.i.f.'),
(6, 'titulo obtenido');

-- --------------------------------------------------------

--
-- Table structure for table `familiar`
--

CREATE TABLE `familiar` (
  `CodigoRegistroFamiliar` int(10) NOT NULL,
  `Trabajador` int(10) NOT NULL,
  `Familiar` int(10) NOT NULL,
  `Parentesco` varchar(20) NOT NULL,
  `idusuario` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `familiar`
--

INSERT INTO `familiar` (`CodigoRegistroFamiliar`, `Trabajador`, `Familiar`, `Parentesco`, `idusuario`) VALUES
(1, 5, 26, 'Abuelo', 2),
(2, 9, 27, 'Hijo', 2),
(3, 5, 28, 'Hijo', 2),
(17, 59, 60, 'Hijo', 2),
(18, 9, 62, 'Hijo', 2),
(19, 68, 69, 'Nieto', 2),
(20, 9, 72, 'Nieta', 2),
(22, 9, 87, 'Hijo', 2),
(24, 9, 89, 'Hija', 2),
(25, 9, 90, 'Nieto', 2),
(27, 9, 93, 'Nieto', 2),
(28, 43, 95, 'Abuelo', 7),
(40, 43, 107, 'Nieto', 7),
(41, 43, 108, 'Nieto', 7),
(42, 43, 109, 'Hijo', 7);

--
-- Triggers `familiar`
--
DELIMITER $$
CREATE TRIGGER `FamiliarInsert` AFTER INSERT ON `familiar` FOR EACH ROW BEGIN
   DECLARE trabajador_cedula VARCHAR(55);
   DECLARE familiar_cedula VARCHAR(55);
   
   
   SELECT CedulaPersona INTO trabajador_cedula FROM persona WHERE CodigoPersona = NEW.Trabajador;
   SELECT CedulaPersona INTO familiar_cedula FROM persona WHERE CodigoPersona = NEW.Familiar;
   
   
   INSERT INTO bitacora (CodigoPersona, Fecha, idUsuario, ActividadRealizada, InformacionActual) 
   VALUES (trabajador_cedula, NOW(), NEW.idusuario, 'Se Registro nuevo Familiar', CONCAT('Datos del Familiar: ', NEW.Parentesco,' ',familiar_cedula));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `FamiliarUpdate` AFTER UPDATE ON `familiar` FOR EACH ROW BEGIN
   DECLARE trabajador_cedula VARCHAR(55);
   DECLARE familiar_cedula VARCHAR(55);
   
   
   SELECT CedulaPersona INTO trabajador_cedula FROM persona WHERE CodigoPersona = NEW.Trabajador;
   SELECT CedulaPersona INTO familiar_cedula FROM persona WHERE CodigoPersona = NEW.Familiar;
   
   
   INSERT INTO bitacora (CodigoPersona, Fecha, idUsuario, ActividadRealizada, InformacionActual) 
   VALUES (trabajador_cedula, NOW(), NEW.idusuario, 'Se Modifico un Familiar', CONCAT('Datos del Familiar: ', NEW.Parentesco,' ',familiar_cedula));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `historico`
--

CREATE TABLE `historico` (
  `CodigoHistorico` int(10) NOT NULL,
  `Cargo` int(10) NOT NULL,
  `FechaInicio` date NOT NULL,
  `FechaCulminacion` date DEFAULT NULL,
  `Obervacion` varchar(120) NOT NULL,
  `InstitucionHistorico` int(10) NOT NULL,
  `personal` int(10) NOT NULL,
  `idusuario` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `historico`
--

INSERT INTO `historico` (`CodigoHistorico`, `Cargo`, `FechaInicio`, `FechaCulminacion`, `Obervacion`, `InstitucionHistorico`, `personal`, `idusuario`) VALUES
(1, 2, '1995-01-01', '1995-02-02', 'tetris', 28, 5, 2),
(2, 1, '1995-01-01', '1995-02-02', 'er', 28, 68, 2);

--
-- Triggers `historico`
--
DELIMITER $$
CREATE TRIGGER `HistoricoInsert` AFTER INSERT ON `historico` FOR EACH ROW BEGIN
   DECLARE trabajador_cedula VARCHAR(55);
   DECLARE int_nombre VARCHAR(55);
   DECLARE cargo_nombre VARCHAR(55);
   
   SELECT CedulaPersona INTO trabajador_cedula FROM persona WHERE CodigoPersona = NEW.personal;
   SELECT NombreInstitucion INTO int_nombre FROM instituciones WHERE CodigoInstituciones = NEW.InstitucionHistorico;
   SELECT NombreCargo INTO cargo_nombre FROM cargos WHERE CodigoCargo = NEW.Cargo;
   
   INSERT INTO bitacora (CodigoPersona, Fecha, idUsuario, ActividadRealizada, InformacionActual) 
   VALUES (trabajador_cedula, NOW(), NEW.idusuario, 'Se Registro nuevo Historial', CONCAT('Datos del Historial: ', int_nombre,' ',cargo_nombre));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `HistoricoUpdate` AFTER UPDATE ON `historico` FOR EACH ROW BEGIN
   DECLARE trabajador_cedula VARCHAR(55);
   DECLARE int_nombre VARCHAR(55);
   DECLARE cargo_nombre VARCHAR(55);
   
   SELECT CedulaPersona INTO trabajador_cedula FROM persona WHERE CodigoPersona = NEW.personal;
   SELECT NombreInstitucion INTO int_nombre FROM instituciones WHERE CodigoInstituciones = NEW.InstitucionHistorico;
   SELECT NombreCargo INTO cargo_nombre FROM cargos WHERE CodigoCargo = NEW.Cargo;
   
   INSERT INTO bitacora (CodigoPersona, Fecha, idUsuario, ActividadRealizada, InformacionActual) 
   VALUES (trabajador_cedula, NOW(), NEW.idusuario, 'Se Modifico un Historial', CONCAT('Datos del Historial: ', int_nombre,' ',cargo_nombre));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `instituciones`
--

CREATE TABLE `instituciones` (
  `CodigoInstituciones` int(10) NOT NULL,
  `NombreInstitucion` varchar(50) NOT NULL,
  `CodigoRegistro` varchar(50) NOT NULL,
  `Sector` varchar(50) NOT NULL,
  `Direccion` varchar(50) NOT NULL,
  `ParroquiaInstitucion` int(10) NOT NULL,
  `idusuario` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `instituciones`
--

INSERT INTO `instituciones` (`CodigoInstituciones`, `NombreInstitucion`, `CodigoRegistro`, `Sector`, `Direccion`, `ParroquiaInstitucion`, `idusuario`) VALUES
(11, 'La Inmaculada', 'C1223', 'valentin valiente', 'Avenida Carupano', 51, 0),
(12, 'pdvsaa', '1651515', 'gtav', 'nonononono', 41, 0),
(28, 'caipe', 'c288', '', 'direccion pdvsa', 39, 0),
(38, 'wewe', 'we', 'wew', 'we', 23, 2);

--
-- Triggers `instituciones`
--
DELIMITER $$
CREATE TRIGGER `InstitucionInsert` AFTER INSERT ON `instituciones` FOR EACH ROW BEGIN 


INSERT INTO bitacora(CodigoPersona, idUsuario,ActividadRealizada,InformacionActual)VALUES
(NEW.CodigoRegistro,NEW.idusuario,'Se Registro nueva Institucion',concat('Datos de la Institucion: ' ,NEW.CodigoRegistro,' ',NEW.NombreInstitucion));


END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `InstitucionUpdate` AFTER UPDATE ON `instituciones` FOR EACH ROW BEGIN 


INSERT INTO bitacora(CodigoPersona, idUsuario,ActividadRealizada,InformacionActual)VALUES
(NEW.CodigoRegistro,NEW.idusuario,'Se Modifico una Institucion',concat('Datos de la Institucion: ' ,NEW.CodigoRegistro,' ',NEW.NombreInstitucion));


END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `municipio`
--

CREATE TABLE `municipio` (
  `CodigoMunicipio` int(10) NOT NULL,
  `NombreMunicipio` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `municipio`
--

INSERT INTO `municipio` (`CodigoMunicipio`, `NombreMunicipio`) VALUES
(1, 'Andrés Eloy Blanco'),
(2, 'Andrés Mata'),
(3, 'Arismendi'),
(4, 'Benítez'),
(5, 'Bermúdez'),
(6, 'Bolívar'),
(7, 'Cajigal'),
(8, 'Cruz Salmerón Acosta'),
(9, 'Libertador'),
(10, 'Mariño'),
(11, 'Mejía'),
(12, 'Montes'),
(13, 'Ribero'),
(14, 'Sucre'),
(15, 'Valdez');

-- --------------------------------------------------------

--
-- Table structure for table `parroquia`
--

CREATE TABLE `parroquia` (
  `CodigoParroquia` int(10) NOT NULL,
  `NombreParroquia` varchar(50) NOT NULL,
  `MunicipioParroquia` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parroquia`
--

INSERT INTO `parroquia` (`CodigoParroquia`, `NombreParroquia`, `MunicipioParroquia`) VALUES
(1, 'Mariño', 1),
(2, 'Rómulo Gallegos', 1),
(3, 'San José de Areocuar', 2),
(4, 'Tavera Acosta', 2),
(5, 'Río Caribe', 3),
(6, 'Antonio José de Sucre', 3),
(7, 'El Morro de Puerto Santo', 3),
(8, 'Puerto Santo', 3),
(9, 'San Juan de las Galdonas', 3),
(10, 'El Pilar', 4),
(11, 'El Rincón', 4),
(12, 'General Francisco Antonio Vázquez', 4),
(13, 'Guaraúnos', 4),
(14, 'Tunapuicito', 4),
(15, 'Unión', 4),
(16, 'Santa Catalina', 5),
(17, 'Santa Rosa', 5),
(18, 'Santa Teresa', 5),
(19, 'Bolívar', 5),
(20, 'Maracapana', 5),
(21, 'Divina Misericordia', 5),
(22, 'Nuestra Señora De Lourdes', 5),
(23, 'Marigüitar', 6),
(24, 'Libertad', 7),
(25, 'El Paujil', 7),
(26, 'Yaguaraparo', 7),
(27, 'Araya', 8),
(28, 'Chacopata', 8),
(29, 'Manicuare', 8),
(30, 'Tunapuy', 9),
(31, 'Campo Elías', 9),
(32, 'Irapa', 10),
(33, 'Campo Claro', 10),
(34, 'Marabal', 10),
(35, 'San Antonio de Irapa', 10),
(36, 'Soro', 10),
(37, 'San Antonio del Golfo', 11),
(38, 'Cumanacoa', 12),
(39, 'Arenas', 12),
(40, 'Aricagua', 12),
(41, 'Cocollar', 12),
(42, 'San Fernando', 12),
(43, 'San Lorenzo', 12),
(44, 'Cariaco', 13),
(45, 'Catuaro', 13),
(46, 'Rendón', 13),
(47, 'Santa Cruz', 13),
(48, 'Santa María', 13),
(49, 'Altagracia', 14),
(50, 'Santa Inés', 14),
(51, 'Valentín Valiente', 14),
(52, 'Ayacucho', 14),
(53, 'San Juan', 14),
(54, 'Raúl Leoni', 14),
(55, 'Gran Mariscal', 14),
(56, 'Cristóbal Colón', 15),
(57, 'Bideau', 15),
(58, 'Punta de Piedras', 15),
(59, 'Güiria', 15);

-- --------------------------------------------------------

--
-- Table structure for table `persona`
--

CREATE TABLE `persona` (
  `CodigoPersona` int(10) NOT NULL,
  `CedulaPersona` varchar(10) NOT NULL DEFAULT '',
  `Nombres` varchar(50) NOT NULL,
  `Apellidos` varchar(50) NOT NULL,
  `FechaNacimiento` date NOT NULL,
  `Sexo` varchar(10) NOT NULL,
  `EstadoCivil` varchar(20) NOT NULL,
  `ParroquiaPersona` int(10) DEFAULT NULL,
  `Sector` varchar(50) NOT NULL,
  `Direccion` varchar(120) NOT NULL,
  `TelefonoPrincipal` varchar(20) NOT NULL,
  `TelefonoHabitacion` varchar(20) NOT NULL,
  `Peso` varchar(10) NOT NULL,
  `Estatura` varchar(10) NOT NULL,
  `TallaCamisa` varchar(5) NOT NULL,
  `TallaPantalon` varchar(5) NOT NULL,
  `TallaCalzado` varchar(5) NOT NULL,
  `CheckBoxPartidaNacimientoFami` varchar(5) NOT NULL,
  `idusuario` int(10) NOT NULL,
  `TipoPersona` varchar(20) NOT NULL,
  `EstatusPersonal` varchar(10) NOT NULL,
  `CorreoElectronico` varchar(85) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `persona`
--

INSERT INTO `persona` (`CodigoPersona`, `CedulaPersona`, `Nombres`, `Apellidos`, `FechaNacimiento`, `Sexo`, `EstadoCivil`, `ParroquiaPersona`, `Sector`, `Direccion`, `TelefonoPrincipal`, `TelefonoHabitacion`, `Peso`, `Estatura`, `TallaCamisa`, `TallaPantalon`, `TallaCalzado`, `CheckBoxPartidaNacimientoFami`, `idusuario`, `TipoPersona`, `EstatusPersonal`, `CorreoElectronico`) VALUES
(1, '26293417', 'Endys Leonel', 'Rodriguez Rodriguez', '1997-11-25', 'masculino', 'soltero', 5, 'Valentin Valiente', 'Urbanizacion Salvador allende, Torre 13, Piso 4, Apto n20', '04126949323', '04126949323', '74', '190', 'xl', '36', '44', '', 0, 'trabajador', 'inactivo', ''),
(2, '29652552', 'hijo endys', 'rodriguez', '2000-11-25', 'masculino', 'soltero', 37, 'Sector de San Antonio', 'calle verde, ali', '04126949323', '04126949323', '70', '190', 'xl', '36', '44', '', 0, 'familiar', 'inactivo', ''),
(4, '20293417', 'endys2', 'werwer', '1997-11-25', 'masculino', 'casado', 39, 'La playa', 'miami newyork', '04121231212', '04123121212', '80', '1.90', 'm', '2', '30', '', 0, 'personal', 'inactivo', ''),
(5, '21293417', 'erer', 'sdasdad', '1222-12-12', 'masculino', 'soltero', 46, '12312312123123', '3123123123', '122312312312', '123123123123', '123123', '12312', '12312', '1231', '23', '', 2, 'personal', 'inactivo', ''),
(9, '34234237', 'xbx', '784', '1955-01-01', 'masculino', 'soltero', 31, '', 'y', '324234324', '234234234', '', '', '', '', '', '', 2, 'personal', 'inactivo', ''),
(10, '32487474', 'rodolfo', 'rodriguez', '2008-01-04', 'masculino', 'soltero', 0, '', '', '123134564', '234234234', '', '', '', '', '', '', 0, 'personal', 'inactivo', ''),
(26, '22337', 'ps5 hijo es', 'pse ape', '2007-01-03', 'masculino', '', 45, 'sector miami', 'direccion miami', '234234', '234234', '2', '2', '1', '1', '1', '', 2, 'familiar', 'inactivo', ''),
(27, '7845', 'xx', 'ps', '2007-01-03', 'masculino', '', 45, 'sector miami', 'direccion miami', '234234', '234234', '2', '2', '1', '1', '1', '', 2, 'familiar', 'inactivo', ''),
(28, '12452', 'ps5 hijo holi', 'pse ape', '1995-01-03', 'masculino', '', 30, 'sector miami', 'direccion miami', '234234', '234234', '2', '2', '1', '1', '1', '', 2, 'familiar', 'inactivo', ''),
(36, '2277', 'angular', 'angular ape', '1997-02-02', 'masculino', 'soltero', 0, '', '', '325235235', '235325235', '', '', '', '', '', '', 0, 'personal', 'inactivo', ''),
(37, '44557', 'hijo de react', 'react ape', '2005-01-01', 'masculino', '', 46, 'secto', 'direccion', '43534534', '534534534', '7', '7', '1', '1', '1', '', 2, 'familiar', 'inactivo', ''),
(38, '1122', 'hijo de react', 'react ape', '2005-01-01', 'masculino', '', 46, 'secto', 'direccion', '43534534', '534534534', '7', '7', '1', '1', '1', '', 2, 'familiar', 'inactivo', ''),
(43, '234324', 'react js', 'react js ape', '1995-03-02', 'masculino', 'casado', 46, 'werwerwerwerwerwe', 'rewrwerwerewrewr', '423423423', '4234234234234', '3', '3', '3', '3', '3', '', 2, 'personal', 'inactivo', ''),
(44, '7847', 'werr', 'wer', '1955-01-01', 'masculino', 'soltero', 32, '', '', '23423423', '423423423', '', '', '', '', '', '', 2, 'personal', 'inactivo', ''),
(59, '7457', 'angular', 'angular p', '1995-02-03', 'masculino', 'soltero', 46, '', '', '4234234234', '23423423423', '', '', '', '', '', '', 2, 'personal', 'inactivo', ''),
(60, '2323', 'ps5 hijo hol', 'pse ape', '1995-01-03', 'masculino', '', 47, 'sector miami', 'direccion miami', '234234', '234234', '2', '2', '1', '1', '1', '', 2, 'familiar', 'inactivo', ''),
(62, '74577', 'ps5 hijo ', 'pse ape', '1950-01-03', 'masculino', '', 46, 'sector miami', 'direccion miami', '234234', '234234', '2', '2', '1', '1', '1', '', 2, 'familiar', 'inactivo', ''),
(67, '23255', 'erer', 'er', '1995-01-01', 'masculino', 'casado', NULL, '', '', '342342', '3423423423', '', '', '', '', '', '', 2, 'personal', 'inactivo', ''),
(68, '232', 'rt', 'rt', '1995-03-31', 'masculino', 'casado', 46, '', '', '2342342', '34234234', '', '', '', '', '', '', 2, 'personal', 'inactivo', ''),
(69, '23423', 'erw', 'werwer', '1995-01-01', 'masculino', '', 45, '', '', '234234', '234234', '', '', '', '', '', '', 2, 'familiar', 'inactivo', ''),
(89, '11223377', 'er', 'er', '1993-03-03', 'masculino', '', 30, '', '', '324234234234', '4234234234234234', '', '', '', '', '', '', 2, 'familiar', 'inactivo', ''),
(93, '3427', 'tt', 'tt', '1995-01-01', 'masculino', '', 30, '', '', '32423423423', '4234234234', '', '', '', '', '', '', 2, 'familiar', 'inactivo', ''),
(95, '12345', 'erer', 'erer', '1955-01-01', 'masculino', '', 27, 'ertertertertert', 'ertertertert', '32434534', '534534534', '4', '4', '4', '4', '4', '', 7, 'familiar', 'inactivo', ''),
(96, '4545783', 'nieto er', 'nieto ape', '2007-03-03', 'masculino', '', 30, '', '', '345453435345', '435345435534', '', '', '', '', '', '', 7, 'familiar', 'inactivo', ''),
(107, '778855', 'tt', 'tt', '2007-03-03', 'masculino', '', 46, '', '', '5345345', '345345', '', '', '', '', '', 'si', 7, 'familiar', 'inactivo', ''),
(108, '7788553', 'tt', 'tt', '2007-03-03', 'masculino', '', 46, '', '', '5345345', '345345', '', '', '', '', '', 'no', 7, 'familiar', 'inactivo', ''),
(109, '7733', 'kk', 'kk', '1995-03-03', 'masculino', '', 46, '', '', '345345', '3535345', '', '', '', '', '', 'si', 7, 'familiar', 'inactivo', '');

--
-- Triggers `persona`
--
DELIMITER $$
CREATE TRIGGER `PersonaInsert` AFTER INSERT ON `persona` FOR EACH ROW BEGIN 
   DECLARE trabajador_cedula VARCHAR(55);

   SELECT CedulaPersona INTO trabajador_cedula FROM persona WHERE CodigoPersona = NEW.CodigoPersona;

INSERT INTO bitacora(CodigoPersona, idUsuario,ActividadRealizada,InformacionActual)VALUES(trabajador_cedula,NEW.idusuario,'Se Registro nueva Persona',concat('Datos de la Persona: ' ,NEW.CedulaPersona,' ',NEW.Nombres,' ',NEW.Apellidos));


END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `PersonaUpdate` AFTER UPDATE ON `persona` FOR EACH ROW BEGIN 
   DECLARE trabajador_cedula VARCHAR(55);

   SELECT CedulaPersona INTO trabajador_cedula FROM persona WHERE CodigoPersona = NEW.CodigoPersona;

INSERT INTO bitacora(CodigoPersona,	idUsuario,ActividadRealizada,InformacionActual)VALUES(trabajador_cedula,NEW.idusuario,'Se Modifico una Persona',concat('Datos de la Persona: ' ,NEW.CedulaPersona,' ',NEW.Nombres,' ',NEW.Apellidos));


END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tipocargos`
--

CREATE TABLE `tipocargos` (
  `CodigoTipoCargo` int(10) NOT NULL,
  `NombreTipoCargo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tipocargos`
--

INSERT INTO `tipocargos` (`CodigoTipoCargo`, `NombreTipoCargo`) VALUES
(1, 'Empleado'),
(10, 'Alto Nivel'),
(11, 'Obrero');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `CodigoUsuario` int(10) NOT NULL,
  `CodigoPersona` int(10) NOT NULL,
  `NombreUsuario` varchar(20) NOT NULL,
  `ConstraseñaUsuario` varchar(80) NOT NULL,
  `RolUsuario` varchar(20) NOT NULL,
  `EstatusUsuario` varchar(20) NOT NULL,
  `idusuario` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`CodigoUsuario`, `CodigoPersona`, `NombreUsuario`, `ConstraseñaUsuario`, `RolUsuario`, `EstatusUsuario`, `idusuario`) VALUES
(1, 1, 'APOLOENDYS', 'OROGZ.123*', 'administrador', 'usuarioactivo', 0),
(2, 68, 'msql', '1234', 'analista', 'usuariodesactivado', 7),
(3, 59, 'react', '12345', 'analista', 'usuarioactivo', 7),
(7, 9, 'mysql', '1234', 'administrador', 'usuarioactivo', 1);

--
-- Triggers `usuarios`
--
DELIMITER $$
CREATE TRIGGER `UsuarioInsert` AFTER INSERT ON `usuarios` FOR EACH ROW BEGIN 
   DECLARE persona_cedula VARCHAR(55);

   SELECT CedulaPersona INTO persona_cedula FROM persona WHERE CodigoPersona = NEW.CodigoPersona;

INSERT INTO bitacora(CodigoPersona, Fecha,idUsuario,ActividadRealizada,InformacionActual)VALUES(persona_cedula,NOW(),NEW.idusuario,'Se Registro nuevo Usuario',concat('Datos del Usuario: ' ,persona_cedula,' ',NEW.NombreUsuario,' ',NEW.RolUsuario));


END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `UsuarioUpdate` AFTER UPDATE ON `usuarios` FOR EACH ROW BEGIN 
   DECLARE persona_cedula VARCHAR(55);

   SELECT CedulaPersona INTO persona_cedula FROM persona WHERE CodigoPersona = NEW.CodigoPersona;

INSERT INTO bitacora(CodigoPersona, Fecha,idUsuario,ActividadRealizada,InformacionActual)VALUES(persona_cedula,NOW(),NEW.idusuario,'Se Modifico nuevo Usuario',concat('Datos del Usuario: ' ,persona_cedula,' ',NEW.NombreUsuario,' ',NEW.RolUsuario));


END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `archivos`
--
ALTER TABLE `archivos`
  ADD PRIMARY KEY (`ArchivoRegistro`),
  ADD KEY `CodigoDocumento` (`CodigoDocumento`),
  ADD KEY `idperarchivos` (`idperarchivos`);

--
-- Indexes for table `bitacora`
--
ALTER TABLE `bitacora`
  ADD PRIMARY KEY (`CodigoBitacora`),
  ADD KEY `idUsuario` (`idUsuario`);

--
-- Indexes for table `cargos`
--
ALTER TABLE `cargos`
  ADD PRIMARY KEY (`CodigoCargo`),
  ADD UNIQUE KEY `NombreCargo` (`NombreCargo`),
  ADD KEY `TipoCargo` (`TipoCargo`);

--
-- Indexes for table `documento`
--
ALTER TABLE `documento`
  ADD PRIMARY KEY (`CodigoDocumento`),
  ADD UNIQUE KEY `NombreDocumento` (`NombreDocumento`);

--
-- Indexes for table `familiar`
--
ALTER TABLE `familiar`
  ADD PRIMARY KEY (`CodigoRegistroFamiliar`),
  ADD KEY `Trabajador` (`Trabajador`,`Familiar`),
  ADD KEY `familiar_ibfk_2` (`Familiar`);

--
-- Indexes for table `historico`
--
ALTER TABLE `historico`
  ADD PRIMARY KEY (`CodigoHistorico`),
  ADD KEY `Trabajador` (`Cargo`,`InstitucionHistorico`),
  ADD KEY `InstitucionHistorico` (`InstitucionHistorico`),
  ADD KEY `trabajador_2` (`personal`);

--
-- Indexes for table `instituciones`
--
ALTER TABLE `instituciones`
  ADD PRIMARY KEY (`CodigoInstituciones`),
  ADD UNIQUE KEY `NombreInstitucion` (`NombreInstitucion`),
  ADD KEY `ParroquiaInstitucion` (`ParroquiaInstitucion`);

--
-- Indexes for table `municipio`
--
ALTER TABLE `municipio`
  ADD PRIMARY KEY (`CodigoMunicipio`),
  ADD UNIQUE KEY `CodigoEstado` (`NombreMunicipio`),
  ADD KEY `NombreMunicipio` (`NombreMunicipio`);

--
-- Indexes for table `parroquia`
--
ALTER TABLE `parroquia`
  ADD PRIMARY KEY (`CodigoParroquia`),
  ADD UNIQUE KEY `NombreParroquia` (`NombreParroquia`),
  ADD KEY `MunicipioParroquia` (`MunicipioParroquia`);

--
-- Indexes for table `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`CodigoPersona`),
  ADD UNIQUE KEY `CedulaPersona` (`CedulaPersona`),
  ADD KEY `ParroquiaPersona` (`ParroquiaPersona`);

--
-- Indexes for table `tipocargos`
--
ALTER TABLE `tipocargos`
  ADD PRIMARY KEY (`CodigoTipoCargo`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`CodigoUsuario`),
  ADD UNIQUE KEY `IdPersona` (`CodigoPersona`,`NombreUsuario`),
  ADD KEY `IdPersona_2` (`CodigoPersona`),
  ADD KEY `codigopersona` (`CodigoPersona`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `archivos`
--
ALTER TABLE `archivos`
  MODIFY `ArchivoRegistro` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `bitacora`
--
ALTER TABLE `bitacora`
  MODIFY `CodigoBitacora` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;

--
-- AUTO_INCREMENT for table `cargos`
--
ALTER TABLE `cargos`
  MODIFY `CodigoCargo` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `documento`
--
ALTER TABLE `documento`
  MODIFY `CodigoDocumento` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1314;

--
-- AUTO_INCREMENT for table `familiar`
--
ALTER TABLE `familiar`
  MODIFY `CodigoRegistroFamiliar` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `historico`
--
ALTER TABLE `historico`
  MODIFY `CodigoHistorico` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `instituciones`
--
ALTER TABLE `instituciones`
  MODIFY `CodigoInstituciones` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `municipio`
--
ALTER TABLE `municipio`
  MODIFY `CodigoMunicipio` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `parroquia`
--
ALTER TABLE `parroquia`
  MODIFY `CodigoParroquia` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `persona`
--
ALTER TABLE `persona`
  MODIFY `CodigoPersona` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `tipocargos`
--
ALTER TABLE `tipocargos`
  MODIFY `CodigoTipoCargo` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `CodigoUsuario` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `archivos`
--
ALTER TABLE `archivos`
  ADD CONSTRAINT `archivos_ibfk_1` FOREIGN KEY (`CodigoDocumento`) REFERENCES `documento` (`CodigoDocumento`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `archivos_ibfk_2` FOREIGN KEY (`idperarchivos`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bitacora`
--
ALTER TABLE `bitacora`
  ADD CONSTRAINT `bitacora_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuarios` (`CodigoUsuario`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cargos`
--
ALTER TABLE `cargos`
  ADD CONSTRAINT `cargos_ibfk_1` FOREIGN KEY (`TipoCargo`) REFERENCES `tipocargos` (`CodigoTipoCargo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `familiar`
--
ALTER TABLE `familiar`
  ADD CONSTRAINT `familiar_ibfk_1` FOREIGN KEY (`Trabajador`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `familiar_ibfk_2` FOREIGN KEY (`Familiar`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `historico`
--
ALTER TABLE `historico`
  ADD CONSTRAINT `historico_ibfk_2` FOREIGN KEY (`Cargo`) REFERENCES `cargos` (`CodigoCargo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `historico_ibfk_3` FOREIGN KEY (`InstitucionHistorico`) REFERENCES `instituciones` (`CodigoInstituciones`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `historico_ibfk_4` FOREIGN KEY (`personal`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `instituciones`
--
ALTER TABLE `instituciones`
  ADD CONSTRAINT `instituciones_ibfk_1` FOREIGN KEY (`ParroquiaInstitucion`) REFERENCES `parroquia` (`CodigoParroquia`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `parroquia`
--
ALTER TABLE `parroquia`
  ADD CONSTRAINT `parroquia_ibfk_1` FOREIGN KEY (`MunicipioParroquia`) REFERENCES `municipio` (`CodigoMunicipio`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`ParroquiaPersona`) REFERENCES `parroquia` (`CodigoParroquia`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`CodigoPersona`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`CodigoPersona`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
