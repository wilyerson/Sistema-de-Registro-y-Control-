<style type="text/css">
  @font-face{
    font-family: opensan;
    src: url(../fonts/googlesansnormal.woff2) format('woff2'), 
    url('../fonts/OpenSans-Regular.ttf') format('truetype');
  }

/*body {
  background-image: linear-gradient(120deg, #b1eef7 0%, #f3f3f3 100%);
  background-size: 400% 400%;
  animation: gradient 15s ease infinite;
  height: 100vh;
}

@keyframes gradient {
  0% {
    background-position: 0% 50%;
  }
  50% {
    background-position: 100% 50%;
  }
  100% {
    background-position: 0% 50%;
  }
}*/



  body{
    font-family: opensan;
    background-image: linear-gradient(120deg, #c9eff5 0%, #f3f3f3 100%);
  }

  .dropdown-toggle::after {
    border-top-color: white !important; /* Cambia el color de la flecha */
  }


</style>

<div style="position: sticky; top: 0; z-index: 8;">

<div class="container-fluid py-4 px-5 bg-primary">
  <header class="">
    <div class="d-flex align-items-center justify-content-between">
      <a href="bienvenida.php" class="d-flex align-items-center mb-0 mb-lg-0 link-body-emphasis text-decoration-none">
        <img src="../icons/housesolid.svg" style="height: 20px" class="mx-2">
        <h5 class="text-white m-0 p-0">INICIO</h5>
      </a>
      <div class="dropdown text-end">
        <a href="#" class="d-block link-body-emphasis text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" type="button">
          <img src="../icons/circleusersolidorigin.svg" width="30" class="rounded-circle">
        </a>
        <ul class="dropdown-menu">
          <li class="dropdown-item">
            <a class="nav-link decoracionopcionmenu" aria-current="page" href="modificar-contrasena-usuario.php">
              Cambiar Contraseña
            </a>
          </li>
          <li class="dropdown-item">
            <a class="nav-link decoracionopcionmenu" id="icononosmenucerrarsesion" aria-current="page" style="cursor:pointer;">
              Cerrar Sesión
            </a>
          </li>
        </ul>
      </div>
    </div>
  </header>  
</div>

<div class="container-fluid bg-white" id="nav-pills">
  <header class="d-flex flex-wrap align-items-center justify-content-center justify-content-ms-between py-1 mb-4 border-bottom">


    <ul class="nav nav-pills col-12 col-md-auto mb-2 justify-content-center mb-md-0">
      <li>
        <a href="inicio.php" class="nav-link px-2 ">Buscar Trabajador</a>
      </li>
      <li>
        <a href="registro-persona2.php" class="nav-link px-2 ">Registro de Personal</a>
      </li>
      <li>
        <a href="control-usuarios-sistema.php" class="nav-link px-2 ">Manejo de Usuarios</a>
      </li>
      <li class="nav-item dropdown">
        <a href="#" class="nav-link dropdown-toggle px-2" data-bs-toggle="dropdown" role="button" aria-expanded="true">    Configuración de Sistema
        </a>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item " href="registro-institucion.php">Añadir Instituciones</a></li>
          <li><a class="dropdown-item " href="registro-cargos.php">Agregar Cargos</a></li>
        </ul>
      </li>
      <li>
        <a href="reportesexcel.php" class="nav-link px-2 ">Generar Reportes</a>
      </li>
      <li>
        <a href="bitacora.php" class="nav-link px-2 ">Bitácora</a>
      </li>
    </ul>

  </header>
</div>

</div>

  


<script src="../js/cerrarsession.js"></script>
<script type="text/javascript">
  
//let buscarcedu = document.getElementById('buscarcedu');
//let formdatadoc = document.querySelector("a");

  // Obtén todos los elementos <a> en el documento
let links = document.querySelectorAll('.a');

// Itera sobre cada elemento <a>
for(let i = 0; i < links.length; i++) {
    // Agrega un evento de clic a cada elemento <a>
    links[i].addEventListener('click', function() {
        // Busca cualquier elemento <a> con la clase 'active' y remuévela
        let current = document.getElementsByClassName('active');
        if(current.length > 0) {
            current[0].className = current[0].className.replace(' active', '');
        }

        // Agrega la clase 'active' al elemento <a> que se hizo clic
        this.className += ' active';
    });
}


</script>
