   <?php 

	class coneccion extends mysqli{

		function __construct(){
			parent::__construct('localhost', 'root', '', 'sirceop'); 
			$this->set_charset('utf8');
			$this->connect_error == NULL ? 'BD conectada' : die('error al conectarse');
		}
	}

 ?>