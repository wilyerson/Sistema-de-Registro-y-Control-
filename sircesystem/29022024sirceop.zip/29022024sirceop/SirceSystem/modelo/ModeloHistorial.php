<?php

class Historial extends dbconexion
{
    public function get_historiales()
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT CodigoInstituciones, NombreInstitucion, CodigoRegistro FROM instituciones");
        $sql->execute();
        return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_historial($idperhis)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT instituciones.NombreInstitucion, instituciones.CodigoInstituciones, cargos.CodigoCargo, cargos.NombreCargo, persona.CodigoPersona, 
        persona.Nombres, historico.FechaInicio, historico.FechaCulminacion, historico.Obervacion, historico.CodigoHistorico FROM historico 
        INNER JOIN instituciones on historico.InstitucionHistorico = instituciones.CodigoInstituciones
        INNER JOIN cargos on historico.Cargo = cargos.CodigoCargo
        INNER JOIN persona on historico.personal = persona.CodigoPersona 
        WHERE historico.personal = ?");
        $sql->bindValue(1, $idperhis);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function insert_historial($idperhist, $fechainiciohist, $fechaculmhist, $cargohist, $institucionhist, $obshist, $idusuario)
    {
        $conectar = dbconexion::conexion();

                $sql = $conectar->prepare("INSERT INTO historico (personal, FechaInicio, FechaCulminacion, Cargo, InstitucionHistorico, Obervacion, idusuario) VALUES (?, ?, ?, ?, ?, ?, ?)");                
                $sql->bindValue(1, $idperhist);
                $sql->bindValue(2, $fechainiciohist);
                $sql->bindValue(3, $fechaculmhist);
                $sql->bindValue(4, $cargohist);
                $sql->bindValue(5, $institucionhist);
                $sql->bindValue(6, $obshist);
                $sql->bindValue(7, $idusuario);

                if ($sql->execute()) {
                    return "Registro insertado correctamente.";
                }
        
    }

    public function update_historial($idperhist, $fechainiciohist, $fechaculmhist, $cargohist, $institucionhist, $obshist, $idusuario, $idhistoricoedit)
{
    $conectar = dbconexion::conexion();

    // Actualizar el registro existente
    $sql = $conectar->prepare("UPDATE historico SET FechaInicio = ?, FechaCulminacion = ?, Cargo = ?, InstitucionHistorico = ?, Obervacion = ?, idusuario = ?,  personal = ? WHERE CodigoHistorico = ?");

    $nullVar = NULL;

    if ($fechaculmhist) {

        $sql->bindValue(1, $fechainiciohist);
        $sql->bindValue(2, $fechaculmhist);
        $sql->bindValue(3, $cargohist);
        $sql->bindValue(4, $institucionhist);
        $sql->bindValue(5, $obshist);
        $sql->bindValue(6, $idusuario);
        $sql->bindValue(7, $idperhist);
        $sql->bindValue(8, $idhistoricoedit);

    } else {

        // Pasamos la variable en lugar de NULL directamente
        $sql->bindValue(1, $fechainiciohist);
        $sql->bindValue(2, $nullVar);
        $sql->bindValue(3, $cargohist);
        $sql->bindValue(4, $institucionhist);
        $sql->bindValue(5, $obshist);
        $sql->bindValue(6, $idusuario);
        $sql->bindValue(7, $idperhist);

    }

    $sql->execute();
    return "Registro actualizado correctamente.";
}

    public function get_editarmodalhistorial($codhistorial)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT instituciones.NombreInstitucion, instituciones.CodigoInstituciones, cargos.CodigoCargo, cargos.NombreCargo, persona.CodigoPersona, 
        persona.Nombres, historico.FechaInicio, historico.FechaCulminacion, historico.Obervacion, historico.CodigoHistorico FROM historico 
        INNER JOIN instituciones on historico.InstitucionHistorico = instituciones.CodigoInstituciones
        INNER JOIN cargos on historico.Cargo = cargos.CodigoCargo
        INNER JOIN persona on historico.personal = persona.CodigoPersona 
        WHERE historico.CodigoHistorico = ?");
        $sql->bindValue(1, $codhistorial);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }


}
