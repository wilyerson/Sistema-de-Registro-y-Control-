<?php 
	require_once "ModeloConeccion.php";

	class Cargo{

		public function obtener_cargos_select(){
			$db = new coneccion();
			$query = "SELECT CodigoCargo, NombreCargo from cargos";
			$resultado = $db->query($query);
			$datos=[];
			if ($resultado->num_rows) {
				while ($row = $resultado->fetch_assoc()) {
					$datos[] = [
						'NombreCargo' => $row['NombreCargo'],
						'CodigoCargo' => $row['CodigoCargo'],
					];				
				}			
			}
			return $datos;
		}
	}

 ?>