const formdatamodificacionusuario = document.querySelector("#formulariosuariomodificacion");
formdatamodificacionusuario.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formulariosuariomodificacion"));

    if (camposVaciosUsuarioModificacion(datos)) {
        //console.log('Hay campos vacíos');
        let toastusercamposvacios = document.querySelector("#toastusercampovaciosmodificacion");
		let toast = new bootstrap.Toast(toastusercamposvacios, {autohide: true, delay: 2000});
		toast.show();

		setTimeout(() => {
		    toast.hide();
		}, 2000);
        return;
    }

	console.log(" conectado");

	let url = "../controlador/usuarios-control.php?op=update";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);

            var status = data.status;
            var datos = data.data;

            if (status == "esta_usuario_ya_existe") {
                document.getElementById('nombreunewusereditar').classList.remove('is-valid');
                document.getElementById('nombreunewusereditar').classList.add('is-invalid');
                swal.fire({
                    title: "¡Este Nombre de Usuario Ya Existe!",
                    icon: "error",
                });
            }

            if (status == "usuario_actualizado_exitosamente") {
                listarusuariosfetch();
            //formdataregistrousuario.reset();
            document.getElementById('tipousereditar').classList.remove('is-valid');
            document.getElementById('tipousereditar').classList.remove('is-invalid');
            document.getElementById('nombreunewusereditar').classList.remove('is-valid');
            document.getElementById('nombreunewusereditar').classList.remove('is-invalid');
            document.getElementById('estatususuarioeditar').classList.remove('is-valid');
            document.getElementById('estatususuarioeditar').classList.remove('is-invalid');
            document.getElementById('passnewusereditar').classList.remove('is-valid');
            document.getElementById('passnewusereditar').classList.remove('is-invalid');
            document.getElementById('passnu2editar').classList.remove('is-valid');
            document.getElementById('passnu2editar').classList.remove('is-invalid');

            $('#editar-usuario').modal('hide');
            swal.fire({
                title: "Modificacion de Usuario Exitoso!",
                icon: "success",
            });
            }
			
			
		})
		.catch((error) => console.log(`error: ${error}`));
});

function camposVaciosUsuarioModificacion(datos) {

    let tipouser = document.getElementById('tipousereditar');
    let nombreunewuser = document.getElementById('nombreunewusereditar');
    let estatususuario = document.getElementById('estatususuarioeditar');
    let passnewuser = document.getElementById('passnewusereditar');
    let passnu2 = document.getElementById('passnu2editar');
    
    const tipouservalue = tipouser.value.trim();
    const nombreunewuservalue = nombreunewuser.value.trim();
    const estatususuariovalue = estatususuario.value.trim();
    const passnewuservalue = passnewuser.value.trim();
    const passnu2value = passnu2.value.trim();
    
    let hayCamposVacios = false;

    //--------------------validando los inputs

    if (tipouservalue == "") {
        tipouser.classList.remove('is-valid');
        tipouser.classList.add('is-invalid');
        //document.getElementById('validcedulavacia').classList.remove('invisible');
		//document.getElementById('validcedulavacia').classList.add('visible');
        hayCamposVacios = true;
    } else {
        tipouser.classList.remove('is-invalid');
        tipouser.classList.add('is-valid');
        //document.getElementById('validcedulavacia').classList.add('invisible');
		//document.getElementById('validcedulavacia').classList.remove('visible');
    }

     if (nombreunewuservalue == "") {
        nombreunewuser.classList.remove('is-valid');
        nombreunewuser.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        nombreunewuser.classList.remove('is-invalid');
        nombreunewuser.classList.add('is-valid');
    }

    if (estatususuariovalue == "") {
        estatususuario.classList.remove('is-valid');
        estatususuario.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        estatususuario.classList.remove('is-invalid');
        estatususuario.classList.add('is-valid');
    }

    if (passnewuservalue == "") {
        passnewuser.classList.remove('is-valid');
        passnewuser.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        passnewuser.classList.remove('is-invalid');
        passnewuser.classList.add('is-valid');
    }

    if (passnu2value == "") {
        passnu2.classList.remove('is-valid');
        passnu2.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        passnu2.classList.remove('is-invalid');
        passnu2.classList.add('is-valid');
    }

    return hayCamposVacios;
}

    
    let botonresetlocaleditar = document.getElementById('botonresetlocaleditar');
    
    botonresetlocaleditar.addEventListener('click', (e) => {
        document.getElementById('tipousereditar').classList.remove('is-valid');
        document.getElementById('tipousereditar').classList.remove('is-invalid');
        document.getElementById('nombreunewusereditar').classList.remove('is-valid');
        document.getElementById('nombreunewusereditar').classList.remove('is-invalid');
        document.getElementById('estatususuarioeditar').classList.remove('is-valid');
        document.getElementById('estatususuarioeditar').classList.remove('is-invalid');
        document.getElementById('passnewusereditar').classList.remove('is-valid');
        document.getElementById('passnewusereditar').classList.remove('is-invalid');
        document.getElementById('passnu2editar').classList.remove('is-valid');
        document.getElementById('passnu2editar').classList.remove('is-invalid');

    });