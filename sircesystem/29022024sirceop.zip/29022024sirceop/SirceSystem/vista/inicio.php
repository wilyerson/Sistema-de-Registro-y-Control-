  <!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

  
</head>
<body >

    <?php

session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}


?>

 <?php include"../componentes/nav.php" ?> 


<div class="container border rounded py-3 bg-white rounded-3 shadow" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px; ">

  <div class="row m-4">
    <h5><p class="text-center">Buscar Personal</p></h5>
  </div>

  <form id="formbuscarpersona" method="POST" >

  <div class="row m-4 d-flex justify-content-center">
    <div class="col-md-6">
      <label class="form-label"for="">Filtrar Por:</label>
      <input class="form-control" type="number" id="cedulabuscar" name="cedulabuscar" placeholder="Cedula de Identidad" value="">
    </div>
  </div>

  <div class="row m-4">
    <div class="col-md-6 d-flex justify-content-end">
      <button type="reset" id="botonresetbuscarpersona" class="btn btn-primary">limpiar</button>
    </div>
    <div class="col-md-6">
      <button type="submit" name="enviar"  class="btn btn-primary">Buscar</button>
    </div>
  </div>

  <div class="row mt-4 mb-0">
    <hr>
  </div>

  <div class="row mb-4 my-4">
    <div class="col-sm-12">
      <table class="table table-hover" style="margin-top: 40px;">
        
        <thead>
          <tr>
            <th scope="col">Cedula</th>
            <th scope="col">Nombre</th>
            <th scope="col">Apellido</th>
            <th scope="col">Estado civil</th>
            <th scope="col"><img src="../icons/buscar.png" width="20px"></th>
          </tr>
        </thead>

        <tbody id="content">
          
        </tbody>
      </table>
      </form>

    </div>
  </div>

 <!-- paginacion -->

     <nav aria-label="Page navigation example" >
              <ul class="pagination">
                <li class="page-item">
                  <button class="page-link" onclick="previusPageBuscarpersona()">
                    <span aria-hidden="true">&laquo;</span>
                  </button>
                </li>

                <div id="items" class="d-flex"></div>

                <li class="page-item">
                  <button class="page-link" onclick="nextPageBuscarpersona()">
                    <span aria-hidden="true">&raquo;</span>
                  </button>
                </li>
              </ul>
            </nav>

    <!-- fin paginacion -->

</div>

  <script src="../js/inicio.js"></script>

</body>
</html>