<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>
@font-face{
  font-family: opensan;
  src: url(fonts/googlesansnormal.woff2);

}

body{
  font-family: opensan;
  background-color: #e8f2f7;
}

input::placeholder {
color: black;
  
}



    #zonanombresombra{
    box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
    -moz-box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
    border-radius: 25px;
     overflow-x: hidden;
      /*overflow: hidden;*/

  }



  #botonbuscar{
        background-color: #008CBA;
    color: white;
    border-radius: 100px;
    position: relative;
    top: 35%;
    left: 55%;
    border: none;
  }

      #botonbuscar:hover {
  background-color: #008CBA; 
  box-shadow: 0 5px 17px 0px rgb(89 88 88 / 49%);
  color: white;

}

  #botonlimpiar{
    background-color: #008CBA;
    color: white;
    border-radius: 100px;
        position: relative;
  position: relative;
    left: 39%;
    top: -10px;
    border: none;
  }

  #botonlimpiar:hover {
  background-color: #008CBA; 
  box-shadow: 0 5px 17px 0px rgb(89 88 88 / 49%);
  color: white;
}

#botonver{
        background-color: #008CBA;
    color: white;
    border-radius: 100px;
    border: none;
}

#botonver:hover {
  box-shadow: 0 5px 17px 0px rgb(89 88 88 / 49%);
} 

#inputtextdecoracion{
  border-radius: 100px;
}

.form-control {
  background-color: #e8e9e9;
  border-radius: 100px;
}

.form-select {
  border-radius: 15px;
}

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }

    .botonhamburguesa{
      position: relative;
      left: 02%;
    }


    .botones{
      text-align: center;
  text-decoration: none;
  color: #fff;
  /*margin: auto;*/
  margin: 4% 2.8% 0% 5%;
  width: 157px;
  display: inline-block;
  line-height: 28px;
  font-size: 12px;
  font-weight: 500;
  letter-spacing: 2px;
  border-radius: 100px;
  text-transform: uppercase;
  background-color: #c70069;
  /*box-shadow: 0px 15px 18px -6px rgba(199, 0, 105, 0.65);*/
  transition: all 0.4s;
  
  cursor: pointer;
  border-style: none;
  border: none;
  padding: 8px 0px;
  /*position: relative;
  left: 17%;
  top: 7%;*/
  font-weight: 800;
  letter-spacing: 1px;
  text-transform: uppercase;
  outline: none;
    }


  .botones:hover {
  background-color: #c70069cc;
  /*box-shadow: 0px 22px 19px -8px rgba(199, 0, 105, 0.5);*/
  transform: scale(1.02, 1.02);
}
.botones:active {
  transition: all 0.4s -0.125s;
  background-color: #ab005a;
  /*box-shadow: 0px 12px 18px -4px rgba(199, 0, 105, 0.9);*/
  transform: scale(0.95, 0.95);
}

.zonadecoracion{
  border-radius: 20px;
max-width: 108%;
    margin-top: 2%;
    margin-bottom: 9px;
    /*padding: 2.8% 24% 0%;*/
    width: 102%;
    height: 21%;
    background-color: #d8f3f7;
    /*background-color: #e5e5e5;*/
}

.zonadecoracionamplia{
    border-radius: 20px;
max-width: 108%;
    margin-top: 2%;
    margin-bottom: 9px;
    /*padding: 2.8% 24% 0%;*/
    width: 102%;
    height: 47%;
    background-color: #d8f3f7;
}

.center{

  position: relative;
    top: 50%;
    left: 70%;
    transform: translate(-70%, -50%);
    margin: 0% -16% 0% 7%;
    padding: 0% 28%;
}

.form-select{
  background-color: white;
}


    </style>
  
</head>
<body class="bg-gray">

    <?php

session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}

?>

<?php include"../componentes/nav.php"; ?>

 <!-- poner  border -->

 <div class="container border py-3 bg-white rounded-3 shadow" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px;">

  <div class="row">
    <div class="col mt-3 col-sm-12 d-flex justify-content-center">
      <h4>Generar Reportes</h4>
    </div>
  </div>
  
  <hr class="hr py-1">

  <form action="../controlador/excelreportegenero.php" method="POST">
    <div class="row py-3">
      <div class="col col-sm-3 d-flex justify-content-center align-items-center">
        <label for="genero">Género</label>
      </div>
      <div class="col col-sm-6">
        <select class="form-select" name="genero" id="genero">
          <option selected disabled value="">Seleccione Género</option>
          <option value="masculino">Masculino</option>
          <option value="femenino">Femenino</option>
        </select>
      </div>
      <div class="col col-sm-3 d-flex justify-content-center">
        <button class="btn btn-primary" type="submit" >Generar Reporte</button>
      </div>
    </div>
  </form>

    <hr class=" py-2">

    <form action="../controlador/generarreportefiltroinstitucion.php" method="POST">
      <div class="row py-3">
        <div class="col col-sm-3 d-flex justify-content-center align-items-center">
          <label for="institucion">Instituciones</label>
        </div>
        <div class="col col-sm-6">
          <select class="form-select" name="institucion" id="institucion">
            <option selected disabled value="">Seleccione Institución</option>
          </select>
        </div>
        <div class="col col-sm-3 d-flex justify-content-center">
          <button class="btn btn-primary" type="submit" >Generar Reporte</button>
        </div>
      </div>
    </form>

    <hr class="hr py-2">

    <form  action="../controlador/generarreportefiltrocargo.php" method="POST">
      <div class="row py-3">
        <div class="col col-sm-3 d-flex justify-content-center align-items-center">
          <label for="cargo">Cargos</label>
        </div>
        <div class="col col-sm-6">
          <select class="form-select" name="cargo" id="cargo">
            <option selected disabled value="">Seleccione Cargo</option>
            <option value="BACHILLER I">BACHILLER I</option>
            <option value="BACHILLER II">BACHILLER II</option>
            <option value="BACHILLER III">BACHILLER III</option>
            <option value="TSU I">TSU I</option>
            <option value="TSU II">TSU II</option>
            <option value="PROFESIONAL I">PROFESIONAL I</option>
            <option value="PROFESIONAL II">PROFESIONAL II</option>
            <option value="PROFESIONAL III">PROFESIONAL III</option>
            <option value="OBRERO GRADO 1">OBRERO GRADO 1</option>
            <option value="OBRERO GRADO 2">OBRERO GRADO 2</option>
            <option value="OBRERO GRADO 3">OBRERO GRADO 3</option>
            <option value="OBRERO GRADO 4">OBRERO GRADO 4</option>
            <option value="OBRERO GRADO 5">OBRERO GRADO 5</option>
            <option value="OBRERO GRADO 6">OBRERO GRADO 6</option>
            <option value="OBRERO GRADO 7">OBRERO GRADO 7</option>
            <option value="OBRERO GRADO 8">OBRERO GRADO 8</option>
            <option value="OBRERO GRADO 9">OBRERO GRADO 9</option>
            <option value="OBRERO GRADO 10">OBRERO GRADO 10</option>
          </select>
        </div>
        <div class="col col-sm-3 d-flex justify-content-center">
          <button class="btn btn-primary" type="submit" >Generar Reporte</button>
        </div>
      </div>
    </form>

    <hr class="hr py-2">

    <form action="../controlador/generarreportefiltrotablahistorico.php" method="POST">
      <div class="row py-3">
        <div class="col col-sm-3 d-flex justify-content-center align-items-center">
          <label for="tipotrabajdor">Tipo de Trabajador</label>
        </div>
        <div class="col col-sm-6">
          <select class="form-select" name="tipotrabajdor" id="tipotrabajdor">
            <option selected disabled value="">Seleccione Tipo de Trabajador</option>
            <option value="Eleccion popular">Eleccion popular</option>
            <option value="Libre nombramiento y remoción">Libre nombramiento y remoción</option>
            <option value="Empleados">Empleados</option>
            <option value="Obreros">Obreros</option>
            <option value="Contratados">Contratados</option>
            <option value="Honorarios profesionales">Honorarios profesionales</option>
            <option value="Rotativos">Rotativos</option>
            <option value="Comisión de Servicio">Comisión de Servicio</option>
            <option value="Apoyo institucional">Apoyo institucional</option>
          </select>
        </div>
        <div class="col col-sm-3 d-flex justify-content-center">
          <button class="btn btn-primary" type="submit" >Generar Reporte</button>
        </div>
      </div>
    </form>

    <hr class="hr py-2">

    <form action="../controlador/generarreportefiltrotipodepersonal.php" method="POST">
      <div class="row py-3">
        <div class="col col-sm-3 d-flex justify-content-center align-items-center">
          <label id="tipopersonal">Tipo de Personal</label>        
        </div>
        <div class="col col-sm-6">
          <select id="tipopersonal" name="tipopersonal" class="form-select">
            <option selected disabled value="">Seleccione el Tipo de Personal</option>
            <option value="Activo">Activo</option>
            <option value="Jubilado">Jubilado</option>
            <option value="Pensionado">Pensionado</option>
          </select>        
        </div>
        <div class="col col-sm-3 d-flex justify-content-center">
          <button class="btn btn-primary" type="submit">Generar Reporte</button>        
        </div>
      </div>
    </form>

    <hr class="hr py-2">

    <form action="../controlador/generarreportefiltrotablahistorico.php" method="POST">
      <div class="row py-3">
        <div class="col col-sm-3 d-flex justify-content-center align-items-center">
          <label id="cargo">Cargos</label>
        </div>
        <div class="col col-sm-6">
          <select id="cargo" name="cargo" class="form-select">
            <option selected disabled value="">Seleccione un Cargo</option>
            <option value="BACHILLER I">BACHILLER I</option>
            <option value="BACHILLER II">BACHILLER II</option>
            <option value="BACHILLER III">BACHILLER III</option>
            <option value="TSU I">TSU I</option>
            <option value="TSU II">TSU II</option>
            <option value="PROFESIONAL I">PROFESIONAL I</option>
            <option value="PROFESIONAL II">PROFESIONAL II</option>
            <option value="PROFESIONAL III">PROFESIONAL III</option>
            <option value="OBRERO GRADO 1">OBRERO GRADO 1</option>
            <option value="OBRERO GRADO 2">OBRERO GRADO 2</option>
            <option value="OBRERO GRADO 3">OBRERO GRADO 3</option>
            <option value="OBRERO GRADO 4">OBRERO GRADO 4</option>
            <option value="OBRERO GRADO 5">OBRERO GRADO 5</option>
            <option value="OBRERO GRADO 6">OBRERO GRADO 6</option>
            <option value="OBRERO GRADO 7">OBRERO GRADO 7</option>
            <option value="OBRERO GRADO 8">OBRERO GRADO 8</option>
            <option value="OBRERO GRADO 9">OBRERO GRADO 9</option>
            <option value="OBRERO GRADO 10">OBRERO GRADO 10</option>
          </select>
        </div>
      </div>

      <div class="row py-3">
        <div class="col col-sm-3 d-flex justify-content-center align-items-center">
         <label id="tipotrabajdor">Tipo de Trabajador</label>
       </div>
       <div class="col col-sm-6">
        <select id="tipotrabajdor" name="tipotrabajdor" class="form-select">
          <option selected disabled value="">Seleccione un tipo de trabajador</option>
          <option value="Eleccion popular">Elección popular</option>
          <option value="Libre nombramiento y remoción">Libre nombramiento y remoción</option>
          <option value="Empleados">Empleados</option>
          <option value="Obreros">Obreros</option>
          <option value="Contratados">Contratados</option>
          <option value="Honorarios profesionales">Honorarios profesionales</option>
          <option value="Rotativos">Rotativos</option>
          <option value="Comisión de Servicio">Comisión de Servicio</option>
          <option value="Apoyo institucional">Apoyo institucional</option>
        </select>
      </div>
      <div class="col col-sm-3 d-flex justify-content-center">
        <button class="btn btn-primary" type="submit">Generar Reporte</button>
      </div>
    </div>

    <div class="row py-3">
      <div class="col col-sm-3 d-flex justify-content-center align-items-center">
        <label id="">Tipo de Personal</label>
      </div>
      <div class="col col-sm-6">
        <select id="tipopersonal" name="tipopersonal" class="form-select">
          <option selected disabled value="">Seleccione el Tipo de Personal</option>
          <option value="Activo">Activo</option>
          <option value="Jubilado">Jubilado</option>
          <option value="Pensionado">Pensionado</option>
        </select>
      </div>
    </div>
  </form>

 </div>

<!-- //////////////////////////////////////////////////////////////////////////////////////////////////////////////////// -->




 <div class="container py-3 bg-white" id="zonanombresombra" 
        style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;
              padding: 4%;  
              height: 528px;
        ">

        <br>


    <!-- zona div  --> 
    

    <div class="zonadecoracion">
      
    <form class="center" action="../controlador/generarreportefiltrogenero.php" method="POST">

      <label style="position: relative;transform: translate(-117%, 192%);/*left: 60%;top: 57%;*/">Genero</label>


      <select class="form-select" id="genero" name="genero" style="width: 52%; position: relative; transform: translate(-110%, 47%); left: 59%; top: 54%;">
        <option selected disabled value="">Seleccione un genero</option>
        <option value="masculino">Masculino</option>
        <option value="femenino">Femenino</option>
      </select>

      <!--<button class="btn btn-primary" type="submit">Generar Reporte</button>-->
      <button class="botones" type="submit" style="position: relative; transform: translate(-5%, -92%); left: 59%; top: 54%;" >Generar Reporte</button>

    </form>


    </div>




    <div class="zonadecoracion">

       <form action="../controlador/generarreportefiltroinstitucion.php" method="POST">

      <label style="position: relative;transform: translate(87%, 192%);/*left: 60%;top: 57%;*/">Institucion</label>
      <select id="institucion" name="institucion" style="width: 35%; position: relative; transform: translate(-110%, 47%); left: 59%; top: 54%;" class="form-select">
        <option selected disabled value="">Seleccione una institucion</option>
        <option value="">Masculino</option>
        <option value="">Femenino</option>
      </select>

      <button class="botones" type="submit" style="position: relative; transform: translate(-29%, -124%); left: 59%; top: 54%;">Generar Reporte</button>

    </form>
      


    </div>
    

<div class="zonadecoracion">
  

   <form  action="../controlador/generarreportefiltrocargo.php" method="POST">

      <label style="position: relative;transform: translate(140%, 192%);/*left: 60%;top: 57%;*/">Cargos</label>
      <select  id="cargo" name="cargo" style="width: 35%; position: relative; transform: translate(-110%, 47%); left: 59%; top: 54%;" class="form-select">
        <option selected disabled value="">Seleccione un cargo</option>
                          <option value="BACHILLER I">BACHILLER I</option>
                          <option value="BACHILLER II">BACHILLER II</option>
                          <option value="BACHILLER III">BACHILLER III</option>
                          <option value="TSU I">TSU I</option>
                          <option value="TSU II">TSU II</option>
                          <option value="PROFESIONAL I">PROFESIONAL I</option>
                          <option value="PROFESIONAL II">PROFESIONAL II</option>
                          <option value="PROFESIONAL III">PROFESIONAL III</option>
                          <option value="OBRERO GRADO 1">OBRERO GRADO 1</option>
                          <option value="OBRERO GRADO 2">OBRERO GRADO 2</option>
                          <option value="OBRERO GRADO 3">OBRERO GRADO 3</option>
                          <option value="OBRERO GRADO 4">OBRERO GRADO 4</option>
                          <option value="OBRERO GRADO 5">OBRERO GRADO 5</option>
                          <option value="OBRERO GRADO 6">OBRERO GRADO 6</option>
                          <option value="OBRERO GRADO 7">OBRERO GRADO 7</option>
                          <option value="OBRERO GRADO 8">OBRERO GRADO 8</option>
                          <option value="OBRERO GRADO 9">OBRERO GRADO 9</option>
                          <option value="OBRERO GRADO 10">OBRERO GRADO 10</option>
      </select>

      <button class="botones" type="submit" style="position: relative; transform: translate(-29%, -124%); left: 59%; top: 54%;">Generar Reporte</button>

    </form>

</div>

       
<div  class="zonadecoracion">
  

            <form action="../controlador/generarreportefiltrotipodetrabajador.php" method="POST">

      <label style="position: relative;transform: translate(15%, 192%);/*left: 60%;top: 57%;*/">Tipo de Trabajador</label>
      <select id="tipotrabajdor" name="tipotrabajdor" style="width: 35%; position: relative; transform: translate(-110%, 47%); left: 59%; top: 54%;" class="form-select">
        <option selected disabled value="">Seleccione un tipo de trabajador</option>
                          <option value="Eleccion popular">Eleccion popular</option>
                          <option value="Libre nombramiento y remoción">Libre nombramiento y remoción</option>
                          <option value="Empleados">Empleados</option>
                          <option value="Obreros">Obreros</option>
                          <option value="Contratados">Contratados</option>
                          <option value="Honorarios profesionales">Honorarios profesionales</option>
                          <option value="Rotativos">Rotativos</option>
                          <option value="Comisión de Servicio">Comisión de Servicio</option>
                          <option value="Apoyo institucional">Apoyo institucional</option>
      </select>

      <button class="botones" type="submit" style="position: relative; transform: translate(-29%, -124%); left: 59%; top: 54%;">Generar Reporte</button>

    </form>


</div>


<div class="zonadecoracion">
  
        <form action="../controlador/generarreportefiltrotipodepersonal.php" method="POST">

      <label style="position: relative;transform: translate(15%, 192%);/*left: 60%;top: 57%;*/">Tipo de Personal</label>
      <select id="tipopersonal" name="tipopersonal" style="width: 35%; position: relative; transform: translate(-110%, 47%); left: 59%; top: 54%;" class="form-select">
        <option selected disabled value="">Seleccione el Tipo de Personal</option>
        <option value="Activo">Activo</option>
        <option value="Jubilado">Jubilado</option>
        <option value="Pensionado">Pensionado</option>
      </select>

      <button class="botones" type="submit" style="position: relative; transform: translate(-29%, -124%); left: 59%; top: 54%;">Generar Reporte</button>

    </form>

</div>



  <div  class="zonadecoracionamplia">
    

 <form action="../controlador/generarreportefiltrotablahistorico.php" method="POST">


                    <label style="position: relative;transform: translate(100%, 192%);/*left: 60%;top: 57%;*/">Cargos</label>
      <select id="cargo" name="cargo" style="width: 35%; position: relative; transform: translate(-110%, 47%); left: 59%; top: 54%;" class="form-select">
        <option selected disabled value="">Seleccione un cargo</option>
                          <option value="BACHILLER I">BACHILLER I</option>
                          <option value="BACHILLER II">BACHILLER II</option>
                          <option value="BACHILLER III">BACHILLER III</option>
                          <option value="TSU I">TSU I</option>
                          <option value="TSU II">TSU II</option>
                          <option value="PROFESIONAL I">PROFESIONAL I</option>
                          <option value="PROFESIONAL II">PROFESIONAL II</option>
                          <option value="PROFESIONAL III">PROFESIONAL III</option>
                          <option value="OBRERO GRADO 1">OBRERO GRADO 1</option>
                          <option value="OBRERO GRADO 2">OBRERO GRADO 2</option>
                          <option value="OBRERO GRADO 3">OBRERO GRADO 3</option>
                          <option value="OBRERO GRADO 4">OBRERO GRADO 4</option>
                          <option value="OBRERO GRADO 5">OBRERO GRADO 5</option>
                          <option value="OBRERO GRADO 6">OBRERO GRADO 6</option>
                          <option value="OBRERO GRADO 7">OBRERO GRADO 7</option>
                          <option value="OBRERO GRADO 8">OBRERO GRADO 8</option>
                          <option value="OBRERO GRADO 9">OBRERO GRADO 9</option>
                          <option value="OBRERO GRADO 10">OBRERO GRADO 10</option>
      </select>

      <label style="position: relative;transform: translate(15%, 192%);/*left: 60%;top: 57%;*/">Tipo de Trabajador</label>
      <select id="tipotrabajdor" name="tipotrabajdor" style="width: 35%; position: relative; transform: translate(-110%, 47%); left: 59%; top: 54%;" class="form-select">
        <option selected disabled value="">Seleccione un tipo de trabajador</option>
                          <option value="Eleccion popular">Eleccion popular</option>
                          <option value="Libre nombramiento y remoción">Libre nombramiento y remoción</option>
                          <option value="Empleados">Empleados</option>
                          <option value="Obreros">Obreros</option>
                          <option value="Contratados">Contratados</option>
                          <option value="Honorarios profesionales">Honorarios profesionales</option>
                          <option value="Rotativos">Rotativos</option>
                          <option value="Comisión de Servicio">Comisión de Servicio</option>
                          <option value="Apoyo institucional">Apoyo institucional</option>
      </select>

      <label style="position: relative;transform: translate(15%, 192%);/*left: 60%;top: 57%;*/">Tipo de Personal</label>
      <select id="tipopersonal" name="tipopersonal" style="width: 35%; position: relative; transform: translate(-110%, 47%); left: 59%; top: 54%;" class="form-select">
        <option selected disabled value="">Seleccione el Tipo de Personal</option>
        <option value="Activo">Activo</option>
        <option value="Jubilado">Jubilado</option>
        <option value="Pensionado">Pensionado</option>
      </select>


      <button class="botones" type="submit" style="position: relative; transform: translate(-29%, -124%); left: 59%; top: 54%;">Generar Reporte</button>

    </form>


  </div>
       




    <!-- zona div  -->    


    
  </div>




  <script>

const campobuscar = document.getElementById('cedulapersonabuscar');

const campobuscarValue = campobuscar.value.trim();

  if (campobuscarValue === '') {
      console.log("campo vacio");
      //alert("El campo esta vacío");
  }else {
    console.log("campo lleno");
  }


    </script>

</body>
</html>