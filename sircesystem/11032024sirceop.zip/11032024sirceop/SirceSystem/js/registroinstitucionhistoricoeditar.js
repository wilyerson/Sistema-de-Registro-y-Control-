let dataCopyEditar = [];

fetch('../controlador/institucionesfetch.php')
    .then(response => response.json())
    .then(data => {
        dataCopyEditar = [...data]; // Hacemos una copia de los datos originales
        updateOptionsListeditar(dataCopyEditar);
    })
    .catch(error => console.error('Error:', error));

function updateOptionsListeditar(data) {
    const optionseditar = document.querySelector(".optionseditar");
    optionseditar.innerHTML = "";
    dataCopyEditar.forEach(institucion => {
        let li = `<li onclick="updateName(this)" data-value="${institucion.CodigoInstituciones}" >${institucion.NombreInstitucion}</li>`;
        optionseditar.insertAdjacentHTML("beforeend", li);
    });
}

const wrappereditar = document.querySelector(".wrappereditar"),
selectBtneditar = wrappereditar.querySelector(".select-btneditar"),
searchInpeditar = wrappereditar.querySelector(".searcheditar input"),
optionseditar = wrappereditar.querySelector(".optionseditar");

searchInpeditar.addEventListener("keyup", () => {
    let arreditar = [];
    let searchWordeditar = searchInpeditar.value.toLowerCase();
    arreditar = dataCopyEditar.filter(institucion => { // Usamos dataCopyEditar en lugar de data
        return institucion.NombreInstitucion.toLowerCase().startsWith(searchWordeditar);
    }).map(institucion => {
        let isSelected = institucion.NombreInstitucion == selectBtneditar.firstElementChild.innerText ? "selected" : "";
        return `<li onclick="updateName(this)" class="${isSelected}" data-value="${institucion.CodigoInstituciones}">${institucion.NombreInstitucion}</li>`;
    }).join("");
    optionseditar.innerHTML = arreditar ? arreditar : `<p style="margin-top: 10px;">No esta Registrada esa Institucion</p>`;
});

function limpiarmodalhistorico() {
    document.getElementById("institucionhistorico").dataset.value= "";
   document.getElementById("institucionhistorico").innerHTML = "Seleccione";
}

const formdatainstitucionhistoricoeditar = document.querySelector("#formulariogeistroinstitucionhistoricoeditar");
formdatainstitucionhistoricoeditar.addEventListener("submit", (e) => {
    e.preventDefault();
    const datos = new FormData(document.getElementById("formulariogeistroinstitucionhistoricoeditar"));

    console.log(" conectado");

    let url = "../controlador/ctlr-reg-instituciones.php?op=guardarinstitucionhistoricoeditar";
    fetch(url, {
        method: "post",
        body: datos,
    })
        .then((data) => data.json())
        .then((data) => {
            var status = data.status;
            var datos = data.data;

            switch (status){
                case 'institucionhistorico_ya_existe':
                    swal.fire({
                        title: "¡Esta Institucion Ya Existe!",
                        icon: "error",
                    });
                    break;

                case 'institucion_registrada_exitoso':

                    var backgroundeditar = document.getElementById("backgroundeditar");

                    backgroundeditar.style.animationName = "fadeOuteditar";
                    backgroundeditar.style.animationDuration = "0.18s";

                    backgroundeditar.addEventListener('animationend', function() {
                    backgroundeditar.style.display = "none"; 
                    }, {once: true});

                    document.getElementById('myModal2editar').style.display = "none";
                    formdatainstitucionhistorico.reset();
                    swal.fire({
                        title: "¡Registro Exitoso!",
                        icon: "success",
                    });
                    // Aquí es donde actualizamos la lista de instituciones
                    dataCopyEditar.push(datos); // Añadimos la nueva institución a la copia de los datos
                    updateOptionsListeditar(dataCopyEditar);
                    break;
            }

        })
        .catch((error) => console.log(`error: ${error}`));
});