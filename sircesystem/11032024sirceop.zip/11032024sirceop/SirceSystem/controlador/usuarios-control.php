<?php
require_once "../config/dbconexion.php";
require_once "../modelo/ModeloUsuarios.php";

session_start();

$usuarios = new Usuarios();

switch ($_GET["op"]) {

        case 'listar':
        $result_set = $usuarios->get_usuarios();
        $data = array();
        foreach ($result_set as $row) {
            array_push($data, array("CodigoPersona" => $row['CodigoPersona'], "CodigoUsuario" => $row['CodigoUsuario'], "RolUsuario" => $row['RolUsuario'], "EstatusUsuario" => $row['EstatusUsuario'], "NombreUsuario" => $row['NombreUsuario']));
        }
            echo json_encode($data); //formateado como json
        break;

        case 'guardar':
        $CodigoPersona = $_POST['codigopersonauser'];
        $tipouser = $_POST['tipouser'];
        $nombreunewuser = $_POST['nombreunewuser'];
        $passnewuser = password_hash($_POST['passnewuser'], PASSWORD_BCRYPT);
        //$passnewuser = $_POST['passnewuser'];
        $idusuario = $_SESSION['iduser'];
        $estatususuarioinput = $_POST['estatususuarioinput'];

        $insercion = $usuarios->insert_usuario($CodigoPersona, $tipouser, $nombreunewuser, $passnewuser,$idusuario, $estatususuarioinput);
        echo json_encode($insercion);
        break;

        case 'get_usuario':
        $idusuarioeditar = $_POST['idusuarioeditar'];
        $data = $usuarios->get_editarmodalusuario($idusuarioeditar);
            echo json_encode($data);
        break;

        case 'update':
        $CodigoPersonaedit = $_POST['codigopersonausereditar'];
        $Codiusuarioedit = $_POST['codigousereditar'];
        $tipouseredit = $_POST['tipousereditar'];
        $nombreunewuseredit = $_POST['nombreunewusereditar'];
        $estatususuarioedit = $_POST['estatususuarioeditar'];
        //$passnewuseredit = password_hash($_POST['passnewusereditar'], PASSWORD_BCRYPT);
        $idusuarioedit = $_SESSION['iduser'];

        $actualizacion = $usuarios->update_usuario($CodigoPersonaedit, $Codiusuarioedit, $tipouseredit, $nombreunewuseredit, $estatususuarioedit, $idusuarioedit);
        echo json_encode($actualizacion);
        break;

        case 'get_persona':
        $CedulaPersona = $_POST['buscarcedu'];
        $data = $usuarios->get_persona($CedulaPersona);
            echo json_encode($data);
        break;

        case 'check_nombre_usuario':
            $Nombreuser = $_POST['nombreuser'];
            $existe = $usuarios->verificar_nombre_usuario($Nombreuser);
            echo json_encode(array("existe" => $existe));
            
        break;  

        case 'inserlogintbitacorauser':
            $Nameuser = $_POST['nombreusuario'];
            $Nombreuser = $_SESSION['iduser'];
            $idusuario = $_SESSION['iduser'];
            $actividadrealizada = 'Inicio de Sesion';
            $informacionactual = 'Datos de inicio de sesion Id: ' . $idusuario . ' Usuario: ' . $Nameuser;
            $login = $usuarios->sesion_bitacora($Nameuser, $Nombreuser, $idusuario, $actividadrealizada, $informacionactual);
            echo json_encode($login);
        break;

        case 'insercerrarlogintbitacorauser':
            $Nameuser = $_SESSION['usuarioad'];
            $Nombreuser = $_SESSION['iduser'];
            $idusuario = $_SESSION['iduser'];
            $actividadrealizada = 'Cierre de Sesion';
            $informacionactual = 'Datos de Cierre de sesion Id: ' . $idusuario . ' Usuario: ' . $Nameuser;
            $login = $usuarios->sesion_bitacora($Nameuser, $Nombreuser, $idusuario, $actividadrealizada, $informacionactual);
            echo json_encode($login);
        break;

        case 'updatepassuser':
            $CodigoPersonapass = $_POST['codigopersonauserpasseditar'];
            $Codiusuariopass = $_POST['codigouserpasseditar'];
            $newpassworduser = password_hash($_POST['newpasswordusereditar'], PASSWORD_BCRYPT);
            $idusuario = $_SESSION['iduser'];

            $actualizacionpassword = $usuarios->update_newpassworduser($Codiusuariopass, $newpassworduser, $idusuario);
            echo json_encode($actualizacionpassword);
            break;

        case 'cambionombreuser':
            $codusuario = $_SESSION['iduser'];
            $Nombreuser = $_POST['nombreusuarioeditar'];
            
            $idusuario = $_SESSION['iduser'];
            $actualizacionpassword = $usuarios->update_nombreuser($codusuario, $Nombreuser, $idusuario);
            echo json_encode($actualizacionpassword);
            break;

        case 'cambiopassworduser':
            $codusuario = $_SESSION['iduser'];
            $passworduser = password_hash($_POST['newpassworduser'], PASSWORD_BCRYPT);
            
            $idusuario = $_SESSION['iduser'];
            $actualizacionpassword = $usuarios->update_passworduser($codusuario, $passworduser, $idusuario);
            echo json_encode($actualizacionpassword);
            break;

        case 'cambiopassworduseranalistaconsulta':
            $codusuario = $_SESSION['iduser'];
            $passwordactualuser = $_POST['passwordactualuser'];
            $newpasswordusuario2 = password_hash($_POST['newpasswordusuario2'], PASSWORD_BCRYPT);
            
            $idusuario = $_SESSION['iduser'];
            $actualizacionpassword = $usuarios->update_passworduseranalistaconsulta($codusuario, $passwordactualuser,$newpasswordusuario2, $idusuario);
            echo json_encode($actualizacionpassword);
            break;

        case 'get_usuariouser':
            $idusuariouser = $_SESSION['iduser'];
            $data = $usuarios->get_usuariouser($idusuariouser);
            echo json_encode($data);
        break;

        case 'guardarusuarioexterno':

            $cedulaexterno = $_POST['cedulaexterno'];
            $nombreexterno = $_POST['nombreexterno'];
            $apellidosexterno = $_POST['apellidosexterno'];
            $telefonopexterno = $_POST['telefonopexterno'];
            $telefonohexterno = $_POST['telefonohexterno'];
            $emailexterno = $_POST['emailexterno'];
            $fechanacexterno = $_POST['fechanacexterno'];
            $direccionexterno = $_POST['direccionexterno'];
            $tipopersonaexterno = $_POST['tipopersonaexterno'];
            
            $tipouserexterno = $_POST['tipouserexterno'];
            $nombreuserexterno = $_POST['nombreuserexterno'];
            //$passnewuser = password_hash($_POST['passnewuser'], PASSWORD_BCRYPT);
            $passexterno = $_POST['passexterno'];
            $idusuario = $_SESSION['iduser'];
            $estatusexterno = $_POST['estatusexterno'];

            $insercion = $usuarios->insert_usuarioexterno($cedulaexterno, $nombreexterno, $apellidosexterno, $telefonopexterno,$telefonohexterno, $emailexterno, $fechanacexterno, $direccionexterno, $tipopersonaexterno, $tipouserexterno, $nombreuserexterno, $passexterno, $idusuario, $estatusexterno);
            echo json_encode($insercion);
        break;

        case 'buscarnombrebienvenida':
            $idusuarionombreuser = $_SESSION['iduser'];
            $datanombreuser = $usuarios->get_buscarnombrebienvenida($idusuarionombreuser);
            echo json_encode($datanombreuser);
        break;

        default:
        # code...
        break;
    }
