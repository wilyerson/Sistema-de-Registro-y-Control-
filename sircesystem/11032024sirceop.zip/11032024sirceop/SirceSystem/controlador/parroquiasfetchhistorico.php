<?php 


	require_once "../modelo/ModeloParroquia.php";

	$parroquias = [];
	if (isset($_GET['id_munH'])) {
		$tabla_parroquia = new parroquia();
		$parroquias = $tabla_parroquia->obtener_parroquia_select($_GET['id_munH']);
	}
		echo json_encode(['data' => $parroquias] );

		
 ?>