<?php 


$conn = mysqli_connect("localhost","root","","sirceop"); 

//$id = $_GET['id'];
//$usuarios = "SELECT * FROM persona WHERE idpersona = '$id'";


?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro de Personal</title>
  <link href="../estilos/estiloregistropersona.css" rel="stylesheet" type="text/css">
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
  <link href="../estilos/estilosrepersona.css" rel="stylesheet">
  

  <style>

    @font-face{
      font-family: opensan;
      src: url(fonts/googlesansnormal.woff2);

    }

    body{
      font-family: opensan;
    }

    .menumenu{
      margin: 0 auto;
      width: 900px;
    }
    .articulo{
      margin: 100px auto 0;
      max-width: 900px;
    }
    .nuevo-trb{
      text-decoration: none;
      color: white;
    }
    .linka{
      color: black;
    }

    #iconomunero1{
      position: relative;
      width: 5%;
      top: -52%;
      left: 10%;
      cursor: pointer;
    }

    #iconomunero2{
      position: relative;
      width: 5%;
      top: -52%;
      left: 27%;
      cursor: pointer;
    }

    #iconomunero3{
      position: relative;
      width: 5%;
      top: -52%;
      left: 47%;
      cursor: pointer;
    }

    #iconomunero4{
      position: relative;
      width: 5%;
      top: -52%;
      left: 67%;
      cursor: pointer;
    }

    #linea{
      position: relative;
      top: -35%;
    }

    #letranumero1{
      position: relative;
      width: 5%;
      top: -50%;
      left: 10%;
    }

    #letranumero2{
      position: relative;
      width: 5%;
      top: -74%;
      left: 30%;
    }

    #letranumero3{
      position: relative;
      width: 5%;
      top: -88%;
      left: 57%;
    }

    #letranumero4{
      position: relative;
      width: 5%;
      top: -104%;
      left: 82%;
    }

    #multiregister{
      margin: 0px 0px -210px;
    }

    #imgcedula{
      display: none;
      width: 602px;
      height: 357px;
    }



  </style>
  
</head>
<?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>
<body class="bg-gray">

   <?php 

 $rolusuario = $_SESSION["roluser"];

 switch ($rolusuario) {

        case 'administrador':

          include"../componentes/nav.php";
        break;

        case 'analista':

          include"../componentes/nav-analista.php";
        break;

        case 'consulta':

          include"../componentes/nav-consulta.php";
        break;


        default:
        # code...
        break;
    }

 ?>


  <div class="container py-3 bg-white" style="max-width: 1000px; 
  margin-top: 100px;
  margin-bottom: 20px;
  ">

  <!--  CONTENIDO  -->

  <div class="tab-content" id="pills-tabContent">
    <!-- TAB-PERFIL  -->


    <div class="articulo tab-pane  active" id="nav-perfil" role="tabpanel" aria-labelledby="nav-perfil-tab" >


      <form id="formdatap" name="formulario1" class="row needs-validation"  method="post" enctype="multipart/form-data"  novalidate>


        <div id="multiregister" class="col col-sm-12">

          <hr id="linea" ></hr>
          <img id="iconomunero1" src="../icons/numero-uno.png">
          <img id="iconomunero2" src="../icons/numero-2inicio.png">
          <img id="iconomunero3" src="../icons/numero-3inicio.png">
          <img id="iconomunero4" src="../icons/numero-4inicio.png">


          <p id="letranumero1">Datos Básicos</p>
          <p id="letranumero2">Documentos</p>
          <p id="letranumero3">Historico</p>
          <p id="letranumero4">Familiares</p>

        </div>

        <!--TITULO DE NUEVO TRABAJADOR</!-->
        <div class="row mb-4">
          <div class="col col-sm-12">
            <h4>Registro de Personal</h4>
          </div>
        </div>


        <!--TITULO DE NUEVO TRABAJADOR</!-->

        <!--  CEDULA - ESTADO CIVIL</!--->

        <div class="row ">

          <div class="col-6 col-sm-6 formu-control">
            <label for="cedula" class="form-label" for="Cedulapersona">Cédula</label>
            <input minlength="7" maxlength="9" type="number" class="form-control inputss" id="Cedulapersona" name="Cedulapersona" placeholder="Ingrese Cédula de Identidad" >
            <img class="fas fa-check-circle" src="../icons/circle-check-solid.svg" style="width: 25px;">
            <img class="fas fa-exclamation-circle" src="../icons/circle-exclamation-solid.svg" style="width: 25px;">
            <small>Error message</small>
          </div>

          <div class="col col-sm-6 formu-control">
           <label for="std-civil" class="form-label" for="Estadocivil">Estado Civil</label>
           <select name="Estadocivil" class="form-select selectee inputss" style="text-transform: uppercase;" id="Estadocivil">
            <option selected disabled value="">Seleccione</option>
            <option value="casado">casado</option>
            <option value="soltero">soltero</option>
            <option value="soltero">viudo</option>
          </select>
          <small>Error message</small>
        </div>

      </div>

      <!--  CEDULA - ESTADO CIVIL</!--->

      <!-- IMAGEN</!--->

      <div class="row mb-4">
        <div class="col col-sm-12 formu-control">
          <label for="Fotopersona" class="form-label btn btn-primary" for="Fotopersona">Añadir Imagen Cedula</label>
          <input type="file" class="form-control inputss" id="Fotopersona" name="Fotopersona" style=" display: none; ">
          <img id="imgcedula" src="">
          <small>Error message</small>
        </div>
      </div>

      <!-- IMAGEN</!--->

      <!-- NOMRBES Y APELLIDOS</!--->

      <div class="row mb-4">

        <div class="col col-sm-6 formu-control">
          <label for="Nombres" class="form-label inputss" for="Nombres" >Nombres</label>
          <input minlength="4" maxlength="20" type="text" class="form-control" placeholder="Ingrese Nombres" style="text-transform: uppercase;" id="Nombres" name="Nombres">
          <small>Error message</small>
        </div>

        <div class="col col-sm-6 formu-control">
          <label for="Apellidos" class="form-label inputss" for="Apellidos" >Apellidos</label>
          <input minlength="4" maxlength="25" type="text" class="form-control" placeholder="Ingrese Apellidos" style="text-transform: uppercase;" id="Apellidos" name="Apellidos">
          <small>Error message</small>
        </div>

      </div>

      <!-- NOMRBES Y APELLIDOS</!--->

      <!-- FECHA - SEXO</!--->

      <div class="row mb-4">

        <div class="col col-sm-6 formu-control">
          <label for="fecha-nac" class="form-label" for="Fechanacimiento" >Fecha de Nacimiento</label>

          <input type="date" class="form-control inputss" id="Fechanacimiento" name="Fechanacimiento">
          <small>Error message</small>

          <div id="mostraredad" >

          </div>
        </div>

        <div class="col col-sm-6 formu-control">
         <label for="sexo" class="form-label" for="sexo" >Sexo</label>
         <select name="sexo" class="form-select inputss" id="sexo">
          <option selected disabled value="">Seleccione</option>
          <option value="MASCULINO">MASCULINO</option>
          <option value="FEMENINO">FEMENINO</option>

        </select>
        <small>Error message</small>
      </div>

    </div>

    <!-- FECHA - SEXO</!--->

    <!--  NUMEROS TELEFONICOS </!--->

    <div class="row mb-4">
      <div class="col sm-6 formu-control">
        <label for="Telefonoprincipal" class="form-label">Numero telefonico Principal</label>
        <input min="11" max="20" placeholder="Ingrese su Número Telefónico" type="number" class="form-control inputss" id="Telefonoprincipal" name="Telefonoprincipal">
        <small>Error message</small>
      </div>
      <div class="col sm-6 formu-control">
        <label for="Telefonohabitacion" class="form-label">Numero telefonico Habitacion</label>
        <input min="11" max="20" placeholder="Ingrese su Número Telefónico" type="number" class="form-control inputss" id="Telefonohabitacion" name="Telefonohabitacion">
        <small>Error message</small>
      </div>
    </div>

    <!--  NUMEROS TELEFONICOS </!--->


    <!-- LOCALIDAD</!--->

    <div class="row mb-4">

      <div class="col col-sm-6">
        <label for="municipio" class="form-label">Municipio</label>
        <select name="cosa" class="form-select" id="municipio" style="text-transform: uppercase;" aria-label="Default select example" onchange="cambia()">
          <option selected disabled value>Seleccione Municipio</option>
          <?php 

            require "../controlador/municipiosfetch.php";

            foreach ($municipio as $municipio) {
              echo '<option value="'.$municipio['CodigoMunicipio'].'">'.$municipio['NombreMunicipio'].'</option>';
              }
            ?>
        </select>
      </div>

      <di|v class="col col-sm-6">
        <label for="parroquia" class="form-label">Parroquia</label>
        <select name="opt" style="text-transform: uppercase;" id="parroquia" class="form-select">
          <option selected disabled value="">Seleccione Parroquia</option>
          </select>
          <script>document.querySelector('#municipioinstitucion').addEventListener('change', event => {console.log(event.target.value);fetch('../controlador/parroquiasfetch.php?municipioinstitucion='+event.target.value).then(res => {if(!res.ok){throw new Error('error en la respuesta');}return res.json();}).then(datos => {let html = '<option="">Seleccione Parroquia</option>';if(datos.data.length > 0){for(let i = 0; i < datos.data.length; i++){html += `<option value="${datos.data[i].CodigoParroquia}">${datos.data[i].NombreParroquia}</option>`;}}document.querySelector('#parroquiainstitucion').innerHTML = html;}).catch(error => {console.error('ocurrio un error '+error);});});</script>
        </div>

          <div class="mb-2 mt-4">
            <div class="col col-sm-12">
              <label for="sector" class="form-label">Sector</label>
              <input minlength="10" maxlength="50" type="text"placeholder="Ingrese Sector" class="form-control form-control-lg inputss" id="sector" name="nombresector">
            </div>
          </div>
          
          <div class="col col-sm-12 mt-4 formu-control">
            <label for="direccion" class="form-label">Dirección</label>
            <input minlength="10" maxlength="100" type="text" placeholder="Ingrese Dirección" class="form-control form-control-lg inputss" id="direccion" name="direccion">
            <small>Error message</small>
          </div>

        </div>


        <!-- LOCALIDAD</!--->

        <!--  PESO Y ESTATURA </!--->

        <div class="row mb-4">
          <div class="col sm-6 formu-control">
            <label for="peso" class="form-label">Peso (Kg)</label>
            <input minlength="1" maxlength="7" type="text" class="form-control inputss" placeholder=".Kg" id="peso" name="peso">
            <small>Error message</small>
          </div>
          <div class="col sm-6 formu-control">
            <label for="estatura" class="form-label">Estatura (Metros)</label>
            <input type="text" class="form-control inputss" placeholder=".Mts" id="estatura" name="estatura">
            <small>Error message</small>
          </div>
        </div>

        <!--  PESO Y ESTATURA </!--->

        <!--  TALLAS</!--->

        <div class="row mb-4">

          <div class="col sm-4 formu-control">
            <label for="camisa" class="form-label">Talla Camisa</label>
            <input minlength="1" maxlength="12" type="text" class="form-control inputss" placeholder="Torso" id="tallacamisa" name="tallacamisa">
            <small>Error message</small>
          </div>

          <div class="col sm-4 formu-control">
            <label for="pantalon" class="form-label">Talla Pantalón</label>
            <input minlength="1" maxlength="12" type="text" class="form-control inputss" placeholder="Piernas" id="tallapantalon" name="tallapantalon">
            <small>Error message</small>
          </div>

          <div class="col sm-4 formu-control">
            <label for="calzado" class="form-label">Talla Calzado</label>
            <input minlength="1" maxlength="12" type="text" class="form-control inputss" placeholder="Calzado" id="tallacalzado" name="tallacalzado">
            <small>Error message</small>
          </div>




        </div>

        <!--  TALLAS</!--->
        <div class="row text-center">
          <div class="col col-sm-12">
            <button class="btn btn-secondary" type="reset">Limpiar</button> 
            <button class="btn btn-primary" id="Guardarp"  type="submit" name="Guardarp">Registrar</button>      
          </div>
          <div class="col col-sm-12">

          </div>
        </div>


        <!--  modal seguir -->

        <!-- Modal -->
        <!-- Button trigger modal -->
        <!-- Button trigger modal -->
 <!--<button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modalregistrardocumentos">
              Añadir Documentos
            </button>-->




          </div>

          <!-- Modal -->
          <div class="modal fade" id="modalregistrarexitoso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->

                </div>
                <div class="modal-body">

                  <div class="row">


                    <div class="col col-sm-6">

                      <p>registro existoso</p>
                    </div>


                  </div>

                </div>
                <div class="modal-footer">


                </div>
              </div>
            </div>
          </div>


          <!-- modal seguir  -->

          <div class="modal fade" id="modalregistrarrellenecampos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                  <div class="row" style="position: relative; left: 27%;">



                    <div class="col col-sm-6">

                      <svg class="checkmarkerror" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52"><circle class="checkmark_circle_error" cx="26" cy="26" r="25" fill="none"/><path class="checkmark_checkerror" stroke-linecap="round" fill="none" d="M16 16 36 36 M36 16 16 36
                        "/></svg>

                        <p>rellener todos los campos</p>
                      </div>


                    </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    

                  </div>
                </div>
              </div>
            </div>


            <div class="modal fade" id="modaledad" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">

                    <div class="row" >


                      <div class="col col-sm-6">

                        <p>no se puede registrar menores de edad, debe tener 18 años</p>
                      </div>


                    </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>


                  </div>
                </div>
              </div>
            </div>

            <!-- modal seguir  -->

            <!-- modal registro exitoso  -->

            <div class="modal fade" id="modalregistrexitosopersona" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">

                    <div class="row" style="position: relative; left: 27%;" >


                      <div class="col col-sm-6">


                       <svg width="100" height="100" class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52" style=" position: relative; left: -8%;">
                        <g stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10">
                          <circle class="checkmark__circle" cx="26" cy="26" r="26" fill="none"/>
                          <path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
                        </g>
                      </svg>


                      <p style="position: relative;left: 19%;">registro exitoso</p>
                    </div>


                  </div>

                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                  <!--<button type="submit" name="Guardard" class="btn btn-primary">registrar documentos</button>-->
                  <a href="registrodocumentosprincipal.php?htmlcedulap=">Continuar</a>
                </div>
              </div>
            </div>
          </div>

          <!-- modal registro exitoso  -->





        </form>

      </div>

      <!-- TAB-PERFIL  -->

      <!-- TAB-PERFIL  -->
      
      <!-- TAB-PERFIL  -->



      <!--  CONTENIDO  -->
      <script src="../js/jquery.min.js"></script>
      <script src="../js/registropersona.js"></script>
      <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="../js/vistapreviafotopersona.js"></script>

      <script type="text/javascript">
        const botonirpersona = document.getElementById("iconomunero1");
        const botonirdocumento = document.getElementById("iconomunero2");
        const botonirhistorico = document.getElementById("iconomunero3");
        const botonirfamiliar = document.getElementById("iconomunero4");

        botonirpersona.onclick = function() {

          window.location.href ='registro-persona.php';


        }

        botonirdocumento.onclick = function() {

          window.location.href ='registrodocumentosprincipal.php';


        }

        botonirhistorico.onclick = function() {

          window.location.href ='registrohistoricoprincipal.php';


        }

        botonirfamiliar.onclick = function() {

          window.location.href ='registrofamiliarprincipal.php';


        }


      </script>


      <script src="../js/registropersonamain.js"></script>
    </body>
    </html>