<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Perfil de Usuario</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
  

  <style>

    @font-face{
      font-family: opensan;
      src: url(fonts/googlesansnormal.woff2);

    }

    body{
      font-family: opensan;
      
    }

    #nombreusuario{
      animation: animacionletrabienvenida 1.5s ease-in-out ;

    }



    @keyframes animacionletrabienvenida { 
      0%{color: white;}
      /*50%{background-position:96% 100%}*/
      100%{color: black;}
    }

    #zonanombreusuario{
      box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
      -moz-box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
    }

        .successinput input {
      border-color: #2ecc71;
      border-width: 3.8px;
    }

    .errorinput input {
      border-color: #e74c3c;
      border-width: 3.8px;
    }

    .successinput select {
      border-color: #2ecc71;
      border-width: 3.8px;
    }

    .errorinput select {
      border-color: #e74c3c;
      border-width: 3.8px;
    } 

    small {
      color: #e74c3c;

      visibility: hidden;
    }

    .successinput small {
      color: #e74c3c;

      visibility: hidden;
    }

    .errorinput small {
      visibility: visible;
      font-size: 98%;
      font-weight: bold;
    }

  </style>

</head>
<body class="bg-gray">

    <?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>

  <?php 

 $rolusuario = $_SESSION["roluser"];

 switch ($rolusuario) {

        case 'administrador':

          include"../componentes/nav.php";
        break;

        case 'analista':

          include"../componentes/nav-analista.php";
        break;

        case 'consulta':

          include"../componentes/nav-consulta.php";
        break;


        default:
        # code...
        break;
    }

 ?>


  <div class="container border py-3 bg-white rounded-3 shadow" id="zonanombreusuario" 
        style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;">

      <div class="row mb-4 mt-2"> 
        <h4 class="text-center">Perfil de Usuario: <label id="maneuserperfil"></label></h4>
      </div>

      <div class="row mb-5 mt-3"> 
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalcambiarnombreusurio" style="width: 28%;
    margin-left: 35%;">
        Cambiar Nombre de Usuario
       </button>
      </div>

       <?php 

 $rolusuario = $_SESSION["roluser"];

 switch ($rolusuario) {

        case 'administrador':
?>
      <div class="row mb-5 mt-3"> 
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalcambiarpasswordusuario" style="width: 28%;
    margin-left: 35%;">
        Cambiar Contraseña
        </button>
      </div>  
<?php 

        break;

        case 'analista':
?>
      <div class="row mb-5 mt-3"> 
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalcambiarpasswordusuarioanalistaconsulta" style="width: 28%;
    margin-left: 35%;">
        Cambiar Contraseña
        </button>
      </div>  
<?php 
          
        break;

        case 'consulta':
?>
      <div class="row mb-5 mt-3"> 
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalcambiarpasswordusuarioanalistaconsulta" style="width: 28%;
    margin-left: 35%;">
        Cambiar Contraseña
        </button>
      </div>  
<?php          
        break;
        
        default:
        # code...
        break;
    }

 ?>

  

  </div>

  <!-- Modal cambiar nombre usuario-->
<div class="modal fade" id="modalcambiarnombreusurio" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #009aff;">
        <h5 class="modal-title text-white" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="z-index: 5;"></button>
      </div>
      <div class="modal-body">
        
        <form id="formcambionombreusuario" method="post">

        <div class="row mb-4 mt-2"> 
        <h5 class="text-left">Cambio de Nombre de Usuario</h5>
        </div>

          <div class="form-floating mb-3">
            <input type="text" class="form-control" id="nombreusuarioeditar" name="nombreusuarioeditar" placeholder="nombre" autocomplete="usuario-161254789">
            <label for="nombreunewuser" autocomplete="">Ingrese Nombre de Usuario</label>
            <div class="invalid-feedback invisible p-0 m-0" id="n-no-valido">Nombre de Usuario no Valido</div>
            <div class="form-text invalid-feedback invisible p-0 m-0" id="n-valido">Este Nombre de Usuario ya está siendo usado</div>
          </div>

          <div class="row text-center" style="margin-top: 8%;">
            <div class="col col-sm-12">
              <button class="btn btn-secondary" type="reset" style="margin-right: 3%;">Limpiar</button> 
              <button class="btn btn-primary" id="cambiarpassuser"  type="submit" name="cambiarpassuser">Cambiar</button>      
            </div>
          </div>

        </form>  

      </div>

    </div>
  </div>
</div>

<!-- Modal cambiar password usuario administrador-->
<div class="modal fade" id="modalcambiarpasswordusuario" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #009aff;">
        <h5 class="modal-title text-white" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="z-index: 5;"></button>
      </div>
      <div class="modal-body">
    
        <form id="formcambiopassword" method="post">

        <div class="row mb-4 mt-2"> 
        <h5 class="text-left">Cambio de Contraseña</h5>
        </div>

          <div class="form-floating input-group">
            <input type="password" class="form-control" id="newpassworduser" name="newpassworduser" placeholder="ctr1" autocomplete="">
            <label for="newpassworduser">Ingrese la Nueva Contraseña</label>
            <img class="input-group-text" id="imgnu" src="../icons/ojo-ver.svg" style="width: 50px; cursor: pointer;">
          </div>
            <div class="form-text invisible is-invalid" id="c_invalida">Contraseña Invalida</div>

          <script>
            const passnu = document.getElementById("newpassworduser"),
            iconnu = document.getElementById("imgnu");

            iconnu.addEventListener("click", e =>{
              if(passnu.type === "password") {
                passnu.type = "text";
                iconnu.src = "../icons/ojo-slash.svg";
              }else{
                passnu.type = "password";
                iconnu.src = "../icons/ojo-ver.svg";
              }
            })

          </script>

          <div class="form-floating input-group mb-3">
            <input type="password" class="form-control" id="newpassworduser2" name="newpassworduser2" placeholder="ctr2" autocomplete="usuario-161254789" autocomplete="usuario-161254789" autocomplete="usuario-161254789">
            <label for="newpassworduser2">Repita Nuevamente la Nueva Contraseña</label>
            <img class="input-group-text" id="imgnu2" src="../icons/ojo-ver.svg" style="width: 50px; cursor: pointer;">
          </div>
            <div class="form-text invisible p-0 m-0" id="c_noc">Las Contraseñas no coinciden</div>
            <div class="form-text invisible p-0 m-0" id="c_sic">Las Contraseñas coinciden</div>

          <script>
            const passnu2 = document.getElementById("newpassworduser2"),
            iconnu2 = document.getElementById("imgnu2");

            iconnu2.addEventListener("click", e =>{
              if(passnu2.type === "password") {
                passnu2.type = "text";
                iconnu2.src = "../icons/ojo-slash.svg";                 
              }else{
                passnu2.type = "password";
                iconnu2.src = "../icons/ojo-ver.svg";                 
              }
            })
          </script>

    <div class="row text-center">
      <div class="col col-sm-12">
        <button class="btn btn-secondary" type="reset" style="margin-right: 3%;">Limpiar</button> 
        <button class="btn btn-primary" id="cambiarpassuser"  type="submit" name="cambiarpassuser">Cambiar</button>      
      </div>
    </div>

      </form>

      </div>
      
    </div>
  </div>
</div>

<!-- Modal cambiar password usuario para analista y consulta-->
<div class="modal fade" id="modalcambiarpasswordusuarioanalistaconsulta" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #009aff;">
        <h5 class="modal-title text-white" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="z-index: 5;"></button>
      </div>
      <div class="modal-body">
    
        <form id="formcambiopasswordanalistaconsulta" method="post">

        <div class="row mb-4 mt-2"> 
        <h5 class="text-left">Cambio de Contraseña</h5>
        </div>

          <div class="form-floating input-group">
            <input type="password" class="form-control" id="passwordactualuser" name="passwordactualuser" placeholder="ctr1" autocomplete="">
            <label for="passwordactualuser">Ingrese la Contraseña Actual</label>
            <img class="input-group-text" id="imgnu11" src="../icons/ojo-ver.svg" style="width: 50px; cursor: pointer;">
          </div>
            <div class="form-text invisible is-invalid" id="c_invalida">Contraseña Invalida</div>

          <script>
            const passnu1 = document.getElementById("passwordactualuser"),
            iconnu1 = document.getElementById("imgnu11");

            iconnu1.addEventListener("click", e =>{
              if(passnu1.type === "password") {
                passnu1.type = "text";
                iconnu1.src = "../icons/ojo-slash.svg";
              }else{
                passnu1.type = "password";
                iconnu1.src = "../icons/ojo-ver.svg";
              }
            })

          </script>

          <div class="form-floating input-group">
            <input type="password" class="form-control" id="newpassworduserr" name="newpassworduserr" placeholder="ctr1" autocomplete="">
            <label for="newpassworduserr">Ingrese la Nueva Contraseña</label>
            <img class="input-group-text" id="imgnu22" src="../icons/ojo-ver.svg" style="width: 50px; cursor: pointer;">
          </div>
            <div class="form-text invisible is-invalid" id="c_invalida">Contraseña Invalida</div>

          <script>
            const passnu22 = document.getElementById("newpassworduserr"),
            iconnu22 = document.getElementById("imgnu22");

            iconnu22.addEventListener("click", e =>{
              if(passnu22.type === "password") {
                passnu22.type = "text";
                iconnu22.src = "../icons/ojo-slash.svg";
              }else{
                passnu22.type = "password";
                iconnu22.src = "../icons/ojo-ver.svg";
              }
            })

          </script>

          <div class="form-floating input-group mb-3">
            <input type="password" class="form-control" id="newpasswordusuario2" name="newpasswordusuario2" placeholder="ctr2" autocomplete="usuario-161254789" autocomplete="usuario-161254789" autocomplete="usuario-161254789">
            <label for="newpasswordusuario2">Repita Nuevamente la Nueva Contraseña</label>
            <img class="input-group-text" id="imgnu33" src="../icons/ojo-ver.svg" style="width: 50px; cursor: pointer;">
          </div>
            <div class="form-text invisible p-0 m-0" id="c_noc">Las Contraseñas no coinciden</div>
            <div class="form-text invisible p-0 m-0" id="c_sic">Las Contraseñas coinciden</div>

          <script>
            const passnu33 = document.getElementById("newpasswordusuario2"),
            iconnu33 = document.getElementById("imgnu33");

            iconnu33.addEventListener("click", e =>{
              if(passnu33.type === "password") {
                passnu33.type = "text";
                iconnu33.src = "../icons/ojo-slash.svg";                 
              }else{
                passnu33.type = "password";
                iconnu33.src = "../icons/ojo-ver.svg";                 
              }
            })
          </script>

    <div class="row text-center">
      <div class="col col-sm-12">
        <button class="btn btn-secondary" type="reset" style="margin-right: 3%;">Limpiar</button> 
        <button class="btn btn-primary" id="cambiarpassuser"  type="submit" name="cambiarpassuser">Cambiar</button>      
      </div>
    </div>

      </form>

      </div>
      
    </div>
  </div>
</div>

  <script src="../js/jquery.min.js"></script>
  <script src="../librerias/wall.js"></script>
  <script src="../js/perfilusuario.js"></script>

</body>
</html>