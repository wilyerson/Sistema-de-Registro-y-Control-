<?php 
	require_once "ModeloConeccion.php";

	class municipio{

		public function obtener_municipios_select(){
			$db = new coneccion();
			$query = "SELECT CodigoMunicipio, NombreMunicipio from municipio";
			$resultado = $db->query($query);
			$datos=[];
			if ($resultado->num_rows) {
				while ($row = $resultado->fetch_assoc()) {
					$datos[] = [
						'NombreMunicipio' => $row['NombreMunicipio'],
						'CodigoMunicipio' => $row['CodigoMunicipio'],
					];				
				}			
			}
			return $datos;
		}
	}

 ?>