const formdatainstitucionhistorico = document.querySelector("#formulariogeistroinstitucionhistorico");
formdatainstitucionhistorico.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formulariogeistroinstitucionhistorico"));

	console.log(" conectado");

	let url = "../controlador/ctlr-reg-instituciones.php?op=guardarinstitucionhistorico";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);
			dibujarTabla(data);
			formdata.reset();
			swal.fire({
				title: "¡Registro Exitoso!",
				icon: "success",
			});
		})
		.catch((error) => console.log(`error: ${error}`));
});