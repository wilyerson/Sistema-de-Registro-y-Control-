document.querySelector('#icononosmenucerrarsesion').addEventListener('click', function(event) {
    event.preventDefault();

    let url = "../controlador/usuarios-control.php?op=insercerrarlogintbitacorauser";

    fetch(url, {
        method: "post",
    })
    .then((data) => data.json())
    .then((data) => {
        console.log(data);

        if (data.estado === 'exito') {
            location.href = `../controlador/cierre.php`;
        }

    })
    .catch((error) => console.log(`error: ${error}`));
});