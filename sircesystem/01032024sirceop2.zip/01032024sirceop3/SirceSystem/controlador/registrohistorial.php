<?php
$persona_id = $_POST['idpersonahistorial'];
$institucion = $_POST['institucionhistorico'];
$cargo = $_POST['cargohistorico'];
$fecha_inicio = $_POST['fecha-iniciohistorial'];
$fecha_fin = isset($_POST['fecha-culminacionhistorial']) ? $_POST['fecha-culminacionhistorial'] : NULL;
$observacion = $_POST['observacionhistorico'];

// Conexión a la base de datos
$conexion = new mysqli('localhost', 'root', '', 'sirceop');

// Verificar si hay superposición de fechas
$sql = "SELECT COUNT(*) AS count FROM historico WHERE personal = ? AND ((FechaInicio <= ? AND (FechaCulminacion >= ? OR FechaCulminacion IS NULL)) OR (FechaInicio <= ? AND (FechaCulminacion >= ? OR FechaCulminacion IS NULL)) OR (FechaInicio >= ? AND (FechaCulminacion <= ? OR FechaCulminacion IS NULL)))";
$stmt = $conexion->prepare($sql);
$stmt->bind_param('issssss', $persona_id, $fecha_inicio, $fecha_inicio, $fecha_fin, $fecha_fin, $fecha_inicio, $fecha_fin);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row['count'] > 0) {
    echo "Las fechas se superponen con un registro existente.";
} else {
    // Insertar el nuevo registro
    $sql = "INSERT INTO historico (personal, FechaInicio, FechaCulminacion, Cargo, InstitucionHistorico, Obervacion) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($sql);
    $nullVar = NULL; // Variable para almacenar NULL
    if ($fecha_fin) {
        $stmt->bind_param('isssss', $persona_id, $fecha_inicio, $fecha_fin, $cargo, $institucion, $observacion);
    } else {
        $stmt->bind_param('isssss', $persona_id, $fecha_inicio, $nullVar, $cargo, $institucion, $observacion); // Pasamos la variable en lugar de NULL directamente
    }
    $stmt->execute();

    echo "Registro insertado correctamente.";
}
?>
