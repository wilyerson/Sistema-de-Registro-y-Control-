<?php 

const SERVER="localhost";
const DB="sirceop";
const USER="root";
const PASS="";
const UTF8="utf8";

const SGBD="mysql:host=".SERVER.";dbname=".DB.";charset=".UTF8;

class dbconexion
{
    protected function conexion()
    {
        try {
            $con = new PDO(SGBD, USER, PASS);
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $con;
        } catch (PDOException $e) {
            echo "Conexion Fallida: " . $e->getMessage();
        }
    }

    public function getConexion() {
        return $this->conexion();
    }
}

$db = new dbconexion();
$conexion = $db->getConexion();
$sql = "SELECT usuarios.CodigoUsuario, usuarios.NombreUsuario, bitacora.*
FROM bitacora 
INNER JOIN usuarios ON bitacora.idUsuario = usuarios.CodigoUsuario 
WHERE bitacora.idUsuario = :usersistema";
$stmt = $conexion->prepare($sql);
$stmt->bindParam(':usersistema', $_POST['usersistema'], PDO::PARAM_STR);
$stmt->execute();
$datosh = $stmt->fetchAll(PDO::FETCH_ASSOC);

if(!empty($datosh)){
    echo json_encode($datosh);
}else{
    echo json_encode([]);
}



?>