function camposVacioss(datos) {

    let institucionhistoricoreg = document.getElementById('institucionhistorico');
    let cargohistoricoreg = document.getElementById('cargohistorico');
    let fechainiciohistorialreg = document.getElementById('fecha-iniciohistorial');
    //let fechaculminacionhistorial = document.getElementById('fecha-culminacionhistorial');


    const institucionhistoricoregvalue = institucionhistoricoreg.value.trim();
    const cargohistoricoregvalue = cargohistoricoreg.value.trim();
    const fechainiciohistorialregvalue = fechainiciohistorialreg.value.trim();
    //const fechaculminacionhistorialvalue = fechaculminacionhistorial.value.trim();

    let hayCamposVacios = false;

	//--------------------validando los inputs

    if (institucionhistoricoregvalue == "") {
		setErrorFor(institucionhistoricoreg, 'Ingrese la Intitucion');
		hayCamposVacios = true;
	} else {
		setSuccessFor(institucionhistoricoreg);
	}

    if (cargohistoricoregvalue == "") {
		setErrorFor(cargohistoricoreg, 'Ingrese el Cargo');
		hayCamposVacios = true;
	} else {
		setSuccessFor(cargohistoricoreg);
	}

    if (fechainiciohistorialregvalue == "") {
		setErrorFor(fechainiciohistorialreg, 'Ingrese Fecha de Inicio');
		hayCamposVacios = true;
	} else {
		setSuccessFor(fechainiciohistorialreg);
	}

    // Agrega más condiciones aquí para los otros campos

    return hayCamposVacios;
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.classList.add('errorinput'); // Agrega la clase 'errorinput'
	small.innerText = message;
  }
  
  function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.classList.remove('errorinput');
	formControl.classList.add('successinput');
  
  }

const formdatahistorial = document.querySelector("#formregistrarhistorial");
formdatahistorial.addEventListener("submit", (e) => {
	e.preventDefault();

	let idpersonalhistorial = localStorage.getItem("idpesonaid");
	console.log(idpersonalhistorial);

	document.getElementById("idpersonahistorial").value = idpersonalhistorial;

	const datos = new FormData(document.getElementById("formregistrarhistorial"));

    //validar campos vacios
    if (camposVacioss(datos)) {
		//console.log('Hay campos vacíos');
		return;
	}

	console.log(" conectado");

	let url = "../controlador/ctr-historial.php?op=guardar";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);
			//ya hay un registro historico con estas fechas
			//no es requerido fecha de culminacion y ni observacion
			//cambiar cuando la fecha fin no exista poner al trabajador activo
			//el estatus del personal, si esta activo y la fecha del culminacion es null = no se puede registrar
            
            if (data == "Registro insertado correctamente.") {
                $('#registro-historico').modal("hide");
                swal.fire({
                    title: "¡Registro de Historial Exitoso!",
                    icon: "success",
                });
            }
            if (data == "Las fechas se superponen con un registro existente.") {
                swal.fire({
                    title: "¡Las fechas se superponen con un registro existente!",
                    icon: "error",
                });
            }

			mostrarHistorialLaboral();
		})
		.catch((error) => console.log(`error: ${error}`));

});


async function mostrarHistorialLaboral() {
    let idperhis = localStorage.getItem("idpesonaid");

    document.getElementById("idperhis").value = idperhis;

    try {
        const url = "../controlador/ctr-historial.php?op=editar";
        const datos = new FormData(document.getElementById("fomrcapturaridhis"));

        const response = await fetch(url, {
            method: "POST",
            body: datos,
        });

        if (!response.ok) {
            throw new Error(`Error al obtener los datos. Código de estado: ${response.status}`);
        }

        const responseData = await response.json();
        console.log(responseData); 

        let tbody = document.querySelector("#mostrarhistoriallaboral");
        tbody.innerHTML = "";
        if (responseData.length > 0) {
            for (let registro of responseData) {
                tbody.innerHTML += `
                    <tr>
                        <td class="text-left">${registro.NombreInstitucion}</td>
                        <td>${registro.NombreCargo}</td>
                        <td>${registro.FechaInicio}</td>
                        <td>${registro.FechaCulminacion}</td>
                        <td>
                        <form method="POST" id="editarhistorial">
                        <input type="hidden" id="codhistorial" name="codhistorial" value="${registro.CodigoHistorico}">

                        <div class="dropdown">
                        <a class="btn btn-primary dropdown-toggle" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                            Seleccione
                        </a>

                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <li><button  type="submit"  class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modal-editar-historial" >Editar</button></li>
                            <li><button  type="submit"  class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modal-verdatos-historico" >Ver Datos</button></li>
                        </ul>
                        </div>
                    </form> 
                        </td>
                    </tr>
                `;
            }
        } else {
            tbody.innerHTML += `
                <tr>
                    <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${responseData}</th>
                </tr>
            `;
        }
    } catch (error) {
        console.error(`Error en la solicitud: ${error.message}`);
    }
}

// Llamamos a la función al cargar la página
document.addEventListener('DOMContentLoaded', mostrarHistorialLaboral);
