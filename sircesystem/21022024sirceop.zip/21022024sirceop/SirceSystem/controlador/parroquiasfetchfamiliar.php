<?php 


	require_once "../modelo/ModeloParroquia.php";

	$parroquiaspersona = [];
	if (isset($_GET['idmunicipiofamiliar'])) {
		$tabla_parroquia = new parroquia();
		$parroquiaspersona = $tabla_parroquia->obtener_parroquia_select($_GET['idmunicipiofamiliar']);
	}
		echo json_encode(['data' => $parroquiaspersona] );

		
 ?>