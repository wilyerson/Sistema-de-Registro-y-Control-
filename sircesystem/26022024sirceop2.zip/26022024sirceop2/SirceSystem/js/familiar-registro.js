function camposVaciossss(datos) {
    let cedulafamiliar = datos.get("cedulafamiliar");
    let regpartidafamiliar = datos.get("regpartidafamiliar");
    let nombresfamiliar = datos.get("nombresfamiliar");
    let apellidosfamiliar = datos.get("apellidosfamiliar");
    let numtelefonofamiliar = datos.get("numtelefonofamiliar");
    let numtelefono2familiar = datos.get("numtelefono2familiar");


    let cedulafamiliarinputreg = document.getElementById('cedulafamiliar');
    let regpartidafamiliarinputreg = document.getElementById('regpartidafamiliar');
    let parentescofamiliarinputreg = document.getElementById('parentescofamiliar');
    let nombresfamiliarinputreg = document.getElementById('nombresfamiliar');
    let apellidosfamiliarinputreg = document.getElementById('apellidosfamiliar');
    let sexofamiliarinputreg = document.getElementById('sexofamiliar');
    let fechanacfamiliarinputreg = document.getElementById('fechanacfamiliar');
    let numtelefonofamiliarinputreg = document.getElementById('numtelefonofamiliar');
    let numtelefono2familiarinputreg = document.getElementById('numtelefono2familiar');

    //let fechaculminacionhistorial = document.getElementById('fecha-culminacionhistorial');


    const parentescofamiliarinputregvalue = parentescofamiliarinputreg.value.trim();
    const sexofamiliarinputregvalue = sexofamiliarinputreg.value.trim();
    const fechanacfamiliarinputregregvalue = fechanacfamiliarinputreg.value.trim();

    //const fechaculminacionhistorialvalue = fechaculminacionhistorial.value.trim();

    let hayCamposVacios = false;

	//--------------------validando los inputs

    //-----------checkbox de cedula----------------------------

    let checkboxfamiliarvalidar = document.getElementById('checkboxfamiliar').value;

    if (checkboxfamiliarvalidar == false ) {
        if (cedulafamiliar == "") {
            setErrorFor(cedulafamiliarinputreg, 'Ingrese la cedula');
            hayCamposVacios = true;
        } else {
            setSuccessFor(cedulafamiliarinputreg);
        }
    } else {
        if (regpartidafamiliar == "") {
            setErrorFor(regpartidafamiliarinputreg, 'Ingrese el numero de registro de la Partida de Nacimiento');
            hayCamposVacios = true;
        } else {
            setSuccessFor(regpartidafamiliarinputreg);
        }
    }

    //--------------------------------------------------------

    if (parentescofamiliarinputregvalue == "") {
		setErrorFor(parentescofamiliarinputreg, 'Ingrese el Parentesco');
		hayCamposVacios = true;
	} else {
		setSuccessFor(parentescofamiliarinputreg);
	}

    if (nombresfamiliar == "") {
		setErrorFor(nombresfamiliarinputreg, 'Ingrese el Nombre');
		hayCamposVacios = true;
	} else {
		setSuccessFor(nombresfamiliarinputreg);
	}

    if (apellidosfamiliar == "") {
		setErrorFor(apellidosfamiliarinputreg, 'Ingrese el Apellido');
		hayCamposVacios = true;
	} else {
		setSuccessFor(apellidosfamiliarinputreg);
	}

    if (sexofamiliarinputregvalue == "") {
		setErrorFor(sexofamiliarinputreg, 'Ingrese el Sexo');
		hayCamposVacios = true;
	} else {
		setSuccessFor(sexofamiliarinputreg);
	}

    if (fechanacfamiliarinputregregvalue == "") {
		setErrorFor(fechanacfamiliarinputreg, 'Ingrese la Fecha de Nacimiento');
		hayCamposVacios = true;
	} else {
		setSuccessFor(fechanacfamiliarinputreg);
	}

    if (numtelefonofamiliar == "") {
		setErrorFor(numtelefonofamiliarinputreg, 'Ingrese el Numero de Telefono Principal');
		hayCamposVacios = true;
	} else {
		setSuccessFor(numtelefonofamiliarinputreg);
	}

    if (numtelefono2familiar == "") {
		setErrorFor(numtelefono2familiarinputreg, 'Ingrese el Numero de Telefono de Habitacion');
		hayCamposVacios = true;
	} else {
		setSuccessFor(numtelefono2familiarinputreg);
	}

    // Agrega más condiciones aquí para los otros campos

    return hayCamposVacios;
}

function verificarCedula(cedula) {
    let urlVerificar = "../controlador/ctr-familiares.php?op=verificarcedula";
    let datosVerificar = new FormData();
    datosVerificar.append("cedulafamiliar", cedula);

    return fetch(urlVerificar, {
        method: "post",
        body: datosVerificar,
    })
    .then((data) => data.json())
    .then((data) => data.existe)
    .catch((error) => console.log(`error: ${error}`));
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.classList.add('errorinput'); // Agrega la clase 'errorinput'
	small.innerText = message;
  }
  
  function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.classList.remove('errorinput');
	formControl.classList.add('successinput');
  
  }

const formdatafamiliar = document.querySelector("#formregistrarfamiliar");

    // Obtén la referencia al campo de cédula
    let cedulapersonainputf = document.getElementById('cedulafamiliar');
    
    // Agrega el evento keyup al campo de cédula
    cedulapersonainputf.addEventListener('keyup', (e) => {
        const datos = new FormData(document.getElementById("formregistrarfamiliar"));
        verificarCedula(datos.get("cedulafamiliar")).then((existe) => {
            if (existe) {
                setErrorFor(cedulapersonainputf, 'Esta Cedula ya Existe');

            } else {
                setSuccessFor(cedulapersonainputf);
            }
        }).catch((error) => console.log(`error: ${error}`));
    });

    formdatafamiliar.addEventListener("submit", (e) => {
        e.preventDefault();
    
        let idpersonalfamiliar = localStorage.getItem("idpesonaid");
        console.log(idpersonalfamiliar);
    
        document.getElementById("idpersonafamiliar").value = idpersonalfamiliar;
    
        const datos = new FormData(document.getElementById("formregistrarfamiliar"));
    
                // Ejecuta ambas funciones al mismo tiempo
            Promise.all([verificarCedula(datos.get("cedulafamiliar")), camposVaciossss(datos)]).then((resultados) => {
                let existe = resultados[0];
                let camposVaciosResultado = resultados[1];
        
                if (existe) {
                    let cedulapersonainput = document.getElementById('cedulafamiliar');
                    setErrorFor(cedulapersonainput, 'Esta Cedula ya Existe');
                    Swal.fire({
                        title: "Esta Cedula ya Existe",
                        icon: "error"
                    });
                } else if (camposVaciosResultado) {
                    console.log("campos vacios");
                    return;
                } else {
    
        let url = "../controlador/ctr-familiares.php?op=guardar";
        fetch(url, {
            method: "post",
            body: datos,
        })
            .then((data) => data.json())
            .then((data) => {
                //console.log(`Success: ${JSON.stringify(data)}`);
                //dibujarTabla(data);
                //formdata.reset();
                
                $('#registro-familiar').modal('hide');
                swal.fire({
                    title: "¡Registro Exitoso de Familiar!",
                    icon: "success",
                });
                // Aquí llamas a la función que muestra los documentos en la tabla
                mostrarFamiliares();
            })
            .catch((error) => console.log(`error: ${error}`));
    
                        }
            })
            .catch((error) => console.log(`error: ${error}`));
    });

async function mostrarFamiliares() {
    let idperfami = localStorage.getItem("idpesonaid");
    console.log(idperfami);

    document.getElementById("idperfamilia").value = idperfami;

    var disablecedulaverfami = document.getElementById('cedulafamiliarver');

    disablecedulaverfami.disabled = true;

    

    try {
        const url = "../controlador/ctr-familiares.php?op=editar";
        const datos = new FormData(document.getElementById("fomrcapturaridfamilia"));

        const response = await fetch(url, {
            method: "POST",
            body: datos,
        });

        if (!response.ok) {
            throw new Error(`Error al obtener los datos. Código de estado: ${response.status}`);
        }

        let responseData = await response.json();
        responseData = responseData.reverse();
        console.log(responseData); 

                // Agrega la comprobación aquí
                if (Array.isArray(responseData) && responseData.length > 0) {
                 

        //----------------------calcular edad

        const fechaOriginal = responseData[0].FechaNacimiento; // Cambia esto a la fecha correcta

        function calcularEdadEnAnos(fechaNacimiento) {
		    if (typeof fechaNacimiento !== 'string' || !fechaNacimiento || isNaN(new Date(fechaNacimiento).getTime())) {
		        return 'Fecha de nacimiento inválida';
		    }

		    const [ano, mes, dia] = fechaNacimiento.split('-').map(Number);
		    const hoy = new Date();
		    const ahoraAno = hoy.getFullYear();
		    const ahoraMes = hoy.getMonth() + 1;
		    const ahoraDia = hoy.getDate();

		    let edad = ahoraAno - ano;

		    if (ahoraMes < mes || (ahoraMes === mes && ahoraDia < dia)) {
		        edad--; // Ajuste si aún no ha cumplido años este año
		    }

		    return `${edad} años`;
		}

		const edad = calcularEdadEnAnos(fechaOriginal);
		



		// Formatea la fecha al estilo "DD-MM-YYYY"
		function cambiarFormatoFecha(fecha) {
		    const partes = fecha.split('-'); // Divide la fecha en partes: año, mes, día
		    const nuevaFecha = `${partes[2]}-${partes[1]}-${partes[0]}`; // Reorganiza las partes en el nuevo formato
		    return nuevaFecha;
		}

		const fechaFormateada = cambiarFormatoFecha(fechaOriginal);

        //-----------------------------------

        let tbody = document.querySelector("#verfamiliares");
        tbody.innerHTML = "";
        if (responseData.length > 0) {
            for (let registro of responseData) {
                tbody.innerHTML += `
                    <tr>
                        <td class="text-left">${registro.Nombres}</td>
                        <td class="text-left">${registro.Apellidos}</td>
                        <td class="text-left">${registro.Parentesco}</td>
                        <td class="text-left">${calcularEdadEnAnos(registro.FechaNacimiento)}</td>
                        <td class="">
                          <form method="POST" id="editarfamiliar">
                        <input type="hidden" id="codfamiliar" name="codfamiliar" value="${registro.CodigoPersona}">

                        <div class="dropdown">
                        <a class="btn btn-primary dropdown-toggle" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                            Seleccione
                        </a>

                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <li><button  type="submit" id="botonmodificarfami" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modal-editar-familiar" >Editar</button></li>
                            <li><button  type="submit" id="verfamiliar" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modal-verdatos-familiar" >Ver Datos</button></li>
                        </ul>
                        </div>
                    </form> 
                    </td>
                    </tr>
                `;
            }
        } else {
            tbody.innerHTML += `
                <tr>
                    <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${responseData}</th>
                </tr>
            `;
        } 
    }else {
            console.log('responseData no es un array o está vacío');
            tbody.innerHTML += `
            <tr>
                <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${responseData}</th>
            </tr>
        `;
        }
    } catch (error) {
        console.error(`Error en la solicitud: ${error.message}`);
    }
}

// Llamamos a la función al cargar la página
document.addEventListener('DOMContentLoaded', mostrarFamiliares);


var checkboxfamiliar = document.getElementById('checkboxfamiliar');
var inputcedula = document.getElementById('cedulafamiliar');
var inputregpartidafamiliar = document.getElementById('regpartidafamiliar');


checkboxfamiliar.addEventListener('change', function() {
    if(this.checked) {
        
        inputcedula.disabled = true;
        inputregpartidafamiliar.disabled = false;
    } else {
        
        inputcedula.disabled = false;
        inputregpartidafamiliar.disabled = true;
    }
});

var checkboxeditar = document.getElementById('checkboxfamiliareditar');
var inputcedulaeditar = document.getElementById('cedulafamiliareditar');
var inputregpartidafamiliareditar = document.getElementById('regpartidafamiliareditar');


checkboxeditar.addEventListener('change', function() {
    if(this.checked) {
        
        inputcedulaeditar.disabled = true;
        inputregpartidafamiliareditar.disabled = false;
    } else {
        
        inputcedulaeditar.disabled = false;
        inputregpartidafamiliareditar.disabled = true;
    }
});