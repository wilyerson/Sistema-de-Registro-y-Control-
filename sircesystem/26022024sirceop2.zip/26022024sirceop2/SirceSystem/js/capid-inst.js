const tbody = document.querySelector("#data");

tbody.addEventListener("submit", (e) => {
  if (e.target.matches("#editarinstitucion")) {
    e.preventDefault();

    let url = '../controlador/ctlr-reg-instituciones.php?op=editar';
    let data = new FormData(e.target); // Utiliza e.target para acceder al formulario correcto

    fetch(url, {
      method: 'POST',
      body: data
    })
    .then(response => response.json())
    .then(respuesta => {
      console.log(respuesta);
      console.log(respuesta[0].CodigoInstituciones);

      document.getElementById("codinstitucionmodificar").value = respuesta[0].CodigoInstituciones;
      document.getElementById("nombremodificarinstitucion").value = respuesta[0].NombreInstitucion;
      document.getElementById("codigomodificarinstitucion").value = respuesta[0].CodigoRegistro;
      document.getElementById("id_mun2").value = respuesta[0].CodigoMunicipio;
      document.getElementById("parroquiareg2").value = respuesta[0].ParroquiaInstitucion;
      document.getElementById("sectormodificarinstution").value = respuesta[0].Sector;
      document.getElementById("direccionmodificarinstitucion").value = respuesta[0].Direccion;
      let parroquianumero = respuesta[0].ParroquiaInstitucion;
      let parroquianombre = respuesta[0].NombreParroquia;

      localStorage.setItem("ParroquiaInstitucion", parroquianumero);
      localStorage.setItem("ParroquiaNombre", parroquianombre);

      var selecte = document.getElementById("id_mun2");

      //----modal editar pasar datos de base datos------

      document.getElementById("codinstitucionmodificar").value = respuesta[0].CodigoInstituciones;
      document.getElementById("nombre-ver-inst").value = respuesta[0].NombreInstitucion;
      document.getElementById("codigoreg-ver-inst").value = respuesta[0].CodigoRegistro;
      document.getElementById("municipio-ver-inst").value = respuesta[0].NombreMunicipio ;
      document.getElementById("parroquia-ver-inst").value = respuesta[0].NombreParroquia;
      document.getElementById("sector-ver-inst").value = respuesta[0].Sector;
      document.getElementById("dirección-ver-inst").value = respuesta[0].Direccion;


      if (!respuesta.error) {
        console.log("sirve");
      } else {
        if (respuesta.error === true) {
          // Handle error
        }
      }
    })
    .catch(error => {
      // Handle fetch error
      console.log(error);
    });
  }
});