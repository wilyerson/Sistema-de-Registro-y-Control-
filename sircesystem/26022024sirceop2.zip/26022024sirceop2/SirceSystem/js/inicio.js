function camposVaciosBuscarPersona(datos) {

    let campobuscar = document.getElementById('cedulabuscar');

    let campobuscarValue = campobuscar.value.trim();

    let hayCamposVacios = false;

    if (campobuscarValue === '') {
      campobuscar.classList.remove('is-valid');
      campobuscar.classList.add('is-invalid');
      hayCamposVacios = true;
    }else {
      campobuscar.classList.remove('is-invalid');
      campobuscar.classList.add('is-valid');
    }

    return hayCamposVacios;
}

const formdatabuscarpersona = document.querySelector("#formbuscarpersona");
formdatabuscarpersona.addEventListener("submit", (e) => {
  e.preventDefault();
  const datos = new FormData(document.getElementById("formbuscarpersona"));

      if (camposVaciosBuscarPersona(datos)) {
        //console.log('Hay campos vacíos');
        return;
    }

  console.log(" conectado");

  let url = "../controlador/ctr-personas.php?op=buscarpersona";
  fetch(url, {
    method: "post",
    body: datos,
  })
    .then((data) => data.json())
    .then((responseData) => {
     responseData = responseData.reverse(); 
    console.log(responseData);

        let tbodybuscarpersona = document.querySelector("#content");
        tbodybuscarpersona.innerHTML = "";
        if (responseData.length > 0) {
            for (let registro of responseData) {
                tbodybuscarpersona.innerHTML += `
                    <tr>
                        <td class="text-left" style="padding-left: 1%;">${registro.CedulaPersona}</td>
                        <td class="text-left" style="padding-left: 1%;">${registro.Nombres}</td>
                        <td class="text-left" style="padding-left: 1%;">${registro.Apellidos}</td>
                        <td class="text-left" style="padding-left: 1%;">${registro.EstadoCivil}</td>
                        <td class="align-middle">
                    <a class="btn btn-info" href="../vista/manejo-trabajador2.php?id=${registro.CodigoPersona}">ver</a>
                  </td>
                    </tr>
                `;
            }
        } else {
            tbodybuscarpersona.innerHTML += `
                <tr>
                    <th class="text-center" colspan="5" >No Existe Registro</th>
                </tr>
            `;
        }

        var botonreset = document.querySelector("#botonresetbuscarpersona");

          botonreset.addEventListener('click', function() {
          tbodybuscarpersona.innerHTML = "";
        });

    })
    .catch((error) => console.log(`error: ${error}`));
});


