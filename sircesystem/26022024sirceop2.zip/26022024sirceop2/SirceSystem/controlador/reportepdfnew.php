<?php
const SERVER="localhost";
const DB="sirceop";
const USER="root";
const PASS="";
const UTF8="utf8";

const SGBD="mysql:host=".SERVER.";dbname=".DB.";charset=".UTF8;

class dbconexion
{
    protected function conexion()
    {
        try {
            $con = new PDO(SGBD, USER, PASS);
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $con;
        } catch (PDOException $e) {
            echo "Conexion Fallida: " . $e->getMessage();
        }
    }

    public function getConexion() {
        return $this->conexion();
    }
}

$db = new dbconexion();
$conexion = $db->getConexion();

$id = $_GET['id'];
$sentenciaSQL = $conexion->prepare("SELECT   documento.NombreDocumento,
archivos.CodigoDocumento,
archivos.ArchivoRegistro,
archivos.archivosjpg
FROM
archivos
INNER JOIN documento on archivos.CodigoDocumento = documento.CodigoDocumento
WHERE archivos.idperarchivos = :id");
$sentenciaSQL->bindParam(':id', $id, PDO::PARAM_INT);
$sentenciaSQL->execute();
$ImagenesDocumentos = $sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);

    require_once '../librerias/tcpdf/tcpdf_include.php';
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Sistema mesa de Partes');
    $pdf->SetTitle('Ejemplo TCPDF');

    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    $pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);

    $pdf->setHeaderFont(array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
    $pdf->setFooterFont(array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
    $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

    $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

    $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

    if (@file_exists(dirname(__FILE__) . '/lang/eng.php')) {
        require_once(dirname(__FILE__) . '/lang/eng.php');
        $pdf->setLanguageArray($l);
    }

    $pdf->SetFont('helvetica', '', 11);

    $pdf->AddPage();

    $html = '
        <style>
            h1{
                font-family: Arial, Helvetica, sans-serif;
            }
        </style>
        <h1>Ejemplo de Reporte</h1>
        <h3>Reporte Listado de Menu</h3>
        <br><br>
    ';

    $html.='
        <style>
            table {
                border-collapse: collapse;
                margin-top: 100px;
            }
            th{
                vertical-align:middle;
            }

            table, th, td {
                border: 1px solid black;
            }
            table > tr > th {
                font-weight: bold; 
                text-align: center;
                vertical-align: middle;
                color: black;
                height: 40px;
            }

            table > tr > td {
                font-weight: bold; 
                text-align: center;
                color: black;
                height: 40px;
            }
        </style>
        
        <table>
            <tr>
                <td>Nombre Documento</td>
                <td>Imagen Documento</td>
            </tr>';

            foreach ($ImagenesDocumentos as $row) {
                $html.= 
                '<tr>
                    <td>' . $row['NombreDocumento'] . '</td>
                    <td><img src="../controlador/'.$row['archivosjpg'].'"></td>
                    
                </tr>';
            }

    $html.=' 
            </table>';

    $pdf->writeHTML($html, true, false, false, false, 'C');

    // move pointer to last page
    $pdf->lastPage();
    ob_end_clean();
    // ---------------------------------------------------------

    //Close and output PDF document
    $pdf->Output('EjemploTCPDF.pdf', 'I');
?>