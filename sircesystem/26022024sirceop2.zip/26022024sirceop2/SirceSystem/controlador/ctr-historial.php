<?php
require_once "../config/dbconexion.php";
require_once "../modelo/ModeloHistorial.php";

session_start();

$historial = new Historial();

switch ($_GET["op"]) {

    case 'listar':
        $result_set = $documento->get_documentos(); // devuelve un conjunto de arreglos, cada arreglo es una fila de la tabla de la db
        $data = array();
        //if (count($result_set) > 0) {
        foreach ($result_set as $row) {
            array_push($data, array("ArchivoRegistro" => $row['ArchivoRegistro'], "CodigoDocumento" => $row['CodigoDocumento'], "idperarchivos" => $row['idperarchivos'], "archivosjpg" => $row['archivosjpg']));
        }
        echo json_encode($data); //formateado como json
        break;

    case 'guardar':
        $idperhist  = $_POST['idpersonahistorial'];
        $fechainiciohist  = $_POST['fecha-iniciohistorial'];
        $fechaculmhist  = $_POST['fecha-culminacionhistorial'];
        $cargohist  = $_POST['cargohistorico'];
        $institucionhist  = $_POST['institucionhistorico'];
        $obshist = $_POST['observacionhistorico'];
        $idusuario = $_SESSION['iduser'];
        
        $insercion = $historial->insert_historial($idperhist, $fechainiciohist, $fechaculmhist, $cargohist, $institucionhist, $obshist, $idusuario);
        echo json_encode($insercion);
        break;

    case 'editar':
        $idperhis = $_POST['idperhis'];
        $ejecutar = $historial->get_historial($idperhis);
        echo json_encode($ejecutar);
        break;

    case 'update':
        $idhistoricoedit  = $_POST['idhistoricoedit'];
        $idperhist  = $_POST['idpersonahistorialedit'];
        $fechainiciohist  = $_POST['fecha-iniciohistorialedit'];
        $fechaculmhist  = $_POST['fecha-culminacionhistorialedit'];
        $cargohist  = $_POST['cargohistoricoedit'];
        $institucionhist  = $_POST['institucionhistoricoedit'];
        $obshist = $_POST['observacionhistoricoedit'];
        $idusuario = $_SESSION['iduser'];
        
        $actualizacion = $historial->update_historial($idperhist, $fechainiciohist, $fechaculmhist, $cargohist, $institucionhist, $obshist, $idusuario, $idhistoricoedit);
        echo json_encode($actualizacion);
        break;

        case 'editarmodalhistorial':
            $codhistorial = $_POST['codhistorial'];
            $ejecutar = $historial->get_editarmodalhistorial($codhistorial);
            echo json_encode($ejecutar);
            break;

    default:
        # code...
        break;
}
