<?php

class Historial extends dbconexion
{
    public function get_historiales()
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT CodigoInstituciones, NombreInstitucion, CodigoRegistro FROM instituciones");
        $sql->execute();
        return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_historial($idperhis)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT instituciones.NombreInstitucion, instituciones.CodigoInstituciones, cargos.CodigoCargo, cargos.NombreCargo, persona.CodigoPersona, 
        persona.Nombres, historico.FechaInicio, historico.FechaCulminacion, historico.Obervacion, historico.CodigoHistorico FROM historico 
        INNER JOIN instituciones on historico.InstitucionHistorico = instituciones.CodigoInstituciones
        INNER JOIN cargos on historico.Cargo = cargos.CodigoCargo
        INNER JOIN persona on historico.personal = persona.CodigoPersona 
        WHERE historico.personal = ?");
        $sql->bindValue(1, $idperhis);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function insert_historial($idperhist, $numerodocumentohistorico, $tipodocumentohistorico, $fechainiciohist, $fechaculmhist, $cargohist, $institucionhist, $obshist, $idusuario)
    {
        $conectar = dbconexion::conexion();

                $sql = $conectar->prepare("INSERT INTO historico (personal, NumeroDocumento, TipoDocumento,FechaInicio, FechaCulminacion, Cargo, InstitucionHistorico, Obervacion, idusuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");                
                $sql->bindValue(1, $idperhist);
                $sql->bindValue(2, $numerodocumentohistorico);
                $sql->bindValue(3, $tipodocumentohistorico);
                $sql->bindValue(4, $fechainiciohist);
                $sql->bindValue(5, $fechaculmhist);
                $sql->bindValue(6, $cargohist);
                $sql->bindValue(7, $institucionhist);
                $sql->bindValue(8, $obshist);
                $sql->bindValue(9, $idusuario);

                if ($sql->execute()) {
                    return "Registro insertado correctamente.";
                }
        
    }

    public function update_historial($idperhist, $numerodocumentohistoricoeditar, $tipodocumentohistoricoeditar, $fechainiciohist, $fechaculmhist, $cargohist, $institucionhist, $obshist, $idusuario, $idhistoricoedit)
{
    $conectar = dbconexion::conexion();

    // Actualizar el registro existente
    $sql = $conectar->prepare("UPDATE historico SET NumeroDocumento = ?, TipoDocumento = ?, FechaInicio = ?, FechaCulminacion = ?, Cargo = ?, InstitucionHistorico = ?, Obervacion = ?, idusuario = ?,  personal = ? WHERE CodigoHistorico = ?");



        $sql->bindValue(1, $numerodocumentohistoricoeditar);
        $sql->bindValue(2, $tipodocumentohistoricoeditar);
        $sql->bindValue(3, $fechainiciohist);
        $sql->bindValue(4, $fechaculmhist);
        $sql->bindValue(5, $cargohist);
        $sql->bindValue(6, $institucionhist);
        $sql->bindValue(7, $obshist);
        $sql->bindValue(8, $idusuario);
        $sql->bindValue(9, $idperhist);
        $sql->bindValue(10, $idhistoricoedit);



    $sql->execute();
    return "Registro actualizado correctamente.";
}

    public function get_editarmodalhistorial($codhistorial)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT instituciones.NombreInstitucion, instituciones.CodigoInstituciones, cargos.CodigoCargo, cargos.NombreCargo, persona.CodigoPersona, 
        persona.Nombres, historico.NumeroDocumento, historico.TipoDocumento, historico.FechaInicio, historico.FechaCulminacion, historico.Obervacion, historico.CodigoHistorico FROM historico 
        INNER JOIN instituciones on historico.InstitucionHistorico = instituciones.CodigoInstituciones
        INNER JOIN cargos on historico.Cargo = cargos.CodigoCargo
        INNER JOIN persona on historico.personal = persona.CodigoPersona 
        WHERE historico.CodigoHistorico = ?");
        $sql->bindValue(1, $codhistorial);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }


}
