<?php

class Familiar extends dbconexion
{
    public function get_familiares()
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT CodigoInstituciones, NombreInstitucion, CodigoRegistro FROM instituciones");
        $sql->execute();
        return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_familiar($idperfami)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT municipio.NombreMunicipio, 
        municipio.CodigoMunicipio, 
               parroquia.NombreParroquia, familiar.Parentesco, persona.CodigoPersona, persona.Nombres, persona.Apellidos, persona.FechaNacimiento 
               FROM familiar 
               INNER JOIN persona ON familiar.familiar = persona.CodigoPersona 
               INNER JOIN parroquia ON persona.ParroquiaPersona = parroquia.CodigoParroquia 
               INNER JOIN municipio ON parroquia.MunicipioParroquia = municipio.CodigoMunicipio
               WHERE familiar.Trabajador = ?");
        $sql->bindValue(1, $idperfami);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function insert_familiar($cedulafamiliar, $checkboxfamiliar, $regpartidafamiliar, $parentescofamiliar, $nombresfamiliar, $apellidosfamiliar, $sexofamiliar, $fechanacfamiliar, $numtelefonofamiliar, $numtelefono2familiar, $id_parrfamiliar, $sectorfamiliar, $direccionfamiliar, $pesofamiliar, $estaturafamiliar, $tallacamisafamiliar, $tallapantfamiliar, $tallacalzafamiliar, $tipopersonafamiliar, $estatusfamiliar, $idpersonafamiliar, $idusuario)
    {
        $conectar = dbconexion::conexion();

        if (!empty($regpartidafamiliar)) {

            $check = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona=?");
            $check->bindValue(1, $regpartidafamiliar);
            $check->execute();

            if($check->rowCount() > 0){
                return array("estado" => "esta_partidanacimiento_ya_existe");
            }

             $sql = $conectar->prepare("INSERT INTO persona (CedulaPersona, CheckBoxPartidaNacimientoFami, Nombres, Apellidos, Sexo, FechaNacimiento, TelefonoPrincipal, TelefonoHabitacion, ParroquiaPersona, Sector, Direccion,  Peso, Estatura, TallaCamisa, TallaPantalon, TallaCalzado, TipoPersona , EstatusPersonal, idusuario) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $sql->bindValue(1, $regpartidafamiliar);
        $sql->bindValue(2, $checkboxfamiliar);
        $sql->bindValue(3, $nombresfamiliar);
        $sql->bindValue(4, $apellidosfamiliar);
        $sql->bindValue(5, $sexofamiliar);
        $sql->bindValue(6, $fechanacfamiliar);
        $sql->bindValue(7, $numtelefonofamiliar);
        $sql->bindValue(8, $numtelefono2familiar);
        $sql->bindValue(9, $id_parrfamiliar);
        $sql->bindValue(10, $sectorfamiliar);
        $sql->bindValue(11, $direccionfamiliar);
        $sql->bindValue(12, $pesofamiliar);
        $sql->bindValue(13, $estaturafamiliar);
        $sql->bindValue(14, $tallacamisafamiliar);
        $sql->bindValue(15, $tallapantfamiliar);
        $sql->bindValue(16, $tallacalzafamiliar);
        $sql->bindValue(17, $tipopersonafamiliar);
        $sql->bindValue(18, $estatusfamiliar);
        $sql->bindValue(19, $idusuario);
        
        
        if ($sql->execute()) {
            $CodigoPersona = $conectar->lastInsertId();
            $sql2 = $conectar->prepare("INSERT INTO familiar (Trabajador, Familiar, Parentesco, idusuario) VALUES (?,?,?,?)");
            $sql2->bindValue(1, $idpersonafamiliar);
            $sql2->bindValue(2, $CodigoPersona);
            $sql2->bindValue(3, $parentescofamiliar);
            $sql2->bindValue(4, $idusuario);
            if ($sql2->execute()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }

        } else {

        // Verifica si la cedula ha sido modificada
        if($cedulafamiliar != $idpersonafamiliar){
            // Verifica si la cedula ya existe
            $check = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona=?");
            $check->bindValue(1, $cedulafamiliar);
            $check->execute();

            if($check->rowCount() > 0){
                return array("estado" => "esta_cedula_ya_existe");
            }
        }

             $sql = $conectar->prepare("INSERT INTO persona (CedulaPersona, CheckBoxPartidaNacimientoFami, Nombres, Apellidos, Sexo, FechaNacimiento, TelefonoPrincipal, TelefonoHabitacion, ParroquiaPersona, Sector, Direccion,  Peso, Estatura, TallaCamisa, TallaPantalon, TallaCalzado, TipoPersona , EstatusPersonal, idusuario) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $sql->bindValue(1, $cedulafamiliar);
        $sql->bindValue(2, $checkboxfamiliar);
        $sql->bindValue(3, $nombresfamiliar);
        $sql->bindValue(4, $apellidosfamiliar);
        $sql->bindValue(5, $sexofamiliar);
        $sql->bindValue(6, $fechanacfamiliar);
        $sql->bindValue(7, $numtelefonofamiliar);
        $sql->bindValue(8, $numtelefono2familiar);
        $sql->bindValue(9, $id_parrfamiliar);
        $sql->bindValue(10, $sectorfamiliar);
        $sql->bindValue(11, $direccionfamiliar);
        $sql->bindValue(12, $pesofamiliar);
        $sql->bindValue(13, $estaturafamiliar);
        $sql->bindValue(14, $tallacamisafamiliar);
        $sql->bindValue(15, $tallapantfamiliar);
        $sql->bindValue(16, $tallacalzafamiliar);
        $sql->bindValue(17, $tipopersonafamiliar);
        $sql->bindValue(18, $estatusfamiliar);
        $sql->bindValue(19, $idusuario);
        
        
        if ($sql->execute()) {
            $CodigoPersona = $conectar->lastInsertId();
            $sql2 = $conectar->prepare("INSERT INTO familiar (Trabajador, Familiar, Parentesco, idusuario) VALUES (?,?,?,?)");
            $sql2->bindValue(1, $idpersonafamiliar);
            $sql2->bindValue(2, $CodigoPersona);
            $sql2->bindValue(3, $parentescofamiliar);
            $sql2->bindValue(4, $idusuario);
            if ($sql2->execute()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }

        }
    }

   public function update_familiar($cedulafamiliar, $checkboxfamiliar, $regpartidafamiliar, $parentescofamiliar, $nombresfamiliar, $apellidosfamiliar, $sexofamiliar, $fechanacfamiliar, $numtelefonofamiliar, $numtelefono2familiar, $id_parrfamiliar, $sectorfamiliar, $direccionfamiliar, $pesofamiliar, $estaturafamiliar, $tallacamisafamiliar, $tallapantfamiliar, $tallacalzafamiliar, $tipopersonafamiliar, $estatusfamiliar, $idpersonafamiliar, $idpersona, $idusuario)
{
    $conectar = dbconexion::conexion();

    if (!empty($regpartidafamiliar)) {

        $check = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona=? AND CodigoPersona!=?");
        $check->bindValue(1, $regpartidafamiliar);
        $check->bindValue(2, $idpersonafamiliar);
        $check->execute();

        if($check->rowCount() > 0){
            return (['status' => 'esta_partidanacimiento_ya_existe']);
        }

         // Actualiza los datos
    $sql = "UPDATE persona SET CedulaPersona=?, CheckBoxPartidaNacimientoFami=?, Nombres=?, Apellidos=?, Sexo=?, FechaNacimiento=?, TelefonoPrincipal=?, TelefonoHabitacion=?, ParroquiaPersona=?, Sector=?, Direccion=?, Peso=?, Estatura=?, TallaCamisa=?, TallaPantalon=?, TallaCalzado=?, TipoPersona=?, EstatusPersonal=?, idusuario=? WHERE CodigoPersona=?";
    $sql = $conectar->prepare($sql);
    $sql->bindValue(1, $regpartidafamiliar);
        $sql->bindValue(2, $checkboxfamiliar);
        $sql->bindValue(3, $nombresfamiliar);
        $sql->bindValue(4, $apellidosfamiliar);
        $sql->bindValue(5, $sexofamiliar);
        $sql->bindValue(6, $fechanacfamiliar);
        $sql->bindValue(7, $numtelefonofamiliar);
        $sql->bindValue(8, $numtelefono2familiar);
        $sql->bindValue(9, $id_parrfamiliar);
        $sql->bindValue(10, $sectorfamiliar);
        $sql->bindValue(11, $direccionfamiliar);
        $sql->bindValue(12, $pesofamiliar);
        $sql->bindValue(13, $estaturafamiliar);
        $sql->bindValue(14, $tallacamisafamiliar);
        $sql->bindValue(15, $tallapantfamiliar);
        $sql->bindValue(16, $tallacalzafamiliar);
        $sql->bindValue(17, $tipopersonafamiliar);
        $sql->bindValue(18, $estatusfamiliar);
        $sql->bindValue(19, $idusuario);
        $sql->bindValue(20, $idpersonafamiliar);

        if (!$sql->execute()) {
            return (['status' => 'error_actualizacion_persona']);
        }

        $sql2 = $conectar->prepare("UPDATE familiar SET Trabajador=?, Familiar=?, Parentesco=?, idusuario=? WHERE Familiar=?");
        $sql2->bindValue(1, $idpersona);
        $sql2->bindValue(2, $idpersonafamiliar);
        $sql2->bindValue(3, $parentescofamiliar);
        $sql2->bindValue(4, $idusuario);
        $sql2->bindValue(5, $idpersonafamiliar);

        if (!$sql2->execute()) {
            return (['status' => 'error_actualizacion_familiar']);
        }

        return (['status' => 'modificacion_exitosa']);
        //return true;

    } else {

    // Verifica si la cedula ha sido modificada
    if($cedulafamiliar != $idpersonafamiliar){
        // Verifica si la cedula ya existe
        $check = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona=? AND CodigoPersona!=?");
        $check->bindValue(1, $cedulafamiliar);
        $check->bindValue(2, $idpersonafamiliar);
        $check->execute();

        if($check->rowCount() > 0){
            return (['status' => 'esta_cedula_ya_existe']);
        }
    }

    // Actualiza los datos
    $sql = "UPDATE persona SET CedulaPersona=?, CheckBoxPartidaNacimientoFami=?, Nombres=?, Apellidos=?, Sexo=?, FechaNacimiento=?, TelefonoPrincipal=?, TelefonoHabitacion=?, ParroquiaPersona=?, Sector=?, Direccion=?, Peso=?, Estatura=?, TallaCamisa=?, TallaPantalon=?, TallaCalzado=?, TipoPersona=?, EstatusPersonal=?, idusuario=? WHERE CodigoPersona=?";
    $sql = $conectar->prepare($sql);
    $sql->bindValue(1, $cedulafamiliar);
        $sql->bindValue(2, $checkboxfamiliar);
        $sql->bindValue(3, $nombresfamiliar);
        $sql->bindValue(4, $apellidosfamiliar);
        $sql->bindValue(5, $sexofamiliar);
        $sql->bindValue(6, $fechanacfamiliar);
        $sql->bindValue(7, $numtelefonofamiliar);
        $sql->bindValue(8, $numtelefono2familiar);
        $sql->bindValue(9, $id_parrfamiliar);
        $sql->bindValue(10, $sectorfamiliar);
        $sql->bindValue(11, $direccionfamiliar);
        $sql->bindValue(12, $pesofamiliar);
        $sql->bindValue(13, $estaturafamiliar);
        $sql->bindValue(14, $tallacamisafamiliar);
        $sql->bindValue(15, $tallapantfamiliar);
        $sql->bindValue(16, $tallacalzafamiliar);
        $sql->bindValue(17, $tipopersonafamiliar);
        $sql->bindValue(18, $estatusfamiliar);
        $sql->bindValue(19, $idusuario);
        $sql->bindValue(20, $idpersonafamiliar);

        if (!$sql->execute()) {
            return (['status' => 'error_actualizacion_persona']);
        }

        $sql2 = $conectar->prepare("UPDATE familiar SET Trabajador=?, Familiar=?, Parentesco=?, idusuario=? WHERE Familiar=?");
        $sql2->bindValue(1, $idpersona);
        $sql2->bindValue(2, $idpersonafamiliar);
        $sql2->bindValue(3, $parentescofamiliar);
        $sql2->bindValue(4, $idusuario);
        $sql2->bindValue(5, $idpersonafamiliar);

        if (!$sql2->execute()) {
            return (['status' => 'error_actualizacion_familiar']);
        }

        return (['status' => 'modificacion_exitosa']);
        //return true;
    }
}


    public function get_editarmodalfamiliar($codfamiliar)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT municipio.NombreMunicipio, 
        municipio.CodigoMunicipio, 
               parroquia.NombreParroquia, familiar.*, persona.* 
               FROM familiar 
               INNER JOIN persona ON familiar.familiar = persona.CodigoPersona 
               INNER JOIN parroquia ON persona.ParroquiaPersona = parroquia.CodigoParroquia 
               INNER JOIN municipio ON parroquia.MunicipioParroquia = municipio.CodigoMunicipio
               WHERE familiar.Familiar = ?");
        $sql->bindValue(1, $codfamiliar);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function get_institucionvalidacion($nombreinstitucion,$codigodeinstitucion)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT municipio.NombreMunicipio, municipio.CodigoMunicipio,parroquia.NombreParroquia, instituciones.NombreInstitucion, instituciones.CodigoInstituciones, instituciones.CodigoRegistro, instituciones.Direccion, instituciones.ParroquiaInstitucion, instituciones.Sector FROM instituciones INNER JOIN parroquia ON instituciones.ParroquiaInstitucion = parroquia.CodigoParroquia INNER JOIN municipio ON parroquia.MunicipioParroquia = municipio.CodigoMunicipio WHERE instituciones.NombreInstitucion = ? OR instituciones.CodigoRegistro = ?");
        $sql->bindValue(1, $nombreinstitucion);
        $sql->bindValue(2, $codigodeinstitucion);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function verificar_cedula($CedulaPersona)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona = ?");
        $sql->bindValue(1, $CedulaPersona);
        $sql->execute();
        $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        return !empty($resultado);
    }

    public function check_cedula($CedulaPersona, $CedulaOriginal)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona = ? AND CedulaPersona != ?");
        $sql->bindValue(1, $CedulaPersona);
        $sql->bindValue(2, $CedulaOriginal);
        $sql->execute();
        $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($resultado)) {
            return true;
        } else {
            return false;
        }
    }
}
