const formdatacambiopassworduser = document.querySelector("#formcambiopassword");
formdatacambiopassworduser.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formcambiopassword"));

	console.log(" conectado");

	let url = "../controlador/usuarios-control.php?op=cambiopassworduser";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);

		var status = data.status;
		
		if (status == "password_user_actualizado_exitosamente") {

			swal.fire({
				title: "Cambio de Contraseña Exitoso!",
				icon: "success",
			});

		}	

		})
		.catch((error) => console.log(`error: ${error}`));
});

window.addEventListener('DOMContentLoaded', (event) => {
    let url = "../controlador/usuarios-control.php?op=get_usuariopass";

    fetch(url, {
        method: "post",
    })
    .then((data) => data.json())
    .then((data) => {
        console.log(data);

        document.getElementById("newpassworduser").value = data[0].ConstraseñaUsuario;
        document.getElementById("newpassworduser2").value = data[0].ConstraseñaUsuario;

    })
    .catch((error) => console.log(`error: ${error}`));
});