const formdata = document.querySelector("#formmodificarinstitucion");
formdata.addEventListener("submit", (e) => {
	e.preventDefault();

	let url = '../controlador/ctlr-reg-instituciones.php?op=update';
	let data = new FormData(formdata);

	for (let [key, value] of data.entries()) {
		console.log(key, value);
	}

	fetch(url, {
		method: 'POST',
		body: data
	})
	.then(response => response.json())
	.then(respuesta => {
		console.log(respuesta);
		//console.log(respuesta[0].CodigoInstituciones);

		var status = respuesta.status;
        var datos = respuesta.data;

         switch (status){
        case 'esta_nombre_institucion_ya_existe':

        	//let nombreinsti = document.getElementById('nombremodificarinstitucion');
			//setErrorFor(nombreinsti, 'Este Institucion ya Existe');

            swal.fire({
                title: "¡Este Nombre de Institucion Ya Existe!",
                icon: "error",
            });
            break;

        case 'institucion_modificacion_exitoso':

			listarinstituciones();
			formdata.reset();
			$('#modal-editar').modal('hide');
			Swal.fire({
				title: "Institucion Modificada con exito!",
				icon: "success"
			});

            break;
        }



		

		if (!respuesta.error) {
			console.log("ok");
		} else {
			if (respuesta.error === true ) {
				// Handle error
			}
		}
	})
	.catch(error => {
		console.log(error);
	});
});

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.classList.add('errorinput'); // Agrega la clase 'errorinput'
	small.innerText = message;
  }
  
  function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.classList.remove('errorinput');
	formControl.classList.add('successinput');
  
  }