<?php
require_once "../config/dbconexion.php";
require_once "../modelo/ModeloInstituciones.php";

session_start();

$institucion = new Institucion();

switch ($_GET["op"]) {

    case 'listar':
        $result_set = $institucion->get_instituciones(); // devuelve un conjunto de arreglos, cada arreglo es una fila de la tabla de la db
        $data = array();
        //if (count($result_set) > 0) {
        foreach ($result_set as $row) {
            array_push($data, array("CodigoInstituciones" => $row['CodigoInstituciones'], "NombreInstitucion" => $row['NombreInstitucion']));
        }
        echo json_encode($data); //formateado como json
        break;

    case 'guardar':
        $nombreinstitucion = $_POST['nombreinstitucion'];
        $parroquiareg = $_POST['parroquiareg'];
        $sectorreg = $_POST['sectorinstitucion'];   
        $direccionreg = $_POST['direccioninstitucion'];
        $idusuario = $_SESSION['iduser'];
        $insercion = $institucion->insert_institucion($nombreinstitucion, $parroquiareg, $sectorreg, $direccionreg, $idusuario);
        echo json_encode($insercion);
        break;

    case 'editar':
        $CodigoInstituciones = $_POST['codinstitucion'];
        $ejecutar = $institucion->get_institucion($CodigoInstituciones);
        echo json_encode($ejecutar);
        break;

    case 'update':
        $codinstimod = $_POST['codinstitucionmodificar'];
        $nombreinstimod = $_POST['nombremodificarinstitucion'];
        $parroquiarinstimod = $_POST['parroquiareg2'];
        $sectorinstimod = $_POST['sectormodificarinstution'];
        $direccioninstimod = $_POST['direccionmodificarinstitucion'];
        $idusuario = $_SESSION['iduser'];
        $actualizacion = $institucion->update_institucion($codinstimod, $nombreinstimod, $parroquiarinstimod, $sectorinstimod, $direccioninstimod, $idusuario);
        echo json_encode($actualizacion);
        break;

        case 'traerdatosvalidacion':
        $nombreinstitucion = $_POST['nombreinstitucion'];
        
        $ejecutar = $institucion->get_institucionvalidacion($nombreinstitucion);
        echo json_encode($ejecutar);
        break;

    case 'guardarinstitucionhistorico':
        $nombreinstitucion = $_POST['nombreinstitucion'];
        $parroquiareg = $_POST['parroquiareg'];
        $sectorreg = $_POST['sectorinstitucion'];   
        $direccionreg = $_POST['direccioninstitucion'];
        $idusuario = $_SESSION['iduser'];
        $insercion = $institucion->insert_institucionhistorico($nombreinstitucion, $parroquiareg, $sectorreg, $direccionreg, $idusuario);
        echo json_encode($insercion);
        break;
        
    default:
        # code...
        break;
}
