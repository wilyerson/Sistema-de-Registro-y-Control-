<?php
 
	require_once "../modelo/ModeloMunicipio.php";

	$tabla_municipio = new municipio();
	$municipiointhistorico = $tabla_municipio->obtener_municipios_select();

	echo json_encode($municipiointhistorico);
 ?>