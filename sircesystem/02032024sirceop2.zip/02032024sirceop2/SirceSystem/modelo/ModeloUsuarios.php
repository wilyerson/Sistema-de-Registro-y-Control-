<?php

class Usuarios extends dbconexion
{
    public function get_usuarios()
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT   persona.Nombres,
                                            persona.CodigoPersona, 
                                            usuarios.CodigoUsuario, 
                                            usuarios.RolUsuario, 
                                            usuarios.EstatusUsuario,
                                            usuarios.NombreUsuario
                                            FROM usuarios 
                                            INNER JOIN persona 
                                            ON usuarios.CodigoPersona = persona.CodigoPersona");
        $sql->execute();
        return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_persona($ciper)
    {
        $conectar = dbconexion::conexion();

        // Consulta para verificar si la persona está en la tabla 'persona'
        $sql = $conectar->prepare("SELECT CodigoPersona, Nombres, Apellidos, CedulaPersona
                                   FROM persona where CedulaPersona = ?");
        $sql->bindValue(1, $ciper);
        $sql->execute();
        $persona = $sql->fetch(PDO::FETCH_ASSOC);

        // Consulta para verificar si la persona está en la tabla 'usuarios'
        $sql2 = $conectar->prepare("SELECT     persona.CodigoPersona, persona.CedulaPersona,
                                                usuarios.CodigoUsuario, usuarios.NombreUsuario, usuarios.RolUsuario,
                                                persona.CedulaPersona
                                                FROM persona
                                                INNER JOIN usuarios on usuarios.CodigoPersona = persona.CodigoPersona where persona.CedulaPersona = ?");
        $sql2->bindValue(1, $ciper);
        $sql2->execute();
        $usuario = $sql2->fetch(PDO::FETCH_ASSOC);

        // Comprobación de la existencia de la persona en las tablas 'persona' y 'usuarios'
        if ($persona && !$usuario) {
            return (['status' => 'registrado_en_persona', 'data' => $persona]);
        } elseif ($persona && $usuario) {
            return (['status' => 'registrado_en_ambas', 'data' => $usuario]);
        } else {
            return (['status' => 'no_registrado']);
        }
    }

    public function verificar_nombre_usuario($nombre_usuario)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT * FROM usuarios WHERE NombreUsuario = ?");
        $sql->bindValue(1, $nombre_usuario);
        $sql->execute();
        $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        return !empty($resultado);
    }

    public function insert_usuario($CodigoPersona, $tipouser, $nombreunewuser, $passnewuser,$idusuario,$estatususuarioinput)
    {
        $conectar = dbconexion::conexion();

            $check = $conectar->prepare("SELECT * FROM usuarios WHERE NombreUsuario=?");
            $check->bindValue(1, $nombreunewuser);
            $check->execute();

            if($check->rowCount() > 0){
                return ['status' => 'usuario_ya_existe'];
            }

        /*$sql = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona = ?");
        $sql->bindValue(1, $CedulaPersona);

        $resultadoCedula = $sql->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($resultadoCedula)) {
                    // La nueva cédula ya está en uso
                   // return array("estado" => "error_cedula_existente");
                   return json_encode(array("estado" => "error_cedula_existente"));
            } else {*/

        $sql = $conectar->prepare("INSERT INTO usuarios (CodigoPersona,RolUsuario, NombreUsuario, ConstraseñaUsuario,idusuario,EstatusUsuario) VALUES (?,?,?,?,?,?)");
        $sql->bindValue(1, $CodigoPersona);
        $sql->bindValue(2, $tipouser);
        $sql->bindValue(3, $nombreunewuser);
        $sql->bindValue(4, $passnewuser);
        $sql->bindValue(5, $idusuario);
        $sql->bindValue(6, $estatususuarioinput);
        
                if ($sql->execute()) {
                    
                   return (['status' => 'usuario_registrado_exitosamente']);
                }

        //}
    }

    public function update_usuario($CodigoPersonaedit, $Codiusuarioedit, $tipouseredit, $nombreunewuseredit, $estatususuarioedit, $passnewuseredit,$idusuarioedit)
    {

        $conectar = dbconexion::conexion();

        $check = $conectar->prepare("SELECT * FROM usuarios WHERE NombreUsuario=? AND CodigoUsuario!=?");
        $check->bindValue(1, $nombreunewuseredit);
        $check->bindValue(2, $Codiusuarioedit);
        $check->execute();

        if($check->rowCount() > 0){
            return (['status' => 'esta_usuario_ya_existe']);
        }

        $sql = $conectar->prepare("UPDATE usuarios SET CodigoPersona = ?, RolUsuario = ?, NombreUsuario = ?, ConstraseñaUsuario = ?, idusuario = ?, EstatusUsuario = ? WHERE CodigoUsuario = ?");
        $sql->bindValue(1, $CodigoPersonaedit);
        $sql->bindValue(2, $tipouseredit);
        $sql->bindValue(3, $nombreunewuseredit);
        $sql->bindValue(4, $passnewuseredit);
        $sql->bindValue(5, $idusuarioedit);
        $sql->bindValue(6, $estatususuarioedit);
        $sql->bindValue(7, $Codiusuarioedit);

        if ($sql->execute()) {
            return (['status' => 'usuario_actualizado_exitosamente']);
        }
    }

        public function get_editarmodalusuario($idusuarioeditar)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT persona.CedulaPersona, persona.Nombres, persona.Apellidos, usuarios.* FROM usuarios 
        INNER JOIN persona on usuarios.CodigoPersona = persona.CodigoPersona 
        WHERE usuarios.CodigoUsuario = ?");
        $sql->bindValue(1, $idusuarioeditar);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function sesion_bitacora($Nameuser, $Nombreuser, $idusuario, $actividadrealizada, $informacionactual)
    {
        $conectar = dbconexion::conexion();

        $sql = $conectar->prepare("INSERT INTO bitacora (CodigoPersona, idUsuario, ActividadRealizada, InformacionActual) VALUES (?,?,?,?)");
        $sql->bindValue(1, $Nombreuser);
        $sql->bindValue(2, $idusuario);
        $sql->bindValue(3, $actividadrealizada);
        $sql->bindValue(4, $informacionactual);

        
        if ($sql->execute()) {
            
            return array("estado" => "exito");              
            
            return;
        }

    }

    public function update_passworduser($codusuario, $passworduser, $idusuario)
    {

        $conectar = dbconexion::conexion();

        $sql = $conectar->prepare("UPDATE usuarios SET ConstraseñaUsuario = ?, idusuario = ? WHERE CodigoUsuario = ?");
        $sql->bindValue(1, $passworduser);
        $sql->bindValue(2, $idusuario);
        $sql->bindValue(3, $codusuario);

        if ($sql->execute()) {
            return (['status' => 'password_user_actualizado_exitosamente']);
        }
    }

    public function get_usuariopass($idusuariopass)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT persona.CedulaPersona, persona.Nombres, persona.Apellidos, usuarios.* FROM usuarios 
        INNER JOIN persona on usuarios.CodigoPersona = persona.CodigoPersona 
        WHERE usuarios.CodigoUsuario = ?");
        $sql->bindValue(1, $idusuariopass);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }


}
