const MostrarTablaUsuarios = (data) => {
  let tbody = document.querySelector("#MostrarUsuarios");
  tbody.innerHTML = "";
  if (data.length > 0) {
    for (let registro of data) {
      tbody.innerHTML += `
           <tr>
           <th class="text-center">${registro.NombreUsuario}</th>
           <td class="text-center">${registro.RolUsuario}</td>
           <td class="text-center">${registro.NombreUsuario}</td>
           <td class="text-center">
           <div class="dropdown" style="position: static">
              <a class="btn btn-primary dropdown-toggle" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                Seleccione
              </a>

              <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
              <form method="POST" id="editarusuarios">

                <input type="hidden" id="idusuarioeditar" name="idusuarioeditar" value="${registro.CodigoUsuario}">
                <li><button class="dropdown-item" id="botoneditarusuario" data-bs-toggle="modal" data-bs-target="#editar-usuario" >Editar</button></li>

              </form> 
              </ul>
            </div>

           </td>
           
           </tr>
           `;
    }
  } else {
    tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${data}</th>
            </td>
            </tr>
            `;
  }
};
