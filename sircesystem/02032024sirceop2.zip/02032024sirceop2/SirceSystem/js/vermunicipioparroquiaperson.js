fetch('../controlador/municipiosfetchpesona.php')
.then(response => response.json())
.then(municipio2 => {
    var select = document.getElementById('editmunicipio');
    municipio2.forEach(function(municipio) {
        var option = document.createElement('option');
        option.value = municipio.CodigoMunicipio;
        option.text = municipio.NombreMunicipio;
        select.add(option);
    });

    // Almacena el valor inicial del select
    var lastValue = select.value;

    
    setInterval(function() {
        if (select.value !== lastValue) {
            lastValue = select.value;  // Actualiza el valor almacenado
            let valuerealmunicipio = lastValue;
            console.log(valuerealmunicipio);

            // Encuentra la opción con el valor actual y la selecciona
            for (var i = 0; i < select.options.length; i++) {
                if (select.options[i].value === valuerealmunicipio) {
                    select.options[i].setAttribute('selected', 'selected'); // Añade el atributo 'selected'
                    break;
                }
            }

            updateParroquiasperson(valuerealmunicipio);
        }
    }, 250);
})
.catch(error => console.error('Error:', error));


function updateParroquiasperson(value) {
if(value) {
    fetch('../controlador/parroquiasfetchpersona.php?editmunicipio='+value)
    .then(res2 => {
        if(!res2.ok){
            throw new Error('error en la respuesta');
        }
        return res2.json();
    })
    .then(datos => {
        let parroquiapersonanumero = localStorage.getItem("ParroquiaPersonanumero");
        let parroquiapersonanombre = localStorage.getItem("ParroquiaPersonanombre");
        let html = parroquiapersonanombre ? '<option value="'+parroquiapersonanumero+'">'+parroquiapersonanombre+'</option>' : '<option value="">Seleccione Parroquia</option>';
        if(datos.data.length > 0){
            for(let i = 0; i < datos.data.length; i++){
                html += `<option value="${datos.data[i].CodigoParroquia}">${datos.data[i].NombreParroquia}</option>`; 
            }
        }
        document.querySelector('#editparroquiareg').innerHTML = html;
    })
    .catch(error => {
        console.error('ocurrio un error '+error);
    }); 
} else {
    document.querySelector('#editparroquiareg').innerHTML = '<option value="">Seleccione Parroquia</option>';
}
}

// Agrega un evento 'change' al select de municipios para llamar a la función updateParroquias cada vez que cambia su valor
document.querySelector('#editmunicipio').addEventListener('change', function() {
// Cuando el valor del select cambia, se eliminan los valores de localStorage
localStorage.removeItem("ParroquiaPersonanumero");
localStorage.removeItem("ParroquiaPersonanombre");
updateParroquias(this.value);
});