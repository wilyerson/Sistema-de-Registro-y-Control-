const formdatainstitucionhistorico = document.querySelector("#formulariogeistroinstitucionhistorico");
formdatainstitucionhistorico.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formulariogeistroinstitucionhistorico"));

	console.log(" conectado");

	let url = "../controlador/ctlr-reg-instituciones.php?op=guardarinstitucionhistorico";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);
			
		var status = data.status;
        var datos = data.data;

        switch (status){
        case 'institucionhistorico_ya_existe':
            swal.fire({
                title: "¡Esta Institucion Ya Existe!",
                icon: "error",
            });
            break;

        case 'institucion_registrada_exitoso':
 			
 			document.getElementById('myModal2').style.display = "none";
    		formdatainstitucionhistorico.reset();
			swal.fire({
				title: "¡Registro Exitoso!",
				icon: "success",
			});

            break;
        }

		})
		.catch((error) => console.log(`error: ${error}`));
});