let dataCopy = [];

fetch('../controlador/institucionesfetch.php')
    .then(response => response.json())
    .then(data => {
        dataCopy = [...data]; // Hacemos una copia de los datos originales
        updateOptionsList(dataCopy);
    })
    .catch(error => console.error('Error:', error));

function updateOptionsList(data) {
    const options = document.querySelector(".options");
    options.innerHTML = "";
    dataCopy.forEach(institucion => {
        let li = `<li onclick="updateName(this)" data-value="${institucion.CodigoInstituciones}" >${institucion.NombreInstitucion}</li>`;
        options.insertAdjacentHTML("beforeend", li);
    });
}

const wrapper = document.querySelector(".wrapper"),
selectBtn = wrapper.querySelector(".select-btn"),
searchInp = wrapper.querySelector(".search input"),
options = wrapper.querySelector(".options");

searchInp.addEventListener("keyup", () => {
    let arr = [];
    let searchWord = searchInp.value.toLowerCase();
    arr = dataCopy.filter(institucion => { // Usamos dataCopy en lugar de data
        return institucion.NombreInstitucion.toLowerCase().startsWith(searchWord);
    }).map(institucion => {
        let isSelected = institucion.NombreInstitucion == selectBtn.firstElementChild.innerText ? "selected" : "";
        return `<li onclick="updateName(this)" class="${isSelected}" data-value="${institucion.CodigoInstituciones}">${institucion.NombreInstitucion}</li>`;
    }).join("");
    options.innerHTML = arr ? arr : `<p style="margin-top: 10px;">No esta Registrada esa Institucion</p>`;
});

const formdatainstitucionhistorico = document.querySelector("#formulariogeistroinstitucionhistorico");
formdatainstitucionhistorico.addEventListener("submit", (e) => {
    e.preventDefault();
    const datos = new FormData(document.getElementById("formulariogeistroinstitucionhistorico"));

    console.log(" conectado");

    let url = "../controlador/ctlr-reg-instituciones.php?op=guardarinstitucionhistorico";
    fetch(url, {
        method: "post",
        body: datos,
    })
        .then((data) => data.json())
        .then((data) => {
            var status = data.status;
            var datos = data.data;

            switch (status){
                case 'institucionhistorico_ya_existe':
                    swal.fire({
                        title: "¡Esta Institucion Ya Existe!",
                        icon: "error",
                    });
                    break;

                case 'institucion_registrada_exitoso':
                    document.getElementById('myModal2').style.display = "none";
                    formdatainstitucionhistorico.reset();
                    swal.fire({
                        title: "¡Registro Exitoso!",
                        icon: "success",
                    });
                    // Aquí es donde actualizamos la lista de instituciones
                    dataCopy.push(datos); // Añadimos la nueva institución a la copia de los datos
                    updateOptionsList(dataCopy);
                    break;
            }

        })
        .catch((error) => console.log(`error: ${error}`));
});

function limpiarmodalhistorico() {
    document.getElementById("institucionhistorico").dataset.value= "";
   document.getElementById("institucionhistorico").innerHTML = "Seleccione";
}