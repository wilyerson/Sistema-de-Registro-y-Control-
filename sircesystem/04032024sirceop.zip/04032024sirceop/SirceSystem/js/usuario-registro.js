const formdataregistrousuario = document.querySelector("#formulariosuario");
formdataregistrousuario.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formulariosuario"));

    if (camposVaciosUsuarioRegistro(datos)) {
        //console.log('Hay campos vacíos');
        let toastusercamposvacios = document.querySelector("#toastusercampovacios");
		let toast = new bootstrap.Toast(toastusercamposvacios, {autohide: true, delay: 2000});
		toast.show();

		setTimeout(() => {
		    toast.hide();
		}, 2000);
        return;
    }

    let passnewuservalid = document.getElementById('passnewuser').value;
    let passnu2valid = document.getElementById('passnu2').value;

    if (passnewuservalid != passnu2valid) {

        document.getElementById('passnu2').classList.remove('is-valid');
        document.getElementById('passnu2').classList.add('is-invalid');
            swal.fire({
                title: "¡Las contraseñas no coiciden!",
                icon: "error",
            });
            return;
    }

	console.log(" conectado");

	let url = "../controlador/usuarios-control.php?op=guardar";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);

        var status = data.status;
        var datos = data.data;

        switch (status){
        case 'usuario_ya_existe':
            document.getElementById('nombreunewuser').classList.remove('is-valid');
            document.getElementById('nombreunewuser').classList.add('is-invalid');
            swal.fire({
                title: "¡Este Nombre de Usuario Ya Existe!",
                icon: "error",
            });
            break;

        case 'usuario_registrado_exitosamente':
            listarusuariosfetch();
            //formdataregistrousuario.reset();
            document.getElementById('tipouser').classList.remove('is-valid');
            document.getElementById('tipouser').classList.remove('is-invalid');
            document.getElementById('nombreunewuser').classList.remove('is-valid');
            document.getElementById('nombreunewuser').classList.remove('is-invalid');
            document.getElementById('passnewuser').classList.remove('is-valid');
            document.getElementById('passnewuser').classList.remove('is-invalid');
            document.getElementById('passnu2').classList.remove('is-valid');
            document.getElementById('passnu2').classList.remove('is-invalid');

            $('#asignar-rol').modal('hide');
            swal.fire({
                title: "¡Registro de Usuario Exitoso!",
                icon: "success",
            });
            break;
        }
			
			
		})
		.catch((error) => console.log(`error: ${error}`));
});

function camposVaciosUsuarioRegistro(datos) {

    let tipouser = document.getElementById('tipouser');
    let nombreunewuser = document.getElementById('nombreunewuser');
    let passnewuser = document.getElementById('passnewuser');
    let passnu2 = document.getElementById('passnu2');
    
    const tipouservalue = tipouser.value.trim();
    const nombreunewuservalue = nombreunewuser.value.trim();
    const passnewuservalue = passnewuser.value.trim();
    const passnu2value = passnu2.value.trim();
    
    let hayCamposVacios = false;

    //--------------------validando los inputs

    if (tipouservalue == "") {
        tipouser.classList.remove('is-valid');
        tipouser.classList.add('is-invalid');
        //document.getElementById('validcedulavacia').classList.remove('invisible');
		//document.getElementById('validcedulavacia').classList.add('visible');
        hayCamposVacios = true;
    } else {
        tipouser.classList.remove('is-invalid');
        tipouser.classList.add('is-valid');
        //document.getElementById('validcedulavacia').classList.add('invisible');
		//document.getElementById('validcedulavacia').classList.remove('visible');
    }

     if (nombreunewuservalue == "") {
        nombreunewuser.classList.remove('is-valid');
        nombreunewuser.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        nombreunewuser.classList.remove('is-invalid');
        nombreunewuser.classList.add('is-valid');
    }

    if (passnewuservalue == "") {
        passnewuser.classList.remove('is-valid');
        passnewuser.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        passnewuser.classList.remove('is-invalid');
        passnewuser.classList.add('is-valid');
    }

    if (passnu2value == "") {
        passnu2.classList.remove('is-valid');
        passnu2.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        passnu2.classList.remove('is-invalid');
        passnu2.classList.add('is-valid');
    }

    return hayCamposVacios;
}

   
    let botonresetlocal = document.getElementById('botonresetlocal');
    
    botonresetlocal.addEventListener('click', (e) => {
        document.getElementById('tipouser').classList.remove('is-valid');
        document.getElementById('tipouser').classList.remove('is-invalid');
        document.getElementById('nombreunewuser').classList.remove('is-valid');
        document.getElementById('nombreunewuser').classList.remove('is-invalid');
        document.getElementById('passnewuser').classList.remove('is-valid');
        document.getElementById('passnewuser').classList.remove('is-invalid');
        document.getElementById('passnu2').classList.remove('is-valid');
        document.getElementById('passnu2').classList.remove('is-invalid');

    });