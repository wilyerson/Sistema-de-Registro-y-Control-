jQuery(document).on('submit','#formulogine', function(event){
	event.preventDefault();

	let nameuser = document.getElementById('nombreusuario').value;
	localStorage.setItem("nameusuario", nameuser);

	jQuery.ajax({
		url: 'controlador/login.php',
		type: 'POST',
		dataType: 'json',
		data: $(this).serialize(),
		beforeSend: function () {
		// body...
		//document.getElementById('botoniniciarsession').value = "Iniciando";
			checkInputs();
		}
	})
	
	.done(function (respuesta) {
	// body...


		console.log(respuesta);
		if (!respuesta.error) {

			if (respuesta.tipo === 'administrador' && respuesta.estatus === 'usuarioactivo') {

				fecthregistrobitacora();
				location.replace('vista/bienvenida.php');
			}else if (respuesta.tipo === 'analista' && respuesta.estatus === 'usuarioactivo') {

				fecthregistrobitacora();
				location.replace('vista/bienvenida.php');

			}else if (respuesta.tipo === 'consulta' && respuesta.estatus === 'usuarioactivo') {

				fecthregistrobitacora();
				location.replace('vista/bienvenida.php');

			}else if (respuesta.estatus === 'usuariodesactivado') {
				$('#modalusuariodesactivo').modal("show");
			}




		}else {

			if (respuesta.error === true && checkInputs() === 5) {
				$('#modalusuarionoesta').modal("show");

			} 

		}


	})
	.fail(function (resp) {
	// body...
	//console.log(resp.responseText);


	})
	.always(function () {
	// body...
		console.log("complete");
	});



});


function checkInputs() {

	const form = document.getElementById('formulogine');
	const usuario = document.getElementById('nombreusuario');
	const password = document.getElementById('passwordusuario');

	let prueba;
	let prueba2;
	let checkcedula = 2;
	let checknombre = 2;
	let checkdireccion = 2;
  // trim to remove the whitespaces
  //const cedulaValue = cedula.value.trim();
	const usuarioValue = usuario.value.trim();
	const passwordValue = password.value.trim();

  //const passwordValue = password.value.trim();
  // password2Value = password2.value.trim();

	if(usuarioValue === '') {

		setErrorFor(usuario, 'Ingrese el Usuario');
	} else {

		setSuccessFor(usuario);
	}

	if(passwordValue === '') {

		setErrorFor(password, 'Ingrese la Contraseña');
	} else {

		setSuccessFor(password);
	}


	if (usuarioValue === '' || passwordValue === '') 
	{


		$('#modalregistrarrellenecampos').modal("show");

		prueba = 2;

		return 2;
	}else{

  //todos los campos llenos
		prueba = 5;
		return 5;
	}


}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.className = 'formu-control error';
	small.innerText = message;
	prueba = 2;
}

function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.className = 'formu-control success';
  //prueba = 12;
}

function fecthregistrobitacora() {
    const datos = new FormData(document.getElementById("formulogine"));

    console.log(" conectado");

    let url = "controlador/usuarios-control.php?op=inserlogintbitacorauser";
    fetch(url, {
        method: "post",
        body: datos,
    })
    .then((data) => data.json())
    .then((data) => {
        //console.log(data);
    })
    .catch((error) => console.log(`error: ${error}`));
}