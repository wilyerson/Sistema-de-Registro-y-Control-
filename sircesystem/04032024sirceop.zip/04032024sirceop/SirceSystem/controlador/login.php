<?php
const SERVER="localhost";
const DB="sirceop";
const USER="root";
const PASS="";
const UTF8="utf8";

const SGBD="mysql:host=".SERVER.";dbname=".DB.";charset=".UTF8;

class dbconexion
{
    protected function conexion()
    {
        try {
            $con = new PDO(SGBD, USER, PASS);
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $con;
        } catch (PDOException $e) {
            echo "Conexion Fallida: " . $e->getMessage();
        }
    }

    public function getConexion() {
        return $this->conexion();
    }
}

/*
$db = new dbconexion();
$conexion = $db->getConexion();

$nombreusuario = $_POST['nombreusuario'];
$passwordusuario = $_POST['passwordusuario'];

// Seleccionamos el hash de la contraseña del usuario de la base de datos
$query = $conexion->prepare("SELECT * FROM usuarios WHERE NombreUsuario = ?");
$query->bindParam(1, $nombreusuario, PDO::PARAM_STR);
$query->execute();

if ($query->rowCount() == 1):
  session_start();
  $datos = $query->fetch(PDO::FETCH_ASSOC);
  
  
  // Usamos password_verify para comparar la contraseña ingresada con el hash almacenado
  if (password_verify($passwordusuario, $datos['ConstraseñaUsuario'])) {
    $_SESSION["usuarioad"]=$nombreusuario;
    $_SESSION["passuser"]=$passwordusuario;
    $_SESSION["iduser"]=$datos['CodigoUsuario'];
    
    echo json_encode(array('error' => false, 'tipo' => $datos['RolUsuario'], 'estatus' => $datos['EstatusUsuario']));
  } else {
    echo json_encode(array('error' => true));
  }
else:
  echo json_encode(array('error' => true));
endif;
*/

$db = new dbconexion();
$conexion = $db->getConexion();

$nombreusuario = $_POST['nombreusuario'];
$passwordusuario = $_POST['passwordusuario'];

$query = $conexion->prepare("SELECT * FROM usuarios WHERE NombreUsuario = ? AND ConstraseñaUsuario  = ?");
$query->bindParam(1, $nombreusuario, PDO::PARAM_STR);
$query->bindParam(2, $passwordusuario, PDO::PARAM_STR);
$query->execute();

if ($query->rowCount() == 1):
  session_start();
  $datos = $query->fetch(PDO::FETCH_ASSOC);
  $_SESSION["usuarioad"]=$nombreusuario;
  $_SESSION["passuser"]=$passwordusuario;
  $_SESSION["iduser"]=$datos['CodigoUsuario'];
  $_SESSION["roluser"]=$datos['RolUsuario'];
  
  echo json_encode(array('error' => false, 'tipo' => $datos['RolUsuario'], 'estatus' => $datos['EstatusUsuario']));
else:
  echo json_encode(array('error' => true));
endif;
?>