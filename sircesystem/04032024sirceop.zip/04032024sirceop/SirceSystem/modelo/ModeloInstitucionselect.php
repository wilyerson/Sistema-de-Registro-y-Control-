<?php 
	require_once "ModeloConeccion.php";

	class institucion{

		public function obtener_instituciones_select(){
			$db = new coneccion();
			$query = "SELECT CodigoInstituciones, NombreInstitucion from instituciones";
			$resultado = $db->query($query);
			$datos=[];
			if ($resultado->num_rows) {
				while ($row = $resultado->fetch_assoc()) {
					$datos[] = [
						'NombreInstitucion' => $row['NombreInstitucion'],
						'CodigoInstituciones' => $row['CodigoInstituciones'],
					];				
				}			
			}
			return $datos;
		}
	}

 ?>