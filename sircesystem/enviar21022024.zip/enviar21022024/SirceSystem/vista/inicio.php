  <!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

  
</head>
<body >

    <?php

session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}


?>

 <?php include"../componentes/nav.php" ?> 


<div class="container border rounded py-3 bg-white" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px; ">

  <div class="row m-4">
    <h5><p class="text-center">Buscar Personal</p></h5>
  </div>

  <form id="form2" method="POST" action="inicio.php">

  <div class="row m-4 d-flex justify-content-center">
    <div class="col-md-6">
      <label class="form-label"for="">Filtrar Por:</label>
      <input class="form-control" type="number" name="cedulabuscar" placeholder="Cedula de Identidad" value="<?php echo @$_POST['cedulabuscar'] ?>">
    </div>
  </div>

    <?php 
      $conexion = mysqli_connect("localhost","root","","sirceop"); 
    
      $sql=mysqli_query($conexion, "SELECT * FROM persona WHERE CedulaPersona LIKE '%".@$_POST['cedulabuscar']."%' AND TipoPersona = 'personal' ");
      
      $numeroSql = mysqli_num_rows($sql);
      ?>

  <div class="row m-4">
    <div class="col-md-6 d-flex justify-content-end">
      <button type="reset" class="btn btn-primary">limpiar</button>
    </div>
    <div class="col-md-6">
      <button type="submit" name="enviar"  class="btn btn-primary">Buscar</button>
    </div>
  </div>

  <div class="row mt-4 mb-0">
    <hr>
  </div>

  <div class="row mb-4 my-4">
    <div class="col-sm-12">
      <table class="table table-hover" style="margin-top: 40px;">
        
        <thead>
          <tr>
            <th scope="col">Cedula</th>
            <th scope="col">Nombre</th>
            <th scope="col">Apellido</th>
            <th scope="col">Estado civil</th>
            <th scope="col"><img src="../icons/buscar.png" width="20px"></th>
          </tr>
        </thead>

        <tbody id="content">
          
          <?php 


          if (!empty($_POST['cedulabuscar'])) {

            if ($sql -> num_rows > 0) {


              while ($rowSql = mysqli_fetch_assoc($sql)) { ?>

                <tr>
                  <td class="align-middle"><?php echo $rowSql["CedulaPersona"]; ?></td>
                  <td style="text-transform: uppercase;" class="align-middle"><?php echo $rowSql["Nombres"]; ?></td>
                  <td style="text-transform: uppercase;" class="align-middle"><?php echo $rowSql["Apellidos"]; ?></td>
                  <td style="text-transform: uppercase;" class="align-middle"><?php echo $rowSql["Sexo"]; ?></td>
                  <td class="align-middle">
                    <a class="btn btn-info" href="../vista/manejo-trabajador2.php?id=<?php echo $rowSql['CodigoPersona'];?> ">ver</a>
                  </td>
                </tr>

              <?php }
            }else{

             ?>
             <tr>
              <td colspan="5">no existe registro</td>

            </tr>
          <?php }  }else{
           ?>

           <tr>
            <td colspan="5">no ha iniciado busqueda</td>

          </tr>
        <?php }
        ?>


        </tbody>
      </table>
      </form>

    </div>
  </div>

  <script>

    const campobuscar = document.getElementById('cedulapersonabuscar');

    const campobuscarValue = campobuscar.value.trim();

    if (campobuscarValue === '') {
      console.log("campo vacio");
      //alert("El campo esta vacío");
    }else {
      console.log("campo lleno");
    }


  </script>

</div>


</body>
</html>