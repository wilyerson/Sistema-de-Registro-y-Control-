<?php

class Usuarios extends dbconexion
{
    public function get_usuarios()
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT   persona.Nombres,
                                            persona.CodigoPersona, 
                                            usuarios.CodigoUsuario, 
                                            usuarios.RolUsuario, 
                                            usuarios.EstatusUsuario,
                                            usuarios.NombreUsuario
                                            FROM usuarios 
                                            INNER JOIN persona 
                                            ON usuarios.CodigoPersona = persona.CodigoPersona");
        $sql->execute();
        return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_persona($ciper)
    {
        $conectar = dbconexion::conexion();

        // Consulta para verificar si la persona está en la tabla 'persona'
        $sql = $conectar->prepare("SELECT CodigoPersona, Nombres, Apellidos, CedulaPersona
                                   FROM persona where CedulaPersona = ?");
        $sql->bindValue(1, $ciper);
        $sql->execute();
        $persona = $sql->fetch(PDO::FETCH_ASSOC);

        // Consulta para verificar si la persona está en la tabla 'usuarios'
        $sql2 = $conectar->prepare("SELECT     persona.CodigoPersona, persona.CedulaPersona,
                                                usuarios.CodigoUsuario, usuarios.NombreUsuario, usuarios.RolUsuario,
                                                persona.CedulaPersona
                                                FROM persona
                                                INNER JOIN usuarios on usuarios.CodigoPersona = persona.CodigoPersona where persona.CedulaPersona = ?");
        $sql2->bindValue(1, $ciper);
        $sql2->execute();
        $usuario = $sql2->fetch(PDO::FETCH_ASSOC);

        // Comprobación de la existencia de la persona en las tablas 'persona' y 'usuarios'
        if ($persona && !$usuario) {
            return (['status' => 'registrado_en_persona', 'data' => $persona]);
        } elseif ($persona && $usuario) {
            return (['status' => 'registrado_en_ambas', 'data' => $usuario]);
        } else {
            return (['status' => 'no_registrado']);
        }
    }

    public function verificar_nombre_usuario($nombre_usuario)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT * FROM usuarios WHERE NombreUsuario = ?");
        $sql->bindValue(1, $nombre_usuario);
        $sql->execute();
        $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        return !empty($resultado);
    }

    public function insert_documento($CodigoDocumento, $idpersonadoc)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("INSERT INTO archivos (CodigoDocumento, idperarchivos, archivosjpg) VALUES (?, ?, ?)");
        $sql->bindValue(1, $CodigoDocumento);
        $sql->bindValue(2, $idpersonadoc);
    
        // Define el directorio donde quieres guardar el archivo
        $directorio = 'imagenes/'.$idpersonadoc;
    
        // Crea el directorio si no existe
        if (!file_exists($directorio)) {
            mkdir($directorio, 0777, true);
        }
    
        // Define la ruta de destino del archivo
        $ruta_destino = $directorio.'/'.$_FILES['archivojpg']['name'];
    
        // Mueve el archivo cargado a la ruta de destino
        if(move_uploaded_file($_FILES['archivojpg']['tmp_name'], $ruta_destino)){
            // Si el archivo se movió correctamente, cambia el valor de $ruta_destino
            $ruta_destino = $ruta_destino;
        }
    
        // Vincula el valor de $ruta_destino a la consulta SQL
        $sql->bindValue(3, $ruta_destino);
    
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function update_documento($codinstimod, $nombreinstimod, $codigoregintimod, $parroquiarinstimod, $sectorinstimod, $direccioninstimod)
    {

        $conectar = dbconexion::conexion();
        $sql = "UPDATE instituciones SET NombreInstitucion = ?, CodigoRegistro = ?, ParroquiaInstitucion = ?, Sector = ?, Direccion = ? WHERE CodigoInstituciones = ?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $nombreinstimod);
        $sql->bindValue(2, $codigoregintimod);
        $sql->bindValue(3, $parroquiarinstimod);
        $sql->bindValue(4, $sectorinstimod);
        $sql->bindValue(5, $direccioninstimod);
        $sql->bindValue(6, $codinstimod);
        if ($sql->execute()) {
            return $resultado = self::get_documentos();
        }
    }


}
