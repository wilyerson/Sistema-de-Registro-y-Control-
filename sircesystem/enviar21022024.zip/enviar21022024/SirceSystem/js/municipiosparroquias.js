var opt_1 = new Array ("-", "Mariño", "Rómulo Gallegos");
var opt_2 = new Array ("-", "San José de Aerocuar", "Tavera Acosta");
var opt_3 = new Array ("-", "El Morro", "Puerto Santo", "Río Caribe", "Sucre", "San Juan");
var opt_4 = new Array ("-", "El Pilar", "El Rincón", "Francisco A. Vásquez", "Guaraunos", "Tunapuicito", "Unión");
var opt_5 = new Array ("-", "Bolívar", "Macarapana", "Santa Catalina", "Santa Rosa", "Santa Teresa");
var opt_6 = new Array ("-", "Marigüitar");
var opt_7 = new Array ("-", "Libertad", "El Paujil", "Yaguaraparo");
var opt_8 = new Array ("-", "Araya", "Chacopata", "Manicuare");
var opt_9 = new Array ("-", "Campo Elías", "Tunapui");
var opt_10 = new Array ("-", "Irapa", "Campo Claro", "Marabal", "San Antonio de Irapa", "Soro");
var opt_11 = new Array ("-", "San Antonio del Golfo");
var opt_12 = new Array ("-", "Cumanacoa", "Arenas", "Aricagua", "Cocollar", "San Fernando", "San Lorenzo");
var opt_13 = new Array ("-", "Cariaco", "Catuaro", "Rendón", "Santa Cruz", "Santa María");
var opt_14 = new Array ("-", "Altagracia", "Ayacucho", "Gran Mariscal", "Raúl Leoni", "San Juan", "Santa Inés", "Valentín Valiente");
var opt_15 = new Array ("-", "Cristóbal Colón", "Bideau", "Punta de Piedras", "Güiria");

function cambia() {
  var cosa;
  //se toma el valor de la "cosa selecionada"
  cosa = document.formulario1.cosa[document.formulario1.cosa.selectedIndex].value;
  //se cheque si la cosa esta definida
  if (cosa!=0) {
    //
    mis_opts=eval("opt_" + cosa);
    //
    num_opts=mis_opts.length;
    //
    document.formulario1.opt.length = num_opts;
    //
    for (i=0; i<num_opts; i++) {
      document.formulario1.opt.options[i].value=mis_opts[i];
      document.formulario1.opt.options[i].text=mis_opts[i];
    }
    }else {
      //
      document.formulario1.opt.length= 1;
      document.formulario1.opt.options[0].value="-";
      document.formulario1.opt.options[0].text="-";
    }

    document.formulario1.opt.options[0].selected = true;

  }
