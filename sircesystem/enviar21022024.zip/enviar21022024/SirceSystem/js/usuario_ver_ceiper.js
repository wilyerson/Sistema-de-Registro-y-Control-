const formdata = document.querySelector("#formbusquedapersonal");
formdata.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formbusquedapersonal"));

	let url = "../controlador/usuarios-control.php?op=get_persona";
	fetch(url, {
		method: "post",
		body: datos,
	})
	.then((data) => data.json())
	.then((response) => {

		var status = response.status;
		var datos = response.data;

		switch (status){
		case 'registrado_en_ambas':
			alert("Esta Persona ya tiene un Usuario activo. \nNombre de Usuario: " + datos.NombreUsuario );
			break;

		case 'registrado_en_persona':
			$('#asignar-rol').modal("show");
			document.getElementById("cedulanewuser").value = datos.CedulaPersona;
			document.getElementById("nombrenewuser").value = datos.Nombres;
			document.getElementById("apellidosnewuser").value = datos.Apellidos;
			break;

		case 'no_registrado':
			$('#modal_comp_regp').modal("show");
			break;
		}

	})
	.catch((error) => console.log(`error: ${error}`));
});