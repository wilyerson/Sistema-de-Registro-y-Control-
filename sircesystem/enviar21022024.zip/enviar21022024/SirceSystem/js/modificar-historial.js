function camposVacios(datos) {

   

    let institucionhistoricoedit = document.getElementById('institucionhistoricoedit');
    let cargohistoricoedit = document.getElementById('cargohistoricoedit');
    let fechainiciohistorialedit = document.getElementById('fecha-iniciohistorialedit');
    let fechaculminacionhistorialedit = document.getElementById('fecha-culminacionhistorialedit');
    

    const institucionhistoricovalue = institucionhistoricoedit.value.trim();
    const cargohistoricovalue = cargohistoricoedit.value.trim();
    const fechainiciohistorialvalue = fechainiciohistorialedit.value.trim();
    const fechaculminacionhistorialvalue = fechaculminacionhistorialedit.value.trim();

    let hayCamposVacios = false;

	//--------------------validando los inputs

    if (institucionhistoricovalue == "") {
		setErrorFor(institucionhistoricoedit, 'Ingrese la Intitucion');
		hayCamposVacios = true;
	} else {
		setSuccessFor(institucionhistoricoedit);
	}

    if (cargohistoricovalue == "") {
		setErrorFor(cargohistoricoedit, 'Ingrese el Cargo');
		hayCamposVacios = true;
	} else {
		setSuccessFor(cargohistoricoedit);
	}

    if (fechainiciohistorialvalue == "") {
		setErrorFor(fechainiciohistorialedit, 'Ingrese Fecha de Inicio');
		hayCamposVacios = true;
	} else {
		setSuccessFor(fechainiciohistorialedit);
	}

    // Agrega más condiciones aquí para los otros campos

    return hayCamposVacios;
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.classList.add('errorinput'); // Agrega la clase 'errorinput'
	small.innerText = message;
  }
  
  function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.classList.remove('errorinput');
	formControl.classList.add('successinput');
  
  }

  

  const formdatahii = document.querySelector("#formeditarhistorial");
  formdatahii.addEventListener("submit", (e) => {
      e.preventDefault();
      
      let idpersondaupdate = localStorage.getItem("idpesonaid");
      console.log(idpersondaupdate);
  
      document.getElementById("idpersonahistorialedit").value = idpersondaupdate;
  
      const datos = new FormData(document.getElementById("formeditarhistorial"));

          //validar campos vacios
    if (camposVacios(datos)) {
		//console.log('Hay campos vacíos');
		return;
	}
  
      let url = "../controlador/ctr-historial.php?op=update";
  
      fetch(url, {
          method: 'POST',
          body: datos
      })
      .then(response => response.json())
      .then(respuesta => {
          console.log(respuesta);

          if (respuesta == "Registro actualizado correctamente.") {
            $('#modal-editar-historial').modal("hide");
            swal.fire({
                title: "¡Modificacion de Historial Exitoso!",
                icon: "success",
            });
        }
        if (respuesta == "Las fechas se superponen con un registro existente.") {
            swal.fire({
                title: "¡Las fechas se superponen con un registro existente!",
                icon: "error",
            });
        }

       

      })
      .catch(error => {
          console.log(error);
      });
  });

