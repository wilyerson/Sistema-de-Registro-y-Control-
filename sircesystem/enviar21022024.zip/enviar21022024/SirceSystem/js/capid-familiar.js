const tbody = document.querySelector("#verfamiliares");

tbody.addEventListener("submit", (e) => {
  if (e.target.matches("#editarfamiliar")) {
    e.preventDefault();

    let url = '../controlador/ctr-familiares.php?op=editarmodalfamiliar';
    let data = new FormData(e.target); // Utiliza e.target para acceder al formulario correcto

    fetch(url, {
      method: 'POST',
      body: data
    })
    .then(response => response.json())
    .then(respuesta => {
      console.log(respuesta);
      console.log(respuesta[0].CodigoPersona);

      var inputcedulaeditar = document.getElementById('cedulafamiliareditar');
      var inputregpartidafamiliareditar = document.getElementById('regpartidafamiliareditar');
      var inputcedulaver = document.getElementById('cedulafamiliarver');
      var inputregpartidafamiliarver = document.getElementById('regpartidafamiliarver');

      if(respuesta[0].CedulaPersona == "") {
        
        inputcedulaeditar.disabled = true;
        inputregpartidafamiliareditar.disabled = false;

        inputcedulaver.disabled = true;
        inputregpartidafamiliarver.disabled = false;
    } else {
        
        inputcedulaeditar.disabled = false;
        inputregpartidafamiliareditar.disabled = true;

        inputcedulaver.disabled = true;
        inputregpartidafamiliarver.disabled = true;
    }


      document.getElementById("idpersonafamiliareditar").value = respuesta[0].CodigoPersona;
      document.getElementById("cedulafamiliareditar").value = respuesta[0].CedulaPersona;
      document.getElementById("regpartidafamiliareditar").value = respuesta[0].RegPartidaNacimientoFami;
      document.getElementById("parentescofamiliareditar").value = respuesta[0].Parentesco;
      document.getElementById("nombresfamiliareditar").value = respuesta[0].Nombres;
      document.getElementById("apellidosfamiliareditar").value = respuesta[0].Apellidos;
      document.getElementById("sexofamiliareditar").value = respuesta[0].Sexo;
      document.getElementById("fechanacfamiliareditar").value = respuesta[0].FechaNacimiento;
      document.getElementById("numtelefonofamiliareditar").value = respuesta[0].TelefonoPrincipal;
      document.getElementById("numtelefono2familiareditar").value = respuesta[0].TelefonoHabitacion;

      document.getElementById("idmunicipiofamiliar").value = respuesta[0].CodigoMunicipio;
      document.getElementById("idparroquiafamiliar").value = respuesta[0].ParroquiaPersona;

      document.getElementById("sectorfamiliareditar").value = respuesta[0].Sector;
      document.getElementById("direccionfamiliareditar").value = respuesta[0].Direccion;
      document.getElementById("pesofamiliareditar").value = respuesta[0].Peso;
      document.getElementById("estaturafamiliareditar").value = respuesta[0].Estatura;
      document.getElementById("tallacamisafamiliareditar").value = respuesta[0].TallaCamisa;
      document.getElementById("tallapantfamiliareditar").value = respuesta[0].TallaPantalon;
      document.getElementById("tallacalzafamiliareditar").value = respuesta[0].TallaCalzado;   

      /*let parroquianumero = respuesta[0].ParroquiaInstitucion;
      let parroquianombre = respuesta[0].NombreParroquia;

      localStorage.setItem("ParroquiaInstitucion", parroquianumero);
      localStorage.setItem("ParroquiaNombre", parroquianombre);*/

      //----modal editar pasar datos de base datos------


      document.getElementById("cedulafamiliarver").value = respuesta[0].CedulaPersona;
      document.getElementById("regpartidafamiliarver").value = respuesta[0].RegPartidaNacimientoFami;
      document.getElementById("parentescofamiliarver").value = respuesta[0].Parentesco;
      document.getElementById("nombresfamiliarver").value = respuesta[0].Nombres;
      document.getElementById("apellidosfamiliarver").value = respuesta[0].Apellidos;
      document.getElementById("sexofamiliarver").value = respuesta[0].Sexo;
      document.getElementById("fechanacfamiliarver").value = respuesta[0].FechaNacimiento;
      document.getElementById("numtelefonofamiliarver").value = respuesta[0].TelefonoPrincipal;
      document.getElementById("numtelefono2familiarver").value = respuesta[0].TelefonoHabitacion;
      document.getElementById("municipio-ver-familiar").value = respuesta[0].NombreMunicipio;
      document.getElementById("parroquia-ver-familiar").value = respuesta[0].NombreParroquia;
      document.getElementById("sectorfamiliarver").value = respuesta[0].Sector;
      document.getElementById("direccionfamiliarver").value = respuesta[0].Direccion;
      document.getElementById("pesofamiliarver").value = respuesta[0].Peso;
      document.getElementById("estaturafamiliarver").value = respuesta[0].Estatura;
      document.getElementById("tallacamisafamiliarver").value = respuesta[0].TallaCamisa;
      document.getElementById("tallapantfamiliarver").value = respuesta[0].TallaPantalon;
      document.getElementById("tallacalzafamiliarver").value = respuesta[0].TallaCalzado; 


      if (!respuesta.error) {
        console.log("sirve");
      } else {
        if (respuesta.error === true) {
          // Handle error
        }
      }
    })
    .catch(error => {
      // Handle fetch error
      console.log(error);
    });
  }
});