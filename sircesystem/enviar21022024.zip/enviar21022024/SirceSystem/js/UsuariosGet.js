fetch("../controlador/usuarios-control.php?op=listar")
	.then((response) => response.json())
	//.then(text => console.log(text))
	.then((data) => {
			MostrarTablaUsuarios(data);
	})
	.catch((err) => console.log(`error is: ${err}`));
