document.addEventListener('DOMContentLoaded', async function() {
    /*let params = new URLSearchParams(window.location.search);
    let id = params.get('id');

    localStorage.setItem("idpesonaid", id);*/
    let idperdoc = localStorage.getItem("idpesonaid");
    console.log(idperdoc);

    document.getElementById("idperdoc").value = idperdoc;



    // Realizamos la solicitud POST para obtener el JSON
    try {
        const url = "../controlador/ctr-documentos.php?op=editar";
       const datos = new FormData(document.getElementById("fomrcapturariddoc"));

        const response = await fetch(url, {
            method: "POST",
            body: datos, // Convierte los datos a formato JSON
            
        });

        if (!response.ok) {
            throw new Error(`Error al obtener los datos. Código de estado: ${response.status}`);
        }

        const responseData = await response.json();
        console.log(responseData); // Aquí puedes manejar los datos JSON recibidos
        //console.log(responseData[0].Nombres);

    let tbody = document.querySelector("#verdocumentos");
    tbody.innerHTML = "";
    if (responseData.length > 0) {
        for (let registro of responseData) {
            tbody.innerHTML += `
         <tr>
         <th class="text-center">${registro.NombreDocumento
}</th>
         <td><img class="imagregistrodocumento" src="../controlador/${registro.archivosjpg}"></td>
         
         </td>
         </tr>
         `;
        }
    } else {
        tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${data}</th>
            </td>
            </tr>
            `;
    }
        



    


    } catch (error) {
        console.error(`Error en la solicitud: ${error.message}`);
    }
});