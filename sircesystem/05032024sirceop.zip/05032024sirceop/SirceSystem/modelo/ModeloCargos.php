<?php

class Cargos extends dbconexion
{

    public function insert_cargos($registrocargos)
    {
        $conectar = dbconexion::conexion();

        $sql = $conectar->prepare("INSERT INTO cargos (NombreCargo) VALUES (?)");
        $sql->bindValue(1, $registrocargos);
        
                if ($sql->execute()) {
                    
                   return (['status' => 'cargo_registrado_exitosamente']);
                }

    }


}
