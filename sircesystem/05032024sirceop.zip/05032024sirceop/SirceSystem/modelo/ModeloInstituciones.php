<?php

class Institucion extends dbconexion
{
    public function get_instituciones()
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT CodigoInstituciones, NombreInstitucion FROM instituciones");
        $sql->execute();
        return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_institucion($CodigoInstituciones)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT municipio.NombreMunicipio, municipio.CodigoMunicipio,parroquia.NombreParroquia, instituciones.NombreInstitucion, instituciones.CodigoInstituciones, instituciones.Direccion, instituciones.ParroquiaInstitucion, instituciones.Sector FROM instituciones INNER JOIN parroquia ON instituciones.ParroquiaInstitucion = parroquia.CodigoParroquia INNER JOIN municipio ON parroquia.MunicipioParroquia = municipio.CodigoMunicipio WHERE instituciones.CodigoInstituciones = ?");
        $sql->bindValue(1, $CodigoInstituciones);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function insert_institucion($nombreinstitucion, $parroquiareg, $sectorreg, $direccionreg, $idusuario)
    {
        $conectar = dbconexion::conexion();

        $check = $conectar->prepare("SELECT * FROM instituciones WHERE NombreInstitucion=?");
        $check->bindValue(1, $nombreinstitucion);
        $check->execute();

        if($check->rowCount() > 0){
            return ['status' => 'institucion_ya_existe'];
        }

        $sql = $conectar->prepare("INSERT INTO instituciones (NombreInstitucion,ParroquiaInstitucion, Sector, Direccion, idusuario) VALUES (?,?,?,?,?)");
        $sql->bindValue(1, $nombreinstitucion);
        $sql->bindValue(2, $parroquiareg);
        $sql->bindValue(3, $sectorreg);
        $sql->bindValue(4, $direccionreg);
        $sql->bindValue(5, $idusuario);
        
        

        if ($sql->execute()) {
             return ['status' => 'institucion_registro_exitoso'];
        }
    }

    public function update_institucion($codinstimod, $nombreinstimod, $parroquiarinstimod, $sectorinstimod, $direccioninstimod, $idusuario)
    {

        $conectar = dbconexion::conexion();

         $check = $conectar->prepare("SELECT * FROM instituciones WHERE NombreInstitucion=? AND CodigoInstituciones!=?");
        $check->bindValue(1, $nombreinstimod);
        $check->bindValue(2, $codinstimod);
        $check->execute();

        if($check->rowCount() > 0){
            return (['status' => 'esta_nombre_institucion_ya_existe']);
        }

        $sql = "UPDATE instituciones SET NombreInstitucion = ?, ParroquiaInstitucion = ?, Sector = ?, Direccion = ?, idusuario = ? WHERE CodigoInstituciones = ?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $nombreinstimod);
        $sql->bindValue(2, $parroquiarinstimod);
        $sql->bindValue(3, $sectorinstimod);
        $sql->bindValue(4, $direccioninstimod);
        $sql->bindValue(5, $idusuario);
        $sql->bindValue(6, $codinstimod);
        if ($sql->execute()) {
            return ['status' => 'institucion_modificacion_exitoso'];
        }
    }

    public function get_institucionvalidacion($nombreinstitucion)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT municipio.NombreMunicipio, municipio.CodigoMunicipio,parroquia.NombreParroquia, instituciones.NombreInstitucion, instituciones.CodigoInstituciones, instituciones.CodigoRegistro, instituciones.Direccion, instituciones.ParroquiaInstitucion, instituciones.Sector FROM instituciones INNER JOIN parroquia ON instituciones.ParroquiaInstitucion = parroquia.CodigoParroquia INNER JOIN municipio ON parroquia.MunicipioParroquia = municipio.CodigoMunicipio WHERE instituciones.NombreInstitucion = ? ");
        $sql->bindValue(1, $nombreinstitucion);
        
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function insert_institucionhistorico($nombreinstitucion,  $parroquiareg, $sectorreg, $direccionreg, $idusuario)
    {
        $conectar = dbconexion::conexion();

        $check = $conectar->prepare("SELECT * FROM instituciones WHERE NombreInstitucion=?");
        $check->bindValue(1, $nombreinstitucion);
        $check->execute();

        if($check->rowCount() > 0){
            return (['status' => 'institucionhistorico_ya_existe']);
        }

        $sql = $conectar->prepare("INSERT INTO instituciones (NombreInstitucion, ParroquiaInstitucion, Sector, Direccion, idusuario) VALUES (?,?,?,?,?)");
        $sql->bindValue(1, $nombreinstitucion);
        $sql->bindValue(2, $parroquiareg);
        $sql->bindValue(3, $sectorreg);
        $sql->bindValue(4, $direccionreg);
        $sql->bindValue(5, $idusuario);
        
        if ($sql->execute()) {
            
            $idNuevaInstitucion = $conectar->lastInsertId();
            
            $sql = $conectar->prepare("SELECT * FROM instituciones WHERE CodigoInstituciones = ?");
            $sql->bindValue(1, $idNuevaInstitucion);
            $sql->execute();
            $institucion = $sql->fetch(PDO::FETCH_ASSOC);

             return (['status' => 'institucion_registrada_exitoso', 'data' => $institucion]);
        }
    }

    public function insert_institucionhistoricoeditar($nombreinstitucion,  $parroquiareg, $sectorreg, $direccionreg, $idusuario)
    {
        $conectar = dbconexion::conexion();

        $check = $conectar->prepare("SELECT * FROM instituciones WHERE NombreInstitucion=?");
        $check->bindValue(1, $nombreinstitucion);
        $check->execute();

        if($check->rowCount() > 0){
            return (['status' => 'institucionhistorico_ya_existe']);
        }

        $sql = $conectar->prepare("INSERT INTO instituciones (NombreInstitucion, ParroquiaInstitucion, Sector, Direccion, idusuario) VALUES (?,?,?,?,?)");
        $sql->bindValue(1, $nombreinstitucion);
        $sql->bindValue(2, $parroquiareg);
        $sql->bindValue(3, $sectorreg);
        $sql->bindValue(4, $direccionreg);
        $sql->bindValue(5, $idusuario);
        
        if ($sql->execute()) {
            
            $idNuevaInstitucion = $conectar->lastInsertId();
            
            $sql = $conectar->prepare("SELECT * FROM instituciones WHERE CodigoInstituciones = ?");
            $sql->bindValue(1, $idNuevaInstitucion);
            $sql->execute();
            $institucion = $sql->fetch(PDO::FETCH_ASSOC);

             return (['status' => 'institucion_registrada_exitoso', 'data' => $institucion]);
        }
    }
}
