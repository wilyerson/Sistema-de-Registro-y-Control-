<?php
	require_once "../modelo/ModeloDocumentoselect.php";

	$tabla_documento = new documento();
	$documento = $tabla_documento->obtener_documentos_select();

	// Convertir el resultado a JSON
	echo json_encode($documento);
?>