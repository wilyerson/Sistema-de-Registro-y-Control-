<?php 

$conn = mysqli_connect("localhost","root","","sirceop"); 


session_start(); 
if(!isset($_SESSION['usuarioad'])) 
  {
    header("Location: ../index.php"); 
  }

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registro de Personal</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

  <style type="text/css">

		@font-face{
			font-family: opensan;
			src: url(fonts/googlesansnormal.woff2);

		}

		body{
			font-family: opensan;
		}
		
		.successinput input {
			border-color: #2ecc71;
      border-width: 3.8px;
		}

		.errorinput input {
			border-color: #e74c3c;
			border-width: 3.8px;
		}

		.successinput select {
			border-color: #2ecc71;
      border-width: 3.8px;
		}

		.errorinput select {
			border-color: #e74c3c;
			border-width: 3.8px;
		}	

		small {
			color: #e74c3c;

			visibility: hidden;
		}

		.successinput small {
			color: #e74c3c;

			visibility: hidden;
		}

		.errorinput small {
			visibility: visible;
			font-size: 98%;
      font-weight: bold;
		}
	</style>

</head>



<body class="bg-gray">

   <?php 

 $rolusuario = $_SESSION["roluser"];

 switch ($rolusuario) {

        case 'administrador':

          include"../componentes/nav.php";
        break;

        case 'analista':

          include"../componentes/nav-analista.php";
        break;

        case 'consulta':

          include"../componentes/nav-consulta.php";
        break;


        default:
        # code...
        break;
    }

 ?>


  <div class="container py-3 bg-white rounded-3 shadow" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px;"><!-- INICIO DEL CONTAINER -->

    <form id="regpersonalform" method="POST">

      <div class="row mb-3 mx-3">
        <p class=""><h4 class="text-center" >Registro de Personal</h4></p>
        <hr>
      </div>
      

      <input type="hidden" name="tipopersona" id="tipopersona" value="personal">
      <input type="hidden" name="estatus" id="estatus" value="inactivo">

      <div class="row mb-3 mx-3">
        <div class="col-sm-12 col-md-6">
          <label for="cedulapersona" class="form-label" for="Cedulapersona">Cédula de Identidad</label>
          <input minlength="7" maxlength="9" type="number" class="form-control" id="cedulapersona" name="cedulapersona" placeholder="Ingrese Cédula de Identidad" >
          <small>Error message</small>
        </div>
        <!-- <div class="col-sm-12 col-md-6">
          <label for="fotopersona" class="form-label" for="Fotopersona">Añadir Imagen Cedula</label>
          <input type="file" class="form-control" id="Fotopersona" name="fotopersona">
        </div> -->

    </div>


    <div class="row mb-3 mx-3">      
      <div class="col-sm-6">
          <label for="estadocivil" class="form-label" for="estadocivil">Estado Civil</label>
            <select name="estadocivil" id="estadocivil" class="form-select" style="text-transform: uppercase;" id="Estadocivil">
              <option selected disabled value="">Seleccione</option>
              <option value="casado">Casado</option>
              <option value="soltero">Soltero</option>
              <option value="viudo">Viudo</option>
              <option value="divorciado">Divorciado</option>
            </select>
            <small>Error message</small>
      </div>
    </div>

    <div class="row mb-3 mx-3">
      <div class="col col-sm-12 col-md-6">
        <label for="nombrespersonal" class="form-label">Nombres</label>
        <input type="text" class="form-control" placeholder="Ingrese los Nombres" name="nombrespersonal" id="nombrespersonal" minlength="" maxlength="" >
        <small>Error message</small>
      </div>
      <div class="col col-sm-12 col-md-6">
        <label for="apellidospersonal" class="form-label">Apellidos</label>
        <input type="text" class="form-control" placeholder="Ingrese los Apellidos" name="apellidospersonal" id="apellidospersonal" minlength="" maxlength="" >
        <small>Error message</small>
      </div>
    </div>

    <!-- NOMRBES Y APELLIDOS</!--->

      <!-- FECHA - SEXO</!--->

      <div class="row mb-4 mx-3">

        <div class="col-sm-12 col-md-6 ">
          <label for="fechanacimiento" class="form-label" for="Fechanacimiento" >Fecha de Nacimiento</label>
          <input type="date" class="form-control" id="fechanacimiento" name="fechanacimiento">
          <small>Error message</small>
        </div>

        <div class="col-sm-6 col-md-6">
         <label for="sexo" class="form-label" for="sexo" >Sexo</label>
         <select name="sexo" class="form-select" id="sexo">
          <option selected disabled value="">Seleccione</option>
          <option value="masculino">MASCULINO</option>
          <option value="femenino">FEMENINO</option>
        </select>
        <small>Error message</small>
      </div>

    </div>

    <!-- FECHA - SEXO</!--->

    <!--  NUMEROS TELEFONICOS </!--->

    <div class="row mb-4 mx-3">
      <div class="col-sm-12 col-md-6">
        <label for="telefonoprincipal" class="form-label">Numero telefonico Principal</label>
        <input placeholder="Ingrese su Número Telefónico" type="number" class="form-control" id="telefonoprincipal" name="telefonoprincipal">
        <small>Error message</small>
      </div>
      <div class="col-sm-12 col-md-6">
        <label for="telefonohabitacion" class="form-label">Numero Telefonico Habitacion</label>
        <input placeholder="Ingrese su Número Telefónico" type="number" class="form-control" id="telefonohabitacion" name="telefonohabitacion">
        <small>Error message</small>
      </div>
    </div>

    <!--  NUMEROS TELEFONICOS </!--->

    <div class="row mb-3 mx-3">
      <hr>
    </div>

    <!-- LOCALIDAD</!--->

    <div class="row mb-4 mx-3">

      <div class="col-sm-12 col-md-6">
        <label for="id_mun" class="form-label">Municipio</label>
        <select class="form-select" name="id_mun" id="id_mun" aria-label="Default select example">
          <option selected disabled value="">Seleccione Municipio</option>
          <?php 

          require "../controlador/municipiosfetch.php";

          foreach ($municipio as $municipio) {
            echo '<option value="'.$municipio['CodigoMunicipio'].'">'.$municipio['NombreMunicipio'].'</option>';
          }
          ?>
        </select>
        <small>Error message</small>
      </div>

      <div class="col-md-6 col-sm-12">
        <label for="parroquiareg" class="form-label">Parroquia</label>
        <select class="form-select" name="parroquiareg" id="parroquiareg" aria-label="Default select example">
          <option selected disabled value="">Seleccione Parroquia</option>
          <script>
            document.querySelector('#id_mun').addEventListener('change', event => {
              console.log(event.target.value);
              fetch('../controlador/parroquiasfetch.php?id_mun='+event.target.value)
              .then(res => {
                if(!res.ok){
                  throw new Error('error en la respuesta');
                }
                return res.json();
              })
              .then(datos => {
                let html = '<option value="">Seleccione Parroquia</option>';
                if(datos.data.length > 0){
                  for(let i = 0; i < datos.data.length; i++){
                    html += `<option value="${datos.data[i].CodigoParroquia}">${datos.data[i].NombreParroquia}</option>`; 
                  }
                }
                document.querySelector('#parroquiareg').innerHTML = html;
              })
              .catch(error => {
                console.error('ocurrio un error '+error);
              }); 
            });
          </script>          
        </select>
        <small>Error message</small>
      </div>
    </div>

    <div class="row mb-4 mx-3">
      <div class="col-sm-12 col-md-6">
        <label for="sector" class="form-label">Sector</label>
        <input minlength="10" maxlength="50" type="text"placeholder="Ingrese Sector" class="form-control" id="sector" name="nombresector">
        </div>
      <div class="col-md-6 col-sm-12">
        <label for="direccion" class="form-label">Dirección</label>
        <input minlength="10" maxlength="100" type="text" placeholder="Ingrese Dirección" class="form-control" id="direccion" name="direccion">
      </div>
    </div>

    <!-- LOCALIDAD</!--->
    <div class="row mb-3 mx-3">
      <hr>
    </div>

    <!--  PESO Y ESTATURA </!--->

    <div class="row mb-4 mx-3">
      <div class="col-sm-12 col-md-6">
        <label for="peso" class="form-label">Peso (Kg)</label>
        <input minlength="1" maxlength="7" type="text" class="form-control inputss" placeholder=".Kg" id="peso" name="peso">
      </div>
      <div class="col-md-6 col-sm-12">
        <label for="estatura" class="form-label">Estatura (Metros)</label>
        <input type="text" class="form-control inputss" placeholder=".Mts" id="estatura" name="estatura">
      </div>
    </div>

    <!--  PESO Y ESTATURA </!--->

    <!--  TALLAS</!--->

    <div class="row mb-4 mx-3">

      <div class="col-md-4 col-sm-12">
        <label for="camisa" class="form-label">Talla Camisa</label>
        <input minlength="1" maxlength="5" type="text" class="form-control inputss" placeholder="Torso" id="tallacamisa" name="tallacamisa">
      </div>

      <div class="col-md-4 col-sm-12">
        <label for="pantalon" class="form-label">Talla Pantalón</label>
        <input minlength="1" maxlength="5" type="text" class="form-control inputss" placeholder="Piernas" id="tallapantalon" name="tallapantalon">
      </div>

      <div class="col-md-4 col-sm-12">
        <label for="calzado" class="form-label">Talla Calzado</label>
        <input minlength="1" maxlength="5" type="text" class="form-control inputss" placeholder="Calzado" id="tallacalzado" name="tallacalzado">
      </div>

    </div>

    <!--  TALLAS</!--->

    <div class="row text-center">
      <div class="col col-sm-12">
        <button class="btn btn-secondary" type="reset" onclick="limpiarformuregperson()">Limpiar</button> 
        <button class="btn btn-primary" id="Guardarp"  type="submit" name="Guardarp">Registrar</button>      
      </div>
    </div>

    </form><!-- FIN DEL FORMULARIO -->

  </div><!-- FIN DEL CONTAINER -->

    <!-- Modal -->
<div class="modal fade" id="modalregistrarexitoso" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div style="margin-top: 6%;">
        
        
      </div>
          <div class="modal-body">
                        <img style="position: relative;
                    left: 50.5%;
                    top: 17%;
                    width: 41%;
                    transform: translate(-50%, -7%);" src="../icons/iconcirclecheck.svg" >
                        <h5 style="position: relative;
                    left: 83.5%;
                    top: 20%;
                    transform: translate(-50%, 21%);">Registro Exitoso</h5>
          </div>
      <div class="modal-footer">
       
       <!-- <button type="button" id="botonidpersonreg" class="btn btn-primary">Continuar</button> -->
      </div>
    </div>
  </div>
</div>

  <script src="../librerias/wall.js"></script>
  <script src="../js/jquery.min.js"></script>
  <script src="../js/validarformpersonal.js"></script>
  <!-- <script src="../js/validarformpersonal.js"></script> -->
  <script src="../js/registro-personal.js"></script>
</body>
</html>