<?php 

session_start();

if(!isset($_SESSION['usuarioad']))
{
	header("Location: ../index.php");
}



?>



<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SIRCE</title>
	<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

	<style type="text/css">
		

		@font-face{
			font-family: opensan;
			src: url(fonts/googlesansnormal.woff2);

		}

		body{
			font-family: opensan;
			/*text-transform: uppercase;*/
		}

		input{
			text-transform: uppercase;
		}

		.imagregistrodocumento{
        width: 138px;
    	height: 102px;
        }

		.successinput input {
			border-color: #2ecc71;
      border-width: 3.8px;
		}

		.errorinput input {
			border-color: #e74c3c;
			border-width: 3.8px;
		}

		.successinput select {
			border-color: #2ecc71;
      border-width: 3.8px;
		}

		.errorinput select {
			border-color: #e74c3c;
			border-width: 3.8px;
		}	

		small {
			color: #e74c3c;

			visibility: hidden;
		}

		.successinput small {
			color: #e74c3c;

			visibility: hidden;
		}

		.errorinput small {
			visibility: visible;
			font-size: 98%;
      font-weight: bold;
		}

		#registrarinsitucion{
		    width: 42%;
		    height: 75%;
		    position: absolute;
		    left: 50%;
		    top: 47%;
		    transform: translate(-50%, -50%);
		    z-index: 9999;
		    display: none;
		}

	.modal2 {
      display: none; /* Hidden by default */
	position: absolute;
    z-index: 8;
	left: 50%;
    top: 39%;
    width: 670px;
    height: 65%;
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
      transform: translate(-50%, -50%);
    }

    .close2 {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close2:hover,
.close2:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

    .close2editar {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close2editar:hover,
.close2editar:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
/* select institucion  */

::selection{
  color: #fff;
  background: #4285f4;
}
.wrapper{
  width: 308px;
  margin: 85px auto 0;
}
.select-btn, li{
  display: flex;
  align-items: center;
  cursor: pointer;
}
.select-btn{
  /*height: 65px;
  padding: 0 20px;
  font-size: 22px;
  background: #fff;
  border-radius: 7px;
  justify-content: space-between;
  box-shadow: 0 10px 25px rgba(0,0,0,0.1);*/
}
.select-btn i{
  font-size: 31px;
  transition: transform 0.3s linear;
}
.wrapper.active .select-btn i{
  transform: rotate(-180deg);
}
.content{
  display: none;
  padding: 15px;
  margin-top: 15px;
  background: #fff;
  border-radius: 7px;
  box-shadow: 0 10px 25px rgba(0,0,0,0.1);
  border: solid;
  border-width: 1px;
}
.wrapper.active .content{
  display: block;
}
.content .search{
  position: relative;
}
.search i{
  top: 50%;
  left: 15px;
  color: #999;
  font-size: 20px;
  pointer-events: none;
  transform: translateY(-50%);
  position: absolute;
}
.search input{
  height: 50px;
  width: 100%;
  outline: none;
  font-size: 17px;
  border-radius: 5px;
  padding: 0 20px 0 43px;
  border: 1px solid #B3B3B3;
}
.search input:focus{
  padding-left: 42px;
  border: 2px solid #4285f4;
}
.search input::placeholder{
  color: #bfbfbf;
}
.content .options{
  margin-top: 10px;
  max-height: 250px;
  overflow-y: auto;
  padding-right: 7px;
}
.options::-webkit-scrollbar{
  width: 7px;
}
.options::-webkit-scrollbar-track{
  background: #f1f1f1;
  border-radius: 25px;
}
.options::-webkit-scrollbar-thumb{
  background: #ccc;
  border-radius: 25px;
}
.options::-webkit-scrollbar-thumb:hover{
  background: #b3b3b3;
}
.options li{
  height: 50px;
  padding: 0 13px;
  font-size: 21px;
  margin-left: -30px;
  padding-left: 28px;
}
.options li:hover, li.selected{
  border-radius: 5px;
  background: #f2f2f2;
}

/* select institucion */

/* select institucion editar */

::selectioneditar{
  color: #fff;
  background: #4285f4;
}
.wrappereditar{
  width: 308px;
  margin: 85px auto 0;
}
.select-btneditar, li{
  display: flex;
  align-items: center;
  cursor: pointer;
}
.select-btneditar{
  /*height: 65px;
  padding: 0 20px;
  font-size: 22px;
  background: #fff;
  border-radius: 7px;
  justify-content: space-between;
  box-shadow: 0 10px 25px rgba(0,0,0,0.1);*/
}
.select-btneditar i{
  font-size: 31px;
  transition: transform 0.3s linear;
}
.wrappereditar.active .select-btneditar i{
  transform: rotate(-180deg);
}
.contenteditar{
  display: none;
  padding: 15px;
  margin-top: 15px;
  background: #fff;
  border-radius: 7px;
  box-shadow: 0 10px 25px rgba(0,0,0,0.1);
  border: solid;
  border-width: 1px;
}
.wrappereditar.active .contenteditar{
  display: block;
}
.contenteditar .searcheditar{
  position: relative;
}
.searcheditar i{
  top: 50%;
  left: 15px;
  color: #999;
  font-size: 20px;
  pointer-events: none;
  transform: translateY(-50%);
  position: absolute;
}
.searcheditar input{
  height: 50px;
  width: 100%;
  outline: none;
  font-size: 17px;
  border-radius: 5px;
  padding: 0 20px 0 43px;
  border: 1px solid #B3B3B3;
}
.searcheditar input:focus{
  padding-left: 42px;
  border: 2px solid #4285f4;
}
.searcheditar input::placeholder{
  color: #bfbfbf;
}
.contenteditar .optionseditar{
  margin-top: 10px;
  max-height: 250px;
  overflow-y: auto;
  padding-right: 7px;
}
.optionseditar::-webkit-scrollbar{
  width: 7px;
}
.optionseditar::-webkit-scrollbar-track{
  background: #f1f1f1;
  border-radius: 25px;
}
.optionseditar::-webkit-scrollbar-thumb{
  background: #ccc;
  border-radius: 25px;
}
.optionseditar::-webkit-scrollbar-thumb:hover{
  background: #b3b3b3;
}
.optionseditar li{
  height: 50px;
  padding: 0 13px;
  font-size: 21px;
  margin-left: -30px;
  padding-left: 28px;
}
.optionseditar li:hover, li.selected{
  border-radius: 5px;
  background: #f2f2f2;
}

/* select institucion editar */

#myBtn2{
	margin-top: 0%;
	margin-left: 0%;
    position: relative;
    left: -5%;
    top: 58%;
    transform: translate(-50%, 70%);
}

	</style>
</head>

<body class="bg-gray">

	 <?php 

 $rolusuario = $_SESSION["roluser"];

 switch ($rolusuario) {

        case 'administrador':

          include"../componentes/nav.php";
        break;

        case 'analista':

          include"../componentes/nav-analista.php";
        break;

        case 'consulta':

          include"../componentes/nav-consulta.php";
        break;


        default:
        # code...
        break;
    }

 ?>

	<form id="fomrcapturarid" method="post">

		<input type="hidden" id="idper" name="idper" value="">


	</form>

	<div class="container p-2" style="max-width: 1000px; margin-top: 100px; ">


		<ul class="nav nav-pills mb-3 justify-content-center" id="pills-tab" role="tablist">
			<li class="nav-item" role="presentation">
				<button class="nav-link active" id="pills-Perfil-tab" data-bs-toggle="pill" data-bs-target="#pills-Perfil" type="button" role="tab" aria-controls="pills-Perfil" aria-selected="true">Datos Personales</button>
			</li>
			<li class="nav-item" role="presentation">
				<button class="nav-link" id="pills-docs-tab" data-bs-toggle="pill" data-bs-target="#pills-docs" type="button" role="tab" aria-controls="pills-docs" aria-selected="false">Documentos</button>
			</li>
			<li class="nav-item" role="presentation">
				<button class="nav-link" id="pills-historico-tab" data-bs-toggle="pill" data-bs-target="#pills-historico" type="button" role="tab" aria-controls="pills-historico" aria-selected="false">Historico</button>
			</li>
			<li class="nav-item" role="presentation">
				<button class="nav-link" id="pills-familiares-tab" data-bs-toggle="pill" data-bs-target="#pills-familiares" type="button" role="tab" aria-controls="pills-familiares" aria-selected="false">Familiares</button>
			</li>
		</ul>

		<div class="tab-content bg-white p-4 rounded-3 shadow" id="pills-tabContent">

			<!-- ///////////////////////////////////////////////////PANEL PERFIL /////////////////////////////////////////////////-->

				<div class="tab-pane fade show active" id="pills-Perfil" role="tabpanel" aria-labelledby="pills-Perfil-tab">




					<div class="row mt-2 mb-2">

						<div class="col col-md-5">
							<img class="rounded mx-auto d-block" id="img-perfil" width="200px">
						</div>




						<input type="hidden" value="" name="id" id="idcedula" >

						<div class="col-sm-7">
							<div id="zonadatospersona">
								
							</div>
							
						</div>
						<div class="col-sm-12 d-flex justify-content-center">
							<button type="button" class="btn btn-primary justify-content-center mr-4" data-bs-toggle="modal" data-bs-target="#modal-ver-trabajador">
								Ver Datos
							</button>
							<div style="margin-left: 5%;"></div>
							<button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-editar-trabajador">
								Modificar Datos
							</button>
						</div>
					</div>
				</div>

				<!-- ///////////////////////////////////////////////////PANEL PERFIL /////////////////////////////////////////////////-->

				<!--///////////////////////////////////////////// MODAL EDITAR DATOS /////////////////////////////////////////////-->

				<div class="modal fade" id="modal-editar-trabajador" tabindex="-1" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-lg">
						<div class="modal-content">

							<div class="modal-header" style="background-color:#009aff; ">
								<h5 class="modal-title text-white" id="exampleModalLabel">Editar Datos del Trabajador</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
							</div>

							<div class="modal-body">

							<!--  CEDULA - NOMBRE Y APELLIDO</!--->

							<form id="formupersonalmodificar"  method="post"  enctype="multipart/form-data"  novalidate>

          					<input type="hidden"  name="idpersona" id="idpersona" value="" >

							<input type="hidden" id="cedula_original" name="cedula_original">
							<input type="hidden" id="cedula_actual" name="cedula_actual" value="">
							
							<div class="row mb-4 mx-3">

								<div class="col-sm-12 col-md-6">
									<label for="cedula" class="form-label">Cédula</label>
									<input type="number" class="form-control" id="CedulaPersona" name="editCi" value="">
									<small>Error message</small>
								</div>

							</div>

							<div class="row mb-4 mx-3">						
								<div class="col-sm-12 col-md-6">
									<label for="nombres" class="form-label">Nombres</label>
									<input type="text" class="form-control" id="Nombrespersona" name="editName" value="">
									<small>Error message</small>
								</div>

								<div class="col-sm-12 col-md-6">
									<label for="apellidos" class="form-label">Apellidos</label>
									<input type="text" class="form-control" id="Apellidospersona" name="editApellidos" value="">
									<small>Error message</small>
								</div>
							</div>


							<!--  CEDULA - ESTADO CIVIL</!--->
							<!-- FECHA - SEXO</!--->

							<div class="row mb-4 mx-3">

								<div class="col-md-6 col-sm-12">
									<label for="fecha-nac" class="form-label">Fecha de Nacimiento</label>
									<input type="date" class="form-control" id="FechaNacimientopersona" name="editFechanacimiento" value="">
									<small>Error message</small>
								</div>

								<div class="col-md-6 col-sm-12">
									<label for="sexo" class="form-label">Sexo</label>
									<select name="editsexo" class="form-select" id="sexopersona">
										<option value="" selected disabled>Seleccione el Genero</option>
										<option value="masculino">Masculino</option>
										<option value="femenino">Femenino</option>

									</select>
									<small>Error message</small>
								</div>
							</div>

							<div class="row mb-4 mx-3">
								<div class="col-sm-12">
									<label for="std-civil" class="form-label">Estado Civil</label>
									<select name="editestadocivil" class="form-select" id="estadocivilpersona">
										<option value="" selected disabled>Seleccione el Estado Civil</option>
										<option value="casado">Casado</option>
										<option value="soltero">Soltero</option>
									</select>
									<small>Error message</small>
								</div>
							</div>


							<!-- FECHA - SEXO</!--->

							<!--  NUMEROS TELEFONICOS </!--->

							<div class="row mb-4 mx-3">
								<div class="col-sm-12 col-md-6 formu-control">
									<label for="n-principal" class="form-label">Numero Principal</label>
									<input type="number" class="form-control" id="TelefonoPrincipalpersona" name="editTelefonoPrincipal" value="" >
									<small>Error message</small>
								</div>
								<div class="col-sm-12 col-md-6 formu-control">
									<label for="n-habitacion" class="form-label">Numero Habitación</label>
									<input type="number" class="form-control" id="TelefonoHabitacionpersona" name="editTelefonoHabitacion" value="">
									<small>Error message</small>
								</div>
							</div>

							<!--  NUMEROS TELEFONICOS </!--->


							<!-- LOCALIDAD</!--->

							<div class="row mb-4 mx-3">

								<div class="col-sm-12 col-md-6">
									<label for="municipio" class="form-label">Municipio</label>
									<select class="form-select" id="editmunicipio" name="editmunicipio"; aria-label="Default select example">

									</select>
									<small>Error message</small>
								</div>

								<div class="col-sm-12 col-md-6">
									<label for="parroquia" class="form-label">Parroquia</label>
									<select class="form-select" id="editparroquiareg" name="editparroquiareg"; aria-label="Default select example">

									</select>
									<small>Error message</small>
								</div>
							</div>

							<div class="row mb-1 mx-3">
								<div class="col-sm-12">
									<label for="sector" class="form-label">Sector</label>
									<input type="text" class="form-control form-control-sm" id="sectorpersona" name="editsector" value="">
									<small>Error message</small>
								</div>								
							</div>

							<div class="row mb-4 mx-3">
								<div class="col col-sm-12 mt-4">
									<label for="direccion" class="form-label">Dirección</label>
									<input type="text" class="form-control form-control-sm" id="direccionpersona" name="editdireccion" value="">
									<small>Error message</small>
								</div>								
							</div>



							<!-- LOCALIDAD</!--->

							<!--  PESO Y ESTATURA </!--->

							<div class="row mb-3 mx-3">
								<div class="col-sm-12 col-md-6">
									<label for="peso" class="form-label">Peso</label>
									<input type="text" class="form-control" id="pesopersona" name="editpeso" value="">
								</div>
								<div class="col-sm-12 col-md-6">
									<label for="estatura" class="form-label">Estatura</label>
									<input type="text" class="form-control" id="estaturapersona" name="editestatura" value="">
									<small>Error message</small>
								</div>
							</div>

							<!--  PESO Y ESTATURA </!--->

							<!--  TALLAS</!--->

							<div class="row mb-3 mx-3">

								<div class="col-sm-12 col-md-4 formu-control">
									<label for="camisa" class="form-label">Talla Camisa</label>
									<input type="text" class="form-control" id="TallaCamisapersona" name="editTallaCamisa" value="">
									<small>Error message</small>
								</div>

								<div class="col-sm-12 col-md-4 formu-control">
									<label for="pantalon" class="form-label">Talla Pantalón</label>
									<input type="text" class="form-control" id="TallaPantalonpersona" name="edittallapantalon" value="">
									<small>Error message</small>
								</div>

								<div class="col-sm-12 col-md-4 formu-control">
									<label for="calzado" class="form-label">Talla Calzado</label>
									<input type="text" class="form-control" id="TallaCalzadopersona" name="editTallaCalzado" value="">
									<small>Error message</small>
								</div>

							</div>

							<!--  TALLAS</!--->

							</div>

							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="limpiarformuregperson()">Cerrar</button>
								<button type="submit" class="btn btn-primary" name="modificar">Guardar Cambios</button>
							</div>
						
							</form>
						</div>
					</div>
				</div>

				<!--///////////////////////////////////////////// MODAL EDITAR DATOS /////////////////////////////////////////////-->


				<!--///////////////////////////////////////////// MODAL VER DATOS PERSONAS /////////////////////////////////////////////-->

				<div class="modal fade" id="modal-ver-trabajador" tabindex="-1" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-lg">
						<div class="modal-content">

							<div class="modal-header" style="background-color:#009aff; ">
								<h5 class="modal-title text-white" id="exampleModalLabel">Editar Datos del Trabajador</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
							</div>

							<div class="modal-body">

							<!--  CEDULA - NOMBRE Y APELLIDO</!--->

							<form id="formupersonalmodificar"  method="post"  enctype="multipart/form-data"  novalidate>

          					<input type="hidden"  name="idpersona" id="idpersona" value="" >
							
							<div class="row mb-4 mx-3">

								<div class="col-sm-12 col-md-6">
									<label for="cedula" class="form-label">Cédula</label>
									<input type="number" class="form-control" id="CedulaPersonaver" name="editCi" value="" disabled>
									<small>Error message</small>
								</div>

							</div>

							<div class="row mb-4 mx-3">						
								<div class="col-sm-12 col-md-6">
									<label for="nombres" class="form-label">Nombres</label>
									<input type="text" class="form-control" id="Nombrespersonaver" name="editName" value="" disabled>
									<small>Error message</small>
								</div>

								<div class="col-sm-12 col-md-6">
									<label for="apellidos" class="form-label">Apellidos</label>
									<input type="text" class="form-control" id="Apellidospersonaver" name="editApellidos" value="" disabled>
									<small>Error message</small>
								</div>
							</div>


							<!--  CEDULA - ESTADO CIVIL</!--->
							<!-- FECHA - SEXO</!--->

							<div class="row mb-4 mx-3">

								<div class="col-md-6 col-sm-12">
									<label for="fecha-nac" class="form-label">Fecha de Nacimiento</label>
									<input type="date" class="form-control" id="FechaNacimientopersonaver" name="editFechanacimiento" value="" disabled>
									<small>Error message</small>
								</div>

								<div class="col-md-6 col-sm-12">
									<label for="sexo" class="form-label">Sexo</label>
									<select name="editsexo" class="form-select" id="sexopersonaver" disabled>
										<option value="" selected disabled>Seleccione el Genero</option>
										<option value="masculino">Masculino</option>
										<option value="femenino">Femenino</option>

									</select>
									<small>Error message</small>
								</div>
							</div>

							<div class="row mb-4 mx-3">
								<div class="col-sm-12">
									<label for="std-civil" class="form-label">Estado Civil</label>
									<select name="editestadocivil" class="form-select" id="estadocivilpersonaver" disabled>
										<option value="" selected disabled>Seleccione el Estado Civil</option>
										<option value="casado">Casado</option>
										<option value="soltero">Soltero</option>
									</select>
									<small>Error message</small>
								</div>
							</div>


							<!-- FECHA - SEXO</!--->

							<!--  NUMEROS TELEFONICOS </!--->

							<div class="row mb-4 mx-3">
								<div class="col-sm-12 col-md-6 formu-control">
									<label for="n-principal" class="form-label">Numero Principal</label>
									<input type="number" class="form-control" id="TelefonoPrincipalpersonaver" name="editTelefonoPrincipal" value="" disabled>
									<small>Error message</small>
								</div>
								<div class="col-sm-12 col-md-6 formu-control">
									<label for="n-habitacion" class="form-label">Numero Habitación</label>
									<input type="number" class="form-control" id="TelefonoHabitacionpersonaver" name="editTelefonoHabitacion" value="" disabled>
									<small>Error message</small>
								</div>
							</div>

							<!--  NUMEROS TELEFONICOS </!--->


							<!-- LOCALIDAD</!--->

							<div class="row mb-4 mx-3">

								<div class="col-sm-12 col-md-6">
									<label for="municipio" class="form-label">Municipio</label>
									<input type="text" name="vermunicipiopersona" id="vermunicipiopersona" class="form-select" disabled>
									<small>Error message</small>
								</div>

								<div class="col-sm-12 col-md-6">
									<label for="parroquia" class="form-label">Parroquia</label>
									<input type="text" name="verparroquiapersona" id="verparroquiapersona" class="form-select" disabled>	
									<small>Error message</small>
								</div>
							</div>

							<div class="row mb-1 mx-3">
								<div class="col-sm-12">
									<label for="sector" class="form-label">Sector</label>
									<input type="text" class="form-control form-control-sm" id="sectorpersonaver" name="editsector" value="" disabled>
									<small>Error message</small>
								</div>								
							</div>

							<div class="row mb-4 mx-3">
								<div class="col col-sm-12 mt-4">
									<label for="direccion" class="form-label">Dirección</label>
									<input type="text" class="form-control form-control-sm" id="direccionpersonaver" name="editdireccion" value="" disabled>
									<small>Error message</small>
								</div>								
							</div>



							<!-- LOCALIDAD</!--->

							<!--  PESO Y ESTATURA </!--->

							<div class="row mb-3 mx-3">
								<div class="col-sm-12 col-md-6">
									<label for="peso" class="form-label">Peso</label>
									<input type="text" class="form-control" id="pesopersonaver" name="editpeso" value="" disabled>
								</div>
								<div class="col-sm-12 col-md-6">
									<label for="estatura" class="form-label">Estatura</label>
									<input type="text" class="form-control" id="estaturapersonaver" name="editestatura" value="" disabled>
									<small>Error message</small>
								</div>
							</div>

							<!--  PESO Y ESTATURA </!--->

							<!--  TALLAS</!--->

							<div class="row mb-3 mx-3">

								<div class="col-sm-12 col-md-4 formu-control">
									<label for="camisa" class="form-label">Talla Camisa</label>
									<input type="text" class="form-control" id="TallaCamisapersonaver" name="editTallaCamisa" value="" disabled>
									<small>Error message</small>
								</div>

								<div class="col-sm-12 col-md-4 formu-control">
									<label for="pantalon" class="form-label">Talla Pantalón</label>
									<input type="text" class="form-control" id="TallaPantalonpersonaver" name="edittallapantalon" value="" disabled>
									<small>Error message</small>
								</div>

								<div class="col-sm-12 col-md-4 formu-control">
									<label for="calzado" class="form-label">Talla Calzado</label>
									<input type="text" class="form-control" id="TallaCalzadopersonaver" name="editTallaCalzado" value="" disabled>
									<small>Error message</small>
								</div>

							</div>

							<!--  TALLAS</!--->

							</div>

							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal" >Cerrar</button>
								
							</div>
						
							</form>
						</div>
					</div>
				</div>

				<!--///////////////////////////////////////////// MODAL VER DATOS PERSONAS /////////////////////////////////////////////-->



				<!-- ////////////////////////////////////////////////PANEL DOCUMENTOS//////////////////////////////////////////////// -->

				<div class="tab-pane fade" id="pills-docs" role="tabpanel" aria-labelledby="pills-docs-tab">

					<div class="row">

					<div class="col-sm-12 d-flex justify-content-end py-3">
						<button type="button" class="btn btn-primary justify-content-center mr-5" onclick="descargarDocumentos()" style="margin: auto; padding: 6px; border-left-width: 5px; border-right-width: 41px;"><img id="housesolid" src="../icons/circle-down-solid.svg" style="color: white; height: 35px; position: relative; left: 212px; top: 0px; width: 31px; margin-left: -15%;" data-bs-toggle="modal" data-bs-target="#modalverpdfdocumento">
							Descargar Documentos
						</button>
						<div style="margin-left: 58%;"></div>
						<button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-registrar-documentos">
							Añadir Documentos
						</button>
					</div>

						<div class="col-sm-12 d-block justify-content-center">

							<table class="table table-hover" >
								<thead>
									<tr>
										<th style="padding-left: 18%;">Nombre Documento</th>
										<th style="padding-left: 10%;">Foto Documento</th>
										<th></th>
									</tr>								
								</thead>
								<tbody id="verdocumentos">

								</tbody>

							</table>

						</div>

					</div>

				</div>

				<!-- ////////////////////////////////////////////////PANEL DOCUMENTOS//////////////////////////////////////////////// -->

				<!-- ////////////////////////////////////////////////PANEL HISTORICO//////////////////////////////////////////////// -->
				<div class="tab-pane fade" id="pills-historico" role="tabpanel" aria-labelledby="pills-historico-tab">

					<div class="row">

						<div class="col-sm-12 d-flex justify-content-end py-3">
							<button type="button" class="btn btn-primary d-flex justify-content-center" data-bs-toggle="modal" data-bs-target="#registro-historico">
								Registrar Historial
							</button>						
						</div>

						<div class="col-sm-12 d-block justify-content-center">

							<table class="table table-hover">
								<thead>
									<tr>
										<th>Institución</th>
										<th>Cargo</th>
										<th>Fecha Inicio</th>
										<th>Fecha Culminacion</th>
										<th>Acción</th>
									</tr>								
								</thead>
								<tbody id="mostrarhistoriallaboral"></tbody>

							</table>

						</div>

					</div>

				</div>
				<!-- ////////////////////////////////////////////////PANEL HISTORICO//////////////////////////////////////////////// -->

				<!-- ////////////////////////////////////////////////PANEL FAMILIARES//////////////////////////////////////////////// -->
				<div class="tab-pane fade" id="pills-familiares" role="tabpanel" aria-labelledby="pills-familiares-tab">

					<div class="row">

						<div class="col-sm-12 d-flex justify-content-end py-3">
							<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#registro-familiar">Registrar Familiar</button>						
						</div>

						<div class="col-sm-12 d-block justify-content-center">

							<table class="table table-hover">
								<thead>
									<tr>
										<th>Nombres</th>
										<th>Apellidos</th>
										<th>Parentesco</th>
										<th>Edad</th>
										<th class="text-center" style="width: 13%;">Acción</th>
									</tr>								
								</thead>
								<tbody id="verfamiliares">

								</tbody>
							</table>
						</div>
					</div>
				</div>
				<!-- ////////////////////////////////////////////////PANEL FAMILIARES//////////////////////////////////////////////// -->

			</div>




				<!-- ///////////////////////////////////////////MODAL REGISTRO FAMILIAR/////////////////////////////////////////// -->

				<div class="modal fade" id="registro-familiar" tabindex="-1" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered modal-md">
						<div class="modal-content">
						<form id="fomrcapturaridfamilia" method="post">

							<input type="hidden" id="idperfamilia" name="idperfamilia" value="">


							</form>
						<form id="formregistrarfamiliar" method="post">

							<input type="hidden"  name="idpersonafamiliar" id="idpersonafamiliar" value="" >

							<input type="hidden" name="tipopersonafamiliar" id="tipopersonafamiliar" value="familiar">
							<input type="hidden" name="estatusfamiliar" id="estatusfamiliar" value="inactivo">

							<div class="modal-header" style="background-color: #009aff;">
								<h5 class="modal-title text-white" id="exampleModalLabel">Registrar Familiar</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
							</div>

							<div class="modal-body">

								<div class="row">

									<div class="col col-md-12 py-1">
										<div class="form-check d-flex justify-content-center">
											<input type="hidden" name="checkboxfamiliar" value="no">
											<input class="form-check-input" type="checkbox" value="si" id="checkboxfamiliar" name="checkboxfamiliar">
											<label class="form-check-label" for="flexCheckDefault">
												&nbsp;&nbsp;&nbsp;No posee Cédula
											</label>
										</div>
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="number" class="form-control" id="cedulafamiliar" name="cedulafamiliar" placeholder="INGRESE CEDULA DE IDENTIDAD" value="">
										<small>Error message</small>
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="number" class="form-control" id="regpartidafamiliar" name="regpartidafamiliar" disabled placeholder="INGRESE REGISTRO DE PARTIDA DE NACIMIENTO" value="">
										<small>Error message</small>
									</div>
								</div>

								<div class="row">
									<div class="col-sm-12 py-3">										
										<select class="form-select" id="parentescofamiliar" name="parentescofamiliar">
											<option selected disabled value="">Seleccione Parentesco</option>
											<option value="Hijo">Hijo</option>
											<option value="Hija">Hija</option>
											<option value="Padre">Padre</option>
											<option value="Madre">Madre</option>
											<option value="Esposa">Esposa</option>
											<option value="Esposo">Esposo</option>
											<option value="Abuelo">Abuelo</option>
											<option value="Abuela">Abuela</option>
											<option value="Nieto">Nieto</option>
											<option value="Nieta">Nieta</option>
											<option value="Sobrino">Sobrino</option>
											<option value="Sobrina">Sobrina</option>
											<option value="Hermano">Hermano</option>
											<option value="Hermana">Hermana</option>
										</select>
										<small>Error message</small>
									</div>
								</div>

							<!-- <div class="row">
									<div class="col-sm-12 py-3">
									&nbsp;&nbsp;&nbsp;<label for="foto">Seleccione Foto del Familiar</label>										
										<input type="file" id="fotofamiliar" name="fotofamiliar" class="form-control">
									</div>
								</div> -->

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="nombresfamiliar" name="nombresfamiliar" placeholder="INGRESE NOMBRES DEL PARIENTE">
										<small>Error message</small>
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="apellidosfamiliar" name="apellidosfamiliar" placeholder="INGRESE APELLIDOS DEL PARIENTE">
										<small>Error message</small>
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<select class="form-select" id="sexofamiliar" name="sexofamiliar">
											<option selected disabled value="">Seleccione Sexo</option>
											<option value="femenino">Femenino</option>
											<option value="masculino">Masculino</option>
										</select>
										<small>Error message</small>
									</div>					 				
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input class="form-control" id="fechanacfamiliar" name="fechanacfamiliar" type="date">
										<small>Error message</small>
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="numtelefonofamiliar" name="numtelefonofamiliar" placeholder="Ingrese número telefonico Principal">
										<small>Error message</small>
									</div>					 				
								</div>

								<div class="row">					 				
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="numtelefono2familiar" name="numtelefono2familiar" placeholder="Ingrese número telefonico de habitación">
										<small>Error message</small>
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<select name="id_munfamiliar" id="id_mun" class="form-select">
											<option selected>Seleccione Municipio</option>
											<?php 

											require "../controlador/municipiosfetch.php";

											foreach ($municipio as $municipio) {
												echo '<option value="'.$municipio['CodigoMunicipio'].'">'.$municipio['NombreMunicipio'].'</option>';
											}

											?>
										</select>
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<select name="id_parrfamiliar" style="text-transform: uppercase;" id="id_parr" class="form-select">
											<option selected disabled value="">Seleccione Parroquia</option>
										</select>
										<script>
											document.querySelector('#id_mun').addEventListener('change', event => {
												console.log(event.target.value);
												fetch('../controlador/parroquiasfetch.php?id_mun='+event.target.value)
												.then(res => {
													if(!res.ok){
														throw new Error('error en la respuesta');
													}
													return res.json();	
												})
												.then(datos => {
													let html = '<option value="">Seleccione Parroquia</option>';
													if(datos.data.length > 0){
														for(let i = 0; i < datos.data.length; i++){
															html += `<option value="${datos.data[i].CodigoParroquia}">${datos.data[i].NombreParroquia}</option>`; 
														}
													}
													console.log(html);
													document.querySelector('#id_parr').innerHTML = html;
												})
												.catch(error => {
													console.error('ocurrio un error '+error);
												});	
											});
										</script>
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="sectorfamiliar" name="sectorfamiliar" placeholder="Ingrese Sector">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="direccionfamiliar" name="direccionfamiliar" placeholder="Ingrese Dirección">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-6 py-3">
										<input type="text" class="form-control" id="pesofamiliar" name="pesofamiliar" placeholder="Peso en kg">
									</div>
									<div class="col col-sm-6 py-3">
										<input type="text" class="form-control" id="estaturafamiliar" name="estaturafamiliar" placeholder="Estatura en En Mts">
									</div>
								</div>

								<div class="row">
									<div class="col-sm-12">
										<hr>
										<p class="text-center">Datos de Individuo</p>
										<hr>
									</div>
								</div>

								<div class="row">

									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" id="tallacamisafamiliar" name="tallacamisafamiliar" placeholder="Torso">
									</div>
									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" id="tallapantfamiliar" name="tallapantfamiliar" placeholder="Pantalón">
									</div>
									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" id="tallacalzafamiliar" name="tallacalzafamiliar" placeholder="Calzado">
									</div>
								</div>					 		

							</div>
							<div class="modal-footer">
								<button type="reset" class="btn btn-secondary" >Limpiar</button>
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
								<button type="submit" name="guardar" class="btn btn-primary">Guardar</button>

							</div>
						 </form>			
						</div>
					</div>
				</div>

				<!-- ///////////////////////////////////////////MODALREGISTROFAMILIAR/////////////////////////////////////////// -->




				<!-- ///////////////////////////////////////////////MODAL HSTORICO///////////////////////////////////////////// -->

				<div class="modal fade " id="registro-historico"  data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            		<div class="modal-dialog modal-dialog-centered modal-lg">
             			<div class="modal-content">
             						<form id="fomrcapturaridhis" method="post">

									<input type="hidden" id="idperhis" name="idperhis" value="">


								</form>
						 <form id="formregistrarhistorial" method="post">

						 	<input type="hidden"  name="idpersonahistorial" id="idpersonahistorial" value="" >
							<div>
						 		
						 	</div>
             				<div class="modal-header" style="background-color: #009aff;">
             					<h5 class="modal-title text-white" id="exampleModalLabel">Nuevo Registro Historico</h5>
             					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="z-index: 8;"></button>
             				</div>

             				<div class="modal-body">
             					
             					<div class="row py-3" style="margin-top: -10%; position: relative; top: -17px;">

             						<div class="col col-sm-3">
									     <div class="wrapper" style="position: relative;">
									     	<label class="form-label">Institucion</label>
									      <div class="select-btn">
									        <span class="form-select" id="institucionhistorico" name="institucionhistorico" data-value="">Seleccione</span>
									       
									      </div>
									      <input type="hidden" id="hiddenInput" name="institucionhistorico">
											<div class="content" id="contentlista" style="position: absolute; top: 85%; z-index: 1;">
											    <div class="search" style="margin-top: -9%;">
											        <img src="../icons/magnifying-glass-solid.svg" style="position: relative; transform: translate(50%, 178%); width: 7%;">
											        <input spellcheck="false" type="text" placeholder="Buscar">
											    </div>
											    <ul class="options" ></ul>
											</div>
										 </div>
										
             						</div>

             						<div class="col col-sm-3" style="margin: auto;">

             							<button type="button" class="btn btn-primary" style="margin-top: 35%; margin-left: 10%;" id="myBtn2">Añadir Institucion</button>



             						</div>


             					</div>

             					<div class="row py-1">

             						<div class="col col-sm-3" style="margin-left: 0%; width: 42%;">
             							<label for="cargo" class="form-label">Cargo</label>
             							<select class="form-select" id="cargohistorico" name="cargohistorico" aria-label="Seleccione">
             								<option selected disabled value="">Seleccione</option>
             							<?php 

											require "../controlador/cargosfetch.php";

											foreach ($cargos as $i) {
												echo '<option value="'.$i['CodigoCargo'].'">'.$i['NombreCargo'].'</option>';
											}

											?>
             							</select>
										<small>Error message</small>
             						</div>

             					</div>

             					<div class="row py-3">
             						<div class="col col-sm-6">
             							<label for="numerodocumentohistorico" class="form-label">Numero de Documento</label>
             							<input type="text" class="form-control" id="numerodocumentohistorico" name="numerodocumentohistorico">
										<small>Error message</small>
             						</div>

             						<div class="col col-sm-6">
             							<label for="tipodocumentohistorico" class="form-label">Tipo de Documento</label>
             							<input type="text" class="form-control" id="tipodocumentohistorico" name="tipodocumentohistorico" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Ingrese solo el tipo de Documento">
										<small>Error message</small>
             						</div>
             					</div>

             					<div class="row py-3">
             						<div class="col col-sm-6">
             							<label for="fecha-inicio" class="form-label">Fecha de Inicio</label>
             							<input type="date" class="form-control" id="fecha-iniciohistorial" name="fecha-iniciohistorial">
										 <small>Error message</small>
             						</div>
             						<div class="col col-sm-6">
             							<label for="fecha-culminacion" class="form-label">Fecha de Culminación</label>
             							<input type="date" class="form-control" id="fecha-culminacionhistorial" name="fecha-culminacionhistorial">
             						</div>
             					</div>

             					<div class="row py-3">
             						<div class="col col-sm-12">
             							<label for="observacion" class="form-label">Observación</label>
             							<input type="text" class="form-control form-control-lg" id="observacionhistorico" name="observacionhistorico">
             						</div>
             					</div>

             				</div> 

             				<div class="modal-footer">
             					<button type="reset" class="btn btn-secondary" onclick="limpiarmodalhistorico();">Limpiar</button>
             					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
             					<button type="submit" class="btn btn-primary">Guardar</button>
             				</div>  
							</form>
             			</div>            			
            		</div>

            		 <!--modal registrar institucion-->

						<div class="container border rounded py-3 bg-white rounded-3 shadow modal2 " tabindex="-2" id="myModal2" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px; padding: 41px;">

							<span class="close2" id="close2">&times;</span>
							<!--<<button id="close2" type="button" onclick="cerrarmodalinsitucion();">cerrar</button>-->

							<div class="row mb-4 mt-2"> 
								<h4 class="text-center">Registro de Institución</h4>
							</div>

							<form id="formulariogeistroinstitucionhistorico"  novalidate>

								<div class="row" id="salida"></div>

								<div class="row py-3">

									<div class="col col-sm-3 d-flex justify-content-end align-items-center">
										<p class="m-0">Nombre de la Institución</p>
									</div>

									<div class="col col-sm-9">
										<input type="text" name="nombreinstitucion" id="nombreinstitucion" class="form-control" placeholder="Nombre de la Institución" aria-label="Nombre de la Institución" aria-describedby="basic-addon1" >
										 <small>Error message</small>
									</div>

								</div>

								<div class="row mb-4 align-baseline">

									<div class="col col-sm-3 d-flex justify-content-end align-items-center">
										<p class="m-0">Municipio</p>
									</div>

									<div class="col col-sm-9">
										<select class="form-select" name="id_munH" id="id_munH" aria-label="Default select example" >
											<option selected disabled value="">Seleccione Municipio</option>
											<?php 

											require "../controlador/municipiosfetchhistorico.php";

											foreach ($municipiointhistorico as $municipio) {
												echo '<option value="'.$municipio['CodigoMunicipio'].'">'.$municipio['NombreMunicipio'].'</option>';
												}
											?>
										</select>
										<small>Error message</small>
									</div>

								</div>

								<div class="row mb-4 align-baseline">

									<div class="col col-sm-3 d-flex justify-content-end align-items-center">
										<p class="m-0">Parroquia</p>
									</div>

									<div class="col col-sm-9">
										<select class="form-select" name="parroquiareg" id="parroquiareg" aria-label="Default select example" >
											
											
										</select>
										<small>Error message</small>
									</div>
									<script>
										document.querySelector('#id_munH').addEventListener('change', event => {
											console.log(event.target.value);
											fetch('../controlador/parroquiasfetchhistorico.php?id_munH='+event.target.value)
											.then(res => {
												if(!res.ok){
													throw new Error('error en la respuesta');
												}
												return res.json();
											})
											.then(datos => {
												let html = '<option value="">Seleccione Parroquia</option>';
												if(datos.data.length > 0){
													for(let i = 0; i < datos.data.length; i++){
														html += `<option value="${datos.data[i].CodigoParroquia}">${datos.data[i].NombreParroquia}</option>`; 
													}
												}
												document.querySelector('#parroquiareg').innerHTML = html;
											})
											.catch(error => {
												console.error('ocurrio un error '+error);
											});	
										});
									</script>

								</div>



								<div class="row mb-4 align-baseline">

									<div class="col col-sm-3 d-flex justify-content-end align-items-center">
										<p class="m-0 ">Sector</p>
									</div>

									<div class="col col-sm-9">
										<input type="text" name="sectorinstitucion" id="sectorinstitucion" class="form-control" placeholder="Sector de la Institución" aria-label="Sector de la Institución" aria-describedby="basic-addon1" >
										<small>Error message</small>
									</div>

								</div>

								<div class="row mb-4 align-baseline">

									<div class="col col-sm-3 d-flex justify-content-end align-items-center">
										<p class="m-0 ">Dirección</p>
									</div>

									<div class="col col-sm-9">
										<input type="text" name="direccioninstitucion" id="direccioninstitucion" class="form-control" placeholder="Ingrese la Dirección" aria-label="Ingrese la Dirección" aria-describedby="basic-addon1" >
										<small>Error message</small>
									</div>

								</div>

								<div class="row mb-4">
									<div class="col col-sm-6 d-flex justify-content-end">
										<button class="btn btn-secondary" type="reset" onclick="limpiarformureginsti()">Limpiar</button>
									</div>
									<div class="col col-sm-6">
										<button class="btn btn-primary ml" type="submit">Registrar Institución</button>  					
									</div>
								</div>

							</form>					

						</div>

             							<!--modal registrar institucion -->

				</div>


				<!-- ///////////////////////////////////////////////MODAL HISTORICO/////////////////////////////////////////////// -->

				<!-- ///////////////////////////////////////////////MODAL EDITAR HSTORICO///////////////////////////////////////////// -->

				<div class="modal fade " id="modal-editar-historial" tabindex="-1" aria-hidden="true">
            		<div class="modal-dialog modal-dialog-centered modal-lg">
             			<div class="modal-content">

						<form id="formeditarhistorial" method="post">

						 	<input type="hidden"  name="idpersonahistorialedit" id="idpersonahistorialedit" value="" >

							<input type="hidden"  name="idhistoricoedit" id="idhistoricoedit" value="" >

							<div>
						 		
						 	</div>
             				<div class="modal-header" style="background-color: #009aff;">
             					<h5 class="modal-title text-white" id="exampleModalLabel">Editar Registro Historico</h5>
             					<button type="button" class="btn-close" data-bs-dismiss="modal" style="z-index: 8;" aria-label="Close"></button>
             				</div>

             				<div class="modal-body">
             					
             					<div class="row py-3"  style="margin-top: -10%; position: relative; top: -17px;">
             						<div class="col col-sm-3">

		             					<div class="wrappereditar" style="position: relative;">
											     	<label class="form-label">Institucion</label>
											      <div class="select-btneditar">
											        <span class="form-select" id="institucionhistoricoeditar" name="institucionhistoricoeditar" data-value="">Seleccione</span>
											       
											      </div>
											      <input type="hidden" id="hiddenInputeditar" name="nombremodificarinstitucion">
													<div class="contenteditar" id="contentlistaeditar" style="position: absolute; top: 85%; z-index: 1;">
													    <div class="searcheditar" style="margin-top: -9%;">
													        <img src="../icons/magnifying-glass-solid.svg" style="position: relative; transform: translate(50%, 178%); width: 7%;">
													        <input spellcheck="false" type="text" placeholder="Buscar">
													    </div>
													    <ul class="optionseditar" ></ul>
													</div>
												 </div>

             						</div>
             						
             						<div class="col col-sm-3" style="margin: auto;">

             							<button type="button" class="btn btn-primary" style="margin-top: 67%; margin-left: -39%;" id="myBtn2editar">Añadir Institucion</button>

             						</div>

             					</div>

             					<div class="row py-1">
             							
             						  <div class="col col-sm-3" style="margin-left: 0%; width: 42%;">
             							<label for="cargo" class="form-label">Cargo</label>
             							<select class="form-select" id="cargohistoricoedit" name="cargohistoricoedit" aria-label="Seleccione">
             								<option selected disabled value="">Seleccione</option>
             							<?php 

											require "../controlador/cargosfetch.php";

											foreach ($cargos as $i) {
												echo '<option value="'.$i['CodigoCargo'].'">'.$i['NombreCargo'].'</option>';
											}

											?>
             							</select>
										 <small>Error message</small>
             						</div>

             					</div>

             					<div class="row py-3">
             						<div class="col col-sm-6">
             							<label for="numerodocumentohistorico" class="form-label">Numero de Documento</label>
             							<input type="text" class="form-control" id="numerodocumentohistoricoeditar" name="numerodocumentohistoricoeditar">
										<small>Error message</small>
             						</div>

             						<div class="col col-sm-6">
             							<label for="tipodocumentohistorico" class="form-label">Tipo de Documento</label>
             							<input type="text" class="form-control" id="tipodocumentohistoricoeditar" name="tipodocumentohistoricoeditar" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Ingrese solo el tipo de Documento">
										<small>Error message</small>
             						</div>
             					</div>

             					<div class="row py-3">
             						<div class="col col-sm-6">
             							<label for="fecha-inicio" class="form-label">Fecha de Inicio</label>
             							<input type="date" class="form-control" id="fecha-iniciohistorialedit" name="fecha-iniciohistorialedit">
										 <small>Error message</small>
             						</div>
             						<div class="col col-sm-6">
             							<label for="fecha-culminacion" class="form-label">Fecha de Culminación</label>
             							<input type="date" class="form-control" id="fecha-culminacionhistorialedit" name="fecha-culminacionhistorialedit">
										 
             						</div>
             					</div>

             					<div class="row py-3">
             						<div class="col col-sm-12">
             							<label for="observacion" class="form-label">Observación</label>
             							<input type="text" class="form-control form-control-lg" id="observacionhistoricoedit" name="observacionhistoricoedit" value="">
             						</div>
             					</div>

             				</div> 

             				<div class="modal-footer">
             					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
             					<button type="submit" class="btn btn-primary">Guardar</button>
             				</div>  
							</form>
             			</div>            			
            		</div>

            		<!--modal registrar institucion-->

						<div class="container border rounded py-3 bg-white rounded-3 shadow modal2 " tabindex="-2" id="myModal2editar" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px; padding: 41px;">

							<span class="close2editar" id="close2editar">&times;</span>
							<!--<<button id="close2" type="button" onclick="cerrarmodalinsitucion();">cerrar</button>-->

							<div class="row mb-4 mt-2"> 
								<h4 class="text-center">Registro de Institución</h4>
							</div>

							<form id="formulariogeistroinstitucionhistoricoeditar"  novalidate>

								<div class="row" id="salida"></div>

								<div class="row py-3">

									<div class="col col-sm-3 d-flex justify-content-end align-items-center">
										<p class="m-0">Nombre de la Institución</p>
									</div>

									<div class="col col-sm-9">
										<input type="text" name="nombreinstitucion" id="nombreinstitucion" class="form-control" placeholder="Nombre de la Institución" aria-label="Nombre de la Institución" aria-describedby="basic-addon1" >
										 <small>Error message</small>
									</div>

								</div>

								<div class="row mb-4 align-baseline">

									<div class="col col-sm-3 d-flex justify-content-end align-items-center">
										<p class="m-0">Municipio</p>
									</div>

									<div class="col col-sm-9">
										<select class="form-select" name="id_munHeditar" id="id_munHeditar" aria-label="Default select example" >
											<option selected disabled value="">Seleccione Municipio</option>
											<?php 

											require "../controlador/municipiosfetchhistorico.php";

											foreach ($municipiointhistorico as $municipio) {
												echo '<option value="'.$municipio['CodigoMunicipio'].'">'.$municipio['NombreMunicipio'].'</option>';
												}
											?>
										</select>
										<small>Error message</small>
									</div>

								</div>

								<div class="row mb-4 align-baseline">

									<div class="col col-sm-3 d-flex justify-content-end align-items-center">
										<p class="m-0">Parroquia</p>
									</div>

									<div class="col col-sm-9">
										<select class="form-select" name="parroquiaregeditar" id="parroquiaregeditar" aria-label="Default select example" >
											
											
										</select>
										<small>Error message</small>
									</div>
									<script>
										document.querySelector('#id_munHeditar').addEventListener('change', event => {
											console.log(event.target.value);
											fetch('../controlador/parroquiasfetchhhistoricoeditar.php?id_munHeditar='+event.target.value)
											.then(res => {
												if(!res.ok){
													throw new Error('error en la respuesta');
												}
												return res.json();
											})
											.then(datos => {
												let html = '<option value="">Seleccione Parroquia</option>';
												if(datos.data.length > 0){
													for(let i = 0; i < datos.data.length; i++){
														html += `<option value="${datos.data[i].CodigoParroquia}">${datos.data[i].NombreParroquia}</option>`; 
													}
												}
												document.querySelector('#parroquiaregeditar').innerHTML = html;
											})
											.catch(error => {
												console.error('ocurrio un error '+error);
											});	
										});
									</script>

								</div>



								<div class="row mb-4 align-baseline">

									<div class="col col-sm-3 d-flex justify-content-end align-items-center">
										<p class="m-0 ">Sector</p>
									</div>

									<div class="col col-sm-9">
										<input type="text" name="sectorinstitucion" id="sectorinstitucion" class="form-control" placeholder="Sector de la Institución" aria-label="Sector de la Institución" aria-describedby="basic-addon1" >
										<small>Error message</small>
									</div>

								</div>

								<div class="row mb-4 align-baseline">

									<div class="col col-sm-3 d-flex justify-content-end align-items-center">
										<p class="m-0 ">Dirección</p>
									</div>

									<div class="col col-sm-9">
										<input type="text" name="direccioninstitucion" id="direccioninstitucion" class="form-control" placeholder="Ingrese la Dirección" aria-label="Ingrese la Dirección" aria-describedby="basic-addon1" >
										<small>Error message</small>
									</div>

								</div>

								<div class="row mb-4">
									<div class="col col-sm-6 d-flex justify-content-end">
										<button class="btn btn-secondary" type="reset" onclick="limpiarformureginsti()">Limpiar</button>
									</div>
									<div class="col col-sm-6">
										<button class="btn btn-primary ml" type="submit">Registrar Institución</button>  					
									</div>
								</div>

							</form>					

						</div>

             							<!--modal registrar institucion -->
				</div>


				<!-- ///////////////////////////////////////////////MODAL EDITAR HISTORICO/////////////////////////////////////////////// -->

				<!-- ///////////////////////////////////////////////MODAL VER HSTORICO///////////////////////////////////////////// -->

				<div class="modal fade " id="modal-verdatos-historico" tabindex="-1" aria-hidden="true">
            		<div class="modal-dialog modal-dialog-centered modal-lg">
             			<div class="modal-content">
							<div>
						 		
						 	</div>
             				<div class="modal-header" style="background-color: #009aff;">
             					<h5 class="modal-title text-white" id="exampleModalLabel">Nuevo Registro Historico</h5>
             					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
             				</div>

             				<div class="modal-body">
             					
             					<div class="row py-3">
             						<div class="col col-sm-6">
             							<label for="institucion" class="form-label">Institución</label>
             							<select class="form-select" disabled id="institucionhistoricover" name="institucionhistoricover" aria-label="Seleccione">
             								<option selected disabled>Seleccione</option>
										<?php 

											require "../controlador/institucionesfetch.php";

											foreach ($instituciones as $i) {
												echo '<option value="'.$i['CodigoInstituciones'].'">'.$i['NombreInstitucion'].'</option>';
											}

											?>
             							</select>
             						</div>

             						<div class="col col-sm-6">
             							<label for="cargo" class="form-label">Cargo</label>
             							<select class="form-select" disabled id="cargohistoricover" name="cargohistoricover" aria-label="Seleccione">
             								<option selected disabled>Seleccione</option>
             							<?php 

											require "../controlador/cargosfetch.php";

											foreach ($cargos as $i) {
												echo '<option value="'.$i['CodigoCargo'].'">'.$i['NombreCargo'].'</option>';
											}

											?>
             							</select>
             						</div>
             					</div>

             					<div class="row py-3">
             						<div class="col col-sm-6">
             							<label for="fecha-inicio" class="form-label">Fecha de Inicio</label>
             							<input type="date" disabled class="form-control" id="fecha-iniciohistorialver" name="fecha-iniciohistorialver">
             						</div>
             						<div class="col col-sm-6">
             							<label for="fecha-culminacion" class="form-label">Fecha de Culminación</label>
             							<input type="date" disabled class="form-control" id="fecha-culminacionhistorialver" name="fecha-culminacionhistorialver">
             						</div>
             					</div>

             					<div class="row py-3">
             						<div class="col col-sm-12">
             							<label for="observacion" class="form-label">Observación</label>
             							<input type="text" disabled class="form-control form-control-lg" id="observacionhistoricover" name="observacionhistoricover">
             						</div>
             					</div>

             				</div> 

             				<div class="modal-footer">
             					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
             					<button type="submit" class="btn btn-primary">Guardar</button>
             				</div>  
							
             			</div>            			
            		</div>
				</div>


				<!-- ///////////////////////////////////////////////MODAL VER HISTORICO/////////////////////////////////////////////// -->



				<!--////////////////////////////////////////////// MODAL DOCUMENTOS //////////////////////////////////////////////-->

				<div class="modal fade" id="modal-registrar-documentos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-md">
						<div class="modal-content">
								<form id="fomrcapturariddoc" method="post">

									<input type="hidden" id="idperdoc" name="idperdoc" value="">


								</form>
							<form id="formregistrardocumentos" method="post" >

								<input type="hidden" id="idpersonadoc" name="idpersonadoc" value="">

							<div class="modal-header" style="background-color:#009aff; ">
								<h5 class="modal-title text-white" id="exampleModalLabel">Registro de Documento</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
							</div>

							<div class="modal-body">
								<div class="row py-4">


									<div class="col col-sm-12">

										<select class="form-select" aria-label="Default select example" id="iddocumento" name="iddocumento">
											<option selected disabled value="">Seleccione un Documento</option>
											<script type="text/javascript">
												fetch('../controlador/documentosfetch.php')
												.then(response => response.json())
												.then(documento => {
													var select = document.getElementById('iddocumento');
													documento.forEach(function(documentooption) {
														var option = document.createElement('option');
														option.value = documentooption.CodigoDocumento;
														option.text = documentooption.NombreDocumento;
														select.add(option);
													});

													var lastValue = select.value;



												})
												.catch(error => console.error('Error:', error));
											</script>
										</select>
									</div>

								</div>
								<div class="row py-4">
									<div class="col col-sm-12">

										<div class="">
											<input class="form-control" type="file" id="archivojpg" name="archivojpg">
										</div>

									</div>
								</div>

							</div>

							<div class="modal-footer">
								<!--<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>-->
								<button type="reset" class="btn btn-secondary" >Limpiar</button>
								<button type="submit" class="btn btn-primary">Guardar</button>
							</div>
							</form>
						</div>						
					</div>
				</div>
				<!--////////////////////////////////////////////// MODAL DOCUMENTOS //////////////////////////////////////////////-->

				<!--///////////////////////////////////////////// MODAL EDITAR DATOS FAMILIAR /////////////////////////////////////-->

				<div class="modal fade" id="modal-editar-familiar" tabindex="-1" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered modal-md">
						<div class="modal-content">

						<form id="formregistrarfamiliareditar" method="post">

						<input type="hidden"  name="idpersonafamiliareditar" id="idpersonafamiliareditar" value="" >
							<input type="hidden"  name="idpersonafamiedit" id="idpersonafamiedit" value="" >

							<input type="hidden" name="tipopersonafamiliareditar" id="tipopersonafamiliareditar" value="familiar">
							<input type="hidden" name="estatusfamiliareditar" id="estatusfamiliareditar" value="inactivo">

							<div class="modal-header" style="background-color: #009aff;">
								<h5 class="modal-title text-white" id="exampleModalLabel">Registrar Familiar</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
							</div>

							<div class="modal-body">

								<div class="row">

									<div class="col col-md-12 py-1">
										<div class="form-check d-flex justify-content-center">
											<input type="hidden" name="checkboxfamiliareditar" value="no">
											<input class="form-check-input" type="checkbox" value="si" id="checkboxfamiliareditar" name="checkboxfamiliareditar">
											<label class="form-check-label" for="flexCheckDefault">
												&nbsp;&nbsp;&nbsp;No posee Cédula
											</label>
										</div>
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="number" class="form-control" id="cedulafamiliareditar" name="cedulafamiliareditar" placeholder="INGRESE CEDULA DE IDENTIDAD">
										<small>Error message</small>
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="number" class="form-control" id="regpartidafamiliareditar" name="regpartidafamiliareditar" disabled placeholder="INGRESE REGISTRO DE PARTIDA DE NACIMIENTO">
										<small>Error message</small>
									</div>
								</div>

								<div class="row">
									<div class="col-sm-12 py-3">										
										<select class="form-select" id="parentescofamiliareditar" name="parentescofamiliareditar">
											<option selected disabled="">Seleccione Parentesco</option>
											<option value="Hijo">Hijo</option>
											<option value="Hija">Hija</option>
											<option value="Padre">Padre</option>
											<option value="Madre">Madre</option>
											<option value="Esposa">Esposa</option>
											<option value="Esposo">Esposo</option>
											<option value="Abuelo">Abuelo</option>
											<option value="Abuela">Abuela</option>
											<option value="Nieto">Nieto</option>
											<option value="Nieta">Nieta</option>
											<option value="Sobrino">Sobrino</option>
											<option value="Sobrina">Sobrina</option>
											<option value="Hermano">Hermano</option>
											<option value="Hermana">Hermana</option>
										</select>
										<small>Error message</small>
									</div>
								</div>

								<!--<div class="row">
									<div class="col-sm-12 py-3">
									&nbsp;&nbsp;&nbsp;<label for="foto">Seleccione Foto del Familiar</label>										
										<input type="file" id="fotofamiliar" name="fotofamiliar" class="form-control">
									</div>
								</div>-->

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="nombresfamiliareditar" name="nombresfamiliareditar" placeholder="INGRESE NOMBRES DEL PARIENTE">
										<small>Error message</small>
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="apellidosfamiliareditar" name="apellidosfamiliareditar" placeholder="INGRESE APELLIDOS DEL PARIENTE">
										<small>Error message</small>
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<select class="form-select" id="sexofamiliareditar" name="sexofamiliareditar">
											<option selected disabled="">Seleccione Sexo</option>
											<option value="femenino">Femenino</option>
											<option value="masculino">Masculino</option>
										</select>
										<small>Error message</small>
									</div>					 				
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input class="form-control" id="fechanacfamiliareditar" name="fechanacfamiliareditar" type="date">
										<small>Error message</small>
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="numtelefonofamiliareditar" name="numtelefonofamiliareditar" placeholder="Ingrese número telefonico Principal">
										<small>Error message</small>
									</div>					 				
								</div>

								<div class="row">					 				
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="numtelefono2familiareditar" name="numtelefono2familiareditar" placeholder="Ingrese número telefonico de habitación">
										<small>Error message</small>
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<select name="idmunicipiofamiliar" id="idmunicipiofamiliar" class="form-select">

										</select>
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<select name="idparroquiafamiliar" style="text-transform: uppercase;" id="idparroquiafamiliar" class="form-select">
											
										</select>
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="sectorfamiliareditar" name="sectorfamiliareditar" placeholder="Ingrese Sector">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="direccionfamiliareditar" name="direccionfamiliareditar" placeholder="Ingrese Dirección">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-6 py-3">
										<input type="text" class="form-control" id="pesofamiliareditar" name="pesofamiliareditar" placeholder="Peso en kg">
									</div>
									<div class="col col-sm-6 py-3">
										<input type="text" class="form-control" id="estaturafamiliareditar" name="estaturafamiliareditar" placeholder="Estatura en En Mts">
									</div>
								</div>

								<div class="row">
									<div class="col-sm-12">
										<hr>
										<p class="text-center">Datos de Individuo</p>
										<hr>
									</div>
								</div>

								<div class="row">

									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" id="tallacamisafamiliareditar" name="tallacamisafamiliareditar" placeholder="Torso">
									</div>
									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" id="tallapantfamiliareditar" name="tallapantfamiliareditar" placeholder="Pantalón">
									</div>
									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" id="tallacalzafamiliareditar" name="tallacalzafamiliareditar" placeholder="Calzado">
									</div>
								</div>					 		

							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
								<button type="submit" name="guardar" class="btn btn-primary">Guardar</button>

							</div>
						 </form>			
						</div>
					</div>
				</div>

			<!--///////////////////////////////////////////// MODAL EDITAR DATOS FAMILIAR /////////////////////////////////////-->

			<!--///////////////////////////////////////////// MODAL VER DATOS FAMILIAR /////////////////////////////////////-->

			<div class="modal fade" id="modal-verdatos-familiar" tabindex="-1" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered modal-md">
						<div class="modal-content">

					
							<div class="modal-header" style="background-color: #009aff;">
								<h5 class="modal-title text-white" id="exampleModalLabel">Registrar Familiar</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
							</div>

							<div class="modal-body">

								<div class="row">

									<div class="col col-md-12 py-1">
										<div class="form-check d-flex justify-content-center">
											<input class="form-check-input" type="checkbox" value="" id="checkboxfamiliareditar">
											<label class="form-check-label" for="flexCheckDefault">
												&nbsp;&nbsp;&nbsp;No posee Cédula
											</label>
										</div>
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="number" disabled class="form-control" id="cedulafamiliarver" name="cedulafamiliarver" placeholder="CEDULA DE IDENTIDAD" >
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="number" class="form-control" disabled id="regpartidafamiliarver" name="regpartidafamiliarver" disabled placeholder="REGISTRO DE PARTIDA DE NACIMIENTO">
									</div>
								</div>

								<div class="row">
									<div class="col-sm-12 py-3">										
										<select class="form-select" disabled id="parentescofamiliarver" name="parentescofamiliarver">
											<option selected disabled="">Seleccione Parentesco</option>
											<option value="Hijo">Hijo</option>
											<option value="Hija">Hija</option>
											<option value="Padre">Padre</option>
											<option value="Madre">Madre</option>
											<option value="Esposa">Esposa</option>
											<option value="Esposo">Esposo</option>
											<option value="Abuelo">Abuelo</option>
											<option value="Abuela">Abuela</option>
											<option value="Nieto">Nieto</option>
											<option value="Nieta">Nieta</option>
											<option value="Sobrino">Sobrino</option>
											<option value="Sobrina">Sobrina</option>
											<option value="Hermano">Hermano</option>
											<option value="Hermana">Hermana</option>
										</select>
									</div>
								</div>

								<!--<div class="row">
									<div class="col-sm-12 py-3">
									&nbsp;&nbsp;&nbsp;<label for="foto">Seleccione Foto del Familiar</label>										
										<input type="file" id="fotofamiliar" name="fotofamiliar" class="form-control">
									</div>
								</div>-->

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" disabled id="nombresfamiliarver" name="nombresfamiliarver" placeholder="INGRESE NOMBRES DEL PARIENTE">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" disabled id="apellidosfamiliarver" name="apellidosfamiliarver" placeholder="INGRESE APELLIDOS DEL PARIENTE">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<select class="form-select" disabled id="sexofamiliarver" name="sexofamiliarver">
											<option selected disabled="">Seleccione Sexo</option>
											<option value="femenino">Femenino</option>
											<option value="masculino">Masculino</option>
										</select>
									</div>					 				
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input class="form-control" disabled id="fechanacfamiliarver" name="fechanacfamiliarver" type="date">
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" disabled id="numtelefonofamiliarver" name="numtelefonofamiliarver" placeholder="Ingrese número telefonico Principal">
									</div>					 				
								</div>

								<div class="row">					 				
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" disabled id="numtelefono2familiarver" name="numtelefono2familiarver" placeholder="Ingrese número telefonico de habitación">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
									<label for="">Municipio</label>
 									<input type="text" name="municipio-ver-familiar" id="municipio-ver-familiar" class="form-select" disabled>	
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
									<label for="">Parroquia</label>
									<input type="text" name="parroquia-ver-familiar" id="parroquia-ver-familiar" class="form-select" disabled>	
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" disabled id="sectorfamiliarver" name="sectorfamiliarver" placeholder="Ingrese Sector">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" disabled id="direccionfamiliarver" name="direccionfamiliarver" placeholder="Ingrese Dirección">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-6 py-3">
										<input type="text" class="form-control" disabled id="pesofamiliarver" name="pesofamiliarver" placeholder="Peso en kg">
									</div>
									<div class="col col-sm-6 py-3">
										<input type="text" class="form-control" disabled id="estaturafamiliarver" name="estaturafamiliarver" placeholder="Estatura en En Mts">
									</div>
								</div>

								<div class="row">
									<div class="col-sm-12">
										<hr>
										<p class="text-center">Datos de Individuo</p>
										<hr>
									</div>
								</div>

								<div class="row">

									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" disabled id="tallacamisafamiliarver" name="tallacamisafamiliarver" placeholder="Torso">
									</div>
									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" disabled id="tallapantfamiliarver" name="tallapantfamiliarver" placeholder="Pantalón">
									</div>
									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" disabled id="tallacalzafamiliarver" name="tallacalzafamiliarver" placeholder="Calzado">
									</div>
								</div>					 		

							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
								

							</div>
						 			
						</div>
					</div>
				</div>

			<!--///////////////////////////////////////////// MODAL VER DATOS FAMILIAR /////////////////////////////////////-->

			<!--/////////////////// modal zoom imagen documento//////////////////////////////////-->
				
			<div class="modal fade" id="modalverimagendocumento" data-bs-backdrop="static" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content" >
      <div class="modal-header" >
        <h5 class="modal-title" id="exampleModalLabel">Documento</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" style="overflow-x: auto; overflow-y: auto; width: 1131px; height: 588px; max-width: 98.9%;">
	  <div >
	  <img id="imagendocumento" src="" >
	  </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

			<!--/////////////////// modal zoom imagen documento//////////////////////////////////-->

			<!--/////////////////// modal ver pdf documento//////////////////////////////////-->
				
<div class="modal fade" id="modalverpdfdocumento" data-bs-backdrop="static" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content" >
      <div class="modal-header" >
        <h5 class="modal-title" id="exampleModalLabel">Documento en PDF</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" style="overflow-x: auto; overflow-y: auto; width: 1131px; height: 588px; max-width: 98.9%;">
	  
	  <div>
	  
			<iframe id="iframerepostespdf" width="100%" height="548"></iframe>
			<!--<embed id="iframerepostespdf" width="100%" height="500">-->

	  </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

			<!--/////////////////// modal ver pdf documento//////////////////////////////////-->

			       




		</div>

	<script type="text/javascript">
	var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
		var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
		return new bootstrap.Tooltip(tooltipTriggerEl)
	})
	</script>



	<script src="../js/mostrar-datos-personal.js"></script>
	<script src="../js/editar-datos-personal.js"></script>
	<script src="../js/vermunicipioparroquiaperson.js"></script>
	<script src="../js/vermunicipiosparroquiasfamiliar.js"></script>
	<script src="../js/documentos-registro.js"></script>
	<script src="../js/jquery.min.js"></script>
 	<script src="../librerias/wall.js"></script>
	<script src="../js/familiar-registro.js"></script>
	<script src="../js/capid-familiar.js"></script>
	<script src="../js/capid-historial.js"></script>
	<script src="../js/historial-registro.js"></script>
	<script src="../js/modificar-historial.js"></script>
	<script src="../js/modificar-familiar.js"></script>
	<script src="../js/selectsmenushistorico.js"></script>
	<script src="../js/registroinstitucionhistorico.js"></script>
 	<script src="../js/validar-registro-institucion.js"></script>
	<script src="../js/registroinstitucionhistoricoeditar.js"></script>
  <script src="../js/selectsmenushistoricoeditar.js"></script>
	
 	<!--<script src="../js/documentos-mostrar.js"></script>-->
	


	</body>
	</html>