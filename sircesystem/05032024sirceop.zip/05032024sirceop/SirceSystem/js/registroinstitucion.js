let formulario = document.querySelector("#formulariogeistroinstitucion");
formulario.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formulariogeistroinstitucion"));

	    //validar campos vacios
    if (camposVaciosInsitucionRegistro(datos)) {
		//console.log('Hay campos vacíos');
		return;
	}

	let url = "../controlador/ctlr-reg-instituciones.php?op=guardar";

		fetch(url, {
			method: "post",
			body: datos,
		})
			.then((data) => data.json())
			.then((data) => {	
				//console.log(`Success: ${JSON.stringify(data)}`);

				var status = data.status;
        		var datos = data.data;

        switch (status){
        case 'institucion_ya_existe':

        	let nombreinsti = document.getElementById('nombreinstitucion');
			setErrorFor(nombreinsti, 'Este Nombre ya Existe');

            swal.fire({
                title: "¡Este Nombre de Usuario Ya Existe!",
                icon: "error",
            });
            break;

        case 'institucion_registro_exitoso':
 			
    		let mensajes = document.querySelectorAll("div");
			mensajes.forEach((div) => {
			div.classList.remove('errorinput');	
			div.classList.remove('successinput');
			});

			localStorage.removeItem("nombreinsti");
			localStorage.removeItem("codinstiyaexiste");

			listarinstituciones();
			formulario.reset();
			swal.fire({
			title: "¡Registro Exitoso!",
			icon: "success",
			});

            break;
        }


			})
			.catch((error) => console.log(`error: ${error}`));
	
});

function camposVaciosInsitucionRegistro(datos) {

	let nombreinstitucion = datos.get("nombreinstitucion").trim();
	
	const id_mun = document.getElementById('id_mun');
	const id_munValue = id_mun.value.trim();
	const parroquiareg = document.getElementById('parroquiareg');
	const parroquiaregValue = parroquiareg.value.trim();
	let sectorinstitucion = datos.get("sectorinstitucion").trim();
	let direccioninstitucion = datos.get("direccioninstitucion").trim();
	let sinErrores ;

	let nombreinsti = document.getElementById('nombreinstitucion');
	
	let sectorinsti = document.getElementById('sectorinstitucion');
	let direccioninsti = document.getElementById('direccioninstitucion');

	let nombreinstivalue = nombreinsti.value;

	let hayCamposVacios = false;

	if (nombreinstitucion == "") {
		setErrorFor(nombreinsti, 'Ingrese el Nombre de la Institucion');

		 hayCamposVacios = true;
	} else {
		setSuccessFor(nombreinsti);
	}
	
	if (id_munValue == "") {
		setErrorFor(id_mun, 'Ingrese el Municipio de la Institucion');

		 hayCamposVacios = true;
	} else {
		setSuccessFor(id_mun);
	}

	if (parroquiaregValue == "") {
		setErrorFor(parroquiareg, 'Ingrese la Parroquia de la Institucion');

		 hayCamposVacios = true;
	} else {
		setSuccessFor(parroquiareg);
	}

    

    return hayCamposVacios;
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.classList.add('errorinput'); // Agrega la clase 'errorinput'
	small.innerText = message;
  }
  
  function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.classList.remove('errorinput');
	formControl.classList.add('successinput');
  
  }