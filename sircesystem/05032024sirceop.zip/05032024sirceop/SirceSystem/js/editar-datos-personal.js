function camposVaciosmodificarpersona(datos) {
    let cedula = datos.get("editCi");
    let estadocivil = datos.get("editestadocivil");
    let nombres = datos.get("editName");
    let apellidos = datos.get("editApellidos");
    let fechanacimiento = datos.get("editFechanacimiento");
    let sexo = datos.get("editsexo");
    let telefonoprincipal = datos.get("editTelefonoPrincipal");
    let telefonohabitacion = datos.get("editTelefonoHabitacion");

    
    let cedulapersonainput = document.getElementById('CedulaPersona');
    let estadocivilpersonainput = document.getElementById('estadocivilpersona');
    let nombrespersonainput = document.getElementById('Nombrespersona');
    let apellidospersonainput = document.getElementById('Apellidospersona');
    let fechanacimientopersonainput = document.getElementById('FechaNacimientopersona');
    let sexopersonainput = document.getElementById('sexopersona');
    let telefonoprincipalpersonainput = document.getElementById('TelefonoPrincipalpersona');
    let telefonohabitacionpersonainput = document.getElementById('TelefonoHabitacionpersona');


    const estadocivilvalue = estadocivilpersonainput.value.trim();
    const sexovalue = sexopersonainput.value.trim();



    let hayCamposVacios = false;

	//----------------------comprabamos la edad
		const calcularEdad = (fechanacimientop) => {
			const fechaActual = new Date();
			const anoActual = parseInt(fechaActual.getFullYear());
			const mesActual = parseInt(fechaActual.getMonth()) + 1;
			const diaActual = parseInt(fechaActual.getDate());
		
			// 2023-02-22
			const anoNacimiento = parseInt(String(fechanacimientop).substring(0, 4));
			const mesNacimiento = parseInt(String(fechanacimientop).substring(5, 7));
			const diaNacimiento = parseInt(String(fechanacimientop).substring(8, 10));
		
			let edad = anoActual - anoNacimiento;
			if (mesActual < mesNacimiento) {
				edad--;
			} else if (mesActual === mesNacimiento) {
				if (diaActual < diaNacimiento) {
					edad--;
				}
			}
			return edad;
		};
	
		let edadpersona = calcularEdad(fechanacimientopersonainput.value);
		console.log(edadpersona);

	//--------------------validando los inputs

    if (cedula == "") {
		setErrorFor(cedulapersonainput, 'Ingrese la Cedula');
		hayCamposVacios = true;
	} else {
		setSuccessFor(cedulapersonainput);
	}

    if (estadocivilvalue == "") {
		setErrorFor(estadocivilpersonainput, 'Ingrese el Estado Civil');
		hayCamposVacios = true;
	} else {
		setSuccessFor(estadocivilpersonainput);
	}

    if (nombres == "") {
		setErrorFor(nombrespersonainput, 'Ingrese el Nombre');
		hayCamposVacios = true;
	} else {
		setSuccessFor(nombrespersonainput);
	}

    if (apellidos == "") {
		setErrorFor(apellidospersonainput, 'Ingrese el Apellido');
		hayCamposVacios = true;
	} else {
		setSuccessFor(apellidospersonainput);
	}

    if(fechanacimiento == "") {
		setErrorFor(fechanacimientopersonainput, 'Ingrese la Fecha de Nacimiento');
		hayCamposVacios = true;
	  } else if (edadpersona <= 17) {
		setErrorFor(fechanacimientopersonainput, 'No se puede registrar menores de 18 años ');
		hayCamposVacios = true;
	  } else {
		setSuccessFor(fechanacimientopersonainput);
	  }

    if (sexovalue == "") {
		setErrorFor(sexopersonainput, 'Ingrese el Sexo');
		hayCamposVacios = true;
	} else {
		setSuccessFor(sexopersonainput);
	}

    if (telefonoprincipal == "") {
		setErrorFor(telefonoprincipalpersonainput, 'Ingrese el Apellido');
		hayCamposVacios = true;
	} else {
		setSuccessFor(telefonoprincipalpersonainput);
	}

    if (telefonohabitacion == "") {
		setErrorFor(telefonohabitacionpersonainput, 'Ingrese el Apellido');
		hayCamposVacios = true;
	} else {
		setSuccessFor(telefonohabitacionpersonainput);
	}

    // Agrega más condiciones aquí para los otros campos

    return hayCamposVacios;
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.classList.add('errorinput'); // Agrega la clase 'errorinput'
	small.innerText = message;
  }
  
  function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.classList.remove('errorinput');
	formControl.classList.add('successinput');
  
  }

  

  const formdata = document.querySelector("#formupersonalmodificar");
  formdata.addEventListener("submit", (e) => {
      e.preventDefault();
      
      let idpersondaupdate = localStorage.getItem("idpesonaid");
      console.log(idpersondaupdate);
  
      document.getElementById("idpersona").value = idpersondaupdate;
  
      let data = new FormData(formdata);
  
      let url = '../controlador/ctr-personas.php?op=update';
  
      fetch(url, {
          method: 'POST',
          body: data
      })
      .then(response => response.json())
      .then(respuesta => {
          console.log(respuesta);
  
          let camposVaciosFlag = camposVaciosmodificarpersona(data);
          let cedulaExistenteFlag = (respuesta.estado === "error_cedula_existente");
  
          if (camposVaciosFlag) {
              // Ejecuta tu código para campos vacíos aquí
          }
  
          if (cedulaExistenteFlag) {
              let cedulapersonainput = document.getElementById('CedulaPersona');
              setErrorFor(cedulapersonainput, 'Esta Cedula ya Existe');
              Swal.fire({
                  title: "Esta Cedula ya Existe",
                  icon: "error"
              });
          }
  
          if (!camposVaciosFlag && !cedulaExistenteFlag && respuesta.estado === "exito") {
              Swal.fire({
                  title: "Datos de Personal Editados con exito!",
                  icon: "success"
              });
              document.querySelector('.swal2-confirm').addEventListener('click', function() {
                  location.reload();
              });
          } else if (!camposVaciosFlag && !cedulaExistenteFlag) {
              Swal.fire({
                  title: "Ocurrió un error desconocido",
                  icon: "error"
              });
          }
      })
      .catch(error => {
          console.log(error);
      });
  });

  //--------------buscando verificar cedula por evento keyup 
  let cedulapersonainput = document.getElementById('CedulaPersona');
  let cedulaOriginal = cedulapersonainput.value;
  
  cedulapersonainput.addEventListener('keyup', function() {
    
  let cedulaOriginal = localStorage.getItem("cedulaoriginalpersona");
      let url = '../controlador/ctr-personas.php?op=check_cedula';
      let data = new FormData();
      data.append('cedula', cedulapersonainput.value);
      data.append('cedula_original', cedulaOriginal);
  
      fetch(url, {
          method: 'POST',
          body: data
      })
      .then(response => response.json())
      .then(respuesta => {
          if (respuesta.estado === "error_cedula_existente") {
              setErrorFor(cedulapersonainput, 'Esta Cedula ya Existe');
          } else {
              setSuccessFor(cedulapersonainput);
          }
      })
      .catch(error => {
          console.log(error);
      });
  });