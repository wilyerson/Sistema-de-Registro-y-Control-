const dibujarTabla = (data) => {
	let tbody = document.querySelector("#data");
	tbody.innerHTML = "";
	if (data.length > 0) {
		for (let registro of data) {
			tbody.innerHTML += `
         <tr>
         <td class="">${registro.NombreInstitucion}</td>
         <td class="">
            <form method="POST" id="editarinstitucion">
            <input type="hidden" id="codinstitucion" name="codinstitucion" value="${registro.CodigoInstituciones}">

            <div class="dropdown">
              <a class="btn btn-primary dropdown-toggle" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                Seleccione
              </a>

              <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                <li><button  type="submit" id="botonmodificarinsti" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modal-editar" >Editar</button></li>
                <li><button  type="submit" id="verinstituciones" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modal-verdatos" >Ver Datos</button></li>
              </ul>
            </div>
         </form>
         </td>
         </tr>
         `;
		}
	} else {
		tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${data}</th>
            </td>
            </tr>
            `;
	}
};
