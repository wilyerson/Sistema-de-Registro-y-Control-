jQuery(document).on('submit','#formumismostrarusuariosbitacora', function(event){
	event.preventDefault();

	
	let nameuserr = localStorage.getItem("nameusuario");
	//console.log(cedulauser);

	document.getElementById("nameuser").value = nameuserr;

	console.log(nameuserr);
jQuery.ajax({
	url: '../controlador/mostrarusuariosbitacora.php',
	type: 'POST',
	dataType: 'json',
	data: $(this).serialize(),
	beforeSend: function () {
		// body...

	}
})
.done(function (respuesta) {
	// body...
	console.log(respuesta);

	document.getElementById("listadeusuarios").style.display="block";

	let tbody = document.querySelector("#mostrarusuarios");
	tbody.innerHTML = "";
	if (respuesta.length > 0) {
		for (let registro of respuesta) {
			let cadena = registro.EstatusUsuario;
            let cadenaSeparada = cadena.replace("usuarioactivo", "usuario activo").replace("usuariodesactivado", "usuario desactivado");

			tbody.innerHTML += `
         <tr>
         <th class="text-center">${registro.CodigoUsuario}</th>
         <td class="text-center">${registro.NombreUsuario}</td>
         <td class="text-center">${registro.RolUsuario}</td>
         <td class="text-center">${cadenaSeparada}</td>
         <td class="text-center">
		 

   <button type="submit" class="btn btn-primary" onclick="vermovimientouser(${registro.CodigoUsuario})">Ver Movimientos</button>

         
         </td>
         </tr>


         `;
		}
	} else {
		tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${respuesta}</th>
            </td>
            </tr>
            `;
	}


//$('#modaloffuser').modal("show");

})
.fail(function (resp) {
	// body...
	//console.log(resp.responseText);
		
})
.always(function () {
	// body...
	console.log("complete");
});


});

function vermovimientouser(codigoUsuario) {

    /*let idurl = new URLSearchParams(window.location.search);
    let idpersonalurl = idurl.get('id');*/
    
	location.href = `../vista/bitacora-usuario.php?id=${codigoUsuario}`;
}