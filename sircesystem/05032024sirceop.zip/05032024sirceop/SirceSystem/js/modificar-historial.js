function camposVacios(datos) {

   

    let institucionhistoricoedit = document.getElementById('institucionhistoricoedit');
    let cargohistoricoedit = document.getElementById('cargohistoricoedit');
    let fechainiciohistorialedit = document.getElementById('fecha-iniciohistorialedit');
    let fechaculminacionhistorialedit = document.getElementById('fecha-culminacionhistorialedit');
    

    const institucionhistoricovalue = institucionhistoricoedit.value.trim();
    const cargohistoricovalue = cargohistoricoedit.value.trim();
    const fechainiciohistorialvalue = fechainiciohistorialedit.value.trim();
    const fechaculminacionhistorialvalue = fechaculminacionhistorialedit.value.trim();

    let hayCamposVacios = false;

	//--------------------validando los inputs

    if (institucionhistoricovalue == "") {
		setErrorFor(institucionhistoricoedit, 'Ingrese la Intitucion');
		hayCamposVacios = true;
	} else {
		setSuccessFor(institucionhistoricoedit);
	}

    if (cargohistoricovalue == "") {
		setErrorFor(cargohistoricoedit, 'Ingrese el Cargo');
		hayCamposVacios = true;
	} else {
		setSuccessFor(cargohistoricoedit);
	}

    if (fechainiciohistorialvalue == "") {
		setErrorFor(fechainiciohistorialedit, 'Ingrese Fecha de Inicio');
		hayCamposVacios = true;
	} else {
		setSuccessFor(fechainiciohistorialedit);
	}

    // Agrega más condiciones aquí para los otros campos

    return hayCamposVacios;
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.classList.add('errorinput'); // Agrega la clase 'errorinput'
	small.innerText = message;
  }
  
  function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.classList.remove('errorinput');
	formControl.classList.add('successinput');
  
  }

  

  const formdatahii = document.querySelector("#formeditarhistorial");
  formdatahii.addEventListener("submit", (e) => {
      e.preventDefault();

      document.getElementById('hiddenInputeditar').value = document.getElementById('institucionhistoricoeditar').dataset.value;
      
      let idpersondaupdate = localStorage.getItem("idpesonaid");
      console.log(idpersondaupdate);
  
      document.getElementById("idpersonahistorialedit").value = idpersondaupdate;
  
      const datos = new FormData(document.getElementById("formeditarhistorial"));

          //validar campos vacios
    if (camposVacios(datos)) {
		//console.log('Hay campos vacíos');
		return;
	}
  
      let url = "../controlador/ctr-historial.php?op=update";
  
      fetch(url, {
          method: 'POST',
          body: datos
      })
      .then(response => response.json())
      .then(respuesta => {
          console.log(respuesta);

          if (respuesta == "Registro actualizado correctamente.") {
            mostrarHistorialLaboral();
            $('#modal-editar-historial').modal("hide");
            swal.fire({
                title: "¡Modificacion de Historial Exitoso!",
                icon: "success",
            });
        }

      })
      .catch(error => {
          console.log(error);
      });
  });


var modal2editar = document.getElementById("myModal2editar");

// Get the button that opens the modal
var btn2editar = document.getElementById("myBtn2editar");

// Get the <span> element that closes the modal
var span2editar= document.getElementsByClassName("close2editar")[0];

// When the user clicks the button, open the modal 
btn2editar.onclick = function() {
  modal2editar.style.display = "block";
  //$('#registro-historico').modal("hide");
}

// When the user clicks on <span> (x), close the modal
span2editar.onclick = function() {
  modal2editar.style.display = "none";
}
