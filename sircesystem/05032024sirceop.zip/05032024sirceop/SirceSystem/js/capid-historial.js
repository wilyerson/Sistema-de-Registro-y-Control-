const tbodyhistorico = document.querySelector("#mostrarhistoriallaboral");

tbodyhistorico.addEventListener("submit", (e) => {
  if (e.target.matches("#editarhistorial")) {
    e.preventDefault();

    let url = '../controlador/ctr-historial.php?op=editarmodalhistorial';
    let data = new FormData(e.target); // Utiliza e.target para acceder al formulario correcto

    fetch(url, {
      method: 'POST',
      body: data
    })
    .then(response => response.json())
    .then(respuesta => {
      console.log(respuesta);
      //console.log(respuesta[0].CodigoHistorico);

      document.getElementById("idhistoricoedit").value = respuesta[0].CodigoHistorico;
      document.getElementById("institucionhistoricoeditar").dataset.value = respuesta[0].CodigoInstituciones;
      document.getElementById("institucionhistoricoeditar").innerHTML = respuesta[0].NombreInstitucion;
      document.getElementById("cargohistoricoedit").value = respuesta[0].CodigoCargo;
      document.getElementById("numerodocumentohistoricoeditar").value = respuesta[0].NumeroDocumento;
      document.getElementById("tipodocumentohistoricoeditar").value = respuesta[0].TipoDocumento;
      document.getElementById("fecha-iniciohistorialedit").value = respuesta[0].FechaInicio;
      document.getElementById("fecha-culminacionhistorialedit").value = respuesta[0].FechaCulminacion;
      document.getElementById("observacionhistoricoedit").value = respuesta[0].Obervacion;
  
      /*let parroquianumero = respuesta[0].ParroquiaInstitucion;
      let parroquianombre = respuesta[0].NombreParroquia;

      localStorage.setItem("ParroquiaInstitucion", parroquianumero);
      localStorage.setItem("ParroquiaNombre", parroquianombre);*/

      //----modal editar pasar datos de base datos------

      //document.getElementById("institucionhistoricover").value = respuesta[0].CodigoInstituciones;
      document.getElementById("cargohistoricover").value = respuesta[0].CodigoCargo;
      document.getElementById("fecha-iniciohistorialver").value = respuesta[0].FechaInicio;
      document.getElementById("fecha-culminacionhistorialver").value = respuesta[0].FechaCulminacion;
      document.getElementById("observacionhistoricover").value = respuesta[0].Obervacion;


      if (!respuesta.error) {
        console.log("sirve");
      } else {
        if (respuesta.error === true) {
          // Handle error
        }
      }
    })
    .catch(error => {
      // Handle fetch error
      console.log(error);
    });
  }
});