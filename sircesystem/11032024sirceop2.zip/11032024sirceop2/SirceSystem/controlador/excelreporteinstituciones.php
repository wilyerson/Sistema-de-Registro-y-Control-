<?php

const SERVER="localhost";
const DB="sirceop";
const USER="root";
const PASS="";
const UTF8="utf8";

const SGBD="mysql:host=".SERVER.";dbname=".DB.";charset=".UTF8;

class dbconexion
{
    protected function conexion()
    {
        try {
            $con = new PDO(SGBD, USER, PASS);
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $con;
        } catch (PDOException $e) {
            echo "Conexion Fallida: " . $e->getMessage();
        }
    }

    public function getConexion() {
        return $this->conexion();
    }
}

$db = new dbconexion();
$conexion = $db->getConexion();

use PhpOffice\PhpSpreadsheet\{Spreadsheet, IOFactory};

require '../librerias/excel/vendor/autoload.php';

$instituciones = $_POST['instituciones'];

$sql = "SELECT historico.*, persona.CodigoPersona, persona.CedulaPersona, persona.Nombres, persona.Apellidos, persona.Sexo, instituciones.*
FROM historico
INNER JOIN instituciones
ON historico.InstitucionHistorico = instituciones.CodigoInstituciones
INNER JOIN persona
ON historico.personal = persona.CodigoPersona
WHERE historico.InstitucionHistorico = ?";
$stmt = $conexion->prepare($sql);
$stmt->bindValue(1, $instituciones);
$stmt->execute();
$resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);

$excel = new Spreadsheet();
$hojaActiva = $excel->getActiveSheet();
$hojaActiva->setTitle("Personas");

$hojaActiva->getColumnDimension('A')->setWidth(18);
$hojaActiva->setCellValue('A1','CedulaPersona');
$hojaActiva->getColumnDimension('B')->setWidth(28);
$hojaActiva->setCellValue('B1','Nombres');
$hojaActiva->getColumnDimension('C')->setWidth(28);
$hojaActiva->setCellValue('C1','Apellidos');
$hojaActiva->getColumnDimension('D')->setWidth(25);
$hojaActiva->setCellValue('D1','Sexo');
$hojaActiva->getColumnDimension('E')->setWidth(25);
$hojaActiva->setCellValue('E1','NombreInstitucion');

$fila = 2;

foreach ($resultado as $row) {
    $hojaActiva->setCellValue('A' . $fila, strtoupper($row['CedulaPersona']));
    $hojaActiva->setCellValue('B' . $fila, strtoupper($row['Nombres']));
    $hojaActiva->setCellValue('C' . $fila, strtoupper($row['Apellidos']));
    $hojaActiva->setCellValue('D' . $fila, strtoupper($row['Sexo']));
    $hojaActiva->setCellValue('E' . $fila, strtoupper($row['NombreInstitucion']));
    $fila++;
}

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="personas.xlsx"');
header('Cache-Control: max-age=0');

$writer = IOFactory::createWriter($excel, 'Xlsx');
$writer->save('php://output');
exit;

?>