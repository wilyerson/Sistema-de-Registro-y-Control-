<?php
require_once "../config/dbconexion.php";
require_once "../modelo/ModeloPersonal.php";

session_start();

$personal = new Personal();

switch ($_GET["op"]) {

    case 'listar':
        $result_set = $personal->get_personas();
        $data = array();
        foreach ($result_set as $row) {
            array_push($data, array("id_persona" => $row['id_persona'], "nombres" => $row['nombres'], "apellidos" => $row['apellidos'], "genero" => $row['genero']));
        }
        echo json_encode($data); //formateado como json
        break;

    case 'guardar':
        $CedulaPersona = $_POST['cedulapersona'];
        $Nombres = $_POST['nombrespersonal'];
        $Apellidos = $_POST['apellidospersonal'];
        $FechaNacimiento = $_POST['fechanacimiento'];
        $Sexo = $_POST['sexo'];
        $EstadoCivil = $_POST['estadocivil'];
        $ParroquiaPersona = @$_POST['parroquiareg'];
        $Sector = $_POST['nombresector'];
        $Direccion = $_POST['direccion'];
        $TelefonoPrincipal = $_POST['telefonoprincipal'];
        $TelefonoHabitacion = $_POST['telefonohabitacion'];
        $Peso = $_POST['peso'];
        $Estatura = $_POST['estatura'];
        $TallaCamisa = $_POST['tallacamisa'];
        $TallaPantalon = $_POST['tallapantalon'];
        $TallaCalzado = $_POST['tallacalzado'];
        $idusuario = $_SESSION['iduser'];
        $TipoPersona = $_POST['tipopersona'];
        $EstatusPersonal = $_POST['estatus'];
        $EstatusTrabajador = $_POST['estatuspersona'];

        $insercion = $personal->insert_persona($CedulaPersona, $Nombres, $Apellidos, $FechaNacimiento, $Sexo, $EstadoCivil, $ParroquiaPersona, $Sector, $Direccion,$TelefonoPrincipal, $TelefonoHabitacion, $Peso, $Estatura, $TallaCamisa, $TallaPantalon, $TallaCalzado, $idusuario, $TipoPersona, $EstatusPersonal,$EstatusTrabajador);
       // echo json_encode($insercion);
        break;

    case 'editar':
        $id_persona = $_POST['idper'];
        $ejecutar = $personal->get_persona($id_persona);
        echo json_encode($ejecutar);
        break;

    case 'update':
        $CodigoPersona = $_POST['idpersona'];
        $CedulaPersona = $_POST['editCi'];
        $Nombres = $_POST['editName'];
        $Apellidos = $_POST['editApellidos'];
        $FechaNacimiento = $_POST['editFechanacimiento'];
        $Sexo = $_POST['editsexo'];
        $EstadoCivil = $_POST['editestadocivil'];
        $ParroquiaPersona = $_POST['editparroquiareg'];
        $Sector = $_POST['editsector'];
        $Direccion = $_POST['editdireccion'];
        $TelefonoPrincipal = $_POST['editTelefonoPrincipal'];
        $TelefonoHabitacion = $_POST['editTelefonoHabitacion'];
        $Peso = $_POST['editpeso'];
        $Estatura = $_POST['editestatura'];
        $TallaCamisa = $_POST['editTallaCamisa'];
        $TallaPantalon = $_POST['edittallapantalon'];
        $TallaCalzado = $_POST['editTallaCalzado'];
        $idUsuario = $_SESSION['iduser'];
        $EstatusTrabajador = @$_POST['estatuspersonaeditar'];
        
        $actualizacion = $personal->update_personal($CodigoPersona, $CedulaPersona, $Nombres, $Apellidos, $FechaNacimiento, $Sexo, $EstadoCivil, $ParroquiaPersona, $Sector, $Direccion, $TelefonoPrincipal, $TelefonoHabitacion, $Peso, $Estatura, $TallaCamisa, $TallaPantalon, $TallaCalzado, $idUsuario, $EstatusTrabajador);
        echo json_encode($actualizacion);
        break;

        case 'verificarcedula':
            $CedulaPersona = $_POST['cedulapersona'];
            $existe = $personal->verificar_cedula($CedulaPersona);
            echo json_encode($existe);
            break;

        case 'check_cedula':
            $CedulaPersona = $_POST['cedula'];
            $CedulaOriginal = $_POST['cedula_original'];
            $existe = $personal->check_cedula($CedulaPersona, $CedulaOriginal);
            if ($existe) {
                echo json_encode(array("estado" => "error_cedula_existente"));
            } else {
                echo json_encode(array("estado" => "success"));
            }
            break;    

        case 'buscarpersona':
            $CedulaPersonabuscar = $_POST['cedulabuscar'];
            $buscarpersona = $personal->get_buscarpersona($CedulaPersonabuscar);
            echo json_encode($buscarpersona);
            break;  



    default:
        # code...
        break;
}
