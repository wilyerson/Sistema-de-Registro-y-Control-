<?php
require_once "../config/dbconexion.php";
require_once "../modelo/ModeloCargos.php";

session_start();

$cargos = new Cargos();

switch ($_GET["op"]) {

        case 'guardar':

        $registrocargos = $_POST['registrocargos'];

        $insercion = $cargos->insert_cargos($registrocargos);
        echo json_encode($insercion);
        break;


        default:
        # code...
        break;
    }