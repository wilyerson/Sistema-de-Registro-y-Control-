<?php 


	require_once "../modelo/ModeloParroquia.php";

	$parroquias = [];
	if (isset($_GET['id_munHeditar'])) {
		$tabla_parroquia = new parroquia();
		$parroquias = $tabla_parroquia->obtener_parroquia_select($_GET['id_munHeditar']);
	}
		echo json_encode(['data' => $parroquias] );

		
 ?>