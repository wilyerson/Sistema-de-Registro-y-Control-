document.querySelector('#formumismostrarusuariosbitacora').addEventListener('submit', function(event){
	event.preventDefault();

	let nameuserr = localStorage.getItem("nameusuario");
	document.getElementById("nameuser").value = nameuserr;
	console.log(nameuserr);

	let formData = new FormData(this);

	fetch('../controlador/mostrarusuariosbitacora.php', {
		method: 'POST',
		body: formData
	})
	.then(response => response.json())
	.then(respuesta => {
		console.log(respuesta);

		document.getElementById("listadeusuarios").style.display="block";

		let tbody = document.querySelector("#mostrarusuarios");
		tbody.innerHTML = "";
		if (respuesta.length > 0) {
			for (let registro of respuesta) {
				let cadena = registro.EstatusUsuario;
				let cadenaSeparada = cadena.replace("usuarioactivo", "usuario activo").replace("usuariodesactivado", "usuario desactivado");

				tbody.innerHTML += `
				<tr>
				<th class="text-center">${registro.CodigoUsuario}</th>
				<td class="text-center">${registro.NombreUsuario}</td>
				<td class="text-center">${registro.RolUsuario}</td>
				<td class="text-center">${cadenaSeparada}</td>
				<td class="text-center">
				<button type="submit" class="btn btn-primary" onclick="vermovimientouser(${registro.CodigoUsuario})">Ver Movimientos</button>
				</td>
				</tr>
				`;
			}
		} else {
			tbody.innerHTML += `
				<tr>
				<th class="text-center" colspan="5" >No hay Registros en la Base de datos.${respuesta}</th>
				</td>
				</tr>
				`;
		}
	})
	.catch(error => {
		console.error('Error:', error);
	});
});

function vermovimientouser(codigoUsuario) {
	location.href = `../vista/bitacora-usuario.php?id=${codigoUsuario}`;
}

//boton mostrar los usuarios

document.querySelector('#botonmostrarlosusuarios').addEventListener('click', function(event) {
    event.preventDefault();

	fetch('../controlador/mostrarusuariosbitacora.php', {
		method: 'POST',
	})
	.then(response => response.json())
	.then(respuesta => {
		console.log(respuesta);

		document.getElementById("listadeusuarios").style.display="block";

		let tbody = document.querySelector("#mostrarusuarios");
		tbody.innerHTML = "";
		if (respuesta.length > 0) {
			for (let registro of respuesta) {
				let cadena = registro.EstatusUsuario;
				let cadenaSeparada = cadena.replace("usuarioactivo", "usuario activo").replace("usuariodesactivado", "usuario desactivado");

				tbody.innerHTML += `
				<tr>
				<th class="text-center">${registro.CodigoUsuario}</th>
				<td class="text-center">${registro.NombreUsuario}</td>
				<td class="text-center">${registro.RolUsuario}</td>
				<td class="text-center">${cadenaSeparada}</td>
				<td class="text-center">
				<button type="submit" class="btn btn-primary" onclick="vermovimientouser(${registro.CodigoUsuario})">Ver Movimientos</button>
				</td>
				</tr>
				`;
			}
		} else {
			tbody.innerHTML += `
				<tr>
				<th class="text-center" colspan="5" >No hay Registros en la Base de datos.${respuesta}</th>
				</td>
				</tr>
				`;
		}
	})
	.catch(error => {
		console.error('Error:', error);
	});
});

function vermovimientouser(codigoUsuario) {
	location.href = `../vista/bitacora-usuario.php?id=${codigoUsuario}`;
}