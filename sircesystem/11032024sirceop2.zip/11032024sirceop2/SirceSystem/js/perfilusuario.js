const formdatacambiopassworduser = document.querySelector("#formcambiopassword");
formdatacambiopassworduser.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formcambiopassword"));

	console.log(" conectado");

	let url = "../controlador/usuarios-control.php?op=cambiopassworduser";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);

		var status = data.status;
		
		if (status == "password_user_actualizado_exitosamente") {

			$('#modalcambiarpasswordusuario').modal('hide');
			swal.fire({
				title: "Modificacion de Contraseña Exitosa!",
				icon: "success",
			});

		}

		})
		.catch((error) => console.log(`error: ${error}`));
});

window.addEventListener('DOMContentLoaded', (event) => {
    let url = "../controlador/usuarios-control.php?op=get_usuariouser";

    fetch(url, {
        method: "post",
    })
    .then((data) => data.json())
    .then((data) => {
        console.log(data);

        document.getElementById("nombreusuarioeditar").value = data[0].NombreUsuario;
        let nombreuserperfilhtml = document.getElementById("maneuserperfil");
        nombreuserperfilhtml.innerHTML = data[0].NombreUsuario; 
        

    })
    .catch((error) => console.log(`error: ${error}`));
});

const formdatacambionombreuser = document.querySelector("#formcambionombreusuario");
formdatacambionombreuser.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formcambionombreusuario"));

	console.log(" conectado");

	let url = "../controlador/usuarios-control.php?op=cambionombreuser";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);

		var status = data.status;
		
		if (status == "nombreuser_actualizado_exitosamente") {

			$('#modalcambiarnombreusurio').modal('hide');
			swal.fire({
				title: "Modificacion de Nombre Usuario Exitosa!",
				icon: "success",
			});

		}

		if (status == "estenombre_usuario_ya_existe") {

			swal.fire({
				title: "Este Nombre de Usuario ya Existe!",
				icon: "error",
			});

		}

		})
		.catch((error) => console.log(`error: ${error}`));
});

const formdatacambiopassworduseranalistaconsulta = document.querySelector("#formcambiopasswordanalistaconsulta");
formdatacambiopassworduseranalistaconsulta.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formcambiopasswordanalistaconsulta"));

	console.log(" conectado");

	let url = "../controlador/usuarios-control.php?op=cambiopassworduseranalistaconsulta";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);

		var status = data.status;

		switch (status){
		case 'password_actual_no_coidicen':

			swal.fire({
				title: "Contraseña Actual no Coincide!",
				icon: "error",
			});

			break;

		case 'password_user_actualizado_exitosamente':
			$('#modalcambiarpasswordusuarioanalistaconsulta').modal("hide");
			swal.fire({
				title: "Modificacion de Contraseña Exitosa!",
				icon: "success",
			});
			break;

		}
		
		})
		.catch((error) => console.log(`error: ${error}`));
});