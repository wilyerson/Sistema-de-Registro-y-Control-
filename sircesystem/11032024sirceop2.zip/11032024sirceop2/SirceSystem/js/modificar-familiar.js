function camposVacioseditfami(datos) {
    let cedulafamiliar = datos.get("cedulafamiliareditar");
    let regpartidafamiliar = datos.get("regpartidafamiliareditar");
    let nombresfamiliar = datos.get("nombresfamiliareditar");
    let apellidosfamiliar = datos.get("apellidosfamiliareditar");
    let numtelefonofamiliar = datos.get("numtelefonofamiliareditar");
    let numtelefono2familiar = datos.get("numtelefono2familiareditar");


    let cedulafamiliarinputreg = document.getElementById('cedulafamiliareditar');
    let regpartidafamiliarinputreg = document.getElementById('regpartidafamiliareditar');
    let parentescofamiliarinputreg = document.getElementById('parentescofamiliareditar');
    let nombresfamiliarinputreg = document.getElementById('nombresfamiliareditar');
    let apellidosfamiliarinputreg = document.getElementById('apellidosfamiliareditar');
    let sexofamiliarinputreg = document.getElementById('sexofamiliareditar');
    let fechanacfamiliarinputreg = document.getElementById('fechanacfamiliareditar');
    let numtelefonofamiliarinputreg = document.getElementById('numtelefonofamiliareditar');
    let numtelefono2familiarinputreg = document.getElementById('numtelefono2familiareditar');

    //let fechaculminacionhistorial = document.getElementById('fecha-culminacionhistorial');


    const parentescofamiliarinputregvalue = parentescofamiliarinputreg.value.trim();
    const sexofamiliarinputregvalue = sexofamiliarinputreg.value.trim();
    const fechanacfamiliarinputregregvalue = fechanacfamiliarinputreg.value.trim();

    //const fechaculminacionhistorialvalue = fechaculminacionhistorial.value.trim();

    let hayCamposVacios = false;

	//--------------------validando los inputs

    //-----------checkbox de cedula----------------------------

    let checkboxfamiliarvalidar = document.getElementById('checkboxfamiliareditar').value;

    if (checkboxfamiliarvalidar == false ) {
        if (cedulafamiliar == "") {
            setErrorFor(cedulafamiliarinputreg, 'Ingrese la cedula');
            hayCamposVacios = true;
        } else {
            setSuccessFor(cedulafamiliarinputreg);
        }
    } else {
        if (regpartidafamiliar == "") {
            setErrorFor(regpartidafamiliarinputreg, 'Ingrese el numero de registro de la Partida de Nacimiento');
            hayCamposVacios = true;
        } else {
            setSuccessFor(regpartidafamiliarinputreg);
        }
    }

    //--------------------------------------------------------

    if (parentescofamiliarinputregvalue == "") {
		setErrorFor(parentescofamiliarinputreg, 'Ingrese el Parentesco');
		hayCamposVacios = true;
	} else {
		setSuccessFor(parentescofamiliarinputreg);
	}

    if (nombresfamiliar == "") {
		setErrorFor(nombresfamiliarinputreg, 'Ingrese el Nombre');
		hayCamposVacios = true;
	} else {
		setSuccessFor(nombresfamiliarinputreg);
	}

    if (apellidosfamiliar == "") {
		setErrorFor(apellidosfamiliarinputreg, 'Ingrese el Apellido');
		hayCamposVacios = true;
	} else {
		setSuccessFor(apellidosfamiliarinputreg);
	}

    if (sexofamiliarinputregvalue == "") {
		setErrorFor(sexofamiliarinputreg, 'Ingrese el Sexo');
		hayCamposVacios = true;
	} else {
		setSuccessFor(sexofamiliarinputreg);
	}

    if (fechanacfamiliarinputregregvalue == "") {
		setErrorFor(fechanacfamiliarinputreg, 'Ingrese la Fecha de Nacimiento');
		hayCamposVacios = true;
	} else {
		setSuccessFor(fechanacfamiliarinputreg);
	}

    if (numtelefonofamiliar == "") {
		setErrorFor(numtelefonofamiliarinputreg, 'Ingrese el Numero de Telefono Principal');
		hayCamposVacios = true;
	} else {
		setSuccessFor(numtelefonofamiliarinputreg);
	}

    if (numtelefono2familiar == "") {
		setErrorFor(numtelefono2familiarinputreg, 'Ingrese el Numero de Telefono de Habitacion');
		hayCamposVacios = true;
	} else {
		setSuccessFor(numtelefono2familiarinputreg);
	}

    // Agrega más condiciones aquí para los otros campos

    return hayCamposVacios;
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.classList.add('errorinput'); // Agrega la clase 'errorinput'
	small.innerText = message;
  }
  
  function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.classList.remove('errorinput');
	formControl.classList.add('successinput');
  
  }

  

  const formdataeditfami = document.querySelector("#formregistrarfamiliareditar");
  formdataeditfami.addEventListener("submit", (e) => {
      e.preventDefault();
      
      let idfamiliarupdate = localStorage.getItem("idpesonaid");
      console.log(idfamiliarupdate);
  
      document.getElementById("idpersonafamiedit").value = idfamiliarupdate;
  
      //let data = new FormData(formdata);
      const data = new FormData(document.getElementById("formregistrarfamiliareditar"));
  
      let url = '../controlador/ctr-familiares.php?op=update';
  
      fetch(url, {
          method: 'POST',
          body: data
      })
      .then(response => response.json())
      .then(respuesta => {
          console.log(respuesta);
    
        var status = respuesta.status;

        switch (status){
        case 'esta_cedula_ya_existe':
            $('#modal-editar-familiar').modal("hide");
            archivojpg.classList.remove('is-valid');
            archivojpg.classList.add('is-invalid');
            swal.fire({
                title: "¡Esta Cedula ya Existe!",
                icon: "error",
            });
            break;

        case 'modificacion_exitosa':
            $('#modal-editar-familiar').modal("hide");
            archivojpg.classList.remove('is-valid');
            archivojpg.classList.add('is-invalid');
            swal.fire({
                title: "¡Modificacion Exitosa!",
                icon: "success",
            });
            break;
        }
            //---------------------------

            /*let camposVaciosFlag = camposVacioseditfami(data);
            let cedulaExistenteFlag = (respuesta.estado === "error_cedula_existente");

            if (camposVaciosFlag) {
                // Ejecuta tu código para campos vacíos aquí
            }

            if (cedulaExistenteFlag) {
                let cedulapersonainput = document.getElementById('CedulaPersona');
                setErrorFor(cedulapersonainput, 'Esta Cedula ya Existe');
                Swal.fire({
                    title: "Esta Cedula ya Existe",
                    icon: "error"
                });
            }

            if (!camposVaciosFlag && !cedulaExistenteFlag && respuesta.estado === "exito") {
                Swal.fire({
                    title: "Datos de Personal Editados con exito!",
                    icon: "success"
                });
                document.querySelector('.swal2-confirm').addEventListener('click', function() {
                    location.reload();
                });
            } else if (!camposVaciosFlag && !cedulaExistenteFlag) {
                Swal.fire({
                    title: "Ocurrió un error desconocido",
                    icon: "error"
                });
            }*/

            //---------------------------
            mostrarFamiliares();
            

      })
      .catch(error => {
          console.log(error);
      });
  });

  //--------------buscando verificar cedula por evento keyup 
  let cedulafamiliarinputedit = document.getElementById('cedulafamiliareditar');
  let cedulaOriginalfamiedit = cedulafamiliarinputedit.value;
  
  cedulafamiliarinputedit.addEventListener('keyup', function() {
    
  let cedulaOriginalfamiedit = localStorage.getItem("cedulaoriginalpersona");
      let url = '../controlador/ctr-familiares.php?op=check_cedula';
      let data = new FormData();
      data.append('cedula', cedulafamiliarinputedit.value);
      data.append('cedula_original', cedulaOriginalfamiedit);
  
      fetch(url, {
          method: 'POST',
          body: data
      })
      .then(response => response.json())
      .then(respuesta => {
          if (respuesta.estado === "error_cedula_existente") {
              setErrorFor(cedulafamiliarinputedit, 'Esta Cedula ya Existe');
          } else {
              setSuccessFor(cedulafamiliarinputedit);
          }
      })
      .catch(error => {
          console.log(error);
      });
  });