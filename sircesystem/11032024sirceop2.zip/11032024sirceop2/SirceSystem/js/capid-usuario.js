const tbodyhistorico = document.querySelector("#MostrarUsuarios");

tbodyhistorico.addEventListener("submit", (e) => {
  if (e.target.matches("#editarusuarios")) {
    e.preventDefault();

    let url = "../controlador/usuarios-control.php?op=get_usuario";
    let data = new FormData(e.target); // Utiliza e.target para acceder al formulario correcto

    fetch(url, {
      method: 'POST',
      body: data
    })
    .then(response => response.json())
    .then(respuesta => {
      console.log(respuesta);
      //console.log(respuesta[0].CodigoHistorico);

      //----modal editar pasar datos de base datos------

      document.getElementById("codigousereditar").value = respuesta[0].CodigoUsuario;
      document.getElementById("codigopersonausereditar").value = respuesta[0].CodigoPersona;

      document.getElementById("cedulanewusereditar").value = respuesta[0].CedulaPersona;
      document.getElementById("nombrenewusereditar").value = respuesta[0].Nombres;
      document.getElementById("apellidosnewusereditar").value = respuesta[0].Apellidos;
      document.getElementById("nombreunewusereditar").value = respuesta[0].NombreUsuario;
      document.getElementById("tipousereditar").value = respuesta[0].RolUsuario;
      document.getElementById("estatususuarioeditar").value = respuesta[0].EstatusUsuario;
      /*document.getElementById("passnewusereditar").value = respuesta[0].ConstraseñaUsuario;
      document.getElementById("passnu2editar").value = respuesta[0].ConstraseñaUsuario;*/

      document.getElementById("codigouserpasseditar").value = respuesta[0].CodigoUsuario;
      document.getElementById("codigopersonauserpasseditar").value = respuesta[0].CodigoPersona;

      if (!respuesta.error) {
        console.log("sirve");
      } else {
        if (respuesta.error === true) {
          // Handle error
        }
      }
    })
    .catch(error => {
      // Handle fetch error
      console.log(error);
    });
  }
});


