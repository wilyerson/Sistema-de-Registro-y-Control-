    fetch('../controlador/institucionesfetch.php')
        .then(response => response.json())
        .then(data => {

            const wrapper = document.querySelector(".wrapper"),
selectBtn = wrapper.querySelector(".select-btn"),
searchInp = wrapper.querySelector(".search input"),
options = wrapper.querySelector(".options");



function addCountry(selectedCountry) {
    options.innerHTML = "";
    data.forEach(institucion => {
        let isSelected = institucion.NombreInstitucion == selectedCountry ? "selected" : "";
        let li = `<li onclick="updateName(this)" class="${isSelected}" data-value="${institucion.CodigoInstituciones}" >${institucion.NombreInstitucion}</li>`;
        options.insertAdjacentHTML("beforeend", li);
    });
}
addCountry();

window.updateName = (selectedLi) => {
    
  
    wrapper.classList.remove("active");
    selectBtn.firstElementChild.innerText = selectedLi.innerText;
    selectBtn.firstElementChild.dataset.value = selectedLi.dataset.value; 
};

/*searchInp.addEventListener("keyup", () => {
    let arr = [];
    let searchWord = searchInp.value.toLowerCase();
    arr = data.filter(institucion => {
        return institucion.NombreInstitucion.toLowerCase().startsWith(searchWord);
    }).map(institucion => {
        let isSelected = institucion.NombreInstitucion == selectBtn.firstElementChild.innerText ? "selected" : "";
        return `<li onclick="updateName(this)" class="${isSelected}" data-value="${institucion.CodigoInstituciones}">${institucion.NombreInstitucion}</li>`;
    }).join("");
    options.innerHTML = arr ? arr : `<p style="margin-top: 10px;">No esta Registrada esa Institucion</p>`;
});*/

selectBtn.addEventListener("click", () => wrapper.classList.toggle("active"));

        })
        .catch(error => console.error('Error:', error));

// Variable para rastrear si #contentlista está mostrándose
let isContentlistaVisible = false;

// Muestra el elemento #contentlista cuando se hace clic en .select-btn, a menos que ya esté visible
$('.select-btn').click(function(event) {
    event.stopPropagation();
    if (isContentlistaVisible) {
        $('#contentlista').hide();
        isContentlistaVisible = false;
    } else {
        $('#contentlista').show();
        isContentlistaVisible = true;
    }
});

// Oculta el elemento #contentlista cuando se hace clic en cualquier parte de la página que no sea .select-btn o .search
$(document).click(function(event) {
    var target = $(event.target);
    if (!target.closest('.select-btn').length && !target.closest('.search').length && !target.closest('#contentlista').length) {
        $('#contentlista').hide();
        isContentlistaVisible = false;
    }
});

$('.options').click(function(event) {
    event.stopPropagation();
    $('#contentlista').hide();
    isContentlistaVisible = false;
});

/*$('.options').click(function(event) {
    $('#contentlista').hide();
    isContentlistaVisible = false;
});

$('li').click(function() {
    $('#contentlista').hide();
    isContentlistaVisible = false;
});*/
