  function activarmostrausuarios() {

    document.getElementById("mostraruserdiv").style.display="block";
  }

  function ocultarmostrarusuarios(){

    document.getElementById("mostraruserdiv").style.display="none";

  }

    function ocultarmismovimientos(){

    document.getElementById("divmismovimientos").style.display="none";

  }