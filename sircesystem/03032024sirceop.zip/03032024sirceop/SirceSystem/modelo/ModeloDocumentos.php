<?php

class Documento extends dbconexion
{
    public function get_documentos()
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT CodigoInstituciones, NombreInstitucion, CodigoRegistro FROM instituciones");
        $sql->execute();
        return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_documento($idperdoc)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT   documento.NombreDocumento,
        archivos.CodigoDocumento,
        archivos.ArchivoRegistro,
        archivos.archivosjpg
        FROM
        archivos
        INNER JOIN documento on archivos.CodigoDocumento = documento.CodigoDocumento
        WHERE archivos.idperarchivos = ?");
        $sql->bindValue(1, $idperdoc);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

public function insert_documento($CodigoDocumento, $idpersonadoc, $idusuario)
{
    $conectar = dbconexion::conexion();
    $sql = $conectar->prepare("INSERT INTO archivos (CodigoDocumento, idperarchivos, archivosjpg, idusuario) VALUES (?, ?, ?, ?)");
    $sql->bindValue(1, $CodigoDocumento);
    $sql->bindValue(2, $idpersonadoc);
    $sql->bindValue(4, $idusuario);

    // Define el directorio donde quieres guardar el archivo
    $directorio = 'imagenes/'.$idpersonadoc;

    // Crea el directorio si no existe
    if (!file_exists($directorio)) {
        mkdir($directorio, 0777, true);
    }

    // Define la ruta de destino del archivo
    $ruta_destino = $directorio.'/'.$_FILES['archivojpg']['name'];

    // Verifica el tipo de archivo
    $tipoArchivo = 'image/jpeg';
    if ($_FILES['archivojpg']['type'] != $tipoArchivo) {
        return ['status' => 'El archivo debe ser un jpg'];
        
        
    }

    // Verifica el tamaño del archivo
    $tamanoMaximo = 5 * 1024 * 1024; // 5MB
    if ($_FILES['archivojpg']['size'] > $tamanoMaximo) {
        return ['status' => 'El archivo debe ser de hasta 5MB'];
        
        
    }

    // Mueve el archivo cargado a la ruta de destino
    if(move_uploaded_file($_FILES['archivojpg']['tmp_name'], $ruta_destino)){
        // Si el archivo se movió correctamente, cambia el valor de $ruta_destino
        $ruta_destino = $ruta_destino;
    }

    // Vincula el valor de $ruta_destino a la consulta SQL
    $sql->bindValue(3, $ruta_destino);

    if ($sql->execute()) {
        return ['status' => 'Documento registrado exitoso'];
        //return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    }
}
    public function update_documento($codinstimod, $nombreinstimod, $codigoregintimod, $parroquiarinstimod, $sectorinstimod, $direccioninstimod)
    {

        $conectar = dbconexion::conexion();
        $sql = "UPDATE instituciones SET NombreInstitucion = ?, CodigoRegistro = ?, ParroquiaInstitucion = ?, Sector = ?, Direccion = ? WHERE CodigoInstituciones = ?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $nombreinstimod);
        $sql->bindValue(2, $codigoregintimod);
        $sql->bindValue(3, $parroquiarinstimod);
        $sql->bindValue(4, $sectorinstimod);
        $sql->bindValue(5, $direccioninstimod);
        $sql->bindValue(6, $codinstimod);
        if ($sql->execute()) {
            return $resultado = self::get_documentos();
        }
    }


}
