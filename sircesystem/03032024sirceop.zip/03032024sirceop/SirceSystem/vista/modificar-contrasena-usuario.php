<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bienvenida</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
  

  <style>

    @font-face{
      font-family: opensan;
      src: url(fonts/googlesansnormal.woff2);

    }

    body{
      font-family: opensan;
      
    }

    #nombreusuario{
      animation: animacionletrabienvenida 1.5s ease-in-out ;

    }



    @keyframes animacionletrabienvenida { 
      0%{color: white;}
      /*50%{background-position:96% 100%}*/
      100%{color: black;}
    }

    #zonanombreusuario{
      box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
      -moz-box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
    }

        .successinput input {
      border-color: #2ecc71;
      border-width: 3.8px;
    }

    .errorinput input {
      border-color: #e74c3c;
      border-width: 3.8px;
    }

    .successinput select {
      border-color: #2ecc71;
      border-width: 3.8px;
    }

    .errorinput select {
      border-color: #e74c3c;
      border-width: 3.8px;
    } 

    small {
      color: #e74c3c;

      visibility: hidden;
    }

    .successinput small {
      color: #e74c3c;

      visibility: hidden;
    }

    .errorinput small {
      visibility: visible;
      font-size: 98%;
      font-weight: bold;
    }

  </style>

</head>
<body class="bg-gray">

    <?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>

 <?php include"../componentes/nav.php" ?>


  <div class="container border py-3 bg-white rounded-3 shadow" id="zonanombreusuario" 
        style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;">

      <div class="row mb-4 mt-2"> 
        <h4 class="text-center">Cambio de Contraseña</h4>
      </div>

      <form id="formcambiopassword" method="post">

          <div class="form-floating input-group">
            <input type="password" class="form-control" id="newpassworduser" name="newpassworduser" placeholder="ctr1" autocomplete="">
            <label for="newpassworduser">Ingrese Contraseña</label>
            <img class="input-group-text" id="imgnu" src="../icons/ojo-ver.svg" style="width: 50px; cursor: pointer;">
          </div>
            <div class="form-text invisible is-invalid" id="c_invalida">Contraseña Invalida</div>

          <script>
            const passnu = document.getElementById("newpassworduser"),
            iconnu = document.getElementById("imgnu");

            iconnu.addEventListener("click", e =>{
              if(passnu.type === "password") {
                passnu.type = "text";
                iconnu.src = "../icons/ojo-slash.svg";
              }else{
                passnu.type = "password";
                iconnu.src = "../icons/ojo-ver.svg";
              }
            })

          </script>

          <div class="form-floating input-group mb-3">
            <input type="password" class="form-control" id="newpassworduser2" name="newpassworduser2" placeholder="ctr2" autocomplete="usuario-161254789" autocomplete="usuario-161254789" autocomplete="usuario-161254789">
            <label for="newpassworduser2">Ingrese Nuevamente la Contraseña</label>
            <img class="input-group-text" id="imgnu2" src="../icons/ojo-ver.svg" style="width: 50px; cursor: pointer;">
          </div>
            <div class="form-text invisible p-0 m-0" id="c_noc">Las Contraseñas no coinciden</div>
            <div class="form-text invisible p-0 m-0" id="c_sic">Las Contraseñas coinciden</div>

          <script>
            const passnu2 = document.getElementById("newpassworduser2"),
            iconnu2 = document.getElementById("imgnu2");

            iconnu2.addEventListener("click", e =>{
              if(passnu2.type === "password") {
                passnu2.type = "text";
                iconnu2.src = "../icons/ojo-slash.svg";                 
              }else{
                passnu2.type = "password";
                iconnu2.src = "../icons/ojo-ver.svg";                 
              }
            })
          </script>

    <div class="row text-center">
      <div class="col col-sm-12">
        <button class="btn btn-secondary" type="reset" >Limpiar</button> 
        <button class="btn btn-primary" id="cambiarpassuser"  type="submit" name="cambiarpassuser">Cambiar</button>      
      </div>
    </div>


      </form>
    
       

  </div>

  <script src="../js/jquery.min.js"></script>
  <script src="../librerias/wall.js"></script>
  <script src="../js/cambiopassword.js"></script>

</body>
</html>