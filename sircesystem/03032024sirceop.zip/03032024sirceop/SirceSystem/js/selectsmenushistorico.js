    fetch('../controlador/institucionesfetch.php')
        .then(response => response.json())
        .then(data => {

            const wrapper = document.querySelector(".wrapper"),
selectBtn = wrapper.querySelector(".select-btn"),
searchInp = wrapper.querySelector(".search input"),
options = wrapper.querySelector(".options");



function addCountry(selectedCountry) {
    options.innerHTML = "";
    data.forEach(institucion => {
        let isSelected = institucion.NombreInstitucion == selectedCountry ? "selected" : "";
        let li = `<li onclick="updateName(this)" class="${isSelected}" data-value="${institucion.CodigoInstituciones}" >${institucion.NombreInstitucion}</li>`;
        options.insertAdjacentHTML("beforeend", li);
    });
}
addCountry();

window.updateName = (selectedLi) => {
    
  
    wrapper.classList.remove("active");
    selectBtn.firstElementChild.innerText = selectedLi.innerText;
    selectBtn.firstElementChild.dataset.value = selectedLi.dataset.value; 
};

/*searchInp.addEventListener("keyup", () => {
    let arr = [];
    let searchWord = searchInp.value.toLowerCase();
    arr = data.filter(institucion => {
        return institucion.NombreInstitucion.toLowerCase().startsWith(searchWord);
    }).map(institucion => {
        let isSelected = institucion.NombreInstitucion == selectBtn.firstElementChild.innerText ? "selected" : "";
        return `<li onclick="updateName(this)" class="${isSelected}" data-value="${institucion.CodigoInstituciones}">${institucion.NombreInstitucion}</li>`;
    }).join("");
    options.innerHTML = arr ? arr : `<p style="margin-top: 10px;">No esta Registrada esa Institucion</p>`;
});*/

selectBtn.addEventListener("click", () => wrapper.classList.toggle("active"));

        })
        .catch(error => console.error('Error:', error));



