const formnewuser = document.getElementById('asignar-rol');
const inputs = document.querySelectorAll('#asignar-rol input');




const validarformulario = async (e) => {
	switch (e.target.name) {
		case 'nombreunewuser':
			if(expr.usuario.test(e.target.value)){
				//validar si el nombre de usuario ya esta registrado, hacer la funcion
				let existe = await verificar_nombre_usuario(e.target.value);
				if (existe) {
					document.getElementById('nombreunewuser').classList.add('is-invalid');
					document.getElementById('n-valido').classList.remove('invisible');
					document.getElementById('n-valido').classList.add('visible');
				} else {
					document.getElementById('n-valido').classList.add('visible');
					document.getElementById('n-valido').classList.add('invisible');
					document.getElementById('nombreunewuser').classList.remove('is-invalid');
					document.getElementById('nombreunewuser').classList.add('is-valid');
					document.getElementById('n-no-valido').classList.add('invisible');
				}
			}else{
				document.getElementById('n-valido').classList.add('invisible');
				document.getElementById('nombreunewuser').classList.add('is-invalid');
				document.getElementById('nombreunewuser').classList.remove('is-valid');
				document.getElementById('n-no-valido').classList.remove('invisible');
				document.getElementById('n-no-valido').classList.add('visible');
			}
		break;

		case 'passnewuser':

			if(expr.pass.test(e.target.value)){
				document.getElementById('passnewuser').classList.add('is-valid');
				document.getElementById('passnewuser').classList.remove('is-invalid');
				document.getElementById('c_invalida').classList.add('invisible');
				document.getElementById('c_invalida').classList.remove('visible');
			}else{
				document.getElementById('passnewuser').classList.remove('is-valid');
				document.getElementById('passnewuser').classList.add('is-invalid');
				document.getElementById('c_invalida').classList.remove('invisible');
				document.getElementById('c_invalida').classList.add('visible');
			}

		break;

		case 'passnu2':

			const pass1 = document.getElementById('passnewuser');
			const pass2 = document.getElementById('passnu2');

			document.getElementById('passnu2').classList.remove('is-invalid');

			if (pass1.value !== pass2.value) {

				document.getElementById('passnu2').classList.remove('is-valid');
				document.getElementById('passnu2').classList.add('is-invalid');


				document.getElementById('c_noc').classList.remove('invisible');
				document.getElementById('c_noc').classList.add('visible');

				document.getElementById('c_sic').classList.remove('visible');
				document.getElementById('c_sic').classList.add('invisible');


			}else{
				document.getElementById('passnu2').classList.remove('is-invalid');
				document.getElementById('passnu2').classList.add('is-valid');


				document.getElementById('c_noc').classList.remove('visible');
				document.getElementById('c_noc').classList.add('invisible');


				document.getElementById('c_sic').classList.remove('invisible');
				document.getElementById('c_sic').classList.add('visible');
			}

		break;

	}
}



inputs.forEach((input) =>{
	input.addEventListener('keyup', validarformulario);
	input.addEventListener('blur', validarformulario);
})



formnewuser.addEventListener('submit', (e) => {
	e.preventDefault();

})


const expr = {
	usuario: /^[a-zA-Z0-9\_\-]{4,16}$/,
	pass: /^.{4,12}$/,
}

function verificar_nombre_usuario(user) {
    let urlVerificar = "../controlador/usuarios-control.php?op=check_nombre_usuario";
    let datosVerificar = new FormData();
    datosVerificar.append("nombreuser", user);

    return fetch(urlVerificar, {
        method: "post",
        body: datosVerificar,
    })
    .then((data) => data.json())
    .then((data) => data.existe)
    .catch((error) => console.log(`error: ${error}`));
}

