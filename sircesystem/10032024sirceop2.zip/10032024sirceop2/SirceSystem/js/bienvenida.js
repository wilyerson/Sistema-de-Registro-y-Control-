document.addEventListener('DOMContentLoaded', async function() {
    let paramsuser = new URLSearchParams(window.location.search);
    let iduser = paramsuser.get('id');

    localStorage.setItem("iduserid", iduser);

    let idusuariobit = localStorage.getItem("iduserid");
    console.log(idusuariobit);

    document.getElementById("nombreusersistema").value = idusuariobit;

    // Realizamos la solicitud POST para obtener el JSON
    try {
        const url = "../controlador/usuarios-control.php?op=buscarnombrebienvenida";
        const datos = new FormData(document.getElementById("fomridusernombre"));

        const response = await fetch(url, {
            method: "POST",
            body: datos, // Convierte los datos a formato JSON
            
        });

        if (!response.ok) {
            throw new Error(`Error al obtener los datos. Código de estado: ${response.status}`);
        }

        let responseData = await response.json();
        console.log(responseData)

        let nombreuserhtml = document.getElementById("nombreuser");
        nombreuserhtml.innerHTML = responseData[0].Nombres + " " + responseData[0].Apellidos;

    } catch (error) {
        console.error(`Error: ${error}`);
    }
});