const formdataregistrocargos = document.querySelector("#formregistrarcargos");
formdataregistrocargos.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formregistrarcargos"));

	console.log(" conectado");

	let url = "../controlador/ctr-cargos.php?op=guardar";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);

		var status = data.status;
		
		if (status == "cargo_registrado_exitosamente") {

			swal.fire({
				title: "Cargo Registrado Exitosamente!",
				icon: "success",
			});

		}	

		})
		.catch((error) => console.log(`error: ${error}`));
});