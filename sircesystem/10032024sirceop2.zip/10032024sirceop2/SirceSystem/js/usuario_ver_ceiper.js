const formdata = document.querySelector("#formbusquedapersonal");
formdata.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formbusquedapersonal"));

	    if (camposVaciosUsuario(datos)) {
        //console.log('Hay campos vacíos');
        return;
    }


	let url = "../controlador/usuarios-control.php?op=get_persona";
	fetch(url, {
		method: "post",
		body: datos,
	})
	.then((data) => data.json())
	.then((response) => {

		var status = response.status;
		var datos = response.data;
		console.log(datos);

		 let buscarcedu = document.getElementById('buscarcedu');

		switch (status){
		case 'registrado_en_ambas':
			buscarcedu.classList.remove('is-valid');
        	buscarcedu.classList.add('is-invalid');
        	swal.fire({
            title: "Esta Persona ya tiene un Usuario activo",
            text: "Nombre de Usuario: "+ datos.NombreUsuario,
            icon: "error"
        	});
			//alert("Esta Persona ya tiene un Usuario activo. \nNombre de Usuario: " + datos.NombreUsuario );
			break;

		case 'registrado_en_persona':
			$('#asignar-rol').modal("show");
			document.getElementById("codigopersonauser").value = datos.CodigoPersona;
			document.getElementById("cedulanewuser").value = datos.CedulaPersona;
			document.getElementById("nombrenewuser").value = datos.Nombres;
			document.getElementById("apellidosnewuser").value = datos.Apellidos;
			break;

		case 'no_registrado':
			$('#modal_comp_regp').modal("show");
			break;
		}

	})
	.catch((error) => console.log(`error: ${error}`));
});

function camposVaciosUsuario(datos) {

    let buscarcedu = document.getElementById('buscarcedu');
    

    const buscarceduvalue = buscarcedu.value.trim();
    
    
    let hayCamposVacios = false;

    //--------------------validando los inputs

    if (buscarceduvalue == "") {
        buscarcedu.classList.remove('is-valid');
        buscarcedu.classList.add('is-invalid');
        document.getElementById('validcedulavacia').classList.remove('invisible');
		document.getElementById('validcedulavacia').classList.add('visible');
        hayCamposVacios = true;
    } else {
        buscarcedu.classList.remove('is-invalid');
        buscarcedu.classList.add('is-valid');
        document.getElementById('validcedulavacia').classList.add('invisible');
		document.getElementById('validcedulavacia').classList.remove('visible');
    }

   

    return hayCamposVacios;
}

    // Obtén la referencia al campo de cédula
    let cedulauserinput = document.getElementById('buscarcedu');
    
    // Agrega el evento keyup al campo de cédula
    cedulauserinput.addEventListener('keyup', (e) => {

    let buscarcedu = document.getElementById('buscarcedu');
    

    let buscarceduvalue = buscarcedu.value.trim();

    if (buscarceduvalue == "") {
        buscarcedu.classList.remove('is-valid');
        //buscarcedu.classList.add('is-invalid');
        document.getElementById('validcedulavacia').classList.remove('invisible');
		//document.getElementById('validcedulavacia').classList.add('visible');
    } else {
        buscarcedu.classList.remove('is-invalid');
        buscarcedu.classList.add('is-valid');
        document.getElementById('validcedulavacia').classList.add('invisible');
		document.getElementById('validcedulavacia').classList.remove('visible');
    }

    });


