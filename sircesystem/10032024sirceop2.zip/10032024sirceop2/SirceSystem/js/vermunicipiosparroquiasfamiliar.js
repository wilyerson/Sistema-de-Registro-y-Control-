fetch('../controlador/municipiosfetchfamiliar.php')
.then(response => response.json())
.then(municipio2 => {
    var select = document.getElementById('idmunicipiofamiliar');
    municipio2.forEach(function(municipio) {
        var option = document.createElement('option');
        option.value = municipio.CodigoMunicipio;
        option.text = municipio.NombreMunicipio;
        select.add(option);
    });

    // Almacena el valor inicial del select
    var lastValue = select.value;

    
    setInterval(function() {
        if (select.value !== lastValue) {
            lastValue = select.value;  // Actualiza el valor almacenado
            let valuerealmunicipio = lastValue;
            console.log(valuerealmunicipio);

            // Encuentra la opción con el valor actual y la selecciona
            for (var i = 0; i < select.options.length; i++) {
                if (select.options[i].value === valuerealmunicipio) {
                    select.options[i].setAttribute('selected', 'selected'); // Añade el atributo 'selected'
                    break;
                }
            }

            updateParroquiasfami(valuerealmunicipio);
        }
    }, 250);
})
.catch(error => console.error('Error:', error));


function updateParroquiasfami(value) {
if(value) {
    fetch('../controlador/parroquiasfetchfamiliar.php?idmunicipiofamiliar='+value)
    .then(res2 => {
        if(!res2.ok){
            throw new Error('error en la respuesta');
        }
        return res2.json();
    })
    .then(datos => {
        let parroquiapersonanumero = localStorage.getItem("ParroquiaFaminumero");
        let parroquiapersonanombre = localStorage.getItem("ParroquiaFaminombre");
        let html = parroquiapersonanombre ? '<option value="'+parroquiapersonanumero+'">'+parroquiapersonanombre+'</option>' : '<option value="">Seleccione Parroquia</option>';
        if(datos.data.length > 0){
            for(let i = 0; i < datos.data.length; i++){
                html += `<option value="${datos.data[i].CodigoParroquia}">${datos.data[i].NombreParroquia}</option>`; 
            }
        }
        document.querySelector('#idparroquiafamiliar').innerHTML = html;
    })
    .catch(error => {
        console.error('ocurrio un error '+error);
    }); 
} else {
    document.querySelector('#idparroquiafamiliar').innerHTML = '<option value="">Seleccione Parroquia</option>';
}
}

// Agrega un evento 'change' al select de municipios para llamar a la función updateParroquias cada vez que cambia su valor
document.querySelector('#idmunicipiofamiliar').addEventListener('change', function() {
// Cuando el valor del select cambia, se eliminan los valores de localStorage
localStorage.removeItem("ParroquiaFaminumero");
localStorage.removeItem("ParroquiaFaminombre");
selectParroquia.innerHTML = '<option value="">Seleccione Parroquia</option>'; // Añade la opción por defecto
updateParroquias(this.value);
});