<?php
ob_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Reporte Documento</title>
</head>
<style>
.thestilo{
  border:1px solid black;
  border-collapse:collapse;
  padding: 8px;
  text-align: left;
  width:50%;
}
.tdestilo{
  border:1px solid black;
  border-collapse:collapse;
  padding: 8px;
  text-align: left;
  width:50%;

}
</style>
<body>
	
<?php
const SERVER="localhost";
const DB="sirceop";
const USER="root";
const PASS="";
const UTF8="utf8";

const SGBD="mysql:host=".SERVER.";dbname=".DB.";charset=".UTF8;

class dbconexion
{
    protected function conexion()
    {
        try {
            $con = new PDO(SGBD, USER, PASS);
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $con;
        } catch (PDOException $e) {
            echo "Conexion Fallida: " . $e->getMessage();
        }
    }

    public function getConexion() {
        return $this->conexion();
    }
}

$db = new dbconexion();
$conexion = $db->getConexion();

$id = $_GET['id'];
$sentenciaSQL = $conexion->prepare("SELECT   documento.NombreDocumento,
archivos.CodigoDocumento,
archivos.ArchivoRegistro,
archivos.archivosjpg, 
persona.CedulaPersona,
persona.Nombres,
persona.Apellidos,
persona.EstadoCivil,
persona.Sexo,
persona.FechaNacimiento,
persona.TelefonoPrincipal,
persona.TelefonoHabitacion
FROM
archivos
INNER JOIN documento on archivos.CodigoDocumento = documento.CodigoDocumento
INNER JOIN persona on archivos.idperarchivos = persona.CodigoPersona
WHERE archivos.idperarchivos = :id");
$sentenciaSQL->bindParam(':id', $id, PDO::PARAM_INT);
$sentenciaSQL->execute();
$ImagenesDocumentos = $sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);

?>

<h2>Datos de la Persona: </h2>

<table style="width:100%;  border-collapse:collapse; margin-bottom: 83%;">
  <tr>
    <th class="thestilo">Cedula de Identidad</th>
    <td class="tdestilo"><?php echo $ImagenesDocumentos[0]['CedulaPersona']; ?></td>
  </tr>
  <tr>
    <th class="thestilo">Nombres</th>
    <td class="tdestilo"><?php echo $ImagenesDocumentos[0]['Nombres']; ?></td>
  </tr>
    <tr>
    <th class="thestilo">Apellidos</th>
    <td class="tdestilo"><?php echo $ImagenesDocumentos[0]['Apellidos']; ?>s</td>
  </tr>
  <tr>
    <th class="thestilo">Estado Civil</th>
    <td class="tdestilo"><?php echo $ImagenesDocumentos[0]['EstadoCivil']; ?></td>
  </tr>
  <tr>
    <th class="thestilo">Sexo</th>
    <td class="tdestilo"><?php echo $ImagenesDocumentos[0]['Sexo']; ?></td>
  </tr>
  <tr>
    <th class="thestilo">Fecha de Nacimiento</th>
    <td class="tdestilo"><?php echo $ImagenesDocumentos[0]['FechaNacimiento']; ?></td>
  </tr>
    <tr>
    <th class="thestilo">Numero telefonico Principal</th>
    <td class="tdestilo"><?php echo $ImagenesDocumentos[0]['TelefonoPrincipal']; ?></td>
  </tr>
    <tr>
    <th class="thestilo">Numero Telefonico Habitacion</th>
    <td class="tdestilo"><?php echo $ImagenesDocumentos[0]['TelefonoHabitacion']; ?></td>
  </tr>

</table>

<?php 
$documentosCount = count($ImagenesDocumentos);
foreach($ImagenesDocumentos as $index => $documentos) { ?>
<table>
	<thead>
		<tr>
			
			<th><?php echo $documentos['NombreDocumento']; ?></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			
			<td>
			<img class="imgdocumento" src="http://<?php echo $_SERVER['HTTP_HOST'];?>/SirceSystem/controlador/<?php echo $documentos['archivosjpg']; ?>" width="750" height="930">
			</td>
		</tr>
	</tbody>
</table>
<?php if($index != $documentosCount - 1) { ?>
<div style="page-break-after: always;"></div>
<?php } ?>
<?php } ?>

</body>
</html>
<?php 

$html = ob_get_clean();

require_once '../librerias/dompdf/autoload.inc.php';
use Dompdf\Dompdf;
$dompdf = new Dompdf();

$options = $dompdf->getOptions();
$options->set(array('isRemoteEnabled' => true));
$dompdf->setOptions($options);

$dompdf->loadHtml($html);
$dompdf->setPaper('letter');

$dompdf->render();
$dompdf->stream("archivo.pdf", array("Attachment" => false));

?>