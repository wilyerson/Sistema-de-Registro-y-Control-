<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SIRCE</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
 
  

  <style>

    @font-face{
      font-family: opensan;
      src: url(fonts/googlesansnormal.woff2);

    }

    body{
      font-family: opensan;
      
    }

    #nombreusuario{
      animation: animacionletrabienvenida 1.5s ease-in-out ;

    }

    @keyframes animacionletrabienvenida { 
      0%{color: white;}
      /*50%{background-position:96% 100%}*/
      100%{color: black;}
    }

    #zonanombreusuario{
      box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
      -moz-box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
    }

    #divmismovimientos{
      display: none;
    }

    #botonmovimientosusuarios{
position: relative;
    left: 90%;
    top: 50%;
    transform: translate(-187%, -95%);
    }

    #botonmismovimientos{
position: relative;
    left: 90%;
    top: 50%;
    transform: translate(-417%, 47%);
    }

    #botonmostrarlosusuarios{
    position: relative;
    left: 50%;
    top: 50%;
    transform: translate(-129%, 7%);
    }

    #mostraruserdiv{
      display: none;
    }

    #listadeusuarios{
      display: none;
position: relative;
    top: 20%;
    transform: translate(0%, -17%);
    }

    #expandirmodal{
position: relative;
    width: 187%;
    height: 90%;
    left: 50%;
    transform: translate(-50%, 2%);
    }

    #nombredeusuario{
    position: relative;
    left: 50%;
    transform: translate(57%, -110%);    
  }

    #buscarusuariobitacora{
    position: relative;
    left: 50%;
    transform: translate(-2%, -115%);
    width: 23%;
  }
    

    #botonbuscarusuarios{
position: relative;
    left: 80%;
    transform: translate(-70%, -257%);
    }

    #selectfilterbitacora{
      width: 20%;
    }

       /* #buscardatobitacora{
    position: relative;
    left: 25%;
    transform: translate(-2%, -137%);
    width: 28%;
      padding: 0.5rem 0.5rem;
  line-height: 1;
  border-radius: 0.5rem;
  border: 2px solid hsl(296 3% 93%);
  background: hsl(0 0% 100%);
  color: hsl(212 2% 18%);
  padding-right: 3rem;
  outline-color: hsl(228, 100%, 69%);
    }*/

    #buscardatobitacora{
    position: relative;
    left: 25%;
    transform: translate(-2%, -137%);
    width: 28%;
    }


  </style>

</head>
<body class="bg-gray">

    <?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>

    <?php include"../componentes/nav.php" ?>
  
    <input type="hidden" name="iduser" id="iduser" value="<?php echo $_SESSION['iduser'];?>">

  <div class="container rounded border py-3 bg-white" id="zonanombreusuario" 
        style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;">

  <form id="formumismovimientos" method="post">

    <input type="hidden" name="nameuser" id="nameuser" value="">

    <button id="botonmismovimientos" type="submit" class="btn btn-primary" onclick="ocultarmostrarusuarios()">Mis Movimientos</button>
  </form>
   
  <button id="botonmovimientosusuarios" type="button" class="btn btn-primary" onclick="activarmostrausuarios(), ocultarmismovimientos()">Movimientos de Usuarios</button>

    <div class="container mt-4" id="divmismovimientos">

  <select class="form-select" name="selectfilterbitacora" id="selectfilterbitacora" onchange="">
  <option selected disabled value="">Seleccion un filtro</option>
  <option value="Todos">Todos</option>
  <option value="Registro">Registro</option>
  <option value="Modificacion">Modificacion</option>
  <option value="Sesion">Sesiones</option>
    </select>
    <br>

    <input type="text" name="buscardatobitacora" id="buscardatobitacora" placeholder="Buscar" class="form-control form-control-lg">

    <table class="table table-bordered">
      <thead>
        <tr>
          <th scope="col" class="text-center">Id Registro</th>
          <th scope="col" class="text-center">Cedula Persona</th>
          <th scope="col" class="text-center">Fecha</th>
          <th scope="col" class="text-center">Actividad Realizada</th>
          <th scope="col" class="text-center">Informacion Actual</th>
        </tr>
      </thead>
      <tbody id="mismovimientos">
        
      </tbody>
    </table>

    <!-- paginacion -->

     <nav aria-label="Page navigation example" >
              <ul class="pagination">
                <li class="page-item">
                  <button class="page-link" onclick="previusPage()">
                    <span aria-hidden="true">&laquo;</span>
                  </button>
                </li>

                <div id="items" class="d-flex"></div>

                <li class="page-item">
                  <button class="page-link" onclick="nextPage()">
                    <span aria-hidden="true">&raquo;</span>
                  </button>
                </li>
              </ul>
            </nav>

    <!-- fin paginacion -->

  </div>
        </form>

  </div>



 <div class="container rounded border py-3 bg-white" id="mostraruserdiv">

 <form id="formumismostrarusuariosbitacora" method="post">

 <button id="botonmostrarlosusuarios" type="submit" class="btn btn-primary">Mostrar todos los Usuarios</button>

</form>

 <form id="formbuscarusuariobitacora" method="post">


  <input type="text" id="buscarusuariobitacora" name="buscarusuariobitacora" class="form-control form-control-lg" placeholder="buscar usuario">
 <button id="botonbuscarusuarios" type="submit" class="btn btn-primary">buscar</button>

</form>

<div class="container mt-4" id="listadeusuarios">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th scope="col" class="text-center">Id Usuario</th>
          <th scope="col" class="text-center">Usuario</th>
          <th scope="col" class="text-center">Rol Usuario</th>
          <th scope="col" class="text-center">Estatus Usuario</th>
          <th scope="col" class="text-center">Informacion Actual</th>
        </tr>
      </thead>
      <tbody id="mostrarusuarios">
        
      </tbody>
    </table>
   
</div>





  </div>


  
 <div class="modal fade" id="mostrarmovimientosuser" tabindex="-1"  aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" id="expandirmodal">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel" style="position: relative;top: 31%;left: 3%;">Movimientos del usuario : <div id="nombredeusuario"></div></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" >
       

 
    <table class="table table-bordered">
      <thead>
        <tr>
          <th scope="col" class="text-center">Id Registro</th>
          <th scope="col" class="text-center">Id Persona</th>
          <th scope="col" class="text-center">Fecha</th>
          <th scope="col" class="text-center">Actividad Realizada</th>
          <th scope="col" class="text-center">Informacion Actual</th>
        </tr>
      </thead>
      <tbody id="mismovimientosusuario">
        
      </tbody>
    </table>
   



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>



<script src="../js/jquery.min.js"></script>
<script src="../js/bitacora.js"></script>
<script src="../js/bitacoramostrarusuarios.js"></script>
<script src="../js/buscarusuariobitacora.js"></script>
<script src="../js/manejosdivs.js"></script>
<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../js/traerdatosuserbitacora.js"></script>


</body>
</html>