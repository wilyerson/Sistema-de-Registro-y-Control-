<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SIRCE</title>	
	<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
	

	<style type="text/css">

		@font-face{
			font-family: opensan;
			src: url(fonts/googlesansnormal.woff2);

		}

		body{
			font-family: opensan;
		}
		.inputcedulaestilo{
			display: none;
		}

		.imagregistrodocumento{
			width: 100px;
		}

		.formu-control.success input {
			border-color: #2ecc71;
		}

		.formu-control.error input {
			border-color: #e74c3c;
		}

		.formu-control.success select {
			border-color: #2ecc71;
		}

		.formu-control.error select {
			border-color: #e74c3c;
		}

		.formu-control .fas {
			visibility: hidden;
			}

		.formu-control.success .fas.fa-check-circle {
			color: #2ecc71;
			visibility: visible;
		}

		.formu-control.error .fas.fa-exclamation-circle {
			color: #e74c3c;
			visibility: visible;
		}

		.formu-control small {
			color: #e74c3c;
		  /*position: absolute;
		  bottom: 0;
		  left: 0;*/
		  visibility: hidden;
		}

		.formu-control.error small {
			visibility: visible;

		}

	    .btn-ver-campos{
	    	width:90px;
	    }

	    #td{
	    	width:90px;
	    }

	</style>

</head>

<?php 

session_start();

if(!isset($_SESSION['usuarioad']))
{
	header("Location: ../index.php");
}



?>

<body class="bg-gray pb-5">

	

	<?php include"../componentes/nav.php" ?>

	<div class="container border rounded py-3 bg-white shadow-lg" style="max-width: 1000px; margin-top: 100px; ">
		
		<div class="row px-3 pt-3 pb-1">
			<h4 class="d-flex justify-content-center align-items-center">Gestión de Usuarios</h4>
		</div>
		<div class="pb-3">
			<hr>
		</div>

		<div class="row d-flex align-items-center">
			<div class="col-md-3 col-sm-12">
				<div class="nav nav-pills flex-column mx-0" id="nav-tabs" role="tablist">

					<button class="nav-link active"  id="registro-tab" data-bs-toggle="pill" data-bs-target="#registro" type="button" role="tab" aria-controls="registro-tab" aria-selected="true">Registrar Usuarios </button>

					<button class="nav-link"  id="crear-tab" data-bs-toggle="pill" data-bs-target="#crear" type="button" role="tab" aria-controls="crear-tab" aria-selected="false">Registar Usuarios Externos</button>

				</div>
			</div>
			<div class="col-sm-12 col-md-9">

				<div class="tab-content" id="nav-tabContent" style="padding: 0px 0px 10px 20px;">
					
					<!-- ///////////////////////////////////////PILLS REGISTRAR/////////////////////////////////////////// -->
					<div class="tab-pane fade show active" id="registro" role="tab-panel" aria-labelledby="registro-tab">

						<form id="formbusquedapersonal" method="post">

							<div class="form-text mb-2">
								Los Usuarios listados solo laboran y mantienen un estatus activo dentro de la Dirección de Personal. <br> De lo contrario, debe registrar al usuario como personal de la institución y hacer un registro laboral actual para tener el estatus activo
							</div>

							<div class="row">
								<div class="input-group">
									<select class="form-select" style="width: 10%;">  
										<option value="v">V</option>
										<option value="e">E</option>  
										<option value="p">P</option>
									</select>

									<input type="number" style="width:90%; " id="buscarcedu" name="buscarcedu" class="form-control " placeholder="Cédula de Identidad" aria-label="Text input with dropdown button" >

									<p id="resultado" ></p>

									<div id="passwordHelpBlock" class="form-text">
									</div>

									<div class="invisible invalid-tooltip" id="validcedulavacia">
										Ingrese una Cedula
									</div>

								</div>

								<div id="passwordHelpBlock" class="form-text">
								</div>

								<div class="d-flex justify-content-center mt-1">

									<button type="submit" id="botonasignar-rol" class="btn btn-primary" >Asignar Rol</button>

								</div>
							</div>

						</form>

					</div>
					<!-- ///////////////////////////////////////PILLS REGISTRAR/////////////////////////////////////////// -->

					<!-- ///////////////////////////////////////PILLS AYUDA/////////////////////////////////////////////// -->

					<div class="tab-pane fade show" id="crear" role="tab-panel" aria-labelledby="registro-tab">

						<!-- <form id="formusuarioayuda" method="post"  class="campos formu-control">

							<div class="row">
								<div class="input-group" name="tipo-ci">
									<select class="form-select" style="width: 10%;">  
										<option value="v">V</option>
										<option value="e">E</option>  
										<option value="p">P</option>
									</select>

									<input type="number" style="width:90%; " id="buscarcedu" name="buscarcedu" class="form-control " placeholder="Cédula de Identidad" aria-label="button" >

									<small>Error message</small>	

									<p id="resultado" ></p>

									<div id="passwordHelpBlock" class="form-text">
									</div>

								</div>

								<div id="passwordHelpBlock" class="form-text">
								</div>

							</div>

						</form> -->

						<div class="form-text">
							Los Usuarios de Ayuda no laboran ni mantienen un estatus activo dentro de la Dirección de Personal. <br>
							Se hara un Registro de sus Datos de Igual Manera
						</div>

						<div class="d-flex mt-md-3 justify-content-center">
							<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#botoncrearusuario-ayuda">
								Registrar Usuario Externo
							</button>
						</div>

					</div>

					<!-- ///////////////////////////////////////PILLS AYUDA/////////////////////////////////////////////// -->
				</div><!-- cierrepills -->
			</div>
		</div>

	</div><!-- cierre container --> 


	<div class="container border rounded py-3 bg-white shadow-lg" style="max-width: 1000px; margin-top: 20px; ">

		<div class="row p-2 ">
			<h4 class="d-flex justify-content-center align-items-center mb-4 mt-3">Listado de Usuarios</h4>
		</div>
			
		<div class="row justify-content-md-center table-responsive px-3 py-3">
			<table class="table table-hover" >
			  	<thead>
				    <tr>
				      <th scope="col" class="text-center">Personal</th>
				      <th scope="col" class="text-center">Tipo</th>
				      <th scope="col" class="text-center">Nombre de Usuario</th>
				      <th scope="col" colspan="2" class="text-center">Acción</th>
				    </tr>
			  	</thead>
				  <tbody id="MostrarUsuarios"></tbody>
			</table>
		</div>

	</div>


	<!-- -----------------------------MODAL 1------------------------------- -->


	<div class="modal fade" id="asignar-rol" tabindex="-1" data-bs-backdrop="static" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-md">
			<div class="modal-content">


					<div class="modal-header" style="background-color: #009aff;">
						<h5 class="modal-title" id="exampleModalLabel" style="color: white;">Asignación de Rol</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">

					<div class="form-floating mb-3">
						<input type="text" class="form-control" id="cedulanewuser" disabled value="" name="cedulaayuda" placeholder="name@example.com">
						<label for="cedulaayuda">Cédula de Identidad</label>
					</div>

					<div class="form-floating mb-3">
						<input type="text" class="form-control" id="nombrenewuser" disabled value="" name="nombreayuda" placeholder="name@example.com">
						<label for="nombreayuda">Ingrese Nombres</label>
					</div>

					<div class="form-floating mb-3">
						<input type="text" class="form-control" id="apellidosnewuser" disabled value="" name="apellidosayuda" placeholder="name@example.com">
						<label for="apellidosayuda">Ingrese Apellidos</label>
					</div>

				<form id="formulariosuario" method="post" >
					<input type="hidden" id="codigopersonauser" name="codigopersonauser" value="">
					<input type="hidden" id="estatususuarioinput" name="estatususuarioinput" value="usuarioactivo">

					<div class="form-floating mb-3">
						<select class="form-select" id="tipouser" name="tipouser" aria-label="Floating label select example">
							<option selected disabled value="">Seleccione</option>
							<option value="analista">Analista</option>
							<option value="consulta">Consulta</option>
						</select>
						<label for="tipouser">Seleccione Rol de Usuario</label>
					</div>

					<div>
						<hr>
						<p class="text-center m-2">Datos de Inicio de Sesion</p>
						<hr>
					</div>

					<div class="form-floating mb-3">
						<input type="text" class="form-control" id="nombreunewuser" name="nombreunewuser" placeholder="nombre" autocomplete="usuario-161254789">
						<label for="nombreunewuser" autocomplete="">Ingrese Nombre de Usuario</label>
						<div class="invalid-feedback invisible p-0 m-0" id="n-no-valido">Nombre de Usuario no Valido</div>
						<div class="form-text invalid-feedback invisible p-0 m-0" id="n-valido">Este Nombre de Usuario ya está siendo usado</div>
					</div>

					<div class="form-floating input-group">
						<input type="password" class="form-control" id="passnewuser" name="passnewuser" placeholder="ctr1" autocomplete="">
						<label for="passnewuser">Ingrese Contraseña</label>
						<img class="input-group-text" id="imgnu" src="../icons/ojo-ver.svg" style="width: 50px; cursor: pointer;">
					</div>
						<div class="form-text invisible is-invalid" id="c_invalida">Contraseña Invalida</div>

					<script>
						const passnu = document.getElementById("passnewuser"),
						iconnu = document.getElementById("imgnu");

						iconnu.addEventListener("click", e =>{
							if(passnu.type === "password") {
								passnu.type = "text";
								iconnu.src = "../icons/ojo-slash.svg";
							}else{
								passnu.type = "password";
								iconnu.src = "../icons/ojo-ver.svg";
							}
						})

					</script>

					<div class="form-floating input-group mb-3">
						<input type="password" class="form-control" id="passnu2" name="passnu2" placeholder="ctr2" autocomplete="usuario-161254789" autocomplete="usuario-161254789" autocomplete="usuario-161254789">
						<label for="passnu2">Ingrese Nuevamente la Contraseña</label>
						<img class="input-group-text" id="imgnu2" src="../icons/ojo-ver.svg" style="width: 50px; cursor: pointer;">
					</div>
						<div class="form-text invisible p-0 m-0" id="c_noc">Las Contraseñas no coinciden</div>
						<div class="form-text invisible p-0 m-0" id="c_sic">Las Contraseñas coinciden</div>

					<script>
						const passnu2 = document.getElementById("passnu2"),
						iconnu2 = document.getElementById("imgnu2");

						iconnu2.addEventListener("click", e =>{
							if(passnu2.type === "password") {
								passnu2.type = "text";
								iconnu2.src = "../icons/ojo-slash.svg";									
							}else{
								passnu2.type = "password";
								iconnu2.src = "../icons/ojo-ver.svg";									
							}
						})
					</script>


					<div class="">
						<input type="hidden" class="form-control" id="tipopersonaayuda" name="tipopersonaayuda" value="personaldeayuda">
					</div>

					<div class="">
						<div class="">
							<input type="hidden" class="form-control" id="estatusayuda" name="estatusayuda" value="inactivo">
						</div>
					</div>

					<input type="hidden" name="estatususuario" id="estatususuario" value="usuarioactivo">
					</div>

					<div class="modal-footer">
						<button type="reset" id="botonresetlocal" class="btn btn-secondary">Limpiar</button>
						<button type="submit"  class="btn btn-primary">Registrar Usuario</button>
					</div>

					<div class="toast align-items-center text-white bg-secondary border-0" id="toastusercampovacios" role="alert" aria-live="assertive" aria-atomic="true" style=" position: relative; left: 25%; top: 50%; transform: translate(-15%, -290%); margin-bottom: -9%;">
					  <div class="d-flex">
					    <div class="toast-body ">
					      Hay Campos Vacios
					    </div>
					    <!--<button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>-->
					  </div>
					</div>

				</form>
			</div>
		</div>
	</div>

	<!-- -----------------------------MODAL 1------------------------------- -->


	<!-- -----------------------------MODAL 3------------------------------- -->

	<div class="modal fade" id="botoncrearusuario-ayuda" data-bs-backdrop="static" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-md">
			<div class="modal-content">
				<form id="formuregayuda" method="post" autocomplete="usuario-161254789">
					<div class="modal-header" style="background-color: #009aff;">
						<h5 class="modal-title" id="exampleModalLabel" style="color: white;">Asignación de Rol</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">

						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="cedulaayuda" name="cedulaayuda" placeholder="name@example.com">
							<label for="cedulaayuda">Cédula de Identidad</label>
						</div>

						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="nombreayuda" name="nombreayuda" placeholder="name@example.com">
							<label for="nombreayuda">Ingrese Nombres</label>
						</div>

						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="apellidosayuda" name="apellidosayuda" placeholder="name@example.com">
							<label for="apellidosayuda">Ingrese Apellidos</label>
						</div>

						<div class="form-floating mb-3">
							<input type="number" class="form-control " id="telefonoayudap" name="telefonoayudap" placeholder="name@example.com">
							<label for="telefonoayudap">Ingrese Número Telefónico Principal</label>
						</div>

						<div class="form-floating mb-3">
							<input type="number" class="form-control" id="telefonoayudas" name="telefonoayudas" placeholder="name@example.com">
							<label for="telefonoayudas">Ingrese Número Telefónico de Habitación</label>
						</div>

						<div class="form-floating mb-3">
							<input type="email" class="form-control" id="emailayuda" name="emailayuda" placeholder="name@example.com">
							<label for="emailayuda">Ingrese Correo Electrónico</label>
						</div>

						<div class="form-floating mb-3">
							<input type="date" class="form-control" id="fechanacayuda" name="fechanacayuda" placeholder="name@example.com">
							<label for="fechanacayuda">Ingrese Fecha de Nacimiento</label>
						</div>

						<div class="form-floating">
							<textarea class="form-control" placeholder="Leave a comment here" id="direccionuayuda" name="direccionuayuda"></textarea>
							<label for="direccionuayuda">Ingrese Dirección</label>
						</div>

						<div>
							<hr>
							<p class="text-center mb-2">Datos de Inicio de Sesion</p>
							<hr>
						</div>

						<div class="form-floating mb-3">
							<input type="text" class="form-control" id="nombreuserayuda1" name="nombreuserayuda1" placeholder="nombre" autocomplete="usuario-161254789">
							<label for="nombreuserayuda1" autocomplete="usuario-161254789">Ingrese Nombre de Usuario</label>
						</div>

						<div class="form-floating mb-3" >
							<input type="text" class="form-control" id="nombreuserayuda2" name="nombreuserayuda2" placeholder="nombre2" autocomplete="usuario-161254789">
							<label for="nombreuserayuda2">Ingresar Nuevamente Nombre de Usuario</label>
						</div>

						<div class="form-floating input-group  mb-3">
							<input type="password" class="form-control" id="passayuda1" name="passayuda1" placeholder="ctr1" autocomplete="usuario-161254789">
							<label for="passayuda1">Ingrese Contraseña</label>
							<img class="input-group-text" id="img1" src="../icons/ojo-ver.svg" style="width: 50px; cursor: pointer;">
						</div>

						<script>
							const pass = document.getElementById("passayuda1"),
									icon = document.getElementById("img1");

							icon.addEventListener("click", e =>{
								if(pass.type === "password") {
									pass.type = "text";
									icon.src = "../icons/ojo-slash.svg";
								}else{
									pass.type = "password";
									icon.src = "../icons/ojo-ver.svg";
								}
							})

						</script>

						<div class="form-floating input-group mb-3">
							<input type="password" class="form-control" id="passayuda2" name="passayuda2" placeholder="ctr2" autocomplete="usuario-161254789" autocomplete="usuario-161254789" autocomplete="usuario-161254789">
							<label for="passayuda2">Ingrese Nuevamente la Contraseña</label>
							<img class="input-group-text" id="img2" src="../icons/ojo-ver.svg" style="width: 50px; cursor: pointer;">
						</div>

						<script>
							const pass2 = document.getElementById("passayuda2"),
									icon2 = document.getElementById("img2");

							icon2.addEventListener("click", e =>{
								if(pass2.type === "password") {
									pass2.type = "text";
									icon2.src = "../icons/ojo-slash.svg";									
								}else{
									pass2.type = "password";
									icon2.src = "../icons/ojo-ver.svg";									
								}
							})
						</script>


						<div class="">
							<input type="hidden" class="form-control" id="tipopersonaayuda" name="tipopersonaayuda" value="personaldeayuda">
						</div>

						<div class="row">
							<div class="">
								<input type="hidden" class="form-control" id="estatusayuda" name="estatusayuda" value="inactivo">
							</div>
						</div>
						
					</div>

					<div class="modal-footer">
						<button type="reset" class="btn btn-secondary">Limpiar</button>
						<button type="submit" class="btn btn-primary">Registar</button>
					</div>

				</form>				
			</div>
		</div>
	</div>


	<!-- -----------------------------MODAL 3------------------------------- -->

	<!-- -----------------------------MODAL 4------------------------------- -->
	<div class="modal fade" id="modal_comp_regp" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header" style="background-color: #009aff;">
					<h5 class="modal-title" id="exampleModalLabel"></h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<h4 class="text-center">Esta Cédula de Identidad no está registrada en el sistema</h4><br>
					<p class="text-center">¿Desea registrarla como Personal?</p>
				</div>
				<div class="m-3 d-flex justify-content-center">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal" style="margin: 5px">Cerrar</button>

					<a href="../vista/registro-persona2.php" class="btn btn-primary" style="margin: 5px">Registrar</a>
				</div>
			</div>
		</div>
	</div>
	<!-- -----------------------------MODAL 4------------------------------- -->





<script src="../js/jquery.min.js"></script>
<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../librerias/wall.js"></script>
<script src="../js/usuario_ver_ceiper.js"></script>
<script src="../js/usuarioVefNew.js"></script>
<script src="../js/usuario-registro.js"></script>
<script src="../js/usuariosDibtabla.js"></script>
<script src="../js/UsuariosGet.js"></script>

</body>
</html>