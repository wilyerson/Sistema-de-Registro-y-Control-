function camposVacios(datos) {
    let cedula = datos.get("cedulapersona");
    let estadocivil = datos.get("estadocivil");
    let nombres = datos.get("nombrespersonal");
    let apellidos = datos.get("apellidospersonal");
    let fechanacimiento = datos.get("fechanacimiento");
    let sexo = datos.get("sexo");
    let telefonoprincipal = datos.get("telefonoprincipal");
    let telefonohabitacion = datos.get("telefonohabitacion");

    
    let cedulapersonainput = document.getElementById('cedulapersona');
    let estadocivilpersonainput = document.getElementById('estadocivil');
    let nombrespersonainput = document.getElementById('nombrespersonal');
    let apellidospersonainput = document.getElementById('apellidospersonal');
    let fechanacimientopersonainput = document.getElementById('fechanacimiento');
    let sexopersonainput = document.getElementById('sexo');
    let telefonoprincipalpersonainput = document.getElementById('telefonoprincipal');
    let telefonohabitacionpersonainput = document.getElementById('telefonohabitacion');


    const estadocivilvalue = estadocivilpersonainput.value.trim();
    const sexovalue = sexopersonainput.value.trim();



    let hayCamposVacios = false;

    //----------------------comprabamos la edad
		const calcularEdad = (fechanacimientop) => {
			const fechaActual = new Date();
			const anoActual = parseInt(fechaActual.getFullYear());
			const mesActual = parseInt(fechaActual.getMonth()) + 1;
			const diaActual = parseInt(fechaActual.getDate());
		
			// 2023-02-22
			const anoNacimiento = parseInt(String(fechanacimientop).substring(0, 4));
			const mesNacimiento = parseInt(String(fechanacimientop).substring(5, 7));
			const diaNacimiento = parseInt(String(fechanacimientop).substring(8, 10));
		
			let edad = anoActual - anoNacimiento;
			if (mesActual < mesNacimiento) {
				edad--;
			} else if (mesActual === mesNacimiento) {
				if (diaActual < diaNacimiento) {
					edad--;
				}
			}
			return edad;
		};
	
		let edadpersonareg = calcularEdad(fechanacimientopersonainput.value);
		console.log(edadpersonareg);

	//--------------------validando los inputs

    if (cedula == "") {
		setErrorFor(cedulapersonainput, 'Ingrese la Cedula');
		hayCamposVacios = true;
	} else {
		setSuccessFor(cedulapersonainput);
	}

    if (estadocivilvalue == "") {
		setErrorFor(estadocivilpersonainput, 'Ingrese el Estado Civil');
		hayCamposVacios = true;
	} else {
		setSuccessFor(estadocivilpersonainput);
	}

    if (nombres == "") {
		setErrorFor(nombrespersonainput, 'Ingrese el Nombre');
		hayCamposVacios = true;
	} else {
		setSuccessFor(nombrespersonainput);
	}

    if (apellidos == "") {
		setErrorFor(apellidospersonainput, 'Ingrese el Apellido');
		hayCamposVacios = true;
	} else {
		setSuccessFor(apellidospersonainput);
	}

    if(fechanacimiento == "") {
        setErrorFor(fechanacimientopersonainput, 'Ingrese la Fecha de Nacimiento');
        hayCamposVacios = true;
      } else if (edadpersonareg <= 17) {
        setErrorFor(fechanacimientopersonainput, 'No se puede registrar menores de 18 años ');
        hayCamposVacios = true;
      } else {
        setSuccessFor(fechanacimientopersonainput);
      }

    if (sexovalue == "") {
		setErrorFor(sexopersonainput, 'Ingrese el Sexo');
		hayCamposVacios = true;
	} else {
		setSuccessFor(sexopersonainput);
	}

    if (telefonoprincipal == "") {
		setErrorFor(telefonoprincipalpersonainput, 'Ingrese el Telefono Principal');
		hayCamposVacios = true;
	} else {
		setSuccessFor(telefonoprincipalpersonainput);
	}

    if (telefonohabitacion == "") {
		setErrorFor(telefonohabitacionpersonainput, 'Ingrese el Telefono Habitacion');
		hayCamposVacios = true;
	} else {
		setSuccessFor(telefonohabitacionpersonainput);
	}

    

    // Agrega más condiciones aquí para los otros campos

    return hayCamposVacios;
}

function verificarCedula(cedula) {
    let urlVerificar = "../controlador/ctr-personas.php?op=verificarcedula";
    let datosVerificar = new FormData();
    datosVerificar.append("cedulapersona", cedula);

    return fetch(urlVerificar, {
        method: "post",
        body: datosVerificar,
    })
    .then((data) => data.json())
    .then((data) => {

        var status = data.status;
		var datos = data.data;

        if (status == "cedula existe") {

            document.getElementById("estadocivil").value = datos[0].EstadoCivil;
            document.getElementById("nombrespersonal").value = datos[0].Nombres;
            document.getElementById("apellidospersonal").value = datos[0].Apellidos;
            document.getElementById("fechanacimiento").value = datos[0].FechaNacimiento;
            document.getElementById("sexo").value = datos[0].Sexo;
            document.getElementById("telefonoprincipal").value = datos[0].TelefonoPrincipal;
            document.getElementById("telefonohabitacion").value = datos[0].TelefonoHabitacion;
            /*document.getElementById("id_mun").value = datos[0].masculino;
            document.getElementById("parroquiareg").value = datos[0].masculino;
            document.getElementById("sector").value = datos[0].masculino;
            document.getElementById("direccion").value = datos[0].masculino;
            document.getElementById("peso").value = datos[0].masculino;
            document.getElementById("estatura").value = datos[0].masculino;
            document.getElementById("tallacamisa").value = datos[0].masculino;
            document.getElementById("tallapantalon").value = datos[0].masculino;
            document.getElementById("tallacalzado").value = datos[0].masculino;*/
            
            return true;
        } else {

            document.getElementById("estadocivil").value = "";
            document.getElementById("nombrespersonal").value = "";
            document.getElementById("apellidospersonal").value = "";
            document.getElementById("fechanacimiento").value = "";
            document.getElementById("sexo").value = "";
            document.getElementById("telefonoprincipal").value = "";
            document.getElementById("telefonohabitacion").value = "";

            return false;
        }
    })
    .catch((error) => console.log(`error: ${error}`));
}

function setErrorFor(input, message) {
	const formControl = input.parentElement;
	const small = formControl.querySelector('small');
	formControl.classList.add('errorinput'); // Agrega la clase 'errorinput'
	small.innerText = message;
  }
  
  function setSuccessFor(input) {
	const formControl = input.parentElement;
	formControl.classList.remove('errorinput');
	formControl.classList.add('successinput');
  
  }

function limpiarformuregperson() {
			let mensajes = document.querySelectorAll("div");
			mensajes.forEach((div) => {
			div.classList.remove('errorinput');	
			div.classList.remove('successinput');
		});
	}

    //------------------buscando la cedula para validar si existe
    let formulario = document.querySelector("#regpersonalform");

    // Obtén la referencia al campo de cédula
    let cedulapersonainput = document.getElementById('cedulapersona');
    
    // Agrega el evento keyup al campo de cédula
    cedulapersonainput.addEventListener('keyup', (e) => {
        const datos = new FormData(document.getElementById("regpersonalform"));
        verificarCedula(datos.get("cedulapersona")).then((existe) => {
            if (existe) {
                setErrorFor(cedulapersonainput, 'Esta Cedula ya Existe');
                
            } else {
                setSuccessFor(cedulapersonainput);
            }
        }).catch((error) => console.log(`error: ${error}`));
    });

    //--------------------buscando la fecha para validar 
    let fechanacimientopersonainput = document.getElementById('fechanacimiento');

// Agrega el evento keyup al campo de fecha de nacimiento
fechanacimientopersonainput.addEventListener('keyup', (e) => {
    let fechanacimiento = e.target.value;

    const calcularEdad = (fechanacimientop) => {
        const fechaActual = new Date();
        const anoActual = parseInt(fechaActual.getFullYear());
        const mesActual = parseInt(fechaActual.getMonth()) + 1;
        const diaActual = parseInt(fechaActual.getDate());
    
        // 2023-02-22
        const anoNacimiento = parseInt(String(fechanacimientop).substring(0, 4));
        const mesNacimiento = parseInt(String(fechanacimientop).substring(5, 7));
        const diaNacimiento = parseInt(String(fechanacimientop).substring(8, 10));
    
        let edad = anoActual - anoNacimiento;
        if (mesActual < mesNacimiento) {
            edad--;
        } else if (mesActual === mesNacimiento) {
            if (diaActual < diaNacimiento) {
                edad--;
            }
        }
        return edad;
    };

    let edadpersonareg = calcularEdad(fechanacimiento); // Asegúrate de tener una función para calcular la edad

    if (edadpersonareg <= 17) {
        setErrorFor(fechanacimientopersonainput, 'No se puede registrar menores de 18 años ');
    } else {
        setSuccessFor(fechanacimientopersonainput);
    }
    });


    //let formulario = document.querySelector("#regpersonalform");
    formulario.addEventListener("submit", (e) => {
        e.preventDefault();
        const datos = new FormData(document.getElementById("regpersonalform"));
    
        // Ejecuta ambas funciones al mismo tiempo
        Promise.all([verificarCedula(datos.get("cedulapersona")), camposVacios(datos)]).then((resultados) => {
            let existe = resultados[0];
            let camposVaciosResultado = resultados[1];
    
            if (existe) {
                let cedulapersonainput = document.getElementById('cedulapersona');
                setErrorFor(cedulapersonainput, 'Esta Cedula ya Existe');
                Swal.fire({
                    title: "Esta Cedula ya Existe",
                    icon: "error"
                });
            } else if (camposVaciosResultado) {
                console.log("campos vacios");
                return;
            } else {
                let urlGuardar = "../controlador/ctr-personas.php?op=guardar";
    
                fetch(urlGuardar, {
                    method: "post",
                    body: datos,
                })
                .then((data) => data.json())
                .then((data) => {
                    console.log(data);
                    $('#modalregistrarexitoso').modal("show");
    
                    setInterval(function() {
                        location.href = `../vista/manejo-trabajador2.php?id=${data}`;
                    }, 1500);
                })
                .catch((error) => console.log(`error: ${error}`));
            }
        })
        .catch((error) => console.log(`error: ${error}`));
    });