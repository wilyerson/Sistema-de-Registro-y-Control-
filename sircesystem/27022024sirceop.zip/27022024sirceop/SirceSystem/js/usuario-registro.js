const formdataregistrousuario = document.querySelector("#formulariosuario");
formdataregistrousuario.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formulariosuario"));

    if (camposVaciosUsuarioRegistro(datos)) {
        //console.log('Hay campos vacíos');
        let toastusercamposvacios = document.querySelector("#toastusercampovacios");
		let toast = new bootstrap.Toast(toastusercamposvacios, {autohide: true, delay: 2000});
		toast.show();

		setTimeout(() => {
		    toast.hide();
		}, 2000);
        return;
    }

	console.log(" conectado");

	let url = "../controlador/usuarios-control.php?op=guardar";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);
			
			MostrarTablaUsuarios(data);
			//formdataregistrousuario.reset();
			$('#asignar-rol').modal('hide');
			swal.fire({
				title: "¡Registro de Usuario Exitoso!",
				icon: "success",
			});
		})
		.catch((error) => console.log(`error: ${error}`));
});

function camposVaciosUsuarioRegistro(datos) {

    let tipouser = document.getElementById('tipouser');
    let nombreunewuser = document.getElementById('nombreunewuser');
    let passnewuser = document.getElementById('passnewuser');
    let passnu2 = document.getElementById('passnu2');
    
    const tipouservalue = tipouser.value.trim();
    const nombreunewuservalue = nombreunewuser.value.trim();
    const passnewuservalue = passnewuser.value.trim();
    const passnu2value = passnu2.value.trim();
    
    let hayCamposVacios = false;

    //--------------------validando los inputs

    if (tipouservalue == "") {
        tipouser.classList.remove('is-valid');
        tipouser.classList.add('is-invalid');
        //document.getElementById('validcedulavacia').classList.remove('invisible');
		//document.getElementById('validcedulavacia').classList.add('visible');
        hayCamposVacios = true;
    } else {
        tipouser.classList.remove('is-invalid');
        tipouser.classList.add('is-valid');
        //document.getElementById('validcedulavacia').classList.add('invisible');
		//document.getElementById('validcedulavacia').classList.remove('visible');
    }

     if (nombreunewuservalue == "") {
        nombreunewuser.classList.remove('is-valid');
        nombreunewuser.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        nombreunewuser.classList.remove('is-invalid');
        nombreunewuser.classList.add('is-valid');
    }

    if (passnewuservalue == "") {
        passnewuser.classList.remove('is-valid');
        passnewuser.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        passnewuser.classList.remove('is-invalid');
        passnewuser.classList.add('is-valid');
    }

    if (passnu2value == "") {
        passnu2.classList.remove('is-valid');
        passnu2.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        passnu2.classList.remove('is-invalid');
        passnu2.classList.add('is-valid');
    }

    return hayCamposVacios;
}