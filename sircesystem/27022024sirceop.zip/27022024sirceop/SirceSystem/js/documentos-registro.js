

const formdatadoc = document.querySelector("#formregistrardocumentos");
formdatadoc.addEventListener("submit", (e) => {
	e.preventDefault();

	let idpersonal = localStorage.getItem("idpesonaid");
	console.log(idpersonal);

	document.getElementById("idpersonadoc").value = idpersonal;

	const datos = new FormData(document.getElementById("formregistrardocumentos"));

        //validar campos vacios
    if (camposVaciosdocumentos(datos)) {
        //console.log('Hay campos vacíos');
        return;
    }

	console.log(" conectado");

	let url = "../controlador/ctr-documentos.php?op=guardar";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);
			//dibujarTabla(data);
			//formdata.reset();
            console.log(data);

            var status = data.status;

            switch (status){
        case 'El archivo debe ser un jpg':
            archivojpg.classList.remove('is-valid');
            archivojpg.classList.add('is-invalid');
            swal.fire({
                title: "¡La Imagen debe ser un jpg!",
                icon: "error",
            });
            break;

        case 'El archivo debe ser de hasta 5MB':
            archivojpg.classList.remove('is-valid');
            archivojpg.classList.add('is-invalid');
            swal.fire({
                title: "¡La Imagen debe ser de hasta 5MB!",
                icon: "error",
            });
            break;

        case 'Documento registrado exitoso':
            archivojpg.classList.remove('is-invalid');
            archivojpg.classList.add('is-valid');
            mostrarDocumentos();
            $('#modal-registrar-documentos').modal('hide');
            swal.fire({
                title: "¡Registro Exitoso de Documento!",
                icon: "success",
            });
            break;
        }
			
            // Aquí llamas a la función que muestra los documentos en la tabla
            
		})
		.catch((error) => console.log(`error: ${error}`));
});

async function mostrarDocumentos() {
    let idperdoc = localStorage.getItem("idpesonaid");
    console.log(idperdoc);

    document.getElementById("idperdoc").value = idperdoc;

    try {
        const url = "../controlador/ctr-documentos.php?op=editar";
        const datos = new FormData(document.getElementById("fomrcapturariddoc"));

        const response = await fetch(url, {
            method: "POST",
            body: datos,
        });

        if (!response.ok) {
            throw new Error(`Error al obtener los datos. Código de estado: ${response.status}`);
        }

        let responseData = await response.json();
        responseData = responseData.reverse();
        console.log(responseData); 
        
        let tbody = document.querySelector("#verdocumentos");
        tbody.innerHTML = "";
        if (responseData.length > 0) {
            for (let registro of responseData) {
                tbody.innerHTML += `
                    <tr>
                        <th class="text-center" style="padding-left: 20%;">${registro.NombreDocumento}</th>
                        <td style="padding-left: 10%;"><img class="imagregistrodocumento" src="../controlador/${registro.archivosjpg}"></td>
                        <td style="padding-top: 3.8%; padding-left: 8%;"><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalverimagendocumento" onclick="verDocumentos('${registro.archivosjpg}')">Ver Documento</button></td>
                    </tr>
                `;
            }
        } else {
            tbody.innerHTML += `
                <tr>
                    <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${responseData}</th>
                </tr>
            `;
        }
    } catch (error) {
        console.error(`Error en la solicitud: ${error.message}`);
    }
}

// Llamamos a la función al cargar la página
document.addEventListener('DOMContentLoaded', mostrarDocumentos);

function descargarDocumentos() {

    /*let idpersonal = localStorage.getItem("idpesonaid");
	console.log(idpersonal);

    location.href = `../vista/bienvenida.php?id=${idpersonal}`;*/

    let idurl = new URLSearchParams(window.location.search);
    let idpersonalurl = idurl.get('id');
    
    //location.href = `../controlador/reportespdf.php?id=${idpersonalurl}`;

    $('#modalverpdfdocumento').modal("show");

    document.getElementById('iframerepostespdf').src = '../controlador/reportespdf.php?id='+idpersonalurl+'';

}

function verDocumentos(rutaImagen) {
    // Ahora puedes usar esa ruta para establecer el atributo 'src' de la imagen
    document.getElementById('imagendocumento').src = `../controlador/${rutaImagen}`;
}

let validacionimg = 1;

document.getElementById('archivojpg').addEventListener('change', function() {
    var archivo = this.files[0];
    var tipoArchivo = 'image/jpeg';
    var tamanoMaximo = 5 * 1024 * 1024; // 5MB

    if (archivo.type != tipoArchivo) {
        validacionimg = 2;
        archivojpg.classList.remove('is-valid');
        archivojpg.classList.add('is-invalid');
        swal.fire({
            title: "¡La Imagen debe ser un jpg!",
            icon: "error",
        });
    } else if (archivo.size > tamanoMaximo) {
        validacionimg = 3;
        archivojpg.classList.remove('is-valid');
        archivojpg.classList.add('is-invalid');
        swal.fire({
            title: "¡La Imagen debe ser de hasta 5MB!",
            icon: "error",
        });
    } else {
        validacionimg = true;
        archivojpg.classList.remove('is-invalid');
        archivojpg.classList.add('is-valid');
        console.log('Archivo válido');
    }
});

function camposVaciosdocumentos(datos) {

    let iddocumento = document.getElementById('iddocumento');
    let archivojpg = document.getElementById('archivojpg');

    const iddocumentogvalue = iddocumento.value.trim();
    const archivojpgvalue = archivojpg.value.trim();
    
    let hayCamposVacios = false;

    //--------------------validando los inputs

    if (iddocumentogvalue == "") {
        iddocumento.classList.remove('is-valid');
        iddocumento.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        iddocumento.classList.remove('is-invalid');
        iddocumento.classList.add('is-valid');
    }

    if (validacionimg == 2) {
        swal.fire({
            title: "¡La Imagen debe ser un jpg!",
            icon: "error",
        });
        archivojpg.classList.remove('is-valid');
        archivojpg.classList.add('is-invalid');

    } else if (validacionimg == 3) {
         archivojpg.classList.remove('is-valid');
        archivojpg.classList.add('is-invalid');
        
    } else if (archivojpgvalue == "") {
        archivojpg.classList.remove('is-valid');
        archivojpg.classList.add('is-invalid');
        hayCamposVacios = true;
    } else {
        archivojpg.classList.remove('is-invalid');
        archivojpg.classList.add('is-valid');
    }

    return hayCamposVacios;
}
