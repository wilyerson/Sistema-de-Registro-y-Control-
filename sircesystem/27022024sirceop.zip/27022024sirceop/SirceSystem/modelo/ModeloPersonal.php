<?php


class Personal extends dbconexion
{

    public function get_persona($CodigoPersona)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT 
        	municipio.NombreMunicipio, 
        	municipio.CodigoMunicipio,
        	parroquia.NombreParroquia,
        	persona.CedulaPersona, 
        	persona.Nombres, 
        	persona.Apellidos, 
        	persona.FechaNacimiento,
        	persona.Sexo,
        	persona.EstadoCivil, 
        	persona.Direccion, 
        	persona.ParroquiaPersona, 
        	persona.Sector,
        	persona.Direccion,
        	persona.TelefonoPrincipal,
        	persona.TelefonoHabitacion,
        	persona.Peso,
        	persona.Estatura,
        	persona.TallaCamisa,
        	persona.TallaPantalon,
        	persona.TallaCalzado        	 
        	FROM persona 
        	INNER JOIN parroquia ON persona.ParroquiaPersona = parroquia.CodigoParroquia 
        	INNER JOIN municipio ON parroquia.MunicipioParroquia = municipio.CodigoMunicipio 
        	WHERE persona.CodigoPersona = ?");
        $sql->bindValue(1, $CodigoPersona);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

public function insert_persona($CedulaPersona, $Nombres, $Apellidos, $FechaNacimiento, $Sexo, $EstadoCivil, $ParroquiaPersona, $Sector, $Direccion,$TelefonoPrincipal, $TelefonoHabitacion, $Peso, $Estatura, $TallaCamisa, $TallaPantalon, $TallaCalzado, $idusuario, $TipoPersona, $EstatusPersonal )
    {
        $conectar = dbconexion::conexion();

        $sql = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona = ?");
        $sql->bindValue(1, $CedulaPersona);

        $resultadoCedula = $sql->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($resultadoCedula)) {
                    // La nueva cédula ya está en uso
                   // return array("estado" => "error_cedula_existente");
                   return json_encode(array("estado" => "error_cedula_existente"));
            } else {

        $sql = $conectar->prepare("INSERT INTO persona (CedulaPersona,Nombres, Apellidos, FechaNacimiento, Sexo, EstadoCivil, ParroquiaPersona, Sector, Direccion,TelefonoPrincipal, TelefonoHabitacion, Peso, Estatura, TallaCamisa, TallaPantalon, TallaCalzado, idusuario, TipoPersona, EstatusPersonal ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $sql->bindValue(1, $CedulaPersona);
        $sql->bindValue(2, $Nombres);
        $sql->bindValue(3, $Apellidos);
        $sql->bindValue(4, $FechaNacimiento);
        $sql->bindValue(5, $Sexo);
        $sql->bindValue(6, $EstadoCivil);
        $sql->bindValue(7, $ParroquiaPersona);
        $sql->bindValue(8, $Sector);
        $sql->bindValue(9, $Direccion);
        $sql->bindValue(10, $TelefonoPrincipal);
        $sql->bindValue(11, $TelefonoHabitacion);
        $sql->bindValue(12, $Peso);
        $sql->bindValue(13, $Estatura);
        $sql->bindValue(14, $TallaCamisa);
        $sql->bindValue(15, $TallaPantalon);
        $sql->bindValue(16, $TallaCalzado);
        $sql->bindValue(16, $TallaCalzado);
        $sql->bindValue(17, $idusuario);
        $sql->bindValue(18, $TipoPersona);
        $sql->bindValue(19, $EstatusPersonal);
        
                if ($sql->execute()) {
                    
                    $last_id = $conectar->lastInsertId();
                    
                
                    
                    echo json_encode($last_id);
                }

        }
    }
    
    public function update_personal($CodigoPersona, $CedulaPersona, $Nombres, $Apellidos, $FechaNacimiento, $Sexo, $EstadoCivil, $ParroquiaPersona, $Sector, $Direccion,$TelefonoPrincipal, $TelefonoHabitacion, $Peso, $Estatura, $TallaCamisa, $TallaPantalon, $TallaCalzado, $idUsuario)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT * FROM persona WHERE CodigoPersona = ?");
        $sql->bindValue(1, $CodigoPersona);
        $sql->execute();
        $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    
        if (!empty($resultado)) {
            // El usuario existe en la base de datos
            if ($resultado[0]['CedulaPersona'] != $CedulaPersona) {
                // El usuario está intentando cambiar su cédula
                // Verifica si la nueva cédula ya está en uso
                $sql = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona = ?");
                $sql->bindValue(1, $CedulaPersona);
                $sql->execute();
                $resultadoCedula = $sql->fetchAll(PDO::FETCH_ASSOC);
                if (!empty($resultadoCedula)) {
                    // La nueva cédula ya está en uso
                    return array("estado" => "error_cedula_existente");
                }
            }
            // Actualiza los datos
            $sql = "UPDATE persona SET CedulaPersona = ?, Nombres = ?, Apellidos = ?, FechaNacimiento = ?, Sexo = ?, EstadoCivil = ?, ParroquiaPersona = ?, Sector = ?, Direccion = ?, TelefonoPrincipal = ?, TelefonoHabitacion = ?, Peso = ?, Estatura = ?, TallaCamisa = ?, TallaPantalon= ?, TallaCalzado = ?, idusuario = ? WHERE CodigoPersona = ?";
            $sql = $conectar->prepare($sql);
            $sql->bindValue(1, $CedulaPersona);
            $sql->bindValue(2, $Nombres);
            $sql->bindValue(3, $Apellidos);
            $sql->bindValue(4, $FechaNacimiento);
            $sql->bindValue(5, $Sexo);
            $sql->bindValue(6, $EstadoCivil);
            $sql->bindValue(7, $ParroquiaPersona);
            $sql->bindValue(8, $Sector);
            $sql->bindValue(9, $Direccion);
            $sql->bindValue(10, $TelefonoPrincipal);
            $sql->bindValue(11, $TelefonoHabitacion);
            $sql->bindValue(12, $Peso);
            $sql->bindValue(13, $Estatura);
            $sql->bindValue(14, $TallaCamisa);
            $sql->bindValue(15, $TallaPantalon);
            $sql->bindValue(16, $TallaCalzado);
            $sql->bindValue(17, $idUsuario);
            $sql->bindValue(18, $CodigoPersona);
            
            if ($sql->execute()) {
                return array("estado" => "exito");
            }
        } else {
            // El usuario no existe en la base de datos
            return array("estado" => "error_usuario_no_existe");
        }
    }

public function verificar_cedula($CedulaPersona)
{
    $conectar = dbconexion::conexion();
    //$sql = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona = ? AND TipoPersona = 'personal'");
    $sql = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona = ?");
    $sql->bindValue(1, $CedulaPersona);
    $sql->execute();
    $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($resultado)) {
        return ['status' => 'cedula existe', 'data' => $resultado];
    } else {
        return ['status' => 'cedula no existe'];
    }
}

    public function check_cedula($CedulaPersona, $CedulaOriginal)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT * FROM persona WHERE CedulaPersona = ? AND CedulaPersona != ?");
        $sql->bindValue(1, $CedulaPersona);
        $sql->bindValue(2, $CedulaOriginal);
        $sql->execute();
        $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($resultado)) {
            return true;
        } else {
            return false;
        }
    }

    public function get_buscarpersona($CedulaPersonabuscar)
    {
        $conectar = dbconexion::conexion();
        $CedulaPersonabuscar = $CedulaPersonabuscar . '%'; // Añade el carácter comodín al final
        $sql = $conectar->prepare("SELECT CodigoPersona, CedulaPersona, Nombres, Apellidos, EstadoCivil, TipoPersona  FROM persona WHERE CedulaPersona LIKE ? AND TipoPersona = 'personal' ");
        $sql->bindValue(1, $CedulaPersonabuscar);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }
    

}
