<?php 
	require_once "ModeloConeccion.php";

	class documento{

		public function obtener_documentos_select(){
			$db = new coneccion();
			$query = "SELECT CodigoDocumento, NombreDocumento from documento";
			$resultado = $db->query($query);
			$datos=[];
			if ($resultado->num_rows) {
				while ($row = $resultado->fetch_assoc()) {
					$datos[] = [
						'NombreDocumento' => $row['NombreDocumento'],
						'CodigoDocumento' => $row['CodigoDocumento'],
					];				
				}			
			}
			return $datos;
		}
	}

 ?>