const form = document.getElementById('formud');
const cedula = document.getElementById('Cedulapersona');
const nombre = document.getElementById('Nombredocumento');
const documentos = document.getElementById('fotodocumento');
const botonrecargardocumentos = document.getElementById('botonrecargarpaginadocumentos');

obtener_localstorage();



function obtener_localstorage(){

  let cedulapersona = localStorage.getItem('cedulapersonastorage');

//console.log(cedulapersona);

return cedulapersona;
  
}

console.log(obtener_localstorage());

const inputcedula = document.getElementById("inputcedula");


inputcedula.innerHTML = '<input type="number" class="form-control inputcedulaestilo" value="'+ obtener_localstorage() +'" id="Cedulapersona" name="Cedulapersonad">';
//inputcedula.innerHTML = obtener_localstorage();




form.addEventListener('submit', e => {
  e.preventDefault();

  


//lef frm = document.getElementById('formp');

let data = new FormData(e.currentTarget);

let request;

if (window.XMLHttpRequest) request = new XMLHttpRequest();
      else request = new ActiveXObject('Microsoft.XMLHTTP');


      request.addEventListener('load', () => {

       //console.log(data.get('Cedulapersona'));
         
        prueba = 1;
        //alert("registro exitoso");
        //window.location.href ='../registrodocumentosprincipal.php';

        document.querySelector('#Nombredocumento').value = '';
        document.querySelector('#fotodocumento').value = '';


      });


       request.open(
        'POST',
        '../controlador/registrardocumento.php',
        true,
        request.responseType = 'json'
      );

       if(checkInputs() === 5){
        //alert(" registra");
        $('#modalregistrarexitoso').modal("show");
        $('#modal-registrar-documentos').modal("hide");
      request.send(data);
       prueba = 5;
     //window.location.href ='registrodocumentosprincipal.php';
        



     }else{
      //alert("no registra");
      $('#modalregistrarrellenecampos').modal("show");
      prueba = 5;
     }
     
checkInputs();
console.log(checkInputs());
});


function checkInputs() {
  let prueba;
  let prueba2;
  let checkcedula = 2;
  let checknombre = 2;
  let checkdireccion = 2;
  // trim to remove the whitespaces
  //const cedulaValue = cedula.value.trim();
  const nombreValue = nombre.value.trim();
  const documentosValue = documentos.value.trim();

  //const passwordValue = password.value.trim();
  // password2Value = password2.value.trim();
  
  if(nombreValue === '') {
    
    setErrorFor(nombre, 'No puede dejar la talla de pantalon en blanco');
  } else {
    
    setSuccessFor(nombre);
  }

  if(documentosValue === '') {
    
    setErrorFor(documentos, 'No puede dejar la talla de calzado en blanco');
  } else {
    
    setSuccessFor(documentos);
  }


if (nombreValue === '' || documentosValue === '') 
{

//alert("campos vacios");
prueba = 2;

}else{

  //todos los campos llenos
  prueba = 5;
}

if (checkcedula === 5 && checknombre  === 5 && checkdireccion === 5) {

 //todo esta validado
prueba2 = 5;

}else{
  //algo no esta validado

  prueba2 = 2;

}

//console.log(prueba2);

if (prueba === 5) {
  return 5;
}else{
  return 2;
}

}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector('small');
  formControl.className = 'col-6 col-sm-6 formu-control error';// borde rojito
  small.innerText = message;
  prueba = 2;
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.className = 'col-6 col-sm-6 formu-control success';
  //prueba = 12;
}


traerdatos();

          function traerdatos(){

            console.log('dentro de funcion');

            const xhttp = new XMLHttpRequest();

          xhttp.open(
          'POST',
           '../controlador/mostrardocumentos.php',
             true
               );


          xhttp.send();

          xhttp.onreadystatechange = function()
            {

              if(this.readyState == 4 && this.status == 200)
              {

                //console.log(this.responseText);
                let datos = JSON.parse(this.responseText);
                //console.log(datos);

                
                let cuerpo = document.querySelector('#cuerpo');
                cuerpo.innerHTML ='';


                 let cedu = obtener_localstorage();

                 let pequeños = datos.filter(function(pdatos){
                  return pdatos.Cedulapersona === cedu;
                  
                });

        const botonhistorico = document.getElementById('botonirahistorico');
        let vacioboton;

        botonhistorico.onclick = function() {

          /*if (pequeños.length === 0) 
          {
            //alert("vacio");
            $('#modalmensajeagregueundocumento').modal("show");
          }else{*/
            //alert("lleno");
            window.location.href ='registrohistoricoprincipal.php';
         /* }*/

        }


        console.log(pequeños.length);
                
              for (let item of pequeños) {
                //console.log(item.Nombredocumento);

                cuerpo.innerHTML += `
                <tr>
                  
                  <td>${item.Nombredocumento}</td>
                  <td><img class="imagregistrodocumento" src="../controlador/imagenes/${item.fotodocumento}"></td>
                </tr>
                `

              }

                

              }

            }

          }



      botonrecargardocumentos.onclick = function() {

        window.location.href ='registrodocumentosprincipal.php';
      

      }

