const form = document.getElementById('formup');
const cedula = document.getElementById('Cedulapersona');
const nombre = document.getElementById('Nombres');
const estadocivil = document.getElementById('Estadocivil');
const imagenperfil = document.getElementById('Fotopersona');
const apellidos = document.getElementById('Apellidos');
const fechanacimiento = document.getElementById('Fechanacimiento');
const idsexo = document.getElementById('sexo');
const nprincipal = document.getElementById('Telefonoprincipal');
const nhabitacion = document.getElementById('Telefonohabitacion');
const direccion = document.getElementById('direccion');
const peso = document.getElementById('peso');
const estatura = document.getElementById('estatura');
const tallacamisa = document.getElementById('tallacamisa');
const tallapantalon = document.getElementById('tallapantalon');
const tallacalzado = document.getElementById('tallacalzado');

const mostraredaddiv = document.getElementById('mostraredad');


//let municipios = ["Andrés Eloy Blanc","Andrés Mata","Arismendi","Benítez","Bermúdez","Bolívar","Cajigal","Cruz Salmerón Acosta","Libertador","Mariño","Mejía","Montes","Ribero","Sucre","Valdez"];

//let parroquias = [];

var opt_1 = new Array ("-", "Mariño", "Rómulo Gallegos");
var opt_2 = new Array ("-", "San José de Aerocuar", "Tavera Acosta");
var opt_3 = new Array ("-", "El Morro", "Puerto Santo", "Río Caribe", "Sucre", "San Juan");
var opt_4 = new Array ("-", "El Pilar", "El Rincón", "Francisco A. Vásquez", "Guaraunos", "Tunapuicito", "Unión");
var opt_5 = new Array ("-", "Bolívar", "Macarapana", "Santa Catalina", "Santa Rosa", "Santa Teresa");
var opt_6 = new Array ("-", "Marigüitar");
var opt_7 = new Array ("-", "Libertad", "El Paujil", "Yaguaraparo");
var opt_8 = new Array ("-", "Araya", "Chacopata", "Manicuare");
var opt_9 = new Array ("-", "Campo Elías", "Tunapui");
var opt_10 = new Array ("-", "Irapa", "Campo Claro", "Marabal", "San Antonio de Irapa", "Soro");
var opt_11 = new Array ("-", "San Antonio del Golfo");
var opt_12 = new Array ("-", "Cumanacoa", "Arenas", "Aricagua", "Cocollar", "San Fernando", "San Lorenzo");
var opt_13 = new Array ("-", "Cariaco", "Catuaro", "Rendón", "Santa Cruz", "Santa María");
var opt_14 = new Array ("-", "Altagracia", "Ayacucho", "Gran Mariscal", "Raúl Leoni", "San Juan", "Santa Inés", "Valentín Valiente");
var opt_15 = new Array ("-", "Cristóbal Colón", "Bideau", "Punta de Piedras", "Güiria");

function cambia() {
  var cosa;
  //se toma el valor de la "cosa selecionada"
  cosa = document.formulario1.cosa[document.formulario1.cosa.selectedIndex].value;
  //se cheque si la cosa esta definida
  if (cosa!=0) {
    //
    mis_opts=eval("opt_" + cosa);
    //
    num_opts=mis_opts.length;
    //
    document.formulario1.opt.length = num_opts;
    //
    for (i=0; i<num_opts; i++) {
      document.formulario1.opt.options[i].value=mis_opts[i];
      document.formulario1.opt.options[i].text=mis_opts[i];
    }
    }else {
      //
      document.formulario1.opt.length= 1;
      document.formulario1.opt.options[0].value="-";
      document.formulario1.opt.options[0].text="-";
    }

    document.formulario1.opt.options[0].selected = true;

  }


//const password = document.getElementById('password');
//const password2 = document.getElementById('password2');
const cedup = document.getElementById('Cedulapersona').value;
console.log(cedup);

const calcularEdad = (fechanacimiento) => {
    const fechaActual = new Date();
    const anoActual = parseInt(fechaActual.getFullYear());
    const mesActual = parseInt(fechaActual.getMonth()) + 1;
    const diaActual = parseInt(fechaActual.getDate());

    // 2023-02-22
    const anoNacimiento = parseInt(String(fechanacimiento).substring(0, 4));
    const mesNacimiento = parseInt(String(fechanacimiento).substring(5, 7));
    const diaNacimiento = parseInt(String(fechanacimiento).substring(8, 10));

    let edad = anoActual - anoNacimiento;
    if (mesActual < mesNacimiento) {
        edad--;
    } else if (mesActual === mesNacimiento) {
        if (diaActual < diaNacimiento) {
            edad--;
        }
    }
    return edad;
};

//console.log(calcularEdad(fechanacimiento));

window.addEventListener('load', function () {

            fechanacimiento.addEventListener('change', function () {
        if (this.value) {
            //edad.innerText = `La edad es: ${calcularEdad(this.value)} años`;
          //console.log(calcularEdad(this.value));
          
        }
    });

});



form.addEventListener('submit', e => {
  e.preventDefault();

  


//lef frm = document.getElementById('formp');

let data = new FormData(e.currentTarget);

let request;

if (window.XMLHttpRequest) request = new XMLHttpRequest();
      else request = new ActiveXObject('Microsoft.XMLHTTP');

console.log(data.get("Cedulapersona"));

//let cedulapersona = data.get("Cedulapersona");

guardar_localstorage();

function guardar_localstorage(){

  let cedulapersona = data.get("Cedulapersona");

localStorage.setItem('cedulapersonastorage', cedulapersona);
  
}


      request.addEventListener('load', () => {

       //console.log(data.get('Cedulapersona'));

         
        prueba = 1;
        //alert("registro exitoso");


        document.querySelector('#Cedulapersona').value = '';
        document.querySelector('#Fotopersona').value = '';
        document.querySelector('#Estadocivil').value = '';
        document.querySelector('#Nombres').value = '';
        document.querySelector('#Apellidos').value = '';
        document.querySelector('#Fechanacimiento').value = '';
        document.querySelector('#sexo').value = '';
        document.querySelector('#Telefonoprincipal').value = '';
        document.querySelector('#Telefonohabitacion').value = '';
        document.querySelector('#direccion').value = '';
        document.querySelector('#peso').value = '';
        document.querySelector('#estatura').value = '';
        document.querySelector('#tallacamisa').value = '';
        document.querySelector('#tallapantalon').value = '';
        document.querySelector('#tallacalzado').value = '';

      });


       request.open(
        'POST',
        '../controlador/controladorregistratrabajador.php',
        true,
        request.responseType = 'json'
      );

      
 let edad = calcularEdad(fechanacimiento.value);


       if(checkInputs() === 5 && edad >= 18){
        //alert(" registra");
        $('#modalregistrexitosopersona').modal("show");
      request.send(data);
       prueba = 5;

        
       setInterval(() => {
        //window.location.replace('registrodocumentosprincipal.php');
        //window.location.href ='registrodocumentosprincipal.php';
      }, 3000);


     }else{
      //alert("no registra");
      $('#modalregistrarrellenecampos').modal("show");
      prueba = 5;
      //console.log(fechanacimiento.value);
      
     }
     
checkInputs();
console.log(checkInputs());
});

function checkInputs() {
  let prueba;
  let prueba2;
  let checkcedula = 2;
  let checknombre = 2;
  let checkdireccion = 2;
  // trim to remove the whitespaces
  const cedulaValue = cedula.value.trim();
  const nombreValue = nombre.value.trim();
  const estadocivilValue = estadocivil.value.trim();
  const imagenperfilValue = imagenperfil.value.trim();
  const apellidosValue = apellidos.value.trim();
  const fechanacimientoValue = fechanacimiento.value.trim();
  const idsexoValue = idsexo.value.trim();
  const nprincipalValue = nprincipal.value.trim();
  const nhabitacionValue = nhabitacion.value.trim();
  const direccionValue = direccion.value.trim();
  const pesoValue = peso.value.trim();
  const estaturaValue = estatura.value.trim();
  const tallacamisaValue = tallacamisa.value.trim();
  const tallapantalonValue = tallapantalon.value.trim();
  const tallacalzadoValue = tallacalzado.value.trim();
  //const passwordValue = password.value.trim();
  // password2Value = password2.value.trim();

    let edad = calcularEdad(fechanacimiento.value);
       console.log(calcularEdad(fechanacimiento.value));


     mostraredaddiv.innerHTML = " la edad actual es: " + edad + "";

     if (edad => 18) {
      document.getElementById('mostraredad').style.color="green";
     };

    if (edad <= 17){
      document.getElementById('mostraredad').style.color="red";
     }
     
       
  
  if(cedulaValue === '') {
    
    setErrorFor(cedula, 'No puede dejar la cedula en blanco');
  } else if (!iscedula(cedulaValue)) {
    setErrorFor(cedula, 'No ingrese simbolos ni letras ni cedula menor a 6 letras ');
  } else {
    checkcedula = 5;
    setSuccessFor(cedula);
  }
  
  if(nombreValue === '') {
    
    setErrorFor(nombre, 'No puede dejar el Nombre en blanco');
  } else if (!isnombre(nombreValue)) {
    setErrorFor(nombre, 'No ingrese numeros o simbolos ni nombres nemores a 4 letras ');
  } else {
    checknombre = 5;
    setSuccessFor(nombre);
  }

  if(estadocivilValue === '') {
    
    setErrorFor(estadocivil, 'No puede dejar el estado civil en blanco');
  } else {
    
    setSuccessFor(estadocivil);
  }

  if(imagenperfilValue === '') {
    
    setErrorFor(imagenperfil, 'tienes que escojer una imagen de perfil');
  } else {
    
    setSuccessFor(imagenperfil);
  }

  if(apellidosValue === '') {
    
    setErrorFor(apellidos, 'No puede dejar el apellido en blanco');
  } else {
    
    setSuccessFor(apellidos);
  }

    if(fechanacimientoValue === '') {
    
    setErrorFor(fechanacimiento, 'No puede dejar la fecha de nacimiento en blanco');
  } else if (edad <= 17) {
    setErrorFor(fechanacimiento, 'No se puede registrar menores de 18 anios ');
  } else {
    
    setSuccessFor(fechanacimiento);
  }

  if(idsexoValue === '') {
    
    setErrorFor(idsexo, 'seleccione el sexo');
  } else {
    
    setSuccessFor(idsexo);
  }

  if(nprincipalValue === '') {
    
    setErrorFor(nprincipal, 'No puede dejar el telefon principal en blanco');
  } else {
    
    setSuccessFor(nprincipal);
  }

  if(nhabitacionValue === '') {
    
    setErrorFor(nhabitacion, 'No puede dejar el telefon de habitacion en blanco');
  } else {
    
    setSuccessFor(nhabitacion);
  }
  
  if(direccionValue === '') {
    
    setErrorFor(direccion, 'No puede dejar la direccion en blanco');
  } else if (!isdireccion(direccionValue)) {
    setErrorFor(direccion, 'No ingrese numeros o simbolos ni nombres nemores a 4 letras ');
  } else {
    checkdireccion = 5;
    setSuccessFor(direccion);
  }

  if(pesoValue === '') {
    
    setErrorFor(peso, 'No puede dejar el peso en blanco');
  } else {
    
    setSuccessFor(peso);
  }

  if(estaturaValue === '') {
    
    setErrorFor(estatura, 'No puede dejar la estatura en blanco');
  } else {
    
    setSuccessFor(estatura);
  }

  if(tallacamisaValue === '') {
    
    setErrorFor(tallacamisa, 'No puede dejar la talla de camisa en blanco');
  } else {
    
    setSuccessFor(tallacamisa);
  }

  if(tallapantalonValue === '') {
    
    setErrorFor(tallapantalon, 'No puede dejar la talla de pantalon en blanco');
  } else {
    
    setSuccessFor(tallapantalon);
  }

  if(tallacalzadoValue === '') {
    
    setErrorFor(tallacalzado, 'No puede dejar la talla de calzado en blanco');
  } else {
    
    setSuccessFor(tallacalzado);
  }



if (cedulaValue === '' || nombreValue === '' || estadocivilValue === '' || imagenperfilValue === '' || apellidosValue === '' || fechanacimientoValue === '' || idsexoValue === '' || nprincipalValue === '' || nhabitacionValue === '' || direccionValue === '' || pesoValue === '' || estaturaValue === '' || tallacamisaValue === '' || tallapantalonValue === '' || tallacalzadoValue === '') 
{

//alert("campos vacios");
prueba = 2;

}else{

  //todos los campos llenos
  prueba = 5;
}

if (checkcedula === 5 && checknombre  === 5 && checkdireccion === 5) {

 //todo esta validado
prueba2 = 5;

}else{
  //algo no esta validado

  prueba2 = 2;

}

//console.log(prueba2);

if (prueba === 5 && prueba2 === 5) {
  return 5;
}else{
  return 2;
}

/*if (prueba == 2) {
  return 2;
}*/


//return 7;

/*if (prueba == 7) {
  return 8;
}*/



  /*if(passwordValue === '') {
    setErrorFor(password, 'Password no debe ingresar en blanco.');
  } else {
    setSuccessFor(password);
  }
  
  if(password2Value === '') {
    setErrorFor(password2, 'Password2 no debe ngresar en blanco');
  } else if(passwordValue !== password2Value) {
    setErrorFor(password2, 'Passwords no coinciden');
  } else{
    setSuccessFor(password2);
  }*/
}

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector('small');
  formControl.className = 'col-6 col-sm-6 formu-control error';
  small.innerText = message;
  prueba = 2;
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.className = 'col-6 col-sm-6 formu-control success';
  //prueba = 12;
}


function iscedula(cedula) {
  return /^[0-9]{6,10}$/.test(cedula);
}

function isnombre(nombre) {
  return /^[a-zA-Z\ ]{4,25}$/.test(nombre);
}

function isdireccion(direccion) {
  return /^[a-zA-Z\ ]{10,30}$/.test(direccion);
}

/*guardar_localstorage();

function guardar_localstorage(){

  let nombree = "pedro";

localStorage.setItem('nombrever', nombree);
  
}*/





