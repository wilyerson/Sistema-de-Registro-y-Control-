<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SIRCE</title>	
	<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
	

	<style type="text/css">

		@font-face{
			font-family: opensan;
			src: url(fonts/googlesansnormal.woff2);

		}

		body{
			font-family: opensan;
		}
		.inputcedulaestilo{
			display: none;
		}

		.imagregistrodocumento{
			width: 100px;
		}

		.formu-control.success input {
			border-color: #2ecc71;
		}

		.formu-control.error input {
			border-color: #e74c3c;
		}

		.formu-control.success select {
			border-color: #2ecc71;
		}

		.formu-control.error select {
			border-color: #e74c3c;
		}

		.formu-control .fas {
			visibility: hidden;
			}

		.formu-control.success .fas.fa-check-circle {
			color: #2ecc71;
			visibility: visible;
		}

		.formu-control.error .fas.fa-exclamation-circle {
			color: #e74c3c;
			visibility: visible;
		}

		.formu-control small {
			color: #e74c3c;
		  /*position: absolute;
		  bottom: 0;
		  left: 0;*/
		  visibility: hidden;
		}

		.formu-control.error small {
			visibility: visible;

		}

	    .btn-ver-campos{
	    	width:90px;
	    }

	    #td{
	    	width:90px;
	    }

	</style>

</head>

<?php 

session_start();

if(!isset($_SESSION['usuarioad']))
{
	header("Location: ../index.php");
}



?>

<body class="bg-gray pb-5">

	

	<?php include"componentes/nav.php" ?>

	<div class="container border rounded py-3 bg-white" style="max-width: 1000px; margin-top: 100px; ">
		
		<div class="row p-3">
			<h4 class="d-flex justify-content-center align-items-center">Gestión de Usuarios</h4>
		</div>

		<div class="row">
			<div class="col col-sm-3">
				<div class="nav nav-pills flex-column mx-0" id="nav-tabs" role="tablist">

					<button class="nav-link active"  id="registro-tab" data-bs-toggle="pill" data-bs-target="#registro" type="button" role="tab" aria-controls="registro-tab" aria-selected="true">Registrar Usuarios </button>

					<button class="nav-link"  id="modificar-tab" data-bs-toggle="pill" data-bs-target="#modificar" 	type="button" role="tab" aria-controls="modificar-tab" aria-selected="false">Modificar Usuarios </button>

					<button class="nav-link"  id="crear-tab" data-bs-toggle="pill" data-bs-target="#crear" type="button" role="tab" aria-controls="crear-tab" aria-selected="false">Registar Usuario de Ayuda</button>

				</div>
			</div>
			<div class="col col-sm-9">

				<div class="tab-content" id="nav-tabContent" style="padding: 0px 0px 10px 20px;">
					
					<!-- ///////////////////////////////////////PILLS REGISTRAR/////////////////////////////////////////// -->
					<div class="tab-pane fade show active" id="registro" role="tab-panel" aria-labelledby="registro-tab">

						<form id="formbusqueda" method="post"  class="campos formu-control">

							<div class="row">
								<div class="input-group" name="tipo-ci">
									<select class="form-select" style="width: 10%;">  
										<option value="v">V</option>
										<option value="e">E</option>  
										<option value="p">P</option>
									</select>

									<input type="number" style="width:90%; " id="buscarcedu" name="buscarcedu" class="form-control " placeholder="Cédula de Identidad" aria-label="Text input with dropdown button" >

									<small>Error message</small>	

									<p id="resultado" ></p>

									<div id="passwordHelpBlock" class="form-text">
									</div>

								</div>

								<div id="passwordHelpBlock" class="form-text">
								</div>

								<div class="d-flex mt-md-3 justify-content-center">

									<button type="submit" id="botonasignar-rol" class="btn btn-primary" >Asignar Rol</button>

								</div>
							</div>

						</form>

					</div>
					<!-- ///////////////////////////////////////PILLS REGISTRAR/////////////////////////////////////////// -->

					<!-- ///////////////////////////////////////PILLS MODIFICAR/////////////////////////////////////////// -->

					<div class="tab-pane fade show" id="modificar" role="tab-panel" aria-labelledby="modificar-tab">

						<form id="buscarformulariomodificaruser" method="post"  class="campos formu-control">

							<div class="row">

								<div class="input-group" name="tipo-ci">
									<select class="form-select" style="width: 10%">  
										<option value="v">V</option>
										<option value="e">E</option>  
										<option value="p">P</option>
									</select>
									<input type="number"  class="form-control" style="width: 90%" id="buscarmodificarcedula" name="buscarmodificarcedula" placeholder="Cédula" aria-label="Text input with dropdown button">
								</div>

							</div>

							<div class="row">

								<div class="form-text">Los Usuarios listados solo laboran y mantienen un estatus activo dentro de la Dirección de Personal.
								</div>

							</div>

							<div class="d-flex justify-content-center mt-md-3">

								<button type="submit" class="btn btn-primary" data-bs-toggle="modal" >Modificar Usuario</button>

							</div>

						</form>

					</div>
					<!-- ///////////////////////////////////////PILLS MODIFICAR/////////////////////////////////////////// -->
					<!-- ///////////////////////////////////////PILLS AYUDA/////////////////////////////////////////////// -->

					<div class="tab-pane fade show" id="crear" role="tab-panel" aria-labelledby="registro-tab">

						<form id="formusuarioayuda" method="post"  class="campos formu-control">

							<div class="row">
								<div class="input-group" name="tipo-ci">
									<select class="form-select" style="width: 10%;">  
										<option value="v">V</option>
										<option value="e">E</option>  
										<option value="p">P</option>
									</select>

									<input type="number" style="width:90%; " id="buscarcedu" name="buscarcedu" class="form-control " placeholder="Cédula de Identidad" aria-label="button" >

									<small>Error message</small>	

									<p id="resultado" ></p>

									<div id="passwordHelpBlock" class="form-text">
									</div>

								</div>

								<div id="passwordHelpBlock" class="form-text">
								</div>

								<div class="d-flex mt-md-3 justify-content-center">

									<button type="submit" id="botoncrearusuario-rol" class="btn btn-primary" >Registrar Usuario</button>

								</div>
							</div>

						</form>

					</div>

					<!-- ///////////////////////////////////////PILLS AYUDA/////////////////////////////////////////////// -->
				</div><!-- cierrepills -->
			</div>
		</div>

	</div><!-- cierre container --> 


	<div class="container border rounded py-3 bg-white" style="max-width: 1000px; margin-top: 20px; ">

		<div class="row p-2 ">
			<h4 class="d-flex justify-content-center align-items-center mb-4 mt-3">Listado de Usuarios</h4>
		</div>
			
		<div class="row justify-content-md-center table-responsive px-3 py-3">
			<table class="table table-hover" >
			  	<thead>
				    <tr>
				      <th scope="col">Personal</th>
				      <th scope="col">Tipo</th>
				      <th scope="col">Nombre de Usuario</th>
				      <th scope="col">Fecha de Creación</th>
				      <th scope="col">Hora</th>
				      <th scope="col" colspan="2">Acción</th>
				    </tr>
			  	</thead>
				  <tbody>
				    <tr>
				      <td>Samuel Perez</td>
				      <td>Analista</td>
				      <td>WMalave</td>
				      <td>11/05/2023</td>
				      <td>12:05pm</td>
				      <td><button type="button" data-bs-toggle="modal" data-bs-target="#modaldedatos" class="btn-ver-campos btn btn-warning btn-sm">Desactivar</button></td>
				      <td><button type="button" data-bs-toggle="modal" data-bs-target="#modaldedatos" class="btn-ver-campos btn btn-danger btn-sm">Eliminar</button></td>				      
				    </tr>
				    <tr>
				      <td>Wilyerson Malave</td>
				      <td>Consulta</td>
				      <td>OldRogz</td>
				      <td>11/05/2023</td>
				      <td>12:05pm</td>
				      <td><button type="button" data-bs-toggle="modal" data-bs-target="#modaldedatos" class="btn-ver-campos btn btn-warning btn-sm">Desactivar</button></td>
				      <td><button type="button" data-bs-toggle="modal" data-bs-target="#modaldedatos" class="btn-ver-campos btn btn-danger btn-sm">Eliminar</button></td>
				    </tr>
				    <tr>
				      <td>Endys Rodriguez</td>
				      <td>Consulta</td>
				      <td>SammX</td>
				      <td>11/05/2023</td>
				      <td>12:05pm</td>
				      <td><button type="button" data-bs-toggle="modal" data-bs-target="#modaldedatos" class="btn-ver-campos btn btn-warning btn-sm">Desactivar</button></td>
				      <td>
				      	<div class="dropdown">
				      		<a class="btn btn-info dropdown-toggle btn-ver-campos btn-sm text-end" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false" >
				      			
				      		</a>

				      		<ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
				      			<li><a class="dropdown-item" href="#">Ver Datos</a></li>
				      			<li><a class="dropdown-item" href="#">Modificar</a></li>
				      			<li><a class="dropdown-item" href="#">Desactivar</a></li>
				      			<li><a class="dropdown-item" href="#">Eliminar</a></li>
				      		</ul>
				      	</div>
				      </td>
				    </tr>
				  </tbody>
			</table>
		</div>

	</div>


	<!-- -----------------------------MODAL 1------------------------------- -->


	<div class="modal fade" id="asignar-rol" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-lg">
			<div class="modal-content">
				<form id="formulariosuario" method="post"  class="campos formu-control">

					<div class="modal-header" style="background-color: #950014FF;">
						<h5 class="modal-title" id="exampleModalLabel" style="color: white;">Asignación de Rol</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>

					<div id="inputcedula"></div>

					<div class="row mb-2" id="camposnombreapellido"></div>

					<div class="row mb-2">
						<div class="col col-sm-3" style>
							<p class="text-end"><label for="cedula-usuario" class="form-label">Cedula de Usuario</label></p>	
						</div>
						<div class="col col-sm-9 formu-control">
							<input type="text" class="form-control" id="cedulausuario" name="cedulausuario">
							<small>Error message</small>
						</div>
					</div>

					<div class="row mb-2">
						<div class="col col-sm-3" style>
							<p class="text-end"><label for="select-usuario" class="form-label">Rol a asignar</label></p>
						</div>

						<div class="col col-sm-9 formu-control">
							<select name="rolusuario" class="form-select" id="rolusuario">
								<option selected disabled value="">Seleccione el rol</option>
								<option value="administrador">administrador</option>
								<option value="analista">analista</option>
								<option value="consulta">consulta</option>
							</select>
							<small>Error message</small>
						</div>
					</div>

					<div class="row mb-2">
						<div class="col col-sm-3" style>
							<p class="text-end"><label for="nombre-usuario" class="form-label">Nombre de Usuario</label></p>	
						</div>
						<div class="col col-sm-9 formu-control">
							<input type="text" class="form-control" placeholder="Nombre Usuario" id="nombreusuario" name="nombreusuario">
							<small>Error message</small>
						</div>
					</div>

					<div class="row mb-2">
						<div class="col col-sm-3" style>
							<p class="text-end"><label for="contraseña-usuario" class="form-label">Contraseña</label></p>
						</div>
						<div class="col col-sm-9 formu-control">
							<input type="password" class="form-control" placeholder="Ingrese la Contraseña" id="passwordusuario" name="passwordusuario">
							<small>Error message</small>
						</div>
					</div>

					<div class="row mb-2">
						<div class="col col-sm-3" style>
							<p class="text-end"><label for="contraseña-usuario-2" class="form-label">Repetir Contraseña</label></p>
						</div>
						<div class="col col-sm-9 formu-control">
							<input type="password" class="form-control" placeholder="Repita la Contraseña" id="passwordusuario2" name="passwordusuario2">
							<small>Error message</small>
						</div>
					</div>

					<input type="hidden" name="estatususuario" id="estatususuario" value="usuarioactivo">

					<div class="modal-footer">
						<button type="button" id="botonresetlocal" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
						<button type="submit"  class="btn btn-primary">Guardar</button>
					</div>

				</form>
			</div>
		</div>
	</div>

	<!-- -----------------------------MODAL 1------------------------------- -->


	<!-- -----------------------------MODAL 2------------------------------- -->

	<div class="modal fade" id="modalmodificaruser" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-lg">
			<div class="modal-content">

			<form id="formulariomodificarusuario" method="post"  class="campos formu-control">
					
				<div class="modal-header" style="background-color: #950014FF;">
					<h5 class="modal-title" id="exampleModalLabel" style="color: white;">Asignación de Rol</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>

				<div class="modal-body">
						
					<div id="inputcedula"></div>

					<div class="row mb-2" id="camposnombreapellido"><!--<div class="col col-sm-3"><p class="text-end">Nombre de la Persona</p></div><div class="col col-sm-9 "><p>Nombre Usuario Apellidos</p></div>-->
					</div>

					<div class="row mb-2">
						<div class="col col-sm-3" style>
							<p class="text-end"><label for="cedula-usuario" class="form-label">Cedula de Usuario</label></p>	
						</div>
						<div class="col col-sm-9 formu-control">
							<input type="text" class="form-control" id="usercedulausuario" name="usercedulausuario" value="">
							<small>Error message</small>
						</div>
					</div>

					<div class="row mb-2">
						<div class="col col-sm-3" style>
							<p class="text-end"><label for="select-usuario" class="form-label">Rol a asignar</label></p>
						</div>

						<div class="col col-sm-9 formu-control">
							<select name="userrolusuario" class="form-select" id="userrolusuario">
								<option selected disabled value="">rol usuario</option>
								<option value="administrador">administrador</option>
								<option value="analista">analista</option>
								<option value="consulta">consulta</option>
							</select>
							<small>Error message</small>
						</div>
					</div>

					<div class="row mb-2">
						<div class="col col-sm-3" style>
							<p class="text-end"><label for="nombre-usuario" class="form-label">Nombre de Usuario</label></p>	
						</div>
						<div class="col col-sm-9 formu-control">
							<input type="text" class="form-control" placeholder="Nombre Usuario" id="usernombre" name="usernombre" value="">
							<small>Error message</small>
						</div>
					</div>

					<div class="row mb-2">
						<div class="col col-sm-3" style>
							<p class="text-end"><label for="contraseña-usuario" class="form-label">Contraseña</label></p>
						</div>
						<div class="col col-sm-9 formu-control">
							<input type="text" class="form-control" placeholder="Ingrese la Contraseña" id="userpasswordusuario" name="userpasswordusuario" value="">
							<small>Error message</small>
						</div>
					</div>

					<div class="row mb-2">
						<div class="col col-sm-3" style>
							<p class="text-end"><label for="contraseña-usuario-2" class="form-label">Repetir Contraseña</label></p>
						</div>
						<div class="col col-sm-9 formu-control">
							<input type="text" class="form-control" placeholder="Repita la Contraseña" id="userpasswordusuario2" name="userpasswordusuario2" value="">
							<small>Error message</small>
						</div>
					</div>

					<div class="row mb-2">
						<div class="col col-sm-3" style>
							<p class="text-end"><label for="select-usuario" class="form-label">estado del usuario</label></p>
						</div>

						<div class="col col-sm-9 formu-control">
							<select name="uuserstatus" class="form-select" id="uuserstatus">
								<option selected disabled value="">estatus usuario</option>
								<option value="usuariodesactivado">desactivar</option>
								<option value="usuarioactivo">activar</option>

							</select>
							<small>Error message</small>
						</div>
					</div>

					<input type="hidden" name="usercedulauser" id="usercedulauser" value="">

				</div>

				<div class="modal-footer">
					<button type="button" id="botonresetlocal" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
					<button type="submit"  class="btn btn-primary">Modificar</button>
				</div>

			</form>

			</div>
		</div>
	</div>

	<!-- -----------------------------MODAL 2------------------------------- -->

	<!-- -----------------------------MODAL 3------------------------------- -->

	<div class="modal fade" id="botoncrearusuario-rol" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-lg">
			<div class="modal-content">
				<form id="formulariosuario" method="post"  class="campos formu-control">
					<div class="modal-header" style="background-color: #950014FF;">
						<h5 class="modal-title" id="exampleModalLabel" style="color: white;">Asignación de Rol</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
				<div class="modal-body">
					
				</div>

				</form>				
			</div>
		</div>
	</div>


	<!-- -----------------------------MODAL 3------------------------------- -->

	<!-- -----------------------------MODAL 4------------------------------- -->
	<!-- -----------------------------MODAL 4------------------------------- -->














<script src="jquery.min.js"></script>
<script src="registrarusuarios.js"></script>
<script src="../controlador/buscarusuario.js"></script>
<script src="../controlador/desactivarusuario.js"></script>
<script src="../controlador/modificarusuario.js"></script>
<script src="../controlador/mostrarusuarios.js"></script>
<script src="../controlador/buscarmodificarusuario.js"></script>
<script src="controlusuariosistema.js"></script>
<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>