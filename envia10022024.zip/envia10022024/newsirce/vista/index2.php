<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SIRCE</title>
	<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<style>

	body{
		background: url(../1.jpg);
		background-repeat: no-repeat;
		background-size: cover;
		background-attachment: fixed;
		background-position: center;
		z-index: -1;
	}

	#caja-login{
		display: flex;
		align-content: center;
		width: 60%;
		margin: auto;
	}

</style>


<body>
	
	<div class="container">

		<div class="row">
			<div class="col-md-6 offset-md-3">
				<h2 class="text-center pt-3 text-white">SIRCE</h2>
				<br>
				<h4 class="text-white text-center" >Sistema de Registro y Control de Expedientes</h4>
				<hr class="pb-2" style="color: white;">
			</div>
		</div>

		<div class="row bg-white rounded" id="caja-login" >

			<div class="col-md-6">
				<div style=""><img src="../escudo.png" class="img-fluid float-start"></div>
			</div>

			<div class="col-md-6 ps-4 pe-5 d-flex align-items-center justify-content-center flex-wrap-wrap flex-direction-column ">
				<div class="" >
					<h2 class="p-2 text-center fw-bold">Inicio de Sesión</h2>

					<div class="row">
						<form id="formulogine" method="post"  class="d-flex flex-column justify-content-between">

							<div class="py-3">
								<input type="text"  placeholder="Usuario"  class="texto form-control" style="text-transform: uppercase;" id="nombreusuario" name="nombreusuario">
							</div>

							<div class="pt-2 pb-4 ">
								<input type="password"  placeholder="contraseña" class="texto form-control" style="text-transform: uppercase;" id="passwordusuario" name="passwordusuario">

								<input type="hidden" id="tiporoluser" name="tiporoluser">

							</div>

							<input id="" type="submit" name="" class="py-2 btn btn-primary" value="Iniciar Sesión">
						</form>

					</div>

					<p class="fotg-pass"></p>
				</div>
			</div>
		</div>
	</div>

</body>
</html>