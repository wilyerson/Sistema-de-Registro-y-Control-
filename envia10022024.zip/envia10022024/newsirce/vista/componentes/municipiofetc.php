<div class="row mb-4 align-baseline">

				<div class="col col-sm-3 d-flex justify-content-end align-items-center">
					<p class="m-0">Municipio</p>
				</div>

				<div class="col col-sm-9">
					<select class="form-select" name="id_mun" id="id_mun" aria-label="Default select example">
						<option selected disabled>Seleccione Municipio</option>
						<?php 

						require "../controlador/municipiosfetch.php";

						foreach ($municipio as $municipio) {
							echo '<option value="'.$municipio['CodigoMunicipio'].'">'.$municipio['NombreMunicipio'].'</option>';
							}
						?>
					</select>
				</div>

			</div>

			<div class="row mb-4 align-baseline">

				<div class="col col-sm-3 d-flex justify-content-end align-items-center">
					<p class="m-0">Parroquia</p>
				</div>

				<div class="col col-sm-9">
					<select class="form-select" name="parroquiareg" id="parroquiareg" aria-label="Default select example">
						<option selected disabled>seleccione Parroquia</option>
						
					</select>
				</div>
				<script>
					document.querySelector('#id_mun').addEventListener('change', event => {
						console.log(event.target.value);
						fetch('../controlador/parroquiasfetch.php?id_mun='+event.target.value)
						.then(res => {
							if(!res.ok){
								throw new Error('error en la respuesta');
							}
							return res.json();
						})
						.then(datos => {
							let html = '<option value="">Seleccione Parroquia</option>';
							if(datos.data.length > 0){
								for(let i = 0; i < datos.data.length; i++){
									html += `<option value="${datos.data[i].CodigoParroquia}">${datos.data[i].NombreParroquia}</option>`; 
								}
							}
							document.querySelector('#parroquiareg').innerHTML = html;
						})
						.catch(error => {
							console.error('ocurrio un error '+error);
						});	
					});
				</script>

			</div>