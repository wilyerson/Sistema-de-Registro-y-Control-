const dibujarTabla = (data) => {
	let tbody = document.querySelector("#data");
	tbody.innerHTML = "";
	if (data.length > 0) {
		for (let registro of data) {
			tbody.innerHTML += `
         <tr>
         <td class="text-center">${registro.NombreInstitucion}</td>
         <td class="text-center">${registro.CodigoRegistro}</td>
         <td class="text-center" style="padding-right: ">
         <form method="POST" id="editarinstitucion">
          <input type="hidden" id="codinstitucion" name="codinstitucion" value="${registro.CodigoInstituciones}">
         <button  type="submit" id="botonmodificarinsti" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal-editar" >Editar</button>
         </form>
         </td>
         </tr>
         `;
		}
	} else {
		tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${data}</th>
            </td>
            </tr>
            `;
	}
};
