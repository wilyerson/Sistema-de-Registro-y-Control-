const formdata = document.querySelector("#formmodificarinstitucion");
formdata.addEventListener("submit", (e) => {
	e.preventDefault();

	let url = '../controlador/ctlr-reg-instituciones.php?op=update';
	let data = new FormData(formdata); // Cambia 'this' por 'formdata'

		// Imprimir los valores de FormData en la consola
	for (let [key, value] of data.entries()) {
		console.log(key, value);
	}

	fetch(url, {
		method: 'POST',
		body: data
	})
	.then(response => response.json())
	.then(respuesta => {
		console.log(respuesta);
		//console.log(respuesta[0].CodigoInstituciones);
		$('#modal-editar').modal('hide');

		Swal.fire({
  title: "Institucion Modificada con exito!",
  //text: "Institucion Modificada con exito!",
  icon: "success"
});
   document.querySelector('.swal2-confirm').addEventListener('click', function() {
    location.reload();
});
		

		if (!respuesta.error) {
			console.log("sirve");
		} else {
			if (respuesta.error === true ) {
				// Handle error
			}
		}
	})
	.catch(error => {
		// Handle fetch error
		console.log(error);
	});
});