<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

   
    $user  = $_SESSION["usuarioad"];
    //$passwordusuario = $_SESSION["passuser"];

    $pass = $_POST['pass'];
    //$pass2 = $_POST['pass2'];


    
         $actualizar = "UPDATE usuarios SET passwordusuario ='$pass' WHERE nombreusuario ='$user' ";


         $resultado = mysqli_query($conn,$actualizar);
         if($resultado == 1){
              

             //$query = "INSERT INTO documento(Nombredocumento) values('$datosp[15]')";
            
             //$resultado2 = mysqli_query($conn,$query);

         }else{
        
            // $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
             //$_SESSION['tipo'] = 'danger';
         }



    

?>