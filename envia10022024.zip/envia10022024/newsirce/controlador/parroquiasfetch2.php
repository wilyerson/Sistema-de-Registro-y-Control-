<?php 


	require_once "../modelo/ModeloParroquia.php";

	$parroquias2 = [];
	if (isset($_GET['id_mun2'])) {
		$tabla_parroquia = new parroquia();
		$parroquias2 = $tabla_parroquia->obtener_parroquia_select($_GET['id_mun2']);
	}
		echo json_encode(['data' => $parroquias2] );

		
 ?>