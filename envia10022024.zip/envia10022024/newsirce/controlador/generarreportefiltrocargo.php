<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 


use PhpOffice\PhpSpreadsheet\{Spreadsheet, IOFactory};


require 'excel/vendor/autoload.php';

$cargo = $conn->real_escape_string($_POST['cargo']);



$sql = "SELECT * from historico WHERE cargohistorico LIKE '$cargo' ";
 $resultado = mysqli_query($conn,$sql);
 //$resultado = $mysqli->query($sql);

 $excel = new  Spreadsheet();
 $hojaActiva = $excel->getActiveSheet();
 $hojaActiva->setTitle("Personas");

 $hojaActiva->getColumnDimension('A')->setWidth(18);
 $hojaActiva->setCellValue('A1','Cedulapersona');
 $hojaActiva->getColumnDimension('B')->setWidth(28);
 $hojaActiva->setCellValue('B1','Cargo');

 $hojaActiva->getColumnDimension('C')->setWidth(28);
$hojaActiva->setCellValue('C1','tipo de trabajador');
$hojaActiva->getColumnDimension('D')->setWidth(28);
$hojaActiva->setCellValue('D1','tipo de personal');

 $hojaActiva->getColumnDimension('E')->setWidth(28);
$hojaActiva->setCellValue('E1','fecha de inicio');
$hojaActiva->getColumnDimension('F')->setWidth(25);
$hojaActiva->setCellValue('F1','fecha de culminacion');
$hojaActiva->getColumnDimension('G')->setWidth(25);
$hojaActiva->setCellValue('G1','observacion');



$fila = 2;

 while($rows = $resultado->fetch_assoc()){

    $hojaActiva->setCellValue('A'.$fila,$rows['Cedulapersona']);
    $hojaActiva->setCellValue('B'.$fila,$rows['cargohistorico']);

    $hojaActiva->setCellValue('C'.$fila,$rows['tipotrabajador']);
    $hojaActiva->setCellValue('D'.$fila,$rows['tipopersonal']);

    $hojaActiva->setCellValue('E'.$fila,$rows['fechainiciohistorico']);
    $hojaActiva->setCellValue('F'.$fila,$rows['fechaculminacionhistotico']);
    $hojaActiva->setCellValue('G'.$fila,$rows['observacionhistorico']);
    $fila++;

 }


header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="personas.xlsx"');
header('Cache-Control: max-age=0');

$writer = IOFactory::createWriter($excel, 'Xlsx');
$writer->save('php://output');
exit;

?>