<?php 

//$conn = mysqli_connect("localhost","root","","newsirce"); 


function conexion(){
    return mysqli_connect("localhost","root","","newsirce"); 
}


$conexion = conexion();
$sql = "SELECT Cedulapersona,Nombres,Apellidos FROM persona";
$resultado = mysqli_query($conexion,$sql);
$datos = mysqli_fetch_all($resultado,MYSQLI_ASSOC);

if(!empty($datos)){
    echo json_encode($datos);
}else{
    echo json_encode([]);
}

?>