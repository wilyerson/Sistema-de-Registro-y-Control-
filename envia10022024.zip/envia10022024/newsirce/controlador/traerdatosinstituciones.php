<?php 

//$conn = mysqli_connect("localhost","root","","newsirce"); 


function conexion(){
    return mysqli_connect("localhost","root","","sirceop"); 
}


$conexion = conexion();

$sql = "SELECT municipio.NombreMunicipio, municipio.CodigoMunicipio,parroquia.NombreParroquia, instituciones.NombreInstitucion, instituciones.CodigoInstituciones, instituciones.CodigoRegistro, instituciones.Direccion, instituciones.ParroquiaInstitucion, instituciones.Sector FROM instituciones INNER JOIN parroquia ON instituciones.ParroquiaInstitucion = parroquia.CodigoParroquia INNER JOIN municipio ON parroquia.MunicipioParroquia = municipio.CodigoMunicipio WHERE instituciones.CodigoInstituciones = '".@$_POST['codinstitucion']."' ";
$resultado = mysqli_query($conexion,$sql);
$datosh = mysqli_fetch_all($resultado,MYSQLI_ASSOC);

if(!empty($datosh)){
    
    echo json_encode($datosh);
}else{
    echo json_encode([]);
}



?>