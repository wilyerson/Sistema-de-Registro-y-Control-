<?php 


$conn = mysqli_connect("localhost","root","","newbasesirce"); 

class Persona
{

  public $imagen;
  public $cedula;
  public $estadocivilpersona;
  public $nombrespersona;
  public $apellidospersona;
  public $fechanacimientopersona;
  public $sexopersona;
  public $numerotelefonoprincipalpersona;
  public $numerotelefonicohabitacionpersona;
  public $direccionpersona;
  public $pesopersona;
  public $estaturapersona;
  public $tallacamisapersona;
  public $tallapantalonpersona;
  public $tallacalzadopersona;
  public $nombremunicipio;
  public $nombreparroquia;
  public $nombresector;
 
 // strtoupper($nombrespersona);

 public function registrar($datosp){

  $conn = mysqli_connect("localhost","root","","newbasesirce"); 

//$this->imagen = $imagen;

$query22 = "UPDATE persona SET Nombres = UPPER(Nombres)";
    $resultado2 = mysqli_query($conn,$query22);


    if(isset($datosp['0']) && $datosp['0'] != ""){
        $tipo = $_FILES['Fotopersona']['type'];
        $temp = $_FILES['Fotopersona']['tmp_name'];

       if( !((strpos($tipo,'gif') || strpos($tipo,'jpeg') || strpos($tipo,'webp')))){
         // $_SESSION['mensaje'] = 'solo se permite archivos jpeg, gif, webp';
          
       }else{



         $query = "INSERT INTO municipio (NombreMunicipio ) values('$datosp[15]')";


         $resultado = mysqli_query($conn,$query);

           $ultimo_id=mysqli_insert_id($conn);

             echo "$ultimo_id <br>";

             
         if($resultado == 1){


              move_uploaded_file($temp,'imagenes/'.$datosp['0']);   

             

             $query = "INSERT INTO parroquia(NombreParroquia,MunicipioParroquia) values('$datosp[16]','$ultimo_id')";

             
             $resultado2 = mysqli_query($conn,$query);

              if ($resultado2 == 1) {


             $query = "INSERT INTO sector(NombreSector,ParroquiaSector) values('$datosp[17]','$ultimo_id')";

             
             $resultado3 = mysqli_query($conn,$query);

             if ($resultado3 == 1) {


              $query = "INSERT INTO persona (Fotopersona,CedulaPersona,estadocivil,Nombres,Apellidos,Fechanacimiento,Sexo,TelefonoPrincipal,TelefonoHabitacion,Direccion,Peso,Estatura,TallaCamisa,TallaPantalon,TallaCalzado,IdPersona,Sector) values('$datosp[0]','$datosp[1]','$datosp[2]','$datosp[3]','$datosp[4]','$datosp[5]','$datosp[6]','$datosp[7]','$datosp[8]','$datosp[9]','$datosp[10]','$datosp[11]','$datosp[12]','$datosp[13]','$datosp[14]','$ultimo_id','$ultimo_id')";

             
             $resultado3 = mysqli_query($conn,$query);

             }
                
              }


         }else{
          echo "error error";
            // $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
             //$_SESSION['tipo'] = 'danger';
         }


       }
    }



  }


}

    $imagen = $_FILES['Fotopersona']['name'];
    $cedula = $_POST['Cedulapersona'];
    $estadocivilpersona = @$_POST['Estadocivil'];
    $nombrespersona = $_POST['Nombres'];
    $apellidospersona = $_POST['Apellidos'];
    $fechanacimientopersona = $_POST['Fechanacimiento'];
    $sexopersona = @$_POST['sexo'];
    $numerotelefonoprincipalpersona = $_POST['Telefonoprincipal'];
    $numerotelefonicohabitacionpersona = $_POST['Telefonohabitacion'];
    $direccionpersona = $_POST['direccion'];
    $pesopersona = $_POST['peso'];
    $estaturapersona = $_POST['estatura'];
    $tallacamisapersona = $_POST['tallacamisa'];
    $tallapantalonpersona = $_POST['tallapantalon'];
    $tallacalzadopersona = $_POST['tallacalzado'];
    
    $nombremunicipio = @$_POST['cosa'];
    $nombreparroquia = @$_POST['opt'];
    $nombresector = @$_POST['nombresector'];

    $datosp = array($imagen,$cedula , $estadocivilpersona, $nombrespersona, $apellidospersona, $fechanacimientopersona, $sexopersona,$numerotelefonoprincipalpersona, $numerotelefonicohabitacionpersona, $direccionpersona, $pesopersona, $estaturapersona,  $tallacamisapersona, $tallapantalonpersona, $tallacalzadopersona,$nombremunicipio,$nombreparroquia,$nombresector);



 $objetopersona = new Persona();
 
 if (!($objetopersona->registrar($datosp))) {
   
   //header('location:../vista/ingreso.php');
    @header('location:../vista/registrodocumentosprincipal.php');
 }else{ 
 

 }


?>