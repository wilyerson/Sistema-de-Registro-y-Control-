<?php

  $conn = mysqli_connect("localhost","root","","sirceop");


$query = ("SELECT * FROM usuarios WHERE NombreUsuario = '".@$_POST['nombreusuario']."' AND ConstraseñaUsuario  = '".@$_POST['passwordusuario']."' ");

$result = mysqli_query($conn,$query);

if (mysqli_num_rows($result) == 1):
  session_start();
  $_SESSION["usuarioad"]=$_POST["nombreusuario"];
  $_SESSION["passuser"]=$_POST["passwordusuario"];
  
  $datos = $result->fetch_assoc();
  echo json_encode(array('error' => false, 'tipo' => $datos['RolUsuario'], 'estatus' => $datos['EstatusUsuario']));
else:
    echo json_encode(array('error' => true));
  endif;

  //$mysqli->close();
  // code...





?>