const editar = (id) => {
	let url = "../controlador/ctlr-reg-instituciones.php?op=editar";
	let data = new FormData();
	data.append("CodigoInstituciones", id);
	let CodigoInstituciones, NombreInstitucion, CodigoRegistro, Direccion, ParroquiaInstitucion;
	fetch(url, {
		method: "post",
		body: data,
	})
		.then((response) => response.json())
		.then((response) => {
			console.log("Get reg", response);
			for (const reg of response) {
				CodigoInstituciones = reg.CodigoInstituciones;
				NombreInstitucion = reg.NombreInstitucion;
				CodigoRegistro = reg.CodigoRegistro;
				Direccion = reg.Direccion;
				ParroquiaInstitucion = reg.ParroquiaInstitucion;
			}
			let ModalUpdateform = `
			<form id="UpdateForm" class="g-3">
				<input type="text" class="form-control mb-3" value="${NombreInstitucion}" name="nombreinstitucion">
				<input type="text" class="form-control mb-3" value="${CodigoRegistro}" name="codigodeinstitucion">
				<input type="text" class="form-control mb-3" value="${Direccion}" name="direccion">
				
				<select name="parroquiainstitucion" class="form-control mb-3">
					
					
				</select>
				<input type="text" class="form-control" value="${CodigoInstituciones}" hidden="true" name="idUdt">
			</form>
				`;

			Swal.fire({
				title: "Actualizar Persona",
				html: ModalUpdateform,
				showDenyButton: true,
				confirmButtonText: "Aceptar",
				denyButtonText: "Cancelar",
				confirmButtonColor: "#3085d6",
				showLoaderOnConfirm: true,
				preConfirm: () => {
					return fetch(`../controlador/ctlr-reg-instituciones.php?op=update`, {
						method: "post",
						body: new FormData(document.getElementById("UpdateForm")),
					})
						.then((response) => {
							if (!response.ok) {
								throw new Error(response.statusText);
							}
							return response.json();
						})
						.catch((error) => {
							Swal.showValidationMessage(`Error en Solicitud: ${error}`);
						});
				},
			}).then((result) => {
				if (result.isConfirmed) {
					console.log("Updated reg:", result);
					dibujarTabla(result.value);
					Swal.fire("Exito", "Registro actualizado con exito", "success");
				} else if (result.isDenied) {
					Swal.fire("Los Cambios no fueron guardados", "", "info");
				}
			});
		})
		.catch((error) => console.log("error", error));
};
