-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-02-2023 a las 18:02:35
-- Versión del servidor: 10.4.27-MariaDB
-- Versión de PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `newsirce`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documento`
--

CREATE TABLE `documento` (
  `coddocumento` int(11) NOT NULL,
  `Cedulapersona` int(15) NOT NULL,
  `Nombredocumento` text NOT NULL,
  `fotodocumento` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `documento`
--

INSERT INTO `documento` (`coddocumento`, `Cedulapersona`, `Nombredocumento`, `fotodocumento`) VALUES
(1, 5, 'd2', 'Screenshot8888.jpg'),
(3, 5, 'd1', 'Screenshot8888.jpg'),
(28, 5, 'd1', 'bf0ceae6f06771245019816d9816c7ea.jpg'),
(29, 5, 'd1', '6aofsvaglm_Medium_WW226365.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `familia`
--

CREATE TABLE `familia` (
  `codfamilia` int(11) NOT NULL,
  `Cedulapersona` int(11) NOT NULL,
  `checkcedufami` varchar(5) NOT NULL,
  `parentesco` varchar(30) NOT NULL,
  `cedulafam` int(15) NOT NULL,
  `nombrefam` varchar(30) NOT NULL,
  `apellidofam` varchar(30) NOT NULL,
  `fechanacimientofam` date NOT NULL,
  `sexofam` varchar(15) NOT NULL,
  `estadocivilfam` varchar(30) NOT NULL,
  `telefonoprincipalfam` varchar(30) NOT NULL,
  `telefonohabitacionfam` varchar(30) NOT NULL,
  `direccionfam` text NOT NULL,
  `pesofam` double NOT NULL,
  `estaturafam` double NOT NULL,
  `tallacamisafam` varchar(15) NOT NULL,
  `tallapantalonfam` varchar(15) NOT NULL,
  `tallacalzadofam` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `familia`
--

INSERT INTO `familia` (`codfamilia`, `Cedulapersona`, `checkcedufami`, `parentesco`, `cedulafam`, `nombrefam`, `apellidofam`, `fechanacimientofam`, `sexofam`, `estadocivilfam`, `telefonoprincipalfam`, `telefonohabitacionfam`, `direccionfam`, `pesofam`, `estaturafam`, `tallacamisafam`, `tallapantalonfam`, `tallacalzadofam`) VALUES
(6, 5, '', 'hijo', 24574, '', '', '0000-00-00', '', '', '', '', '', 0, 0, '', '', ''),
(14, 5, '', 'esposa', 6767, '', '', '0000-00-00', '', '', '', '', '', 0, 0, '', '', ''),
(15, 5, '', 'hijo', 2222, '', '', '0000-00-00', '', '', '', '', '', 0, 0, '', '', ''),
(16, 5, 'on', 'hijo', 0, '', '', '0000-00-00', '', '', '', '', '', 0, 0, '', '', ''),
(18, 5, '', 'sobrino', 12345678, 'juann', 'rodriguezzzz', '2008-07-07', 'm', '1', '34423434', '32423423', 'miami miami', 7, 7, '7', '7', '7');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historico`
--

CREATE TABLE `historico` (
  `codhistorico` int(11) NOT NULL,
  `Cedulapersona` int(15) NOT NULL,
  `institucionhistorico` varchar(30) NOT NULL,
  `cargohistorico` varchar(30) NOT NULL,
  `fechainiciohistorico` date NOT NULL,
  `fechaculminacionhistotico` date NOT NULL,
  `observacionhistorico` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `historico`
--

INSERT INTO `historico` (`codhistorico`, `Cedulapersona`, `institucionhistorico`, `cargohistorico`, `fechainiciohistorico`, `fechaculminacionhistotico`, `observacionhistorico`) VALUES
(1, 5, '2', '2', '2023-02-02', '2023-02-08', 'wiiiiiiiiiiiiiiii'),
(2, 5, '1', '3', '2023-02-02', '2023-02-14', 'weeeeee');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `Cedulapersona` int(15) NOT NULL,
  `estadocivil` varchar(30) NOT NULL,
  `Fotopersona` text NOT NULL,
  `Nombres` varchar(30) NOT NULL,
  `Apellidos` varchar(30) NOT NULL,
  `Fechanacimiento` date NOT NULL,
  `sexo` varchar(15) NOT NULL,
  `Telefonoprincipal` varchar(30) NOT NULL,
  `Telefonohabitacion` varchar(30) NOT NULL,
  `sector` text NOT NULL,
  `direccion` text NOT NULL,
  `peso` double NOT NULL,
  `estatura` double NOT NULL,
  `tallacamisa` varchar(15) NOT NULL,
  `tallapantalon` varchar(15) NOT NULL,
  `tallacalzado` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`Cedulapersona`, `estadocivil`, `Fotopersona`, `Nombres`, `Apellidos`, `Fechanacimiento`, `sexo`, `Telefonoprincipal`, `Telefonohabitacion`, `sector`, `direccion`, `peso`, `estatura`, `tallacamisa`, `tallapantalon`, `tallacalzado`) VALUES
(5, '1', 'Screenshot8888.jpg', '', '', '0000-00-00', '', '', '', '', '', 0, 0, '', '', ''),
(12345678, 'soltero', '6aofsvaglm_Medium_WW226365.jpg', 'anaa', 'rodriguez', '2004-02-04', 'f', '546456456', '987879797', '', 'newyork newyork', 5, 5, '5', '5', '5'),
(23433965, 'casado', '6aofsvaglm_Medium_WW226365.jpg', 'samuel', 'perez', '2004-05-04', 'm', '', '7878787', '', 'ertertert ertertert', 7, 7, '7', '7', '7');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `codigousuario` int(11) NOT NULL,
  `Cedulapersona` int(15) NOT NULL,
  `nombreusuario` varchar(30) NOT NULL,
  `correousuario` varchar(40) NOT NULL,
  `passwordusuario` varchar(30) NOT NULL,
  `rolusuario` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`codigousuario`, `Cedulapersona`, `nombreusuario`, `correousuario`, `passwordusuario`, `rolusuario`) VALUES
(1, 12345678, 'juan', 'juan@gmail.com', '1234', 'administrador'),
(2, 12345678, 'consulta', 'consulta@gmail.com', '1234', 'consulta'),
(3, 23433965, 'samuel', '', '1234', 'administrador'),
(6, 23433965, 'samuel8', '', '1234', 'analista');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `documento`
--
ALTER TABLE `documento`
  ADD PRIMARY KEY (`coddocumento`),
  ADD KEY `Cedulapersona` (`Cedulapersona`);

--
-- Indices de la tabla `familia`
--
ALTER TABLE `familia`
  ADD PRIMARY KEY (`codfamilia`),
  ADD KEY `Cedulapersona` (`Cedulapersona`);

--
-- Indices de la tabla `historico`
--
ALTER TABLE `historico`
  ADD PRIMARY KEY (`codhistorico`),
  ADD KEY `Cedulapersona` (`Cedulapersona`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`Cedulapersona`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`codigousuario`),
  ADD KEY `Cedulapersona` (`Cedulapersona`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `documento`
--
ALTER TABLE `documento`
  MODIFY `coddocumento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `familia`
--
ALTER TABLE `familia`
  MODIFY `codfamilia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `historico`
--
ALTER TABLE `historico`
  MODIFY `codhistorico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `codigousuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `documento`
--
ALTER TABLE `documento`
  ADD CONSTRAINT `documento_ibfk_1` FOREIGN KEY (`Cedulapersona`) REFERENCES `persona` (`Cedulapersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `familia`
--
ALTER TABLE `familia`
  ADD CONSTRAINT `familia_ibfk_1` FOREIGN KEY (`Cedulapersona`) REFERENCES `persona` (`Cedulapersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `historico`
--
ALTER TABLE `historico`
  ADD CONSTRAINT `historico_ibfk_1` FOREIGN KEY (`Cedulapersona`) REFERENCES `persona` (`Cedulapersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`Cedulapersona`) REFERENCES `persona` (`Cedulapersona`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
