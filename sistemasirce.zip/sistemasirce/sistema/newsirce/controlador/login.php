<?php

  $conn = mysqli_connect("localhost","root","","newsirce");


$query = ("SELECT nombreusuario, rolusuario FROM usuarios WHERE nombreusuario = '".@$_POST['nombreusuario']."' AND passwordusuario = '".@$_POST['passwordusuario']."' ");

$result = mysqli_query($conn,$query);

if (mysqli_num_rows($result) == 1):
  session_start();
  $_SESSION["usuarioad"]=$_POST["nombreusuario"];
  
  $datos = $result->fetch_assoc();
  echo json_encode(array('error' => false, 'tipo' => $datos['rolusuario']));
else:
    echo json_encode(array('error' => true));
  endif;

  //$mysqli->close();
  // code...





?>