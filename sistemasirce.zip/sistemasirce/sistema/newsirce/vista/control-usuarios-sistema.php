<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>	
	<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
	

<style type="text/css">
		

		 .inputcedulaestilo{
        display: none;
      }

      .imagregistrodocumento{
        width: 100px;
      }

      .formu-control.success input {
  border-color: #2ecc71;
}

.formu-control.error input {
  border-color: #e74c3c;
}

.formu-control.success select {
  border-color: #2ecc71;
}

.formu-control.error select {
  border-color: #e74c3c;
}

.formu-control .fas {
  visibility: hidden;
  /*position: absolute;
  top: 40px;
  right: 10px;*/
}

.formu-control.success .fas.fa-check-circle {
  color: #2ecc71;
  visibility: visible;
}

.formu-control.error .fas.fa-exclamation-circle {
  color: #e74c3c;
  visibility: visible;
}

.formu-control small {
  color: #e74c3c;
  /*position: absolute;
  bottom: 0;
  left: 0;*/
  visibility: hidden;
}

.formu-control.error small {
  visibility: visible;
  
}


	</style>

</head>
	
    <?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>

<body class="bg-light">

	<nav class="navbar fixed-top" style="background-color: #950014FF;">
      <div class="container" style="width: 900px;">
        <a class="navbar-brand " href="#"><H4 style="color:white" >S.I.R.C.E</H4></a>
        <button class="navbar-toggler bg-p bg-light" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end " tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Nombre Usuario</h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item" >
            	<li class="nav-item">
	              <a class="nav-link" aria-current="page" href="inicio.php">Inicio</a>
	            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="modificar-contrasena-usuario.php">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Control de Usuarios de Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Asignar Usuarios de Sistema</a></li>
                <li><a class="dropdown-item" href="#">Eliminar Usuarios del Sistema</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="#">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
  	</nav>

  	<div class="container border rounded py-3 bg-white" style="max-width: 1000px; margin-top: 100px; ">
  		<div class="d-flex align-items-start" >

		  <div class="nav flex-column nav-pills me-3 mt-3" style="width: 27%;" id="v-pills-tab" role="tablist" aria-orientation="vertical">

		    <button class="nav-link active"  id="v-pills-registro-tab" data-bs-toggle="pill" data-bs-target="#v-pills-registro" type="button" role="tab" aria-controls="v-pills-registro" aria-selected="true">Registrar Usuarios del Sistema</button>

		    <button class="nav-link"  id="v-pills-eliminar-tab" data-bs-toggle="pill" data-bs-target="#v-pills-eliminar" type="button" role="tab" aria-controls="v-pills-eliminar" aria-selected="false">Eliminar Usuarios del Sistema</button>

		  </div>

		  <div class="tab-content" id="v-pills-tabContent" style="width: 73%; padding: 10px 30px 10px 30px;">

		    <div class="tab-pane fade show active" id="v-pills-registro" role="tabpanel" aria-labelledby="v-pills-registro-tab">
		    	
			<form id="formbusqueda" method="post"  class="campos formu-control">
				
				<div class="row">
					<label for="cedula-listar-nuevo-usuario" class="form-label"></label>
					<div class="input-group formu-control" name="tipo-ci">
				        <select class="form-select">  
				           <option value="v">V</option>
				           <option value="e">E</option>  
				            <option value="p">P</option>
				          </select>
				          
				          <input type="number" id="buscarcedu" name="buscarcedu" class="form-control" style="width: 70%" placeholder="Cédula hola" aria-label="Text input with dropdown button" >
				        <small>Error message</small>	
				          
				          <p id="resultado" ></p>
				        
				    </div>
					<div id="passwordHelpBlock" class="form-text">Los Usuarios listados solo laboran y mantienen un estatus activo dentro de la Dirección de Personal.
					</div>
				</div>
<!--///////////////////////////////////////	MODAL//////////////////////////////////////////////////-->
<!--///////////////////////////////////////	MODAL//////////////////////////////////////////////////-->
					<!-- Button trigger modal -->
				<div class="d-flex justify-content-center mt-md-3">

					<button type="submit" id="botonasignarrol" class="btn btn-primary" >
					  Asignar Rol
					</button>
								</form>		
				</div>

				<!-- Modal -->
				<div class="modal fade" id="asignar-rol" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-lg">
				    <div class="modal-content">

				    	<!-- form -->

				    	<form id="formulariosuario" method="post"  class="campos formu-control">
				    		
				    	

				      <div class="modal-header" style="background-color: #950014FF;">
				        <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Asignación de Rol</h5>
				        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				    </div>
					<div class="modal-body">

						<div id="inputcedula">
							
						</div>

						<div class="row mb-2" id="camposnombreapellido">
							<!--<div class="col col-sm-3"><p class="text-end">Nombre de la Persona</p></div>
							<div class="col col-sm-9 ">
								<p>Nombre Usuario Apellidos</p>
							</div>-->
						</div>

						<div class="row mb-2">
							<div class="col col-sm-3" style>
								<p class="text-end"><label for="select-usuario" class="form-label">Rol a asignar</label></p>
							</div>
							<div class="col col-sm-9 formu-control">
								<select name="rolusuario" class="form-select" id="rolusuario">
									<option selected>Seleccione el Rol</option>
									<option value="administrador">administrador</option>
									<option value="analista">analista</option>
									<option value="consulta">consulta</option>
								</select>
								 <small>Error message</small>
							</div>
						</div>

						<div class="row mb-2">
							<div class="col col-sm-3" style>
								<p class="text-end"><label for="nombre-usuario" class="form-label">Nombre de Usuario</label></p>	
							</div>
							<div class="col col-sm-9 formu-control">
 							   <input type="text" class="form-control" placeholder="Nombre Usuario" id="nombreusuario" name="nombreusuario">
 							    <small>Error message</small>
							</div>
						</div>

						<div class="row mb-2">
							<div class="col col-sm-3" style>
								<p class="text-end"><label for="contraseña-usuario" class="form-label">Contraseña</label></p>
							</div>
							<div class="col col-sm-9 formu-control">
    							<input type="password" class="form-control" placeholder="Ingrese la Contraseña" id="passwordusuario" name="passwordusuario">
    							 <small>Error message</small>
							</div>
						</div>

						<div class="row mb-2">
							<div class="col col-sm-3" style>
								<p class="text-end"><label for="contraseña-usuario-2" class="form-label">Repetir Contraseña</label></p>
							</div>
							<div class="col col-sm-9 formu-control">
    							<input type="password" class="form-control" placeholder="Repita la Contraseña" id="passwordusuario2" name="passwordusuario2">
    							 <small>Error message</small>
							</div>
						</div> 

					</div>
				      <div class="modal-footer">
				        <button type="button" id="botonresetlocal" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
				        <button type="submit"  class="btn btn-primary">Guardar</button>
				      </div>
				    	</form>
				    </div> <!-- form -->
				  </div> 
				</div>

<!--///////////////////////////////////	CIERRE MODAL 1//////////////////////////////////////////////////-->
<!--///////////////////////////////////	CIERRE MODAL 1//////////////////////////////////////////////////-->
			

		    </div>

		    <div class="tab-pane fade" id="v-pills-eliminar" role="tabpanel" aria-labelledby="v-pills-eliminar-tab">
		    	
		    	<form action="#" method="POST">
				
				<div class="row">
					<label for="cedula-listar-nuevo-usuario" class="form-label"></label>
					<div class="input-group" name="tipo-ci">
				        <select class="form-select">  
				           <option value="v">V</option>
				           <option value="e">E</option>  
				            <option value="p">P</option>
				          </select>
				        <input type="number" name="cedula-persona" class="form-control" style="width: 70%" placeholder="Cédula" aria-label="Text input with dropdown button">
				    </div>
					<div id="passwordHelpBlock" class="form-text">Los Usuarios listados solo laboran y mantienen un estatus activo dentro de la Dirección de Personal.
					</div>
				</div>
<!--///////////////////////////////////////	MODAL 2//////////////////////////////////////////////////-->
<!--///////////////////////////////////////	MODAL 2//////////////////////////////////////////////////-->
					<!-- Button trigger modal -->
				<div class="d-flex justify-content-center mt-md-3">

					<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#eliminar-usuario">
						Eliminar Usuario
					</button>
										
				</div>

				<!-- Modal -->
				<div class="modal fade" id="eliminar-usuario" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
				  <div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-lg">
				    <div class="modal-content">
				      <div class="modal-header" style="background-color: #950014FF;">
				        <h5 class="modal-title" id="exampleModalLabel" style="color: white;">Eliminación de Usuario</h5>
				        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				    </div>
					<div class="modal-body">

						<div class="row mt-5 mb-5">
							<div class="col col-sm-12">
								<h5>¿Está seguro que desea eliminar a la persona "Nombre Persona Apellidos" como usuario del sistema con el rol de "Tipo de usuario"?</h5>
							</div>
						</div>

					</div>
				      <div class="modal-footer">
				        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, cancelar</button>
				        <button type="submit" class="btn btn-primary">si, eliminar</button>
				      </div>
				    </div>
				  </div>
				</div>

<!--///////////////////////////////////	CIERRE MODAL 2////////////////////////////////////////////////-->
<!--///////////////////////////////////	CIERRE MODAL 2////////////////////////////////////////////////-->

			</form>

		    </div>
		  </div>

		</div>
  	</div>


  	<div class="modal fade" id="modalregistrarrellenecampos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                      <div class="col col-sm-6">

                        <p>rellener todos los campos</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

                  </div>
                </div>
              </div>
            </div>


            <div class="modal fade" id="modalusuarionoesta" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">
                                        
                      <div class="col col-sm-6">

                        <p>usuario no existe</p>
                      </div>
    
                     </div>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->
                  </div>
                </div>
              </div>
            </div>

            <div class="modal fade" id="modalregistrarexitoso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">
                                      
                      <div class="col col-sm-6">

                        <p>usuario registrado con existo</p>
                      </div>
      
                     </div>

                  </div>
                  <div class="modal-footer">
                   <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="botonrecargarpaginadocumentos">Cerrar</button>

                  </div>
                </div>
              </div>
            </div>

<script src="jquery.min.js"></script>
 <script src="registrarusuarios.js"></script>
 <script src="controlusuariosistema.js"></script>
 <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>