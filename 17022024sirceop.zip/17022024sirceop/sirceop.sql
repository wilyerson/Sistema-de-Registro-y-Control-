-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2024 at 06:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sirceop`
--
CREATE DATABASE sirceop;
USE sirceop;
-- --------------------------------------------------------

--
-- Table structure for table `archivos`
--

CREATE TABLE `archivos` (
  `ArchivoRegistro` int(10) NOT NULL,
  `CodigoDocumento` int(10) NOT NULL,
  `idperarchivos` int(10) NOT NULL,
  `archivosjpg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `archivos`
--

INSERT INTO `archivos` (`ArchivoRegistro`, `CodigoDocumento`, `idperarchivos`, `archivosjpg`) VALUES
(1, 8, 1, 'imagenes/590054c0-dc7e-4cd8-9ce6-41da51435347.jpg'),
(2, 1, 1, 'imagenes/8aa4ff22-5857-4aee-95e0-672c472c87c8.jpg'),
(3, 1, 9, 'imagenes/leon.jpg'),
(4, 8, 9, 'imagenes/9/leon1.jpg'),
(5, 14, 9, 'imagenes/9/422145271_349365321327281_3848567651902845081_n.jpg'),
(6, 1, 5, 'imagenes/5/Capture001.png'),
(7, 2, 9, 'imagenes/9/Capture001.png'),
(8, 14, 5, 'imagenes/5/leon1.jpg'),
(9, 2, 5, 'imagenes/5/leon.jpg'),
(10, 5, 5, 'imagenes/5/422145271_349365321327281_3848567651902845081_n.jpg'),
(11, 1, 35, 'imagenes/35/leon1.jpg'),
(12, 2, 35, 'imagenes/35/leon.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cargos`
--

CREATE TABLE `cargos` (
  `CodigoCargo` int(10) NOT NULL,
  `NombreCargo` varchar(40) NOT NULL,
  `TipoCargo` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cargos`
--

INSERT INTO `cargos` (`CodigoCargo`, `NombreCargo`, `TipoCargo`) VALUES
(1, 'Bachiller I', 1),
(2, 'Bachiller II', 1),
(3, 'Bachiller III', 1),
(4, 'TSU I', 1),
(5, 'TSU II', 1),
(6, 'Profesional I', 1),
(7, 'Profesional II', 1),
(8, 'Profesional III', 1),
(9, 'Obrero Grado  1', 11),
(10, 'Obrero Grado  2', 11),
(11, 'Obrero Grado  3', 11),
(12, 'Obrero Grado  4', 11),
(13, 'Obrero Grado  5', 11),
(14, 'Obrero Grado  6', 11),
(15, 'Obrero Grado  7', 11),
(16, 'Obrero Grado  8', 11),
(17, 'Obrero Grado  9', 11),
(18, 'Obrero Grado  10', 11),
(19, 'Jefe de Departamento', 10),
(20, 'Jefe de División', 10),
(21, 'Director de Linea', 10),
(22, 'Director General', 10),
(23, 'Secretario General de gobierno', 10),
(24, 'Gobernador', 10);

-- --------------------------------------------------------

--
-- Table structure for table `documento`
--

CREATE TABLE `documento` (
  `CodigoDocumento` int(10) NOT NULL,
  `NombreDocumento` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `documento`
--

INSERT INTO `documento` (`CodigoDocumento`, `NombreDocumento`) VALUES
(7, 'asignacion de trabajado'),
(8, 'boleta de vacaciones'),
(9, 'carta de renuncia'),
(1, 'cedula'),
(10, 'comision de servicio asignado'),
(5, 'cuenta bancaria'),
(2, 'curriculum'),
(14, 'decreto de ascenso'),
(15, 'decreto de jubilacion'),
(13, 'decreto de nombramiento'),
(3, 'partida de nacimiento'),
(12, 'permiso no remunerado'),
(11, 'permiso remunerado'),
(4, 'r.i.f.'),
(6, 'titulo obtenido');

-- --------------------------------------------------------

--
-- Table structure for table `familiar`
--

CREATE TABLE `familiar` (
  `CodigoRegistroFamiliar` int(10) NOT NULL,
  `Trabajador` int(10) NOT NULL,
  `Familiar` int(10) NOT NULL,
  `Parentesco` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `familiar`
--

INSERT INTO `familiar` (`CodigoRegistroFamiliar`, `Trabajador`, `Familiar`, `Parentesco`) VALUES
(1, 5, 26, 'Hijo'),
(2, 9, 27, 'Esposa'),
(3, 5, 28, 'Hija'),
(4, 35, 37, 'Hijo'),
(5, 35, 38, 'Nieto');

-- --------------------------------------------------------

--
-- Table structure for table `historico`
--

CREATE TABLE `historico` (
  `CodigoHistorico` int(10) NOT NULL,
  `Cargo` int(10) NOT NULL,
  `FechaInicio` date NOT NULL,
  `FechaCulminacion` date NOT NULL,
  `Obervacion` varchar(120) NOT NULL,
  `InstitucionHistorico` int(10) NOT NULL,
  `personal` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `historico`
--

INSERT INTO `historico` (`CodigoHistorico`, `Cargo`, `FechaInicio`, `FechaCulminacion`, `Obervacion`, `InstitucionHistorico`, `personal`) VALUES
(1, 1, '1995-01-01', '1995-01-08', 'react', 28, 5);

-- --------------------------------------------------------

--
-- Table structure for table `instituciones`
--

CREATE TABLE `instituciones` (
  `CodigoInstituciones` int(10) NOT NULL,
  `NombreInstitucion` varchar(50) NOT NULL,
  `CodigoRegistro` varchar(50) NOT NULL,
  `Sector` varchar(50) NOT NULL,
  `Direccion` varchar(50) NOT NULL,
  `ParroquiaInstitucion` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `instituciones`
--

INSERT INTO `instituciones` (`CodigoInstituciones`, `NombreInstitucion`, `CodigoRegistro`, `Sector`, `Direccion`, `ParroquiaInstitucion`) VALUES
(11, 'La Inmaculada', 'C1223', 'valentin valiente', 'Avenida Carupano', 51),
(12, 'pdvsaa', '1651515', 'gtav', 'nonononono', 41),
(28, 'caipe', 'c288', '', 'direccion pdvsa', 39);

-- --------------------------------------------------------

--
-- Table structure for table `municipio`
--

CREATE TABLE `municipio` (
  `CodigoMunicipio` int(10) NOT NULL,
  `NombreMunicipio` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `municipio`
--

INSERT INTO `municipio` (`CodigoMunicipio`, `NombreMunicipio`) VALUES
(1, 'Andrés Eloy Blanco'),
(2, 'Andrés Mata'),
(3, 'Arismendi'),
(4, 'Benítez'),
(5, 'Bermúdez'),
(6, 'Bolívar'),
(7, 'Cajigal'),
(8, 'Cruz Salmerón Acosta'),
(9, 'Libertador'),
(10, 'Mariño'),
(11, 'Mejía'),
(12, 'Montes'),
(13, 'Ribero'),
(14, 'Sucre'),
(15, 'Valdez');

-- --------------------------------------------------------

--
-- Table structure for table `parroquia`
--

CREATE TABLE `parroquia` (
  `CodigoParroquia` int(10) NOT NULL,
  `NombreParroquia` varchar(50) NOT NULL,
  `MunicipioParroquia` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parroquia`
--

INSERT INTO `parroquia` (`CodigoParroquia`, `NombreParroquia`, `MunicipioParroquia`) VALUES
(1, 'Mariño', 1),
(2, 'Rómulo Gallegos', 1),
(3, 'San José de Areocuar', 2),
(4, 'Tavera Acosta', 2),
(5, 'Río Caribe', 3),
(6, 'Antonio José de Sucre', 3),
(7, 'El Morro de Puerto Santo', 3),
(8, 'Puerto Santo', 3),
(9, 'San Juan de las Galdonas', 3),
(10, 'El Pilar', 4),
(11, 'El Rincón', 4),
(12, 'General Francisco Antonio Vázquez', 4),
(13, 'Guaraúnos', 4),
(14, 'Tunapuicito', 4),
(15, 'Unión', 4),
(16, 'Santa Catalina', 5),
(17, 'Santa Rosa', 5),
(18, 'Santa Teresa', 5),
(19, 'Bolívar', 5),
(20, 'Maracapana', 5),
(21, 'Divina Misericordia', 5),
(22, 'Nuestra Señora De Lourdes', 5),
(23, 'Marigüitar', 6),
(24, 'Libertad', 7),
(25, 'El Paujil', 7),
(26, 'Yaguaraparo', 7),
(27, 'Araya', 8),
(28, 'Chacopata', 8),
(29, 'Manicuare', 8),
(30, 'Tunapuy', 9),
(31, 'Campo Elías', 9),
(32, 'Irapa', 10),
(33, 'Campo Claro', 10),
(34, 'Marabal', 10),
(35, 'San Antonio de Irapa', 10),
(36, 'Soro', 10),
(37, 'San Antonio del Golfo', 11),
(38, 'Cumanacoa', 12),
(39, 'Arenas', 12),
(40, 'Aricagua', 12),
(41, 'Cocollar', 12),
(42, 'San Fernando', 12),
(43, 'San Lorenzo', 12),
(44, 'Cariaco', 13),
(45, 'Catuaro', 13),
(46, 'Rendón', 13),
(47, 'Santa Cruz', 13),
(48, 'Santa María', 13),
(49, 'Altagracia', 14),
(50, 'Santa Inés', 14),
(51, 'Valentín Valiente', 14),
(52, 'Ayacucho', 14),
(53, 'San Juan', 14),
(54, 'Raúl Leoni', 14),
(55, 'Gran Mariscal', 14),
(56, 'Cristóbal Colón', 15),
(57, 'Bideau', 15),
(58, 'Punta de Piedras', 15),
(59, 'Güiria', 15);

-- --------------------------------------------------------

--
-- Table structure for table `persona`
--

CREATE TABLE `persona` (
  `CodigoPersona` int(10) NOT NULL,
  `CedulaPersona` varchar(10) NOT NULL,
  `Nombres` varchar(50) NOT NULL,
  `Apellidos` varchar(50) NOT NULL,
  `FechaNacimiento` date NOT NULL,
  `Sexo` varchar(10) NOT NULL,
  `EstadoCivil` varchar(20) NOT NULL,
  `ParroquiaPersona` int(10) DEFAULT NULL,
  `Sector` varchar(50) NOT NULL,
  `Direccion` varchar(120) NOT NULL,
  `TelefonoPrincipal` varchar(20) NOT NULL,
  `TelefonoHabitacion` varchar(20) NOT NULL,
  `Peso` varchar(10) NOT NULL,
  `Estatura` varchar(10) NOT NULL,
  `TallaCamisa` varchar(5) NOT NULL,
  `TallaPantalon` varchar(5) NOT NULL,
  `TallaCalzado` varchar(5) NOT NULL,
  `RegPartidaNacimientoFami` text DEFAULT NULL,
  `TipoPersona` varchar(20) NOT NULL,
  `EstatusPersonal` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `persona`
--

INSERT INTO `persona` (`CodigoPersona`, `CedulaPersona`, `Nombres`, `Apellidos`, `FechaNacimiento`, `Sexo`, `EstadoCivil`, `ParroquiaPersona`, `Sector`, `Direccion`, `TelefonoPrincipal`, `TelefonoHabitacion`, `Peso`, `Estatura`, `TallaCamisa`, `TallaPantalon`, `TallaCalzado`, `RegPartidaNacimientoFami`, `TipoPersona`, `EstatusPersonal`) VALUES
(1, '26293417', 'Endys Leonel', 'Rodriguez Rodriguez', '1997-11-25', 'masculino', 'soltero', 5, 'Valentin Valiente', 'Urbanizacion Salvador allende, Torre 13, Piso 4, Apto n20', '04126949323', '04126949323', '74', '190', 'xl', '36', '44', '', 'trabajador', 'inactivo'),
(2, '29652552', 'hijo endys', 'rodriguez', '2000-11-25', 'masculino', 'soltero', 37, 'Sector de San Antonio', 'calle verde, ali', '04126949323', '04126949323', '70', '190', 'xl', '36', '44', '', 'familiar', 'inactivo'),
(4, '20293417', 'endys2', 'werwer', '1997-11-25', 'masculino', 'casado', 39, 'La playa', 'miami newyork', '04121231212', '04123121212', '80', '1.90', 'm', '2', '30', '', 'personal', 'inactivo'),
(5, '21293417', 'asdasda', 'sdasdad', '1222-12-12', 'masculino', 'soltero', 47, '12312312123123', '3123123123', '122312312312', '123123123123', '123123', '12312', '12312', '1231', '23', '', 'personal', 'inactivo'),
(9, '34234237', 'xbx', '784', '1955-01-01', 'masculino', 'soltero', 31, '', 'y', '324234324', '234234234', '', '', '', '', '', '', 'personal', 'inactivo'),
(10, '32487474', 'rodolfo', 'rodriguez', '2008-01-04', 'masculino', 'soltero', NULL, '', '', '123134564', '234234234', '', '', '', '', '', '', 'personal', 'inactivo'),
(26, '22337', 'ps5 hijo', 'pse ape', '1991-01-03', 'masculino', '', 46, 'sector miami', 'direccion miami', '234234', '234234', '2', '2', '1', '1', '1', '', 'familiar', ''),
(27, '7845', 'chapote', 'xbox ape ', '1995-01-01', 'masculino', '', 46, 'sector wow', 'direccion wow', '234234', '23423423', '3', '3', '2', '2', '2', '', 'familiar', ''),
(28, '12452', 'valentina', 'pilera', '2002-01-01', 'femenino', '', 34, 'sector xbox', 'direccion xbox', '2342342342', '234234234234', '3', '3', '7', '7', '8', '', 'familiar', 'inactivo'),
(35, '2255', 'react', 'react ape', '1991-07-07', 'masculino', 'soltero', 46, '', '', '232423', '423423423', '', '', '', '', '', '', 'personal', 'inactivo'),
(36, '2277', 'angular', 'angular ape', '1997-02-02', 'masculino', 'soltero', NULL, '', '', '325235235', '235325235', '', '', '', '', '', '', 'personal', 'inactivo'),
(37, '44557', 'hijo de react', 'react ape', '2005-01-01', 'masculino', '', 44, 'secto', 'direccion', '43534534', '534534534', '7', '7', '1', '1', '1', NULL, 'familiar', 'inactivo'),
(38, '1122', 'nieto de react', 'react apee', '2007-01-01', 'masculino', '', 45, 'sector', 'direccion', '342423423', '4234234234', '1', '1', '1', '1', '1', NULL, 'familiar', 'inactivo');

-- --------------------------------------------------------

--
-- Table structure for table `tipocargos`
--

CREATE TABLE `tipocargos` (
  `CodigoTipoCargo` int(10) NOT NULL,
  `NombreTipoCargo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tipocargos`
--

INSERT INTO `tipocargos` (`CodigoTipoCargo`, `NombreTipoCargo`) VALUES
(1, 'Empleado'),
(10, 'Alto Nivel'),
(11, 'Obrero');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `CodigoUsuario` int(10) NOT NULL,
  `CodigoPersona` int(10) NOT NULL,
  `NombreUsuario` varchar(20) NOT NULL,
  `ConstraseñaUsuario` varchar(20) NOT NULL,
  `RolUsuario` varchar(20) NOT NULL,
  `EstatusUsuario` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`CodigoUsuario`, `CodigoPersona`, `NombreUsuario`, `ConstraseñaUsuario`, `RolUsuario`, `EstatusUsuario`) VALUES
(1, 1, 'APOLOENDYS', 'OROGZ.123*', 'administrador', 'usuarioactivo'),
(2, 9, 'sql', '1234', 'administrador', 'usuarioactivo');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `archivos`
--
ALTER TABLE `archivos`
  ADD PRIMARY KEY (`ArchivoRegistro`),
  ADD KEY `CodigoDocumento` (`CodigoDocumento`),
  ADD KEY `idperarchivos` (`idperarchivos`);

--
-- Indexes for table `cargos`
--
ALTER TABLE `cargos`
  ADD PRIMARY KEY (`CodigoCargo`),
  ADD UNIQUE KEY `NombreCargo` (`NombreCargo`),
  ADD KEY `TipoCargo` (`TipoCargo`);

--
-- Indexes for table `documento`
--
ALTER TABLE `documento`
  ADD PRIMARY KEY (`CodigoDocumento`),
  ADD UNIQUE KEY `NombreDocumento` (`NombreDocumento`);

--
-- Indexes for table `familiar`
--
ALTER TABLE `familiar`
  ADD PRIMARY KEY (`CodigoRegistroFamiliar`),
  ADD KEY `Trabajador` (`Trabajador`,`Familiar`),
  ADD KEY `familiar_ibfk_2` (`Familiar`);

--
-- Indexes for table `historico`
--
ALTER TABLE `historico`
  ADD PRIMARY KEY (`CodigoHistorico`),
  ADD KEY `Trabajador` (`Cargo`,`InstitucionHistorico`),
  ADD KEY `InstitucionHistorico` (`InstitucionHistorico`),
  ADD KEY `trabajador_2` (`personal`);

--
-- Indexes for table `instituciones`
--
ALTER TABLE `instituciones`
  ADD PRIMARY KEY (`CodigoInstituciones`),
  ADD UNIQUE KEY `NombreInstitucion` (`NombreInstitucion`),
  ADD KEY `ParroquiaInstitucion` (`ParroquiaInstitucion`);

--
-- Indexes for table `municipio`
--
ALTER TABLE `municipio`
  ADD PRIMARY KEY (`CodigoMunicipio`),
  ADD UNIQUE KEY `CodigoEstado` (`NombreMunicipio`),
  ADD KEY `NombreMunicipio` (`NombreMunicipio`);

--
-- Indexes for table `parroquia`
--
ALTER TABLE `parroquia`
  ADD PRIMARY KEY (`CodigoParroquia`),
  ADD UNIQUE KEY `NombreParroquia` (`NombreParroquia`),
  ADD KEY `MunicipioParroquia` (`MunicipioParroquia`);

--
-- Indexes for table `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`CodigoPersona`),
  ADD UNIQUE KEY `CedulaPersona` (`CedulaPersona`),
  ADD KEY `ParroquiaPersona` (`ParroquiaPersona`);

--
-- Indexes for table `tipocargos`
--
ALTER TABLE `tipocargos`
  ADD PRIMARY KEY (`CodigoTipoCargo`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`CodigoUsuario`),
  ADD UNIQUE KEY `IdPersona` (`CodigoPersona`,`NombreUsuario`),
  ADD KEY `IdPersona_2` (`CodigoPersona`),
  ADD KEY `codigopersona` (`CodigoPersona`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `archivos`
--
ALTER TABLE `archivos`
  MODIFY `ArchivoRegistro` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cargos`
--
ALTER TABLE `cargos`
  MODIFY `CodigoCargo` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `documento`
--
ALTER TABLE `documento`
  MODIFY `CodigoDocumento` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1314;

--
-- AUTO_INCREMENT for table `familiar`
--
ALTER TABLE `familiar`
  MODIFY `CodigoRegistroFamiliar` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `historico`
--
ALTER TABLE `historico`
  MODIFY `CodigoHistorico` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `instituciones`
--
ALTER TABLE `instituciones`
  MODIFY `CodigoInstituciones` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `municipio`
--
ALTER TABLE `municipio`
  MODIFY `CodigoMunicipio` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `parroquia`
--
ALTER TABLE `parroquia`
  MODIFY `CodigoParroquia` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `persona`
--
ALTER TABLE `persona`
  MODIFY `CodigoPersona` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tipocargos`
--
ALTER TABLE `tipocargos`
  MODIFY `CodigoTipoCargo` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `archivos`
--
ALTER TABLE `archivos`
  ADD CONSTRAINT `archivos_ibfk_1` FOREIGN KEY (`CodigoDocumento`) REFERENCES `documento` (`CodigoDocumento`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `archivos_ibfk_2` FOREIGN KEY (`idperarchivos`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cargos`
--
ALTER TABLE `cargos`
  ADD CONSTRAINT `cargos_ibfk_1` FOREIGN KEY (`TipoCargo`) REFERENCES `tipocargos` (`CodigoTipoCargo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `familiar`
--
ALTER TABLE `familiar`
  ADD CONSTRAINT `familiar_ibfk_1` FOREIGN KEY (`Trabajador`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `familiar_ibfk_2` FOREIGN KEY (`Familiar`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `historico`
--
ALTER TABLE `historico`
  ADD CONSTRAINT `historico_ibfk_2` FOREIGN KEY (`Cargo`) REFERENCES `cargos` (`CodigoCargo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `historico_ibfk_3` FOREIGN KEY (`InstitucionHistorico`) REFERENCES `instituciones` (`CodigoInstituciones`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `historico_ibfk_4` FOREIGN KEY (`personal`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `instituciones`
--
ALTER TABLE `instituciones`
  ADD CONSTRAINT `instituciones_ibfk_1` FOREIGN KEY (`ParroquiaInstitucion`) REFERENCES `parroquia` (`CodigoParroquia`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `parroquia`
--
ALTER TABLE `parroquia`
  ADD CONSTRAINT `parroquia_ibfk_1` FOREIGN KEY (`MunicipioParroquia`) REFERENCES `municipio` (`CodigoMunicipio`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`ParroquiaPersona`) REFERENCES `parroquia` (`CodigoParroquia`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`CodigoPersona`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`CodigoPersona`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
