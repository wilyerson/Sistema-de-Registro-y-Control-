<?php
require_once "../config/dbconexion.php";
require_once "../modelo/ModeloHistorial.php";

$historial = new Historial();

switch ($_GET["op"]) {

    case 'listar':
        $result_set = $documento->get_documentos(); // devuelve un conjunto de arreglos, cada arreglo es una fila de la tabla de la db
        $data = array();
        //if (count($result_set) > 0) {
        foreach ($result_set as $row) {
            array_push($data, array("ArchivoRegistro" => $row['ArchivoRegistro'], "CodigoDocumento" => $row['CodigoDocumento'], "idperarchivos" => $row['idperarchivos'], "archivosjpg" => $row['archivosjpg']));
        }
        echo json_encode($data); //formateado como json
        break;

    case 'guardar':
        $idperhist  = $_POST['idpersonahistorial'];
        $fechainiciohist  = $_POST['fecha-iniciohistorial'];
        $fechaculmhist  = $_POST['fecha-culminacionhistorial'];
        $cargohist  = $_POST['cargohistorico'];
        $institucionhist  = $_POST['institucionhistorico'];
        $obshist = $_POST['observacionhistorico'];
        
        $insercion = $historial->insert_historial($idperhist, $fechainiciohist, $fechaculmhist, $cargohist, $institucionhist, $obshist);
        echo json_encode($insercion);
        break;

    case 'editar':
        $idperhis = $_POST['idperhis'];
        $ejecutar = $historial->get_historial($idperhis);
        echo json_encode($ejecutar);
        break;

    case 'update':
        $codinstimod = $_POST['codinstitucionmodificar'];
        $nombreinstimod = $_POST['nombremodificarinstitucion'];
        $codigoregintimod = $_POST['codigomodificarinstitucion'];
        $parroquiarinstimod = $_POST['parroquiareg2'];
        $sectorinstimod = $_POST['sectormodificarinstution'];
        $direccioninstimod = $_POST['direccionmodificarinstitucion'];
        $actualizacion = $historial->update_historial($codinstimod, $nombreinstimod, $codigoregintimod, $parroquiarinstimod, $sectorinstimod, $direccioninstimod);
        echo json_encode($actualizacion);
        break;

        case 'editarmodalhistorial':
            $codhistorial = $_POST['codhistorial'];
            $ejecutar = $historial->get_editarmodalhistorial($codhistorial);
            echo json_encode($ejecutar);
            break;

    default:
        # code...
        break;
}
