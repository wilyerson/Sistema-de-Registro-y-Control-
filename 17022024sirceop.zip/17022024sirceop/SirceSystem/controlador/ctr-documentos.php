<?php
require_once "../config/dbconexion.php";
require_once "../modelo/ModeloDocumentos.php";

$documento = new Documento();

switch ($_GET["op"]) {

    case 'listar':
        $result_set = $documento->get_documentos(); // devuelve un conjunto de arreglos, cada arreglo es una fila de la tabla de la db
        $data = array();
        //if (count($result_set) > 0) {
        foreach ($result_set as $row) {
            array_push($data, array("ArchivoRegistro" => $row['ArchivoRegistro'], "CodigoDocumento" => $row['CodigoDocumento'], "idperarchivos" => $row['idperarchivos'], "archivosjpg" => $row['archivosjpg']));
        }
        echo json_encode($data); //formateado como json
        break;

    case 'guardar':
        $CodigoDocumento  = $_POST['iddocumento'];
        $idpersonadoc = $_POST['idpersonadoc'];
        
        $insercion = $documento->insert_documento($CodigoDocumento, $idpersonadoc);
        echo json_encode($insercion);
        break;

    case 'editar':
        $idperdoc = $_POST['idperdoc'];
        $ejecutar = $documento->get_documento($idperdoc);
        echo json_encode($ejecutar);
        break;

    case 'update':
        $codinstimod = $_POST['codinstitucionmodificar'];
        $nombreinstimod = $_POST['nombremodificarinstitucion'];
        $codigoregintimod = $_POST['codigomodificarinstitucion'];
        $parroquiarinstimod = $_POST['parroquiareg2'];
        $sectorinstimod = $_POST['sectormodificarinstution'];
        $direccioninstimod = $_POST['direccionmodificarinstitucion'];
        $actualizacion = $documento->update_documento($codinstimod, $nombreinstimod, $codigoregintimod, $parroquiarinstimod, $sectorinstimod, $direccioninstimod);
        echo json_encode($actualizacion);
        break;


        
    default:
        # code...
        break;
}
