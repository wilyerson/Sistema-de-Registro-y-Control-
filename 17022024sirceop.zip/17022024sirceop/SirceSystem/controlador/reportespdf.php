<?php

ob_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Reporte Documento</title>
</head>
<body>
	
<?php
//require_once "../config/dbconexion.php";

const SERVER="localhost";
const DB="sirceop";
const USER="root";
const PASS="";
const UTF8="utf8";

const SGBD="mysql:host=".SERVER.";dbname=".DB.";charset=".UTF8;

class dbconexion
{
    protected function conexion()
    {
        try {
            $con = new PDO(SGBD, USER, PASS);
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $con;
        } catch (PDOException $e) {
            echo "Conexion Fallida: " . $e->getMessage();
        }
    }

    public function getConexion() {
        return $this->conexion();
    }
}

$db = new dbconexion();
$conexion = $db->getConexion();

$id = $_GET['id'];
$sentenciaSQL = $conexion->prepare("SELECT   documento.NombreDocumento,
archivos.CodigoDocumento,
archivos.ArchivoRegistro,
archivos.archivosjpg
FROM
archivos
INNER JOIN documento on archivos.CodigoDocumento = documento.CodigoDocumento
WHERE archivos.idperarchivos = :id");
$sentenciaSQL->bindParam(':id', $id, PDO::PARAM_INT);
$sentenciaSQL->execute();
$ImagenesDocumentos = $sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);

?>

<table>
	<thead>
		<tr>
			<th>Nombre documento</th>
			<th>Foto Documento</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($ImagenesDocumentos as $documentos) { ?>
		<tr>
			<td><?php echo $documentos['NombreDocumento']; ?></td>
			<td>
			<img class="imgdocumento" src="http://<?php echo $_SERVER['HTTP_HOST'];?>/SirceSystem/controlador/<?php echo $documentos['archivosjpg']; ?>" width="500">
            
			</td>
		</tr>
		<?php } ?>
	</tbody>
</table>

</body>
</html>
<?php 

$html = ob_get_clean();
//echo $html;

require_once '../librerias/dompdf/autoload.inc.php';
use Dompdf\Dompdf;
$dompdf = new Dompdf();

$options = $dompdf->getOptions();
$options->set(array('isRemoteEnabled' => true));
$dompdf->setOptions($options);

$dompdf->loadHtml($html);
$dompdf->setPaper('letter');

$dompdf->render();
$dompdf->stream("archivo.pdf", array("Attachment" => false));

?>
