<?php 


	require_once "../modelo/ModeloParroquia.php";

	$parroquiaspersona = [];
	if (isset($_GET['editmunicipio'])) {
		$tabla_parroquia = new parroquia();
		$parroquiaspersona = $tabla_parroquia->obtener_parroquia_select($_GET['editmunicipio']);
	}
		echo json_encode(['data' => $parroquiaspersona] );

		
 ?>