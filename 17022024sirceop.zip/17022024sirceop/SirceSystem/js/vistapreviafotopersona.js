const file = document.getElementById('Fotopersona');
const img = document.getElementById('imgcedula');
file.addEventListener('change', e =>{

if (e.target.files[0]) {
 const reader = new FileReader();
 reader.onload = function(e){
 	document.getElementById('imgcedula').style.display = "block";
 	img.src = e.target.result;
 }
 reader.readAsDataURL(e.target.files[0])
}else{
	img.src = " ";
	document.getElementById('imgcedula').style.display = "none";
}
//console.log(e.target.files);
});

