const formdatadoc = document.querySelector("#formregistrardocumentos");
formdatadoc.addEventListener("submit", (e) => {
	e.preventDefault();

	let idpersonal = localStorage.getItem("idpesonaid");
	console.log(idpersonal);

	document.getElementById("idpersonadoc").value = idpersonal;

	const datos = new FormData(document.getElementById("formregistrardocumentos"));

	console.log(" conectado");

	let url = "../controlador/ctr-documentos.php?op=guardar";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);
			//dibujarTabla(data);
			//formdata.reset();
			
			$('#modal-registrar-documentos').modal('hide');
			swal.fire({
				title: "¡Registro Exitoso de Documento!",
				icon: "success",
			});
            // Aquí llamas a la función que muestra los documentos en la tabla
            mostrarDocumentos();
		})
		.catch((error) => console.log(`error: ${error}`));
});

async function mostrarDocumentos() {
    let idperdoc = localStorage.getItem("idpesonaid");
    console.log(idperdoc);

    document.getElementById("idperdoc").value = idperdoc;

    try {
        const url = "../controlador/ctr-documentos.php?op=editar";
        const datos = new FormData(document.getElementById("fomrcapturariddoc"));

        const response = await fetch(url, {
            method: "POST",
            body: datos,
        });

        if (!response.ok) {
            throw new Error(`Error al obtener los datos. Código de estado: ${response.status}`);
        }

        const responseData = await response.json();
        console.log(responseData); 

        let tbody = document.querySelector("#verdocumentos");
        tbody.innerHTML = "";
        if (responseData.length > 0) {
            for (let registro of responseData) {
                tbody.innerHTML += `
                    <tr>
                        <th class="text-center">${registro.NombreDocumento}</th>
                        <td><img class="imagregistrodocumento" src="../controlador/${registro.archivosjpg}"></td>
                    </tr>
                `;
            }
        } else {
            tbody.innerHTML += `
                <tr>
                    <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${data}</th>
                </tr>
            `;
        }
    } catch (error) {
        console.error(`Error en la solicitud: ${error.message}`);
    }
}

// Llamamos a la función al cargar la página
document.addEventListener('DOMContentLoaded', mostrarDocumentos);

function descargarDocumentos() {

    /*let idpersonal = localStorage.getItem("idpesonaid");
	console.log(idpersonal);

    location.href = `../vista/bienvenida.php?id=${idpersonal}`;*/

    let idurl = new URLSearchParams(window.location.search);
    let idpersonalurl = idurl.get('id');
    
    location.href = `../controlador/reportespdf.php?id=${idpersonalurl}`;
}