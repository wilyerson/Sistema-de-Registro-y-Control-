const formdatahistorial = document.querySelector("#formregistrarhistorial");
formdatahistorial.addEventListener("submit", (e) => {
	e.preventDefault();

	let idpersonalhistorial = localStorage.getItem("idpesonaid");
	console.log(idpersonalhistorial);

	document.getElementById("idpersonahistorial").value = idpersonalhistorial;

	const datos = new FormData(document.getElementById("formregistrarhistorial"));

	console.log(" conectado");

	let url = "../controlador/ctr-historial.php?op=guardar";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);
			//ya hay un registro historico con estas fechas
			//no es requerido fecha de culminacion y ni observacion
			//cambiar cuando la fecha fin no exista poner al trabajador activo
			//el estatus del personal, si esta activo y la fecha del culminacion es null = no se puede registrar
			swal.fire({
				title: "¡Registro de Historial Exitoso!",
				icon: "success",
			});
			mostrarHistorialLaboral();
		})
		.catch((error) => console.log(`error: ${error}`));

});


async function mostrarHistorialLaboral() {
    let idperhis = localStorage.getItem("idpesonaid");

    document.getElementById("idperhis").value = idperhis;

    try {
        const url = "../controlador/ctr-historial.php?op=editar";
        const datos = new FormData(document.getElementById("fomrcapturaridhis"));

        const response = await fetch(url, {
            method: "POST",
            body: datos,
        });

        if (!response.ok) {
            throw new Error(`Error al obtener los datos. Código de estado: ${response.status}`);
        }

        const responseData = await response.json();
        console.log(responseData); 

        let tbody = document.querySelector("#mostrar-historial-laboral");
        tbody.innerHTML = "";
        if (responseData.length > 0) {
            for (let registro of responseData) {
                tbody.innerHTML += `
                    <tr>
                        <td class="text-left">${registro.NombreInstitucion}</td>
                        <td>${registro.NombreCargo}</td>
                        <td>${registro.FechaInicio}</td>
                        <td>${registro.FechaCulminacion}</td>
                        <td>
                        <form method="POST" id="editarhistorial">
                        <input type="hidden" id="codhistorial" name="codhistorial" value="${registro.CodigoPersona}">

                        <div class="dropdown">
                        <a class="btn btn-primary dropdown-toggle" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                            Seleccione
                        </a>

                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <li><button  type="submit" id="botonmodificarfami" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modal-editar-historial" >Editar</button></li>
                            <li><button  type="submit" id="verfamiliar" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modal-verdatos-familiar" >Ver Datos</button></li>
                        </ul>
                        </div>
                    </form> 
                        </td>
                    </tr>
                `;
            }
        } else {
            tbody.innerHTML += `
                <tr>
                    <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${data}</th>
                </tr>
            `;
        }
    } catch (error) {
        console.error(`Error en la solicitud: ${error.message}`);
    }
}

// Llamamos a la función al cargar la página
document.addEventListener('DOMContentLoaded', mostrarHistorialLaboral);
