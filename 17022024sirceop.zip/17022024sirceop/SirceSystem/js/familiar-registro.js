const formdatafamiliar = document.querySelector("#formregistrarfamiliar");
formdatafamiliar.addEventListener("submit", (e) => {
	e.preventDefault();

	let idpersonalfamiliar = localStorage.getItem("idpesonaid");
	console.log(idpersonalfamiliar);

	document.getElementById("idpersonafamiliar").value = idpersonalfamiliar;

	const datos = new FormData(document.getElementById("formregistrarfamiliar"));

	console.log(" conectado");

	let url = "../controlador/ctr-familiares.php?op=guardar";
	fetch(url, {
		method: "post",
		body: datos,
	})
		.then((data) => data.json())
		.then((data) => {
			//console.log(`Success: ${JSON.stringify(data)}`);
			//dibujarTabla(data);
			//formdata.reset();
			
			$('#registro-familiar').modal('hide');
			swal.fire({
				title: "¡Registro Exitoso de Familiar!",
				icon: "success",
			});
            // Aquí llamas a la función que muestra los documentos en la tabla
            mostrarFamiliares();
		})
		.catch((error) => console.log(`error: ${error}`));
});

async function mostrarFamiliares() {
    let idperfami = localStorage.getItem("idpesonaid");
    console.log(idperfami);

    document.getElementById("idperfamilia").value = idperfami;

    var disablecedulaverfami = document.getElementById('cedulafamiliarver');

    disablecedulaverfami.disabled = true;

    

    try {
        const url = "../controlador/ctr-familiares.php?op=editar";
        const datos = new FormData(document.getElementById("fomrcapturaridfamilia"));

        const response = await fetch(url, {
            method: "POST",
            body: datos,
        });

        if (!response.ok) {
            throw new Error(`Error al obtener los datos. Código de estado: ${response.status}`);
        }

        const responseData = await response.json();
        console.log(responseData); 

        //----------------------calcular edad

        const fechaOriginal = responseData[0].FechaNacimiento; // Cambia esto a la fecha correcta

        function calcularEdadEnAnos(fechaNacimiento) {
		    if (typeof fechaNacimiento !== 'string' || !fechaNacimiento || isNaN(new Date(fechaNacimiento).getTime())) {
		        return 'Fecha de nacimiento inválida';
		    }

		    const [ano, mes, dia] = fechaNacimiento.split('-').map(Number);
		    const hoy = new Date();
		    const ahoraAno = hoy.getFullYear();
		    const ahoraMes = hoy.getMonth() + 1;
		    const ahoraDia = hoy.getDate();

		    let edad = ahoraAno - ano;

		    if (ahoraMes < mes || (ahoraMes === mes && ahoraDia < dia)) {
		        edad--; // Ajuste si aún no ha cumplido años este año
		    }

		    return `${edad} años`;
		}

		const edad = calcularEdadEnAnos(fechaOriginal);
		



		// Formatea la fecha al estilo "DD-MM-YYYY"
		function cambiarFormatoFecha(fecha) {
		    const partes = fecha.split('-'); // Divide la fecha en partes: año, mes, día
		    const nuevaFecha = `${partes[2]}-${partes[1]}-${partes[0]}`; // Reorganiza las partes en el nuevo formato
		    return nuevaFecha;
		}

		const fechaFormateada = cambiarFormatoFecha(fechaOriginal);

        //-----------------------------------

        let tbody = document.querySelector("#verfamiliares");
        tbody.innerHTML = "";
        if (responseData.length > 0) {
            for (let registro of responseData) {
                tbody.innerHTML += `
                    <tr>
                        <td class="text-left">${registro.Nombres}</td>
                        <td class="text-left">${registro.Apellidos}</td>
                        <td class="text-left">${registro.Parentesco}</td>
                        <td class="text-left">${calcularEdadEnAnos(registro.FechaNacimiento)}</td>
                        <td class="">
                          <form method="POST" id="editarfamiliar">
                        <input type="hidden" id="codfamiliar" name="codfamiliar" value="${registro.CodigoPersona}">

                        <div class="dropdown">
                        <a class="btn btn-primary dropdown-toggle" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                            Seleccione
                        </a>

                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <li><button  type="submit" id="botonmodificarfami" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modal-editar-familiar" >Editar</button></li>
                            <li><button  type="submit" id="verfamiliar" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#modal-verdatos-familiar" >Ver Datos</button></li>
                        </ul>
                        </div>
                    </form> 
                    </td>
                    </tr>
                `;
            }
        } else {
            tbody.innerHTML += `
                <tr>
                    <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${responseData}</th>
                </tr>
            `;
        }
    } catch (error) {
        console.error(`Error en la solicitud: ${error.message}`);
    }
}

// Llamamos a la función al cargar la página
document.addEventListener('DOMContentLoaded', mostrarFamiliares);


var checkboxfamiliar = document.getElementById('checkboxfamiliar');
var inputcedula = document.getElementById('cedulafamiliar');
var inputregpartidafamiliar = document.getElementById('regpartidafamiliar');


checkboxfamiliar.addEventListener('change', function() {
    if(this.checked) {
        
        inputcedula.disabled = true;
        inputregpartidafamiliar.disabled = false;
    } else {
        
        inputcedula.disabled = false;
        inputregpartidafamiliar.disabled = true;
    }
});

var checkboxeditar = document.getElementById('checkboxfamiliareditar');
var inputcedulaeditar = document.getElementById('cedulafamiliareditar');
var inputregpartidafamiliareditar = document.getElementById('regpartidafamiliareditar');


checkboxeditar.addEventListener('change', function() {
    if(this.checked) {
        
        inputcedulaeditar.disabled = true;
        inputregpartidafamiliareditar.disabled = false;
    } else {
        
        inputcedulaeditar.disabled = false;
        inputregpartidafamiliareditar.disabled = true;
    }
});