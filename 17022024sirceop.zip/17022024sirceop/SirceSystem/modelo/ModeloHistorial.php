<?php

class Historial extends dbconexion
{
    public function get_historiales()
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT CodigoInstituciones, NombreInstitucion, CodigoRegistro FROM instituciones");
        $sql->execute();
        return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_historial($idperhis)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT instituciones.NombreInstitucion, instituciones.CodigoInstituciones, cargos.CodigoCargo, cargos.NombreCargo, persona.CodigoPersona, 
        persona.Nombres, historico.FechaInicio, historico.FechaCulminacion, historico.Obervacion, historico.CodigoHistorico FROM historico 
        INNER JOIN instituciones on historico.InstitucionHistorico = instituciones.CodigoInstituciones
        INNER JOIN cargos on historico.Cargo = cargos.CodigoCargo
        INNER JOIN persona on historico.personal = persona.CodigoPersona 
        WHERE historico.personal = ?");
        $sql->bindValue(1, $idperhis);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function insert_historial($idperhist, $fechainiciohist, $fechaculmhist, $cargohist, $institucionhist, $obshist)
    {
        $conectar = dbconexion::conexion();

        // Verificar si hay superposición de fechas

        $sql = $conectar->prepare("SELECT COUNT(*) AS count FROM historico WHERE personal = ? 
                                    AND     ((FechaInicio <= ? AND (FechaCulminacion >= ? OR FechaCulminacion IS NULL)) 
                                    OR      (FechaInicio <= ? AND (FechaCulminacion >= ? OR FechaCulminacion IS NULL))
                                    OR      (FechaInicio >= ? AND (FechaCulminacion <= ? OR FechaCulminacion IS NULL)))");

        $sql->bindValue(1, $idperhist);
        $sql->bindValue(2, $fechainiciohist);
        $sql->bindValue(3, $fechainiciohist);
        $sql->bindValue(4, $fechaculmhist);
        $sql->bindValue(5, $fechaculmhist);
        $sql->bindValue(6, $fechainiciohist);
        $sql->bindValue(7, $fechaculmhist);
        $sql->execute();
        //$result = $sql->get_result();
        $row = $sql->fetch(PDO::FETCH_ASSOC);

        if ($row['count'] > 0) {
             echo "Las fechas se superponen con un registro existente.";
        } else {

            // Insertar el nuevo registro

                $sql = $conectar->prepare("INSERT INTO historico (personal, FechaInicio, FechaCulminacion, Cargo, InstitucionHistorico, Obervacion) VALUES (?, ?, ?, ?, ?, ?)");
                
                $nullVar = NULL;

            if ($fechaculmhist) {
                
                $sql->bindValue(1, $idperhist);
                $sql->bindValue(2, $fechainiciohist);
                $sql->bindValue(3, $fechaculmhist);
                $sql->bindValue(4, $cargohist);
                $sql->bindValue(5, $institucionhist);
                $sql->bindValue(6, $obshist);

            } else {

                // Pasamos la variable en lugar de NULL directamente
                $sql->bindValue(1, $idperhist);
                $sql->bindValue(2, $fechainiciohist);
                $sql->bindValue(3, $nullVar);
                $sql->bindValue(4, $cargohist);
                $sql->bindValue(5, $institucionhist);
                $sql->bindValue(6, $obshist);

            }

            $sql->execute();
            echo "Registro insertado correctamente.";
        }
    }

    public function update_historial($codinstimod, $nombreinstimod, $codigoregintimod, $parroquiarinstimod, $sectorinstimod, $direccioninstimod)
    {

        $conectar = dbconexion::conexion();
        $sql = "UPDATE instituciones SET NombreInstitucion = ?, CodigoRegistro = ?, ParroquiaInstitucion = ?, Sector = ?, Direccion = ? WHERE CodigoInstituciones = ?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $nombreinstimod);
        $sql->bindValue(2, $codigoregintimod);
        $sql->bindValue(3, $parroquiarinstimod);
        $sql->bindValue(4, $sectorinstimod);
        $sql->bindValue(5, $direccioninstimod);
        $sql->bindValue(6, $codinstimod);
        if ($sql->execute()) {
            return $resultado = self::get_historiales();
        }
    }

    public function get_editarmodalhistorial($codhistorial)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT instituciones.NombreInstitucion, instituciones.CodigoInstituciones, cargos.CodigoCargo, cargos.NombreCargo, persona.CodigoPersona, 
        persona.Nombres, historico.FechaInicio, historico.FechaCulminacion, historico.Obervacion, historico.CodigoHistorico FROM historico 
        INNER JOIN instituciones on historico.InstitucionHistorico = instituciones.CodigoInstituciones
        INNER JOIN cargos on historico.Cargo = cargos.CodigoCargo
        INNER JOIN persona on historico.personal = persona.CodigoPersona 
        WHERE historico.personal = ?");
        $sql->bindValue(1, $codhistorial);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }


}
