<?php

class Familiar extends dbconexion
{
    public function get_familiares()
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT CodigoInstituciones, NombreInstitucion, CodigoRegistro FROM instituciones");
        $sql->execute();
        return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_familiar($idperfami)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT municipio.NombreMunicipio, 
        municipio.CodigoMunicipio, 
               parroquia.NombreParroquia, familiar.Parentesco, persona.CodigoPersona, persona.Nombres, persona.Apellidos, persona.FechaNacimiento 
               FROM familiar 
               INNER JOIN persona ON familiar.familiar = persona.CodigoPersona 
               INNER JOIN parroquia ON persona.ParroquiaPersona = parroquia.CodigoParroquia 
               INNER JOIN municipio ON parroquia.MunicipioParroquia = municipio.CodigoMunicipio
               WHERE familiar.Trabajador = ?");
        $sql->bindValue(1, $idperfami);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function insert_familiar($cedulafamiliar, $regpartidafamiliar, $parentescofamiliar, $nombresfamiliar, $apellidosfamiliar, $sexofamiliar, $fechanacfamiliar, $numtelefonofamiliar, $numtelefono2familiar, $id_parrfamiliar, $sectorfamiliar, $direccionfamiliar, $pesofamiliar, $estaturafamiliar, $tallacamisafamiliar, $tallapantfamiliar, $tallacalzafamiliar, $tipopersonafamiliar, $estatusfamiliar, $idpersonafamiliar)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("INSERT INTO persona (CedulaPersona, RegPartidaNacimientoFami, Nombres, Apellidos, Sexo, FechaNacimiento, TelefonoPrincipal, TelefonoHabitacion, ParroquiaPersona, Sector, Direccion,  Peso, Estatura, TallaCamisa, TallaPantalon, TallaCalzado, TipoPersona , EstatusPersonal) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $sql->bindValue(1, $cedulafamiliar);
        $sql->bindValue(2, $regpartidafamiliar);
        $sql->bindValue(3, $nombresfamiliar);
        $sql->bindValue(4, $apellidosfamiliar);
        $sql->bindValue(5, $sexofamiliar);
        $sql->bindValue(6, $fechanacfamiliar);
        $sql->bindValue(7, $numtelefonofamiliar);
        $sql->bindValue(8, $numtelefono2familiar);
        $sql->bindValue(9, $id_parrfamiliar);
        $sql->bindValue(10, $sectorfamiliar);
        $sql->bindValue(11, $direccionfamiliar);
        $sql->bindValue(12, $pesofamiliar);
        $sql->bindValue(13, $estaturafamiliar);
        $sql->bindValue(14, $tallacamisafamiliar);
        $sql->bindValue(15, $tallapantfamiliar);
        $sql->bindValue(16, $tallacalzafamiliar);
        $sql->bindValue(17, $tipopersonafamiliar);
        $sql->bindValue(18, $estatusfamiliar);
        
        if ($sql->execute()) {
            $CodigoPersona = $conectar->lastInsertId();
            $sql2 = $conectar->prepare("INSERT INTO familiar (Trabajador, Familiar, Parentesco) VALUES (?,?,?)");
            $sql2->bindValue(1, $idpersonafamiliar);
            $sql2->bindValue(2, $CodigoPersona);
            $sql2->bindValue(3, $parentescofamiliar);
            if ($sql2->execute()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function update_familiar($codinstimod, $nombreinstimod, $codigoregintimod, $parroquiarinstimod, $sectorinstimod, $direccioninstimod)
    {

        $conectar = dbconexion::conexion();
        $sql = "UPDATE instituciones SET NombreInstitucion = ?, CodigoRegistro = ?, ParroquiaInstitucion = ?, Sector = ?, Direccion = ? WHERE CodigoInstituciones = ?";
        $sql = $conectar->prepare($sql);
        $sql->bindValue(1, $nombreinstimod);
        $sql->bindValue(2, $codigoregintimod);
        $sql->bindValue(3, $parroquiarinstimod);
        $sql->bindValue(4, $sectorinstimod);
        $sql->bindValue(5, $direccioninstimod);
        $sql->bindValue(6, $codinstimod);
        if ($sql->execute()) {
            return $resultado = self::get_instituciones();
        }
    }

    public function get_editarmodalfamiliar($codfamiliar)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT municipio.NombreMunicipio, 
        municipio.CodigoMunicipio, 
               parroquia.NombreParroquia, familiar.*, persona.* 
               FROM familiar 
               INNER JOIN persona ON familiar.familiar = persona.CodigoPersona 
               INNER JOIN parroquia ON persona.ParroquiaPersona = parroquia.CodigoParroquia 
               INNER JOIN municipio ON parroquia.MunicipioParroquia = municipio.CodigoMunicipio
               WHERE familiar.Familiar = ?");
        $sql->bindValue(1, $codfamiliar);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }

    public function get_institucionvalidacion($nombreinstitucion,$codigodeinstitucion)
    {
        $conectar = dbconexion::conexion();
        $sql = $conectar->prepare("SELECT municipio.NombreMunicipio, municipio.CodigoMunicipio,parroquia.NombreParroquia, instituciones.NombreInstitucion, instituciones.CodigoInstituciones, instituciones.CodigoRegistro, instituciones.Direccion, instituciones.ParroquiaInstitucion, instituciones.Sector FROM instituciones INNER JOIN parroquia ON instituciones.ParroquiaInstitucion = parroquia.CodigoParroquia INNER JOIN municipio ON parroquia.MunicipioParroquia = municipio.CodigoMunicipio WHERE instituciones.NombreInstitucion = ? OR instituciones.CodigoRegistro = ?");
        $sql->bindValue(1, $nombreinstitucion);
        $sql->bindValue(2, $codigodeinstitucion);
        if ($sql->execute()) {
            return $resultado = $sql->fetchAll(PDO::FETCH_ASSOC);
        }
    }
}
