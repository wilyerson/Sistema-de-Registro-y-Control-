let formulario = document.querySelector("#formulariogeistroinstitucion");
formulario.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("formulariogeistroinstitucion"));

	let url = "../controlador/ctlr-reg-instituciones.php?op=guardar";
	if (validate(datos)) {
		fetch(url, {
			method: "post",
			body: datos,
		})
			.then((data) => data.json())
			.then((data) => {	
				//console.log(`Success: ${JSON.stringify(data)}`);
				dibujarTabla(data);
				formulario.reset();
				swal.fire({
				title: "¡Registro Exitoso!",
				icon: "success",
				});
			})
			.catch((error) => console.log(`error: ${error}`));
	}
});