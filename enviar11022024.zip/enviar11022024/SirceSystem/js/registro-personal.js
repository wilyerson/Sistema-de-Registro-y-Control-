let formulario = document.querySelector("#regpersonalform");
formulario.addEventListener("submit", (e) => {
	e.preventDefault();
	const datos = new FormData(document.getElementById("regpersonalform"));

	let url = "../controlador/ctr-personas.php?op=guardar";
	
		fetch(url, {
			method: "post",
			body: datos,
		})
			.then((data) => data.json())
			.then((data) => {	
			//	console.log(`Success: ${JSON.stringify(data)}`);
				console.log(data);

				$('#modalregistrarexitoso').modal("show");
				
				setInterval(function() {
					location.href = `../vista/manejo-trabajador2.php?id=${data}`;
				}, 2000);	
								
				/*document.getElementById("botonidpersonreg").onclick = function () {
					location.href = `../vista/manejo-trabajador2.php?id=${data}`;
				};*/
			})
			.catch((error) => console.log(`error: ${error}`));
	
});