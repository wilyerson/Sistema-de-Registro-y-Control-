

const validate = (formFields) => {
	let nombreinstitucion = formFields.get("nombreinstitucion").trim();
	let codigodeinstitucion = formFields.get("codigodeinstitucion").trim();
	const id_mun = document.getElementById('id_mun');
	const id_munValue = id_mun.value.trim();
	const parroquiareg = document.getElementById('parroquiareg');
	const parroquiaregValue = parroquiareg.value.trim();
	let sectorinstitucion = formFields.get("sectorinstitucion").trim();
	let direccioninstitucion = formFields.get("direccioninstitucion").trim();
	//let alerta = "";
	//mensajes.innerHTML = "";
	let sinErrores;

	//document.querySelector(".invalidinput").style.display="block";
	let nombreinsti = document.getElementById('nombreinstitucion');
	let codigoinsti = document.getElementById('codigodeinstitucion');

	let sectorinsti = document.getElementById('sectorinstitucion');
	let direccioninsti = document.getElementById('direccioninstitucion');

	let nombreinstivalue = nombreinsti.value;
	let codigodeinstitucionvalue = codigoinsti.value;
	console.log(nombreinstivalue);

	

duplicatecodreginsti();
console.log(duplicatecodreginsti())

	

	if (nombreinstitucion == "") {
		setErrorFor(nombreinsti, 'Ingrese el Nombre de la Institucion');

		sinErrores = false;
	} else {
			setSuccessFor(nombreinsti);
	}


	if (id_munValue == "") {
		setErrorFor(id_mun, 'Ingrese el Municipio de la Institucion');

		sinErrores = false;
	} else {
		setSuccessFor(id_mun);
	}

	if (parroquiaregValue == "") {
		setErrorFor(parroquiareg, 'Ingrese la Parroquia de la Institucion');

		sinErrores = false;
	} else {
		setSuccessFor(parroquiareg);
	}

			let codvalidation = localStorage.getItem("codinstiyaexiste");
			//codvalidation = 2;
	console.log("codvalidation : "+ codvalidation);

	

		if (codigodeinstitucion == "") {
			setErrorFor(codigoinsti, 'Ingrese el Codigo de la Institucion');

			sinErrores = false;
		}  
		if (codvalidation == 2) {
	    
	    	sinErrores = false;
	    	//localStorage.removeItem("codinstiyaexiste");
	    } 
	    if (codvalidation == 3) {
	    	//codvalidation = 3;
			sinErrores = true;
			//localStorage.removeItem("codinstiyaexiste");
		}



console.log(sinErrores);
	return sinErrores;
};

function setErrorFor(input, message) {
  const formControl = input.parentElement;
  const small = formControl.querySelector('small');
  formControl.classList.add('errorinput'); // Agrega la clase 'errorinput'
  small.innerText = message;
}

function setSuccessFor(input) {
  const formControl = input.parentElement;
  formControl.classList.remove('errorinput');
  formControl.classList.add('successinput');

}

function limpiarformureginsti() {
		let mensajes = document.querySelectorAll("div");
			mensajes.forEach((div) => {
			div.classList.remove('errorinput');	
			div.classList.remove('successinput');
		});
	}

function duplicatecodreginsti() {
    return new Promise((resolve, reject) => {
        let nombreinsti = document.getElementById('nombreinstitucion');
        let codigoinsti = document.getElementById('codigodeinstitucion');

        let nombreinstivalue = nombreinsti.value;
        let codigodeinstitucionvalue = codigoinsti.value;

        fetch(`../controlador/ctlr-reg-instituciones.php?op=traerdatosvalidacion`, {
            method: "post",
            body: new FormData(document.getElementById("formulariogeistroinstitucion")),
        })			
        .then((data) => data.json())
        .then((respuesta) => {
            console.log(respuesta);
            let nombreInstitucionExiste = false;
            let codigoRegistroExiste = false;
            let sinErrores = false;
            let validarcodreg = 3;

            respuesta.forEach(objeto => {
                if (objeto.NombreInstitucion == nombreinstivalue) {
                    nombreInstitucionExiste = true;
                    sinErrores = false;
                } 
                if (objeto.CodigoRegistro == codigodeinstitucionvalue) {
                    codigoRegistroExiste = true;
                    sinErrores = false;
                    validarcodreg = 2;
                     localStorage.setItem("codinstiyaexiste", validarcodreg);
                    console.log(validarcodreg);
                } 
            });

            if (nombreInstitucionExiste) {
                setErrorFor(nombreinsti, 'Este Nombre de Institucion Ya Existe');
                Swal.fire({
                    title: "Este nombre de Institucion ya Existe",
                    icon: "error"
                });
            } else if (codigoRegistroExiste) { 
                setErrorFor(codigoinsti, 'Este Codigo de Institucion Ya Existe');
                
                Swal.fire({
                    title: "Este Codigo de Institucion ya Existe",
                    icon: "error"
                });
            } 
             if (!codigoRegistroExiste){
            	setSuccessFor(codigoinsti);
            	validarcodreg = 3;
                    localStorage.setItem("codinstiyaexiste", validarcodreg);
                    console.log(validarcodreg);
                    console.log("hola entre en else de CodigoRegistro")
            }

            resolve(sinErrores);
        })
        .catch((error) => {
            console.log(`error: ${error}`);
            reject(error);
        });
    });
}

window.onload = function() {
  localStorage.removeItem("codinstiyaexiste");
};