<?php 

session_start();

if(!isset($_SESSION['usuarioad']))
{
	header("Location: ../index.php");
}


$conn = mysqli_connect("localhost","root","","sirceop"); 

$id = $_GET['id'];
$usuarios = "SELECT * FROM persona WHERE CodigoPersona = '$id'";
$documentos = "SELECT * FROM documento   WHERE CodigoDocumento = '$id'";
$historicos = "SELECT * FROM historico WHERE trabajador = '$id'";
$familias = "SELECT * FROM familiar WHERE Trabajador = '$id'";

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SIRCE</title>
	<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body class="bg-gray">

	<?php include"../componentes/nav.php" ?>


	<div class="container p-2" style="max-width: 1000px; margin-top: 100px; ">


		<ul class="nav nav-pills mb-3 justify-content-center" id="pills-tab" role="tablist">
			<li class="nav-item" role="presentation">
				<button class="nav-link active" id="pills-Perfil-tab" data-bs-toggle="pill" data-bs-target="#pills-Perfil" type="button" role="tab" aria-controls="pills-Perfil" aria-selected="true">Datos Personales</button>
			</li>
			<li class="nav-item" role="presentation">
				<button class="nav-link" id="pills-docs-tab" data-bs-toggle="pill" data-bs-target="#pills-docs" type="button" role="tab" aria-controls="pills-docs" aria-selected="false">Documentos</button>
			</li>
			<li class="nav-item" role="presentation">
				<button class="nav-link" id="pills-historico-tab" data-bs-toggle="pill" data-bs-target="#pills-historico" type="button" role="tab" aria-controls="pills-historico" aria-selected="false">Historico</button>
			</li>
			<li class="nav-item" role="presentation">
				<button class="nav-link" id="pills-familiares-tab" data-bs-toggle="pill" data-bs-target="#pills-familiares" type="button" role="tab" aria-controls="pills-familiares" aria-selected="false">Familiares</button>
			</li>
		</ul>

		<div class="tab-content bg-white p-4" id="pills-tabContent">

				<!-- ///////////////////////////////////////////////////PANEL PERFIL /////////////////////////////////////////////////-->

				<div class="tab-pane fade show active" id="pills-Perfil" role="tabpanel" aria-labelledby="pills-Perfil-tab">


					<?php $resultado = mysqli_query($conn, $usuarios);

					while ($row=mysqli_fetch_assoc($resultado)) { ?>


					<div class="row mt-2 mb-2">

						<div class="col col-md-5">
							<img class="rounded mx-auto d-block" id="img-perfil" width="200px">
						</div>


						<?php  

						$fechapersona = date('Y', strtotime($row['FechaNacimiento']));
						$fechactual = date('Y');
						$edad = $fechactual - $fechapersona;
         			 //$fechaa = $row['fechanacimientopersona'];

						?>

						<input type="hidden" value="<?php echo $row['CedulaPersona']; ?>" name="id" id="idcedula" >

						<div class="col sm-7">
							<div class="row mb-0"><h6>Personal: <?php echo strtoupper($row['Nombres']); ?> <?php echo strtoupper($row['Apellidos']); ?></h6></div>
							<div class="row mb-0 p-0 b-0"><p class="mb-2">Cedula de Identidad: <?php echo $row['CedulaPersona']; ?></p></div>
							<div class="row mb-0 p-0 b-0"><p class="mb-2">Edad: <?php echo $edad; ?></p></div>
							<div class="row mb-0 p-0 b-0"><p class="mb-2">Cargo Actual: </p></div>
							<div class="row mb-0 p-0 b-0"><p class="mb-2">Dirección:<?php echo strtoupper($row['Direccion']); ?></p></div>
						</div>
						<div class="col col-sm-12 d-flex justify-content-center">
							<button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-editar-trabajador">
								Modificar Datos
							</button>
						</div>
					</div>
				</div>

				<!-- ///////////////////////////////////////////////////PANEL PERFIL /////////////////////////////////////////////////-->

				<!--///////////////////////////////////////////// MODAL EDITAR DATOS /////////////////////////////////////////////-->

				<div class="modal fade" id="modal-editar-trabajador" tabindex="-1" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-xl">
						<div class="modal-content">

							<div class="modal-header" style="background-color:#009aff; ">
								<h5 class="modal-title" id="exampleModalLabel">Editar Datos del Trabajador</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
							</div>

							<div class="modal-body">

							<!--  CEDULA - NOMBRE Y APELLIDO</!--->

							<form id="formupersonamodificar"  method="post"  enctype="multipart/form-data"  novalidate>

          					<input type="hidden" value="<?php echo $row['CedulaPersona']; ?>" name="idpersona" id="idpersona" >
							
							<div class="row mb-4">

								<div class="col col-sm-4 formu-control">
									<label for="cedula" class="form-label">Cédula</label>
									<input type="number" class="form-control" id="CedulaPersona" name="CedulaPersona" value="<?php echo $row['CedulaPersona']; ?>">
									<small>Error message</small>
								</div>

								<div class="col col-sm-4 formu-control">
									<label for="nombres" class="form-label">Nombres</label>
									<input type="text" class="form-control" id="Nombres" name="Nombres" value="<?php echo strtoupper($row['Nombres']) ; ?>">
									<small>Error message</small>
								</div>

								<div class="col col-sm-4 formu-control">
									<label for="apellidos" class="form-label">Apellidos</label>
									<input type="text" class="form-control" id="Apellidos" name="Apellidos" value="<?php echo strtoupper($row['Apellidos']); ?>">
									<small>Error message</small>
								</div>

							</div>

							<!--  CEDULA - ESTADO CIVIL</!--->
							<!-- FECHA - SEXO</!--->

							<div class="row mb-4">

								<div class="col col-sm-4 formu-control">
									<label for="fecha-nac" class="form-label">Fecha de Nacimiento</label>
									<input type="date" class="form-control" id="FechaNacimiento" name="Fechanacimiento" value="<?php echo $row['FechaNacimiento']; ?>">
									<small>Error message</small>
								</div>

								<div class="col col-sm-4 formu-control">
									<label for="sexo" class="form-label">Sexo</label>
									<select name="sexo" class="form-select" id="sexo">
										<option value="<?php echo $row['Sexo']; ?>" selected ><?php echo $row['Sexo']; ?></option>
										<option value="masculino">Masculino</option>
										<option value="femenino">Femenino</option>

									</select>
									<small>Error message</small>
								</div>

								<div class="col col-sm-4 formu-control">
									<label for="std-civil" class="form-label">Estado Civil</label>
									<select name="estadocivil" class="form-select" id="estadocivil">
										<option value="<?php echo $row['EstadoCivil']; ?>" selected ><?php echo $row['EstadoCivil']; ?></option>
										<option value="casado">casado</option>
										<option value="soltero">soltero</option>

									</select>
									<small>Error message</small>
								</div>

							</div>

							<!-- FECHA - SEXO</!--->
							<!-- IMAGEN</!--->

							<div class="row mb-4 formu-control">
								<div class="col col-sm-12">
									<label for="img-trb" class="form-label">Seleccione una imagen de Perfil</label>
									<input type="file" class="form-control" id="Fotopersona" name="Fotopersona" value="<?php echo $row['Fotopersona']; ?>" >
									<small>Error message</small>
								</div>
							</div>

							<!-- IMAGEN</!--->
							<!--  NUMEROS TELEFONICOS </!--->

							<div class="row mb-4 ">
								<div class="col sm-6 formu-control">
									<label for="n-principal" class="form-label">Numero Principal</label>
									<input type="number" class="form-control" id="TelefonoPrincipal" name="TelefonoPrincipal" value="<?php echo $row['TelefonoPrincipal']; ?>" >
									<small>Error message</small>
								</div>
								<div class="col sm-6 formu-control">
									<label for="n-habitacion" class="form-label">Numero Habitación</label>
									<input type="number" class="form-control" id="TelefonoHabitacion" name="TelefonoHabitacion" value="<?php echo $row['TelefonoHabitacion']; ?>">
									<small>Error message</small>
								</div>
							</div>

							<!--  NUMEROS TELEFONICOS </!--->


							<!-- LOCALIDAD</!--->

							<div class="row mb-4">

								<div class="col col-sm-4 formu-control">
									<label for="municipio" class="form-label">Municipio</label>
									<select class="form-select" id="municipio" aria-label="Default select example">
										<option selected>Seleccione</option>
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
									</select>
									<small>Error message</small>
								</div>

								<div class="col col-sm-4 formu-control">
									<label for="parroquia" class="form-label">Parroquia</label>
									<select class="form-select" id="parroquia" aria-label="Default select example">
										<option selected>Seleccione</option>
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
									</select>
									<small>Error message</small>
								</div>

								<div class="col col-sm-4 formu-control">
									<label for="sector" class="form-label">Sector</label>
									<input type="text" class="form-control form-control-lg" id="sector" name="sector" value="<?php echo $row['Sector']; ?>">
									<small>Error message</small>
								</div>

								<div class="col col-sm-12 mt-4 formu-control">
									<label for="direccion" class="form-label">Dirección</label>
									<input type="text" class="form-control form-control-lg" id="direccion" name="direccion" value="<?php echo $row['Direccion']; ?>">
									<small>Error message</small>
								</div>

							</div>

							<!-- LOCALIDAD</!--->

							<!--  PESO Y ESTATURA </!--->

							<div class="row mb-4">
								<div class="col sm-6 formu-control">
									<label for="peso" class="form-label">Peso</label>
									<input type="text" class="form-control" id="peso" name="peso" value="<?php echo $row['Peso']; ?>">
								</div>
								<div class="col sm-6 formu-control">
									<label for="estatura" class="form-label">Estatura</label>
									<input type="text" class="form-control" id="estatura" name="estatura" value="<?php echo $row['Estatura']; ?>">
									<small>Error message</small>
								</div>
							</div>

							<!--  PESO Y ESTATURA </!--->

							<!--  TALLAS</!--->

							<div class="row mb-4">

								<div class="col sm-4 formu-control">
									<label for="camisa" class="form-label">Talla Camisa</label>
									<input type="text" class="form-control" id="TallaCamisa" name="TallaCamisa" value="<?php echo $row['TallaCamisa']; ?>">
									<small>Error message</small>
								</div>

								<div class="col sm-4 formu-control">
									<label for="pantalon" class="form-label">Talla Pantalón</label>
									<input type="text" class="form-control" id="TallaPantalon" name="TallaPantalon" value="<?php echo $row['TallaPantalon']; ?>">
									<small>Error message</small>
								</div>

								<div class="col sm-4 formu-control">
									<label for="calzado" class="form-label">Talla Calzado</label>
									<input type="text" class="form-control" id="TallaCalzado" name="TallaCalzado" value="<?php echo $row['TallaCalzado']; ?>">
									<small>Error message</small>
								</div>

							</div>

							<!--  TALLAS</!--->

							</div>

							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
								<button type="submit" class="btn btn-primary" name="modificar">Guardar Cambios</button>
							</div>
							<?php } mysqli_free_result($resultado); ?>
							</form>
						</div>
					</div>
				</div>

				<!--///////////////////////////////////////////// MODAL EDITAR DATOS /////////////////////////////////////////////-->



				<!-- ////////////////////////////////////////////////PANEL DOCUMENTOS//////////////////////////////////////////////// -->

				<div class="tab-pane fade" id="pills-docs" role="tabpanel" aria-labelledby="pills-docs-tab">

					<div class="row">

						<div class="col-sm-12 d-flex justify-content-end py-3">
							<button type="button" class="btn btn-primary justify-content-center" data-bs-toggle="modal" data-bs-target="#modal-registrar-documentos">
								Añadir Documentos
							</button>						
						</div>

						<div class="col-sm-12 d-block justify-content-center">

							<table class="table table-hover">
								<thead>
									<tr>
										<th>Nombre Documento</th>
										<th>Foto Documento</th>
									</tr>								
								</thead>
								<tbody>
									<tr>
										<td colspan="2">no hay registros para mostrar</td>
									</tr>
								</tbody>

							</table>

						</div>

					</div>

				</div>

				<!-- ////////////////////////////////////////////////PANEL DOCUMENTOS//////////////////////////////////////////////// -->

				<!-- ////////////////////////////////////////////////PANEL HISTORICO//////////////////////////////////////////////// -->
				<div class="tab-pane fade" id="pills-historico" role="tabpanel" aria-labelledby="pills-historico-tab">

					<div class="row">

						<div class="col-sm-12 d-flex justify-content-end py-3">
							<button type="button" class="btn btn-primary d-flex justify-content-center" data-bs-toggle="modal" data-bs-target="#registro-historico">
								Registrar Historial
							</button>						
						</div>

						<div class="col-sm-12 d-block justify-content-center">

							<table class="table table-hover">
								<thead>
									<tr>
										<th>Institución</th>
										<th>Cargo</th>
										<th>Fecha Inicio</th>
										<th>Fecha Culminacion</th>
										<th>Acción</th>
									</tr>								
								</thead>
								<tbody>
									<tr>
										<td colspan="4">no hay registros para mostrar</td>
									</tr>
								</tbody>

							</table>

						</div>

					</div>

				</div>
				<!-- ////////////////////////////////////////////////PANEL HISTORICO//////////////////////////////////////////////// -->

				<!-- ////////////////////////////////////////////////PANEL FAMILIARES//////////////////////////////////////////////// -->
				<div class="tab-pane fade" id="pills-familiares" role="tabpanel" aria-labelledby="pills-familiares-tab">

					<div class="row">

						<div class="col-sm-12 d-flex justify-content-end py-3">
							<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#registro-familiar">Registrar Familiar</button>						
						</div>

						<div class="col-sm-12 d-block justify-content-center">

							<table class="table table-hover">
								<thead>
									<tr>
										<th>Nombres</th>
										<th>Apellidos</th>
										<th>Parentesco</th>
										<th>Edad</th>
										<th class="text-center" style="width: 13%;">Acción</th>
									</tr>								
								</thead>
								<tbody>
									<tr>
										<td colspan="4">No hay registros</td>
										<td>											
											<div class="dropdown">
												<button class="btn btn-info dropdown-toggle dropdown-toggle btn-sm text-end" type="button" id="dropdownMenuButton1" style="width: 100%;" data-bs-toggle="dropdown" aria-expanded="false">
													Seleccione
												</button>
												<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
													<li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#modal-editar-familiar">Ver Datos</a></li>
													<li><a class="dropdown-item" href="#">Modificar</a></li>
													<li><a class="dropdown-item" href="#">Eliminar</a></li>
												</ul>
											</div>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<!-- ////////////////////////////////////////////////PANEL FAMILIARES//////////////////////////////////////////////// -->

			</div>




				<!-- ///////////////////////////////////////////MODAL REGISTRO FAMILIAR/////////////////////////////////////////// -->

				<div class="modal fade" id="registro-familiar" tabindex="-1" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered modal-md">
						<div class="modal-content">
							<div class="modal-header" style="background-color: #009aff;">
								<h5 class="modal-title text-white" id="exampleModalLabel">Registrar Familiar</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
							</div>

							<div class="modal-body">

								<div class="row">

									<div class="col col-md-12 py-1">
										<div class="form-check d-flex justify-content-center">
											<input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
											<label class="form-check-label" for="flexCheckDefault">
												&nbsp;&nbsp;&nbsp;No posee Cédula
											</label>
										</div>
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="number" class="form-control" id="cedula" placeholder="INGRESE CEDULA DE IDENTIDAD">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="number" class="form-control" id="regpartida" placeholder="INGRESE REGISTRO DE PARTIDA DE NACIMIENTO">
									</div>
								</div>

								<div class="row">
									<div class="col-sm-12 py-3">										
										<select name="parentesco" class="form-select" id="parentesco">
											<option selected disabled="">Seleccione Parentesco</option>
											<option value="1">Hijo</option>
											<option value="1">Hija</option>
											<option value="1">Padre</option>
											<option value="1">Madre</option>
											<option value="2">Esposa</option>
											<option value="2">Esposo</option>
											<option value="2">Abuelo</option>
											<option value="2">Abuela</option>
											<option value="2">Nieto</option>
											<option value="2">Nieta</option>
											<option value="2">Sobrino</option>
											<option value="2">Sobrina</option>
											<option value="2">Hermano</option>
											<option value="2">Hermana</option>
										</select>
									</div>
								</div>

								<div class="row">
									<div class="col-sm-12 py-3">
									&nbsp;&nbsp;&nbsp;<label for="foto">Seleccione Foto del Familiar</label>										
										<input type="file" id="foto_fam" name="foto_fam" class="form-control">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="nombres" placeholder="INGRESE NOMBRES DEL PARIENTE">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="apellidos" placeholder="INGRESE APELLIDOS DEL PARIENTE">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<select name="sexo" class="form-select" id="sexo">
											<option selected disabled="">Seleccione Sexo</option>
											<option value="f">Femenino</option>
											<option value="m">Masculino</option>
										</select>
									</div>					 				
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input class="form-control" id="fechanac" name="fechanac" type="date">
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="numtelefono" name="numtelefono" placeholder="Ingrese número telefonico Principal">
									</div>					 				
								</div>

								<div class="row">					 				
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="numtelefono2" name="numtelefono2" placeholder="Ingrese número telefonico de habitación">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<select name="" id="id_mun" class="form-select">
											<option selected>Seleccione Municipio</option>
											<?php 

											require "../controlador/municipiosfetch.php";

											foreach ($municipio as $municipio) {
												echo '<option value="'.$municipio['CodigoMunicipio'].'">'.$municipio['NombreMunicipio'].'</option>';
											}

											?>
										</select>
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<select name="parr" style="text-transform: uppercase;" id="id_parr" class="form-select">
											<option selected disabled value="">Seleccione Parroquia</option>
										</select>
										<script>
											document.querySelector('#id_mun').addEventListener('change', event => {
												console.log(event.target.value);
												fetch('../controlador/parroquiasfetch.php?id_mun='+event.target.value)
												.then(res => {
													if(!res.ok){
														throw new Error('error en la respuesta');
													}
													return res.json();	
												})
												.then(datos => {
													let html = '<option value="">Seleccione Parroquia</option>';
													if(datos.data.length > 0){
														for(let i = 0; i < datos.data.length; i++){
															html += `<option value="${datos.data[i].CodigoParroquia}">${datos.data[i].NombreParroquia}</option>`; 
														}
													}
													console.log(html);
													document.querySelector('#id_parr').innerHTML = html;
												})
												.catch(error => {
													console.error('ocurrio un error '+error);
												});	
											});
										</script>
									</div>

								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="sector" name="sector" placeholder="Ingrese Sector">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-12 py-3">
										<input type="text" class="form-control" id="direccion" name="direccion" placeholder="Ingrese Dirección">
									</div>
								</div>

								<div class="row">
									<div class="col col-sm-6 py-3">
										<input type="text" class="form-control" id="peso" name="peso" placeholder="Peso en kg">
									</div>
									<div class="col col-sm-6 py-3">
										<input type="text" class="form-control" id="estatura" name="estatura" placeholder="Estatura en En Mts">
									</div>
								</div>

								<div class="row">
									<div class="col-sm-12">
										<hr>
										<p class="text-center">Datos de Individuo</p>
										<hr>
									</div>
								</div>

								<div class="row">

									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" id="tallacamisa" name="tallacamisa" placeholder="Torso">
									</div>
									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" id="tallapant" name="tallapant" placeholder="Pantalón">
									</div>
									<div class="col col-sm-4 py-3">
										<input type="text" class="form-control" id="tallacalza" name="tallacalza" placeholder="Calzado">
									</div>
								</div>					 		

							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
								<button type="button" name="guardar" class="btn btn-primary">Guardar</button>

							</div>
						</div>
					</div>
				</div>

				<!-- ///////////////////////////////////////////MODALREGISTROFAMILIAR/////////////////////////////////////////// -->




				<!-- ///////////////////////////////////////////////MODAL HISTORICO/////////////////////////////////////////////// -->

				<div class="modal fade " id="registro-historico" tabindex="-1" aria-hidden="true">
            		<div class="modal-dialog modal-dialog-centered modal-lg">
             			<div class="modal-content">
             				<div class="modal-header" style="background-color: #009aff;">
             					<h5 class="modal-title text-white" id="exampleModalLabel">Nuevo Registro Historico</h5>
             					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
             				</div>

             				<div class="modal-body">
             					
             					<div class="row py-3">
             						<div class="col col-sm-6">
             							<label for="institucion" class="form-label">Institución</label>
             							<select class="form-select" id="institucion" aria-label="Seleccione">
             								<option selected>Seleccione</option>
             								<option value="1">1</option>
             								<option value="2">2</option>
             								<option value="3">3</option>
             							</select>
             						</div>

             						<div class="col col-sm-6">
             							<label for="cargo" class="form-label">Cargo</label>
             							<select class="form-select" id="cargo" aria-label="Seleccione">
             								<option selected>Seleccione</option>
             								<option value="1">1</option>
             								<option value="2">2</option>
             								<option value="3">3</option>
             							</select>
             						</div>
             					</div>

             					<div class="row py-3">
             						<div class="col col-sm-6">
             							<label for="fecha-inicio" class="form-label">Fecha de Inicio</label>
             							<input type="date" class="form-control" id="fecha-inicio">
             						</div>
             						<div class="col col-sm-6">
             							<label for="fecha-culminacion" class="form-label">Fecha de Culminación</label>
             							<input type="date" class="form-control" id="fecha-culminacion">
             						</div>
             					</div>

             					<div class="row py-3">
             						<div class="col col-sm-12">
             							<label for="observacion" class="form-label">Observación</label>
             							<input type="text" class="form-control form-control-lg" id="observacion">
             						</div>
             					</div>

             				</div> 

             				<div class="modal-footer">
             					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
             					<button type="button" class="btn btn-primary">Guardar</button>
             				</div>  
             			</div>            			
            		</div>
				</div>


				<!-- ///////////////////////////////////////////////MODAL HISTORICO/////////////////////////////////////////////// -->



				<!--////////////////////////////////////////////// MODAL DOCUMENTOS //////////////////////////////////////////////-->

				<div class="modal fade" id="modal-registrar-documentos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-md">
						<div class="modal-content">
							<div class="modal-header" style="background-color:#009aff; ">
								<h5 class="modal-title text-white" id="exampleModalLabel">Registro de Documento</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
							</div>

							<div class="modal-body">
								<div class="row py-4">


									<div class="col col-sm-12">

										<select class="form-select" aria-label="Default select example">
											<option selected>Seleccione el Tipo de Documento</option>
											<option value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
										</select>
									</div>

								</div>
								<div class="row py-4">
									<div class="col col-sm-12">

										<div class="">
											<input class="form-control" type="file" id="formFileMultiple" multiple>
										</div>

									</div>
								</div>

							</div>

							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
								<button type="button" class="btn btn-primary">Guardar</button>
							</div>
						</div>						
					</div>
				</div>
				<!--////////////////////////////////////////////// MODAL DOCUMENTOS //////////////////////////////////////////////-->

				<!--///////////////////////////////////////////// MODAL EDITAR DATOS FAMILIAR /////////////////////////////////////-->

				<div class="modal fade" id="modal-editar-familiar" tabindex="-1" aria-labelledby="modal-editar-familiarLabel" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered .modal-dialog-scrollable modal-xl">
						<div class="modal-content">

							<div class="modal-header" style="background-color:#009aff; ">
								<h5 class="modal-title" id="exampleModalLabel">Editar Datos del Familiar</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
							</div>

							<form id="formupersonamodificar"  method="post"  enctype="multipart/form-data"  novalidate>
								<div class="modal-body">

								<!--  CEDULA - NOMBRE Y APELLIDO</!--->


		          					<input type="hidden" value="" name="idpersona" id="idpersona" >
									
									<div class="row mb-4">

										<div class="col col-sm-4 formu-control">
											<label for="cedula" class="form-label">Cédula</label>
											<input type="number" class="form-control" id="CedulaPersona" name="CedulaPersona" value="">
											<small>Error message</small>
										</div>

										<div class="col col-sm-4 formu-control">
											<label for="nombres" class="form-label">Nombres</label>
											<input type="text" class="form-control" id="Nombres" name="Nombres" value="">
											<small>Error message</small>
										</div>

										<div class="col col-sm-4 formu-control">
											<label for="apellidos" class="form-label">Apellidos</label>
											<input type="text" class="form-control" id="Apellidos" name="Apellidos" value="">
											<small>Error message</small>
										</div>

									</div>

									<!--  CEDULA - ESTADO CIVIL</!--->
									<!-- FECHA - SEXO</!--->

									<div class="row mb-4">

										<div class="col col-sm-4 formu-control">
											<label for="fecha-nac" class="form-label">Fecha de Nacimiento</label>
											<input type="date" class="form-control" id="FechaNacimiento" name="Fechanacimiento" value="">
											<small>Error message</small>
										</div>

										<div class="col col-sm-4 formu-control">
											<label for="sexo" class="form-label">Sexo</label>
											<select name="sexo" class="form-select" id="sexo">
												<option value="" selected ></option>
												<option value="masculino">Masculino</option>
												<option value="femenino">Femenino</option>

											</select>
											<small>Error message</small>
										</div>

										<div class="col col-sm-4 formu-control">
											<label for="std-civil" class="form-label">Estado Civil</label>
											<select name="estadocivil" class="form-select" id="estadocivil">
												<option value="" selected ></option>
												<option value="casado">casado</option>
												<option value="soltero">soltero</option>

											</select>
											<small>Error message</small>
										</div>

									</div>

									<!-- FECHA - SEXO</!--->
									<!-- IMAGEN</!--->

									<div class="row mb-4 formu-control">
										<div class="col col-sm-12">
											<label for="img-trb" class="form-label">Seleccione una imagen de Perfil</label>
											<input type="file" class="form-control" id="Fotopersona" name="Fotopersona" value="" >
											<small>Error message</small>
										</div>
									</div>

									<!-- IMAGEN</!--->
									<!--  NUMEROS TELEFONICOS </!--->

									<div class="row mb-4 ">
										<div class="col sm-6 formu-control">
											<label for="n-principal" class="form-label">Numero Principal</label>
											<input type="number" class="form-control" id="TelefonoPrincipal" name="TelefonoPrincipal" value="" >
											<small>Error message</small>
										</div>
										<div class="col sm-6 formu-control">
											<label for="n-habitacion" class="form-label">Numero Habitación</label>
											<input type="number" class="form-control" id="TelefonoHabitacion" name="TelefonoHabitacion" value="">
											<small>Error message</small>
										</div>
									</div>

									<!--  NUMEROS TELEFONICOS </!--->


									<!-- LOCALIDAD</!--->

									<div class="row mb-4">

										<div class="col col-sm-4 formu-control">
											<label for="municipio" class="form-label">Municipio</label>
											<select class="form-select" id="municipio" aria-label="Default select example">
												<option selected>Seleccione</option>
												<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
											</select>
											<small>Error message</small>
										</div>

										<div class="col col-sm-4 formu-control">
											<label for="parroquia" class="form-label">Parroquia</label>
											<select class="form-select" id="parroquia" aria-label="Default select example">
												<option selected>Seleccione</option>
												<option value="1">1</option>
												<option value="2">2</option>
												<option value="3">3</option>
											</select>
											<small>Error message</small>
										</div>

										<div class="col col-sm-4 formu-control">
											<label for="sector" class="form-label">Sector</label>
											<input type="text" class="form-control form-control-lg" id="sector" name="sector" value="">
											<small>Error message</small>
										</div>

										<div class="col col-sm-12 mt-4 formu-control">
											<label for="direccion" class="form-label">Dirección</label>
											<input type="text" class="form-control form-control-lg" id="direccion" name="direccion" value="">
											<small>Error message</small>
										</div>

									</div>

									<!-- LOCALIDAD</!--->

									<!--  PESO Y ESTATURA </!--->

									<div class="row mb-4">
										<div class="col sm-6 formu-control">
											<label for="peso" class="form-label">Peso</label>
											<input type="text" class="form-control" id="peso" name="peso" value="">
										</div>
										<div class="col sm-6 formu-control">
											<label for="estatura" class="form-label">Estatura</label>
											<input type="text" class="form-control" id="estatura" name="estatura" value="">
											<small>Error message</small>
										</div>
									</div>

									<!--  PESO Y ESTATURA </!--->

									<!--  TALLAS</!--->

									<div class="row mb-4">

										<div class="col sm-4 formu-control">
											<label for="camisa" class="form-label">Talla Camisa</label>
											<input type="text" class="form-control" id="TallaCamisa" name="TallaCamisa" value="">
											<small>Error message</small>
										</div>

										<div class="col sm-4 formu-control">
											<label for="pantalon" class="form-label">Talla Pantalón</label>
											<input type="text" class="form-control" id="TallaPantalon" name="TallaPantalon" value="">
											<small>Error message</small>
										</div>

										<div class="col sm-4 formu-control">
											<label for="calzado" class="form-label">Talla Calzado</label>
											<input type="text" class="form-control" id="TallaCalzado" name="TallaCalzado" value="">
											<small>Error message</small>
										</div>

									</div>

									<!--  TALLAS</!--->

								</div>

								<div class="modal-footer">
									<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
									<button type="submit" class="btn btn-primary" name="modificar">Guardar Cambios</button>
								</div>
							</form>
						</div>
					</div>
				</div>

				<!--///////////////////////////////////////////// MODAL EDITAR DATOS FAMILIAR /////////////////////////////////////-->

		</div>
	</body>
	</html>