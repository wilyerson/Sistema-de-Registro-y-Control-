<?php
require_once "../config/dbconexion.php";
require_once "../modelo/ModeloPersonal.php";

$personal = new Personal();

switch ($_GET["op"]) {

    case 'listar':
        $result_set = $consultas->get_personas();
        $data = array();
        foreach ($result_set as $row) {
            array_push($data, array("id_persona" => $row['id_persona'], "nombres" => $row['nombres'], "apellidos" => $row['apellidos'], "genero" => $row['genero']));
        }
        echo json_encode($data); //formateado como json
        break;

    case 'guardar':
        $CedulaPersona = $_POST['cedulapersona'];
        $Nombres = $_POST['nombrespersonal'];
        $Apellidos = $_POST['apellidospersonal'];
        $FechaNacimiento = $_POST['fechanacimiento'];
        $Sexo = $_POST['sexo'];
        $EstadoCivil = $_POST['estadocivil'];
        $ParroquiaPersona = $_POST['parroquiareg'];
        $Sector = $_POST['nombresector'];
        $Direccion = $_POST['direccion'];
        $TelefonoPrincipal = $_POST['telefonoprincipal'];
        $TelefonoHabitacion = $_POST['telefonohabitacion'];
        $Peso = $_POST['peso'];
        $Estatura = $_POST['estatura'];
        $TallaCamisa = $_POST['tallacamisa'];
        $TallaPantalon = $_POST['tallapantalon'];
        $TallaCalzado = $_POST['tallacalzado'];
        $TipoPersona = $_POST['tipopersona'];
        $EstatusPersonal = $_POST['estatus'];

        $insercion = $personal->insert_persona($CedulaPersona, $Nombres, $Apellidos, $FechaNacimiento, $Sexo, $EstadoCivil, $ParroquiaPersona, $Sector, $Direccion,$TelefonoPrincipal, $TelefonoHabitacion, $Peso, $Estatura, $TallaCamisa, $TallaPantalon, $TallaCalzado, $TipoPersona, $EstatusPersonal);
        //echo json_encode($insercion);
        break;

    case 'editar':
        $id_persona = $_POST['id'];
        $ejecutar = $consultas->get_persona($id_persona);
        echo json_encode($ejecutar);
        break;

    case 'update':
        $id_persona = $_POST['idUdt'];
        $nombres = $_POST['nombresUdt'];
        $apellidos = $_POST['apellidosUdt'];
        $genero = $_POST['generoUdt'];
        $actualizacion = $consultas->update_persona($id_persona, $nombres, $apellidos, $genero);
        echo json_encode($actualizacion);
        break;

    case 'eliminar':
        $id_persona = $_POST['id'];
        $ejecutar = $consultas->delete_persona($id_persona);
        echo json_encode($ejecutar);
        break;

    default:
        # code...
        break;
}
