<?php 


$conn = mysqli_connect("localhost","root","","sirce"); 





if(isset($_POST['Guardar'])){

	$documento = $_FILES['filendocumento']['name'];
    $nombredocumento = $_POST['nombredocumento'];



	if (isset($documento) && $documento != "") {
		
		$tipo = $_FILES['filendocumento']['type'];
        $temp  = $_FILES['filendocumento']['tmp_name'];

        if( !((strpos($tipo,'gif') || strpos($tipo,'jpeg') || strpos($tipo,'webp')))){

         // header('location:../index.php');
       }else{
         $query = "INSERT INTO documento(filedocumento,nombredocumento) values('$documento','$nombredocumento')";


         $resultado = mysqli_query($conn,$query);
         if($resultado == 1){
              move_uploaded_file($temp,'imagenes/'.$documento);   
            

             header('location:../vista/documentos_trabajador.php');

         }else{
            // $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
             //$_SESSION['tipo'] = 'danger';
         }




       }


	}
  
  }
    


?>