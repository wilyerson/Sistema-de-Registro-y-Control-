<?php 


$conn = mysqli_connect("localhost","root","","sirce"); 

   
    $id = $_POST['id'];
    $nombrespersona = $_POST['nombrespersona'];
    $apellidospersona = $_POST['apellidospersona'];
    $fechanacimientopersona = $_POST['fechanacimientopersona'];
    $sexopersona = $_POST['sexopersona'];
    $numerotelefonoprincipalpersona = $_POST['numerotelefonoprincipalpersona'];
    $numerotelefonicohabitacionpersona = $_POST['numerotelefonicohabitacionpersona'];
   // $direccionpersona = $_POST['direccionpersona'];
    $pesopersona = $_POST['pesopersona'];
    $estaturapersona = $_POST['estaturapersona'];
    $tallacamisapersona = $_POST['tallacamisapersona'];
    $tallapantalonpersona = $_POST['tallapantalonpersona'];
    $tallacalzadopersona = $_POST['tallacalzadopersona'];
    


$actualizar = "UPDATE persona SET nombrespersona='$nombrespersona',  apellidospersona='$apellidospersona',  fechanacimientopersona='$fechanacimientopersona',  sexopersona='$sexopersona',  numerotelefonoprincipalpersona='$numerotelefonoprincipalpersona',  numerotelefonicohabitacionpersona='$numerotelefonicohabitacionpersona',  pesopersona='$pesopersona',  estaturapersona='$estaturapersona',  tallacamisapersona='$tallacamisapersona',  tallapantalonpersona='$tallapantalonpersona',  tallacalzadopersona='$tallacalzadopersona' WHERE idpersona='$id' ";


	$resultado=mysqli_query($conn, $actualizar);

	if ($resultado) {

		echo "bien";
		// code...
	} else {

		echo "ja ja";
	}


?>