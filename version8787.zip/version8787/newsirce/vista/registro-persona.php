<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Inicio Sirce</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 50px;
        max-width: 900px;
      }

    </style>
  
</head>
<body>

  	<nav class="navbar bg-body-tertiary fixed-top">
      <div class="container-fluid menumenu">
        <a class="navbar-brand" href="#">S.I.R.C.E</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Nombre Usuario</h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Inicio</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Cambiar Nombre de Usuario</a></li>
                <li><a class="dropdown-item" href="#">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="#">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <div class="container articulo">

      <form action="../controlador/controladorregistratrabajador.php" method="post" enctype="multipart/form-data">
        
          <!--TITULO DE NUEVO TRABAJADOR</!-->
      <div class="row mb-5">
        <div class="col col-sm-12">
          <h4>Registro de Nuevo Trabajador</h4>
        </div>
      </div>
      <!--TITULO DE NUEVO TRABAJADOR</!-->

      <!--  CEDULA - ESTADO CIVIL</!--->

        <div class="row mb-4">

          <div class="col col-sm-6">
            <label for="cedula" class="form-label">Cedula</label>
            <input type="number" class="form-control" id="cedula" name="cedulapersona">
          </div>

          <div class="col col-sm-6">
             <label for="std-civil" class="form-label">Estado Civil</label>
            <select name="estadocivilpersona" class="form-select" id="std-civil">
              <option selected disabled="">Seleccione</option>
              <option value="1">1</option>
              <option value="2">2</option>
            </select>
          </div>

        </div>

      <!--  CEDULA - ESTADO CIVIL</!--->

      <!-- IMAGEN</!--->

        <div class="row mb-4">
          <div class="col col-sm-12">
            <label for="img-trb" class="form-label">Seleccione una imagen</label>
            <input type="file" class="form-control" id="img-trb" name="fotousuario">
          </div>
        </div>

      <!-- IMAGEN</!--->

      <!-- NOMRBES Y APELLIDOS</!--->

        <div class="row mb-4">

          <div class="col col-sm-6">
            <label for="nombres" class="form-label">Nombres</label>
            <input type="text" class="form-control" id="nombres" name="nombrespersona">
          </div>

          <div class="col col-sm-6">
            <label for="apellidos" class="form-label">Apellidos</label>
            <input type="text" class="form-control" id="apellidos" name="apellidospersona">
          </div>

        </div>

      <!-- NOMRBES Y APELLIDOS</!--->

      <!-- FECHA - SEXO</!--->

        <div class="row mb-4">

          <div class="col col-sm-6">
            <label for="fecha-nac" class="form-label">Fecha de Nacimiento</label>
            <input type="date" class="form-control" id="fecha-nac" name="fechanacimientopersona">
          </div>

          <div class="col col-sm-6">
             <label for="sexo" class="form-label">Sexo</label>
            <select name="sexopersona" class="form-select" id="sexo">
              <option selected disabled="">Seleccione</option>
              <option value="m">Masculino</option>
              <option value="f">Fsemenino</option>
              <option value="o">Otro</option>
            </select>
          </div>

        </div>

      <!-- FECHA - SEXO</!--->

      <!--  NUMEROS TELEFONICOS </!--->

      <div class="row mb-4">
        <div class="col sm-6">
          <label for="n-principal" class="form-label">Numero Principal</label>
          <input type="number" class="form-control" id="n-principal" name="numerotelefonoprincipalpersona">
        </div>
        <div class="col sm-6">
          <label for="n-habitacion" class="form-label">Numero Habitacion</label>
          <input type="number" class="form-control" id="n-habitacion" name="numerotelefonicohabitacionpersona">
        </div>
      </div>

      <!--  NUMEROS TELEFONICOS </!--->


      <!-- LOCALIDAD</!--->

        <div class="row mb-4">

          <div class="col col-sm-4">
            <label for="municipio" class="form-label">Municipio</label>
            <select name="nombremunicipio" class="form-select" id="municipio" aria-label="Default select example">
              <option selected>Seleccione</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </div>

          <div class="col col-sm-4">
            <label for="parroquia" class="form-label">Parroquia</label>
            <select name="nombreparroquia" class="form-select" id="parroquia" aria-label="Default select example">
              <option selected>Seleccione</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </div>

          <div class="col col-sm-4">
            <label for="sector" class="form-label">Sector</label>
            <select name="nombresector" class="form-select" sector="sector" aria-label="Default select example">
              <option selected>Seleccione</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </div>
          
          <div class="col col-sm-12 mt-4">
            <label for="direccion" class="form-label">Dirección</label>
            <input type="text" class="form-control form-control-lg" id="direccion" name="direccionpersona">
          </div>

        </div>

      <!-- LOCALIDAD</!--->

      <!--  PESO Y ESTATURA </!--->

      <div class="row mb-4">
        <div class="col sm-6">
          <label for="peso" class="form-label">Peso</label>
          <input type="text" class="form-control" id="peso" name="pesopersona">
        </div>
        <div class="col sm-6">
          <label for="estatura" class="form-label">Estatura</label>
          <input type="text" class="form-control" id="estatura" name="estaturapersona">
        </div>
      </div>

      <!--  PESO Y ESTATURA </!--->

      <!--  TALLAS</!--->

        <div class="row mb-4">
          
          <div class="col sm-4">
            <label for="camisa" class="form-label">Talla Camisa</label>
            <input type="number" class="form-control" id="camisa" name="tallacamisapersona">
          </div>

          <div class="col sm-4">
            <label for="pantalon" class="form-label">Talla Pantalón</label>
            <input type="number" class="form-control" id="pantalon" name="tallapantalonpersona">
          </div>

          <div class="col sm-4">
            <label for="calzado" class="form-label">Talla Calzado</label>
            <input type="number" class="form-control" id="calzado" name="tallacalzadopersona">
          </div>

        </div>

      <!--  TALLAS</!--->

      <div class="row text-center">
        <div class="col col-sm-12">
         <button class="btn btn-primary" type="submit" name="Guardar">Registrar pendejo</button>          
        </div>
      </div>

      </form>

    </div>

</body>
</html>