<!DOCTYPE html>
<html lang="es">  
  <head>    
    <title>sirce</title>    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <meta name="title" content="sistema de reigristo">  

    
  </head>  
  <body>  

<?php

session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: index.php");
}


?>


<label> sirce </label>
  <label> pagina administrador </label>


<?php

echo "Hola: " . $_SESSION["usuarioad"] . "<br><br>";


?>

<a href="../introsys/controlador/cierre.php">cerrar sesion</a>



<form action="/action_page.php">
  <label for="fname">First name:</label><br>
  <input type="text" id="fname" name="fname" value="John"><br>
  <label for="lname">Last name:</label><br>
  <input type="text" id="lname" name="lname" value="Doe"><br><br>
  <input type="submit" value="Submit">
</form> 




  </body>  

  <!-- <script src="../js/bootstrap.bundle.js"></script>  -->



</html>