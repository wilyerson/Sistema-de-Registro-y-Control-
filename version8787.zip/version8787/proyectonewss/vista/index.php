<!DOCTYPE html>
<html lang="es">  
  <head>    
    <title>sirce</title>    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
     <!-- <link href="../css/estilo.css" rel="stylesheet" type="text/css"/> -->
    <meta name="title" content="sistema de reigristo">  

    
  </head>  
  <body>    
<label> sirce </label>

<form method="post" action="../controlador/conexionbd.php">

	<input type="text" name="htmlusuario">
	<br>
	<input type="password" name="htmlpassword">
	<br>

	<input type="submit" value="ingresar" name="ingresar">
	<input type="reset" name="limpiar">
	


</form>



  </body>  

  <!-- <script src="../js/bootstrap.bundle.js"></script>  -->
</html>