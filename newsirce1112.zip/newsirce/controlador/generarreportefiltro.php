<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 


use PhpOffice\PhpSpreadsheet\{Spreadsheet, IOFactory};


require 'excel/vendor/autoload.php';

$genero = $conn->real_escape_string($_POST['genero']);

 $sql = "SELECT Cedulapersona, Nombres, Apellidos, sexo from persona WHERE sexo LIKE '$genero' ";
 $resultado = mysqli_query($conn,$sql);
 //$resultado = $mysqli->query($sql);

 $excel = new  Spreadsheet();
 $hojaActiva = $excel->getActiveSheet();
 $hojaActiva->setTitle("Personas");

 $hojaActiva->getColumnDimension('A')->setWidth(18);
 $hojaActiva->setCellValue('A1','Cedulapersona');
 $hojaActiva->getColumnDimension('B')->setWidth(28);
 $hojaActiva->setCellValue('B1','Nombres');
 $hojaActiva->getColumnDimension('C')->setWidth(28);
$hojaActiva->setCellValue('C1','Apellidos');
$hojaActiva->getColumnDimension('D')->setWidth(25);
$hojaActiva->setCellValue('D1','sexo');



$fila = 2;

 while($rows = $resultado->fetch_assoc()){

    $hojaActiva->setCellValue('A'.$fila,$rows['Cedulapersona']);
    $hojaActiva->setCellValue('B'.$fila,$rows['Nombres']);
    $hojaActiva->setCellValue('C'.$fila,$rows['Apellidos']);
    $hojaActiva->setCellValue('D'.$fila,$rows['sexo']);
    $fila++;

 }


header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="personas.xlsx"');
header('Cache-Control: max-age=0');

$writer = IOFactory::createWriter($excel, 'Xlsx');
$writer->save('php://output');
exit;

?>