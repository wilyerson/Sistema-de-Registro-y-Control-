

var divdatospersonales = document.getElementById("divdatospersonales");

var divconteinerprincipal = document.getElementById("conteinerprincipal");

var btncargafamiliar = document.getElementById("botonprincipal");

var btndatospersonales = document.getElementById("botondatospersonales");




//var span = document.getElementsByClassName("close")[0];

//var btnregistro = document.getElementById("btnregistrohtml");

//var menunavegacion = document.getElementById("zonaregistro");




btndatospersonales.onclick = function() {
  divdatospersonales.style.display = "block";
  divconteinerprincipal.style.display = "none";
}


btncargafamiliar.onclick = function() {
  divdatospersonales.style.display = "none";
  divconteinerprincipal.style.display = "block";
}










// span.onclick = function() {
//   modal.style.display = "none";
// }


// window.onclick = function(event) {
//   if (event.target == modal) {
//     modal.style.display = "none";
//   }
// }




// alert("Mi primer alert");