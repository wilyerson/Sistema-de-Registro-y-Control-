<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

$columns = ['Cedulapersona', 'Nombres', 'Apellidos', 'estadocivil'];


$table = "persona";

$campo = isset($_POST['campo']) ? $conn->real_escape_string($_POST['campo']) : null;

$where = ''; 

if ($campo != null) {
    $where = "WHERE (";

    $cont = count($columns);
    for ($i=0; $i < $cont; $i++) { 
        $where .= $columns[$i] . " LIKE '%". $campo . "%' OR ";
    }
    $where = substr_replace($where, "", -3);
    $where .= ")";
}


$sql = "SELECT " .implode(", ", $columns) . "
FROM $table
$where ";

//echo $sql;
//exit;

$resultado = $conn->query($sql);
$num_rows = $resultado->num_rows;

$html = '';

if ($num_rows > 0) {
    
    while ($row = $resultado->fetch_assoc()) {
        // code...
        $html .= '<tr>';
        $html .= '<td>' . $row['Cedulapersona'] . '</td>';
        $html .= '<td>' . $row['Nombres'] . '</td>';
        $html .= '<td>' . $row['Apellidos'] . '</td>';
        $html .= '<td>' . $row['estadocivil'] . '</td>';
        $html .= '<td><a href="../vista/manejo-trabajador.php?id='. $row['Cedulapersona'] .' ">ver</a></td>';
        //$html .= '<td><a href="">modificar</a></td>';
        $html .= '</tr>';
    }
}else
    {
        $html .= '<tr>';
        $html .= '<td colspan="7">Sin resultado</td>';
        $html .= '</tr>';
    }

    echo json_encode($html, JSON_UNESCAPED_UNICODE);






?>