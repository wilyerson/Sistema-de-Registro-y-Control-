  <!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

    <style>
@font-face{
  font-family: opensan;
  src: url(fonts/googlesansnormal.woff2);

}

body{
  font-family: opensan;
  background-color: #e8f2f7;
}

input::placeholder {
color: black;
  
}



    #zonanombresombra{
    box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
    -moz-box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
    border-radius: 25px;
  }



  #botonbuscar{
        background-color: #008CBA;
    color: white;
    border-radius: 100px;
    position: relative;
    top: 35%;
    left: 55%;
    border: none;
  }

      #botonbuscar:hover {
  background-color: #008CBA; 
  box-shadow: 0 5px 17px 0px rgb(89 88 88 / 49%);
  color: white;

}

  #botonlimpiar{
    background-color: #008CBA;
    color: white;
    border-radius: 100px;
        position: relative;
  position: relative;
    left: 39%;
    top: -10px;
    border: none;
  }

  #botonlimpiar:hover {
  background-color: #008CBA; 
  box-shadow: 0 5px 17px 0px rgb(89 88 88 / 49%);
  color: white;
}

#botonver{
        background-color: #008CBA;
    color: white;
    border-radius: 100px;
    border: none;
}

#botonver:hover {
  box-shadow: 0 5px 17px 0px rgb(89 88 88 / 49%);
} 

#inputtextdecoracion{
  border-radius: 100px;
}

.form-control {
  background-color: #e8e9e9;
  border-radius: 100px;
}

.form-select {
  background-color: #e8e9e9;
  border-radius: 100px;
}

      .menumenu{
        margin: 0 auto;
        width: 900px;
      }
      .articulo{
        margin: 100px auto 0;
        max-width: 900px;
      }
      .nuevo-trb{
        text-decoration: none;
        color: white;
      }

    .botonhamburguesa{
      position: relative;
      left: 02%;
    }
    </style>
  
</head>
<body >

    <?php

session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}


?>

 <?php include"componentes/nav.php" ?> 

 <!-- poner  border -->

 <div class="container py-3 bg-white" id="zonanombresombra" 
        style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;
              padding: 4%;
        ">

        <br>

    <div class="row mb-4">
      <div class="col col-sm-12 d-flex justify-content-start">
        <h5>Listado de Trabajadores</h5>
      </div>
    </div>

    <div class="row">
      <div class="col col-sm-12">
        <p>Filtrar Por:</p>
      </div>
    </div>

    <form id="form2" method="POST" action="inicio.php">
    <div class="row">
      <div class="col col-sm-4">
        <input class="form-control " id="inputtextdecoracion" type="text" placeholder="institucionbuscar" style="text-transform: uppercase;" value="<?php echo @$_POST['institucionbuscar'] ?>" >
      </div>
      <div class="col col-sm-4">
        
          
        <div class="input-group " name="tipo-ci">
            <select class="form-select">  
              <option value="v">V</option>
              <option value="e">E</option>  
              <option value="p">P</option>
            </select>
          <input type="text" name="cedulabuscar" id="cedulapersonabuscar" class="form-control" style="width: 70%" placeholder="Cédula" aria-label="Text input with dropdown button" value="<?php echo @$_POST['cedulabuscar'] ?>" >
        </div>
        <button class="btn btn-outline-info" type="submit" name="enviar" id="botonbuscar"> <b>Buscar</b> </button>
        
      </div>
      <?php 
      $conexion = mysqli_connect("localhost","root","","newbasesirce"); 
    
      $sql=mysqli_query($conexion, "SELECT * FROM persona WHERE Cedulapersona LIKE '%".@$_POST['cedulabuscar']."%' ");
      
      
      $numeroSql = mysqli_num_rows($sql);
      ?>
      

      <div class="col col-sm-4">
        <input class="form-control" type="text" style="text-transform: uppercase;" id="inputtextdecoracion" placeholder="Profesión">
      </div>
    </div>

<a class="btn btn-outline-info" href="inicio.php" id="botonlimpiar"> <b>Limpiar</b> </a>

<br>

    <table class="table table-hover" style="margin-top: 40px;">
  <thead>
    <tr>
      <th scope="col">Cedula</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellido</th>
      <th scope="col">Estado civil</th>
      <th scope="col"><img src="../icons/buscar.png" width="20px"></th>
    </tr>
  </thead>
  <tbody id="content">
    
    <?php 


    if (!empty($_POST['cedulabuscar'])) {
      // code...
   
    if ($sql -> num_rows > 0) {
      // code...
    

    while ($rowSql = mysqli_fetch_assoc($sql)) { ?>

      <tr>
        <td><?php echo $rowSql["CedulaPersona"]; ?></td>
        <td style="text-transform: uppercase;"><?php echo $rowSql["Nombres"]; ?></td>
        <td style="text-transform: uppercase;"><?php echo $rowSql["Apellidos"]; ?></td>
        <td style="text-transform: uppercase;"><?php echo $rowSql["estadocivil"]; ?></td>
        <td><a class="btn btn-outline-info" id="botonver" href="../vista/manejo-trabajador.php?id=<?php echo $rowSql['IdPersona'];  ?> ">ver</a></td>
      </tr>

    <?php }
  }else{

   ?>
        <tr>
        <td>no existe registro</td>

      </tr>
   <?php }  }else{
   ?>

           <tr>
        <td>no ha iniciado busqueda</td>

      </tr>
 <?php }
   ?>



  </tbody>

</form>
</table>
    
  </div>




  <script>

const campobuscar = document.getElementById('cedulapersonabuscar');

const campobuscarValue = campobuscar.value.trim();

  if (campobuscarValue === '') {
      console.log("campo vacio");
      //alert("El campo esta vacío");
  }else {
    console.log("campo lleno");
  }


    </script>

</body>
</html>