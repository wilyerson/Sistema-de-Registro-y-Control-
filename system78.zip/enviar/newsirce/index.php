<?php 

session_start();

if(isset($_SESSION['usuarioad']))
{
    header("Location: ../newsirce/vista/bienvenida.php");
}


?>


<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="index.css">
	
  <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="controlador/lottie.min.js"></script>
 <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.6.4/lottie_svg.min.js"></script>-->
  

	<style type="text/css">

        <style>

        @font-face{
  font-family: opensan;
  src: url(vista/fonts/googlesansnormal.woff2);

}

body{
  font-family: opensan;
}

#botoniniciarsession{

text-align: center;
  text-decoration: none;
  color: #fff;
  margin: auto;
  width: 208px;
  display: inline-block;
  line-height: 40px;
  font-size: 14px;
  font-weight: 500;
  letter-spacing: 2px;
  border-radius: 8px;
  text-transform: uppercase;
  background-color: #c70069;
  box-shadow: 0px 15px 18px -6px rgba(199, 0, 105, 0.65);
  transition: all 0.4s;
  
  cursor: pointer;
  border-style: none;
  border: none;
  padding: 8px 0px;
  position: relative;
  left: 17%;
  top: 7%;
  font-weight: 800;
  letter-spacing: 2px;
  text-transform: uppercase;
  outline: none;
}

#botoniniciarsession:hover {
  background-color: #c70069cc;
  box-shadow: 0px 22px 19px -8px rgba(199, 0, 105, 0.5);
  transform: scale(1.02, 1.02);
}
#botoniniciarsession:active {
  transition: all 0.4s -0.125s;
  background-color: #ab005a;
  box-shadow: 0px 12px 18px -4px rgba(199, 0, 105, 0.9);
  transform: scale(0.95, 0.95);
}


  #zonanombresombra{
    box-shadow: 0 0 80px 14px rgba(0,0,0,0.2), 0 0 80px -15px rgba(0,0,0,.2);
    /*box-shadow:0 0 70px -10px rgba(0,0,0,.3), 0 0 25px -15px rgba(0,0,0,.2);*/
    /*box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
   -moz-box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);*/
  }
		

		 .inputcedulaestilo{
        display: none;
      }

      .imagregistrodocumento{
        width: 100px;
      }

      .formu-control.success input {
  border-color: #2ecc71;
}

.formu-control.error input {
  border-color: #e74c3c;
}

.formu-control.success select {
  border-color: #2ecc71;
}

.formu-control.error select {
  border-color: #e74c3c;
}

.formu-control .fas {
  visibility: hidden;
  /*position: absolute;
  top: 40px;
  right: 10px;*/
}

.formu-control.success .fas.fa-check-circle {
  color: #2ecc71;
  visibility: visible;
}

.formu-control.error .fas.fa-exclamation-circle {
  color: #e74c3c;
  visibility: visible;
}

.formu-control small {
  color: #e74c3c;
  /*position: absolute;
  bottom: 0;
  left: 0;*/
  visibility: hidden;
}

.formu-control.error small {
  visibility: visible;
  
}

.modal-header{

border-bottom: none;

}

.modal-footer{

border-top: none;

}

#botonmodal{

text-align: center;
  text-decoration: none;
  color: #fff;
  margin: auto;
  width: 128px;
  display: inline-block;
  line-height: 40px;
  font-size: 14px;
  font-weight: 500;
  letter-spacing: 2px;
  border-radius: 8px;
  text-transform: uppercase;
  background-color: #0faec5;
  /*box-shadow: 0px 14px 11px -10px rgb(137 137 137 / 78%);*/
  /*box-shadow: 0px 15px 18px -6px rgba(199, 0, 105, 0.65);*/
  transition: all 0.4s;
  
  cursor: pointer;
  border-style: none;
  border: none;
  padding: 5px 0px;
  position: relative;
  left: 28%;
  top: 7%;
  font-weight: 800;
  letter-spacing: 2px;
  text-transform: uppercase;
  outline: none;

}

#botonmodal:hover {
  background-color: #18cde7;
  box-shadow: 0px 22px 19px -8px rgba(74, 111, 117, 1);
  transform: scale(1.02, 1.02);
}
#botonmodal:active {
  transition: all 0.4s -0.125s;
  background-color: #126a77;
  box-shadow: 0px 12px 18px -4px rgba(15, 108, 121, 1);
  transform: scale(0.95, 0.95);
}


	</style>
</head>
<body>

<div class="body">
	
	<div class="caja-sesion" id="zonanombresombra">


		<div class="logo-sistema">

		</div>


		<div class="caja-login" >
			<h2>Inicio de Sesión</h2>

			<div class="formulario-login">
				<form id="formulogine" method="post"  class="campos formu-control">

					<div class="formu-control">
						<input type="text"  placeholder="Usuario"  class="texto" style="text-transform: uppercase;" id="nombreusuario" name="nombreusuario">
					<small>Error message</small>
					</div>
					
					<div class="formu-control">
						<input type="password"  placeholder="contraseña"  class="texto" style="text-transform: uppercase;" id="passwordusuario" name="passwordusuario">
					<small>Error message</small>

          <input type="hidden" id="tiporoluser" name="tiporoluser">

					</div>
					
					
					<!--<button id="botoniniciarsession" type="submit" >Iniciar Sesión</button>-->
          <input id="botoniniciarsession" type="submit" name="" value="Iniciar Sesión">
				</form>
			</div>

			<p class="fotg-pass"></p>
		</div>


	</div>
</div>

      <div class="modal fade" id="modalregistrarrellenecampos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row" style="margin: -45px;">

                                        
                      <div class="col col-sm-6" style="margin: -40px 0px 15px 0px;">

                        <!--<img style="margin: auto; position: relative; left: 41%; top: 60%; width: 48px;" src="icons/iconsverificarcampos.svg">-->
                        <div style="width: 188px; position: relative; left: 8%; top: 27%;" id="iconrellenarcampos"></div>
                        
                        

                        <p style=" position: relative; left:74%; top: -20%; font-size: 20px;text-align: center;">Rellene todos los campos</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer" style="margin: 0px -42px 8px -48px;">
                    <button type="button" id="botonmodal"  data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

                  </div>
                </div>
              </div>
            </div>


          <div class="modal fade" id="modalusuarionoesta" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row" style="margin: -45px;">

                                        
                      <div class="col col-sm-6" style="margin: -40px 0px 15px 0px;">

                        <!--<img style="margin: auto; position: relative; left: 41%; top: 60%; width: 48px;" src="icons/notsearch.svg">-->
                       <div style="width: 188px; position: relative; left: 8%; top: 27%;" id="iconsanimationrellenecampos"></div>

                        <p style=" position: relative; left:74%; top: -20%; font-size: 20px;text-align: center;">Usuario no esta en sistema</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer" style="margin: 0px -42px 8px -48px;">
                    <button type="button" id="botonmodal"  data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

                  </div>
                </div>
              </div>
            </div>


             <div class="modal fade" id="modalusuariodesactivo" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <div class="modal-header">
                    <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                      
                    <div class="row">

                                        
                                            <div class="col col-sm-6" style="margin: -28px 0px 28px 0px;">

                        <img style="margin: auto; position: relative; left: 41%; top: 61%; width: 48px;" src="icons/offuser.png">

                        <p style=" position: relative; left:59%; top: 18%; font-size: 20px;text-align: center;">Esta usuario esta desactivado</p>
                      </div>

      
                     </div>

                  </div>
                  <div class="modal-footer" style="margin: 0px -42px 8px -48px;">
                    <button type="button" id="botonmodal"  data-bs-dismiss="modal">Cerrar</button>
                    <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

                  </div>
                </div>
              </div>
            </div>


 <script src="vista/jquery.min.js"></script>       
 <script src="controlador/login.js"></script>
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">



bodymovin.loadAnimation({

container: document.getElementById('iconsanimationrellenecampos'),

path: 'icons/notresult8888.json',

renderer: 'svg',

/*loop: true,

autoplay: true,

name: "Demo Animation",*/


});


bodymovin.loadAnimation({

container: document.getElementById('iconrellenarcampos'),

path: 'icons/verificarcampo.json',

renderer: 'svg',

/*loop: true,

autoplay: true,

name: "Demo Animation",*/


});  


</script>
</body>
</html>