<?php 

//include './controlador/controladorregistratrabajador.php';
$conn = mysqli_connect("localhost","root","","newbasesirce"); 
include('controladorregistratrabajador.php');

class Documentos
{

 
  public $Nombredocumento;
  public $fotodocumento;

  
 

 public function registrar($datosd){

  $conn = mysqli_connect("localhost","root","","newbasesirce"); 

//$this->imagen = $imagen;




    if(isset($datosd['1']) && $datosd['1'] != ""){
        $tipo = $_FILES['fotodocumento']['type'];
        $temp  = $_FILES['fotodocumento']['tmp_name'];

       if( !((strpos($tipo,'gif') || strpos($tipo,'jpeg') || strpos($tipo,'webp')))){
         // $_SESSION['mensaje'] = 'solo se permite archivos jpeg, gif, webp';
          
       }else{


        $query = "INSERT INTO archivos(IdPersona,CodigoDocumento) values('$ultimo_id','$ultimo_id')";

        $resultado = mysqli_query($conn,$query);

        if ($resultado == 1) {
            // code...
             $query = "INSERT INTO documento(NombreDocumento,fotodocumento) values('$datosd[0]','$datosd[1]')";


         $resultado2 = mysqli_query($conn,$query);
         if($resultado2 == 1){
              move_uploaded_file($temp,'imagenes/'.$datosd['1']);   

        }

        

             //$query = "INSERT INTO documento(Nombredocumento) values('$datosp[15]')";

            //resultado2 = mysqli_query($conn,$query);

            //modal de si desea registras mas documentos
              
              


         }else{
            // $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
             //$_SESSION['tipo'] = 'danger';
         }


       }
    }



  }


}
    //$Cedulapersonad = @$_POST['Cedulapersonad'];
    $Nombredocumento = @$_POST['Nombredocumento'];
    $imagen = @$_FILES['fotodocumento']['name'];

    
    
    $datosd = array($Nombredocumento, $imagen);


 $objetodocumentos = new Documentos();
 
 if (!($objetodocumentos->registrar($datosd))) {
   
   //header('location:../vista/ingreso.php');
    //@header('location:../vista/inicio.php');
 }else{ 
 
//echo "jodiste";

 }


?>