-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2023 at 07:14 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newbasesirce`
--

-- --------------------------------------------------------

--
-- Table structure for table `archivos`
--

CREATE TABLE `archivos` (
  `ArchivoRegistro` int(10) NOT NULL,
  `IdPersona` int(10) NOT NULL,
  `CodigoDocumento` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cargos`
--

CREATE TABLE `cargos` (
  `CodigoCargo` int(10) NOT NULL,
  `NombreCargo` varchar(40) NOT NULL,
  `TipoCargo` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `documento`
--

CREATE TABLE `documento` (
  `CodigoDocumento` int(10) NOT NULL,
  `NombreDocumento` varchar(20) NOT NULL,
  `fotodocumento` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `familiar`
--

CREATE TABLE `familiar` (
  `CodigoRegistroFamiliar` int(10) NOT NULL,
  `Trabajador` int(10) NOT NULL,
  `Familiar` int(10) NOT NULL,
  `Parentesco` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `historico`
--

CREATE TABLE `historico` (
  `CodigoHistorico` int(10) NOT NULL,
  `Trabajador` int(10) NOT NULL,
  `Cargo` int(10) NOT NULL,
  `FechaInicio` date NOT NULL,
  `FechaCulminacion` date NOT NULL,
  `Obervacion` varchar(120) NOT NULL,
  `InstitucionHistorico` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `instituciones`
--

CREATE TABLE `instituciones` (
  `CodigoInstituciones` int(11) NOT NULL,
  `NombreInstitucion` varchar(50) NOT NULL,
  `CodigoRegistro` varchar(50) NOT NULL,
  `Direccion` varchar(50) NOT NULL,
  `SectorInstitucion` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `municipio`
--

CREATE TABLE `municipio` (
  `CodigoMunicipio` int(10) NOT NULL,
  `NombreMunicipio` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `municipio`
--

INSERT INTO `municipio` (`CodigoMunicipio`, `NombreMunicipio`) VALUES
(1, '2');

-- --------------------------------------------------------

--
-- Table structure for table `parroquia`
--

CREATE TABLE `parroquia` (
  `CodigoParroquia` int(10) NOT NULL,
  `NombreParroquia` varchar(20) NOT NULL,
  `MunicipioParroquia` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parroquia`
--

INSERT INTO `parroquia` (`CodigoParroquia`, `NombreParroquia`, `MunicipioParroquia`) VALUES
(1, 'Tavera Acosta', 1);

-- --------------------------------------------------------

--
-- Table structure for table `persona`
--

CREATE TABLE `persona` (
  `CodigoPersona` int(10) NOT NULL,
  `CedulaPersona` varchar(10) NOT NULL,
  `IdPersona` int(10) NOT NULL,
  `Fotopersona` text NOT NULL,
  `Nombres` varchar(50) NOT NULL,
  `Apellidos` varchar(50) NOT NULL,
  `estadocivil` varchar(45) NOT NULL,
  `Fechanacimiento` date NOT NULL,
  `TelefonoPrincipal` varchar(20) NOT NULL,
  `TelefonoHabitacion` varchar(20) NOT NULL,
  `Peso` varchar(10) NOT NULL,
  `TallaCamisa` varchar(5) NOT NULL,
  `TallaPantalon` varchar(5) NOT NULL,
  `TallaCalzado` varchar(5) NOT NULL,
  `Sexo` varchar(10) NOT NULL,
  `Direccion` varchar(120) NOT NULL,
  `TipoPersona` varchar(20) NOT NULL,
  `Sector` int(10) NOT NULL,
  `Estatura` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `persona`
--

INSERT INTO `persona` (`CodigoPersona`, `CedulaPersona`, `IdPersona`, `Fotopersona`, `Nombres`, `Apellidos`, `estadocivil`, `Fechanacimiento`, `TelefonoPrincipal`, `TelefonoHabitacion`, `Peso`, `TallaCamisa`, `TallaPantalon`, `TallaCalzado`, `Sexo`, `Direccion`, `TipoPersona`, `Sector`, `Estatura`) VALUES
(27, '123122', 1, 'jaja.JPG', 'JAJAJA', 'perez', 'casado', '1995-04-04', '4444444', '44444', '4', '4', '4', '4', 'MASCULINO', 'direccion caiguire', '', 1, '4');

-- --------------------------------------------------------

--
-- Table structure for table `sector`
--

CREATE TABLE `sector` (
  `CodigoSector` int(10) NOT NULL,
  `NombreSector` varchar(20) NOT NULL,
  `ParroquiaSector` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sector`
--

INSERT INTO `sector` (`CodigoSector`, `NombreSector`, `ParroquiaSector`) VALUES
(1, 'sector caiguiere', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tipocargos`
--

CREATE TABLE `tipocargos` (
  `CodigoTipoCargo` int(10) NOT NULL,
  `NombreTipoCargo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `CodigoUsuario` int(10) NOT NULL,
  `IdPersona` int(10) NOT NULL,
  `NombreUsuario` int(20) NOT NULL,
  `ConstraseñaUsuario` int(20) NOT NULL,
  `RolUsuario` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `archivos`
--
ALTER TABLE `archivos`
  ADD PRIMARY KEY (`ArchivoRegistro`),
  ADD KEY `IdPersona` (`IdPersona`,`CodigoDocumento`),
  ADD KEY `CodigoDocumento` (`CodigoDocumento`);

--
-- Indexes for table `cargos`
--
ALTER TABLE `cargos`
  ADD PRIMARY KEY (`CodigoCargo`),
  ADD UNIQUE KEY `NombreCargo` (`NombreCargo`),
  ADD KEY `TipoCargo` (`TipoCargo`);

--
-- Indexes for table `documento`
--
ALTER TABLE `documento`
  ADD PRIMARY KEY (`CodigoDocumento`),
  ADD UNIQUE KEY `NombreDocumento` (`NombreDocumento`);

--
-- Indexes for table `familiar`
--
ALTER TABLE `familiar`
  ADD PRIMARY KEY (`CodigoRegistroFamiliar`),
  ADD KEY `Trabajador` (`Trabajador`,`Familiar`),
  ADD KEY `Familiar` (`Familiar`);

--
-- Indexes for table `historico`
--
ALTER TABLE `historico`
  ADD PRIMARY KEY (`CodigoHistorico`),
  ADD KEY `Trabajador` (`Trabajador`,`Cargo`,`InstitucionHistorico`),
  ADD KEY `Cargo` (`Cargo`),
  ADD KEY `InstitucionHistorico` (`InstitucionHistorico`);

--
-- Indexes for table `instituciones`
--
ALTER TABLE `instituciones`
  ADD PRIMARY KEY (`CodigoInstituciones`),
  ADD UNIQUE KEY `NombreInstitucion` (`NombreInstitucion`),
  ADD KEY `SectorInstitucion` (`SectorInstitucion`),
  ADD KEY `SectorInstitucion_2` (`SectorInstitucion`);

--
-- Indexes for table `municipio`
--
ALTER TABLE `municipio`
  ADD PRIMARY KEY (`CodigoMunicipio`),
  ADD UNIQUE KEY `CodigoEstado` (`NombreMunicipio`),
  ADD KEY `NombreMunicipio` (`NombreMunicipio`);

--
-- Indexes for table `parroquia`
--
ALTER TABLE `parroquia`
  ADD PRIMARY KEY (`CodigoParroquia`),
  ADD UNIQUE KEY `NombreParroquia` (`NombreParroquia`),
  ADD KEY `MunicipioParroquia` (`MunicipioParroquia`);

--
-- Indexes for table `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`CodigoPersona`),
  ADD UNIQUE KEY `CedulaPersona` (`CedulaPersona`),
  ADD UNIQUE KEY `IdPersona` (`IdPersona`),
  ADD KEY `Sector` (`Sector`);

--
-- Indexes for table `sector`
--
ALTER TABLE `sector`
  ADD PRIMARY KEY (`CodigoSector`),
  ADD KEY `ParroquiaSector` (`ParroquiaSector`);

--
-- Indexes for table `tipocargos`
--
ALTER TABLE `tipocargos`
  ADD PRIMARY KEY (`CodigoTipoCargo`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`CodigoUsuario`),
  ADD UNIQUE KEY `IdPersona` (`IdPersona`,`NombreUsuario`),
  ADD KEY `IdPersona_2` (`IdPersona`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `archivos`
--
ALTER TABLE `archivos`
  MODIFY `ArchivoRegistro` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cargos`
--
ALTER TABLE `cargos`
  MODIFY `CodigoCargo` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `documento`
--
ALTER TABLE `documento`
  MODIFY `CodigoDocumento` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `familiar`
--
ALTER TABLE `familiar`
  MODIFY `CodigoRegistroFamiliar` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `historico`
--
ALTER TABLE `historico`
  MODIFY `CodigoHistorico` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `instituciones`
--
ALTER TABLE `instituciones`
  MODIFY `CodigoInstituciones` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `municipio`
--
ALTER TABLE `municipio`
  MODIFY `CodigoMunicipio` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `parroquia`
--
ALTER TABLE `parroquia`
  MODIFY `CodigoParroquia` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `persona`
--
ALTER TABLE `persona`
  MODIFY `CodigoPersona` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `sector`
--
ALTER TABLE `sector`
  MODIFY `CodigoSector` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tipocargos`
--
ALTER TABLE `tipocargos`
  MODIFY `CodigoTipoCargo` int(10) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `archivos`
--
ALTER TABLE `archivos`
  ADD CONSTRAINT `archivos_ibfk_1` FOREIGN KEY (`CodigoDocumento`) REFERENCES `documento` (`CodigoDocumento`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `archivos_ibfk_2` FOREIGN KEY (`IdPersona`) REFERENCES `persona` (`IdPersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cargos`
--
ALTER TABLE `cargos`
  ADD CONSTRAINT `cargos_ibfk_1` FOREIGN KEY (`TipoCargo`) REFERENCES `tipocargos` (`CodigoTipoCargo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `familiar`
--
ALTER TABLE `familiar`
  ADD CONSTRAINT `familiar_ibfk_1` FOREIGN KEY (`Trabajador`) REFERENCES `persona` (`IdPersona`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `familiar_ibfk_2` FOREIGN KEY (`Familiar`) REFERENCES `persona` (`IdPersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `historico`
--
ALTER TABLE `historico`
  ADD CONSTRAINT `historico_ibfk_1` FOREIGN KEY (`Trabajador`) REFERENCES `persona` (`IdPersona`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `historico_ibfk_2` FOREIGN KEY (`Cargo`) REFERENCES `cargos` (`CodigoCargo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `historico_ibfk_3` FOREIGN KEY (`InstitucionHistorico`) REFERENCES `instituciones` (`CodigoInstituciones`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `instituciones`
--
ALTER TABLE `instituciones`
  ADD CONSTRAINT `instituciones_ibfk_1` FOREIGN KEY (`SectorInstitucion`) REFERENCES `sector` (`CodigoSector`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `parroquia`
--
ALTER TABLE `parroquia`
  ADD CONSTRAINT `parroquia_ibfk_1` FOREIGN KEY (`MunicipioParroquia`) REFERENCES `municipio` (`CodigoMunicipio`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`Sector`) REFERENCES `sector` (`CodigoSector`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sector`
--
ALTER TABLE `sector`
  ADD CONSTRAINT `sector_ibfk_1` FOREIGN KEY (`ParroquiaSector`) REFERENCES `parroquia` (`CodigoParroquia`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`IdPersona`) REFERENCES `persona` (`IdPersona`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
