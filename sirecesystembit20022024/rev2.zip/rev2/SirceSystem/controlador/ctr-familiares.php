<?php
require_once "../config/dbconexion.php";
require_once "../modelo/ModeloFamiliares.php";

session_start();

$familiar = new Familiar();

switch ($_GET["op"]) {

    case 'listar':
        $result_set = $familiar->get_documentos(); // devuelve un conjunto de arreglos, cada arreglo es una fila de la tabla de la db
        $data = array();
        //if (count($result_set) > 0) {
        foreach ($result_set as $row) {
            array_push($data, array("ArchivoRegistro" => $row['ArchivoRegistro'], "CodigoDocumento" => $row['CodigoDocumento'], "idperarchivos" => $row['idperarchivos'], "archivosjpg" => $row['archivosjpg']));
        }
        echo json_encode($data); //formateado como json
        break;

    case 'guardar':
        $cedulafamiliar = $_POST['cedulafamiliar'];
        $regpartidafamiliar = @$_POST['regpartidafamiliar'];
        $parentescofamiliar = $_POST['parentescofamiliar'];
        $nombresfamiliar = $_POST['nombresfamiliar'];
        $apellidosfamiliar = $_POST['apellidosfamiliar'];
        $sexofamiliar = $_POST['sexofamiliar'];
        $fechanacfamiliar = $_POST['fechanacfamiliar'];
        $numtelefonofamiliar = $_POST['numtelefonofamiliar'];
        $numtelefono2familiar = $_POST['numtelefono2familiar'];
        $id_parrfamiliar = $_POST['id_parrfamiliar'];
        $sectorfamiliar = $_POST['sectorfamiliar'];
        $direccionfamiliar = $_POST['direccionfamiliar'];
        $pesofamiliar = $_POST['pesofamiliar'];
        $estaturafamiliar = $_POST['estaturafamiliar'];
        $tallacamisafamiliar = $_POST['tallacamisafamiliar'];
        $tallapantfamiliar = $_POST['tallapantfamiliar'];
        $tallacalzafamiliar = $_POST['tallacalzafamiliar'];
        $tipopersonafamiliar = $_POST['tipopersonafamiliar'];
        $estatusfamiliar = $_POST['estatusfamiliar'];
        $idpersonafamiliar = $_POST['idpersonafamiliar'];
        $idusuario = $_SESSION['iduser'];

        $insercion = $familiar->insert_familiar($cedulafamiliar, $regpartidafamiliar, $parentescofamiliar, $nombresfamiliar, $apellidosfamiliar, $sexofamiliar, $fechanacfamiliar, $numtelefonofamiliar, $numtelefono2familiar, $id_parrfamiliar, $sectorfamiliar, $direccionfamiliar, $pesofamiliar, $estaturafamiliar, $tallacamisafamiliar, $tallapantfamiliar, $tallacalzafamiliar, $tipopersonafamiliar, $estatusfamiliar, $idpersonafamiliar, $idusuario);
        echo json_encode($insercion);
        break;

    case 'editar':
        $idperfami = $_POST['idperfamilia'];
        $ejecutar = $familiar->get_familiar($idperfami);
        echo json_encode($ejecutar);
        break;

    case 'update':
        $cedulafamiliar = $_POST['cedulafamiliareditar'];
        $regpartidafamiliar = @$_POST['regpartidafamiliareditar'];
        $parentescofamiliar = $_POST['parentescofamiliareditar'];
        $nombresfamiliar = $_POST['nombresfamiliareditar'];
        $apellidosfamiliar = $_POST['apellidosfamiliareditar'];
        $sexofamiliar = $_POST['sexofamiliareditar'];
        $fechanacfamiliar = $_POST['fechanacfamiliareditar'];
        $numtelefonofamiliar = $_POST['numtelefonofamiliareditar'];
        $numtelefono2familiar = $_POST['numtelefono2familiareditar'];
        $id_parrfamiliar = $_POST['id_parrfamiliar'];
        $sectorfamiliar = $_POST['sectorfamiliareditar'];
        $direccionfamiliar = $_POST['direccionfamiliareditar'];
        $pesofamiliar = $_POST['pesofamiliareditar'];
        $estaturafamiliar = $_POST['estaturafamiliareditar'];
        $tallacamisafamiliar = $_POST['tallacamisafamiliareditar'];
        $tallapantfamiliar = $_POST['tallapantfamiliareditar'];
        $tallacalzafamiliar = $_POST['tallacalzafamiliareditar'];
        $tipopersonafamiliar = $_POST['tipopersonafamiliar'];
        $estatusfamiliar = $_POST['estatusfamiliareditar'];
        $idpersonafamiliar = $_POST['idpersonafamiliareditar'];
        $idusuario = $_SESSION['iduser'];
        $actualizacion = $familiar->update_documento($codinstimod, $nombreinstimod, $codigoregintimod, $parroquiarinstimod, $sectorinstimod, $direccioninstimod);
        echo json_encode($actualizacion);
        break;

    case 'editarmodalfamiliar':
        $codfamiliar = $_POST['codfamiliar'];
        $ejecutar = $familiar->get_editarmodalfamiliar($codfamiliar);
        echo json_encode($ejecutar);
        break;

    case 'verificarcedula':
        $CedulaPersona = $_POST['cedulafamiliar'];
        $existe = $familiar->verificar_cedula($CedulaPersona);
        echo json_encode(array("existe" => $existe));
        break;

    case 'check_cedula':
        $CedulaPersona = $_POST['cedula'];
        $CedulaOriginal = $_POST['cedula_original'];
        $existe = $familiar->check_cedula($CedulaPersona, $CedulaOriginal);
        if ($existe) {
            echo json_encode(array("estado" => "error_cedula_existente"));
        } else {
            echo json_encode(array("estado" => "success"));
        }
        break;  



        
    default:
        # code...
        break;
}
