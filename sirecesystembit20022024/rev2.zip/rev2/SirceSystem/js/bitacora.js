document.addEventListener('DOMContentLoaded', (event) => {
  let nameuser = document.getElementById('iduser').value;
  localStorage.setItem("nameusuario", nameuser);
});

jQuery(document).on('submit','#formumismovimientos', function(event){
	event.preventDefault();

	
	let nameuserr = localStorage.getItem("nameusuario");
	//console.log(cedulauser);

	document.getElementById("nameuser").value = nameuserr;

		function selectfiltrobitacora() {
    var select = document.getElementById("selectfilterbitacora");
    var selectedValue = select.options[select.selectedIndex].value;
    console.log("Has seleccionado: " + selectedValue);
    // Aquí puedes agregar más código para manejar la selección
}




	console.log(nameuserr);
jQuery.ajax({
	url: '../controlador/bitacora.php',
	type: 'POST',
	dataType: 'json',
	data: $(this).serialize(),
	beforeSend: function () {
		// body...

	}
})
.done(function (respuesta) {
	// body...
	console.log(respuesta);

	document.getElementById("divmismovimientos").style.display="block";

	//let selectregistro = document.getElementById("selectfilterbitacora").value = "Registro";
	//console.log(selectregistro);

	

	let selectmodificar = document.getElementById("selectfilterbitacora").value;
	let mostrarregistrobitacora = respuesta.filter(respuesta => respuesta.ActividadRealizada == 'Se Registro nueva Persona');
	let mostrarmodificacionesbitacora = respuesta.filter(respuesta => respuesta.ActividadRealizada == 'Se Modifico una Persona');

	let tbody = document.querySelector("#mismovimientos");

	tbody.innerHTML = "";
	if (respuesta.length > 0) {
		for (let registro of respuesta) {
			tbody.innerHTML += `
         <tr>
         <th class="text-center">${registro.CodigoBitacora}</th>
         <td class="text-center">${registro.CodigoPersona}</td>
         <td class="text-center">${registro.Fecha}</td>
         <td class="text-center">${registro.ActividadRealizada}</td>
         <td class="text-center">${registro.InformacionActual}</td>
         </tr>
         `;
		}
	} else {
		tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.</th>
            </td>
            </tr>
            `;
	}

 	var selecthtml = $("#selectfilterbitacora option:selected" ).text();
    $('#selectfilterbitacora').on('change', function() {
      selecthtml = $("#selectfilterbitacora option:selected" ).text();
      if (selecthtml == "Registro") {
      //	console.log("todos los registro");


tbody.innerHTML = "";
	if (mostrarregistrobitacora.length > 0) {
		for (let registro of mostrarregistrobitacora) {
			tbody.innerHTML += `
         <tr>
         <th class="text-center">${registro.CodigoBitacora}</th>
         <td class="text-center">${registro.CodigoPersona}</td>
         <td class="text-center">${registro.Fecha}</td>
         <td class="text-center">${registro.ActividadRealizada}</td>
         <td class="text-center">${registro.InformacionActual}</td>
         </tr>
         `;
		}
	} else {
		tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.</th>
            </td>
            </tr>
            `;
	}

      }// termina el if registro

       if (selecthtml == "Modificacion") {
      	//console.log("todos los registro");


tbody.innerHTML = "";
	if (mostrarmodificacionesbitacora.length > 0) {
		for (let registro of mostrarmodificacionesbitacora) {
			tbody.innerHTML += `
         <tr>
         <th class="text-center">${registro.CodigoBitacora}</th>
         <td class="text-center">${registro.CodigoPersona}</td>
         <td class="text-center">${registro.Fecha}</td>
         <td class="text-center">${registro.ActividadRealizada}</td>
         <td class="text-center">${registro.InformacionActual}</td>
         </tr>
         `;
		}
	} else {
		tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.</th>
            </td>
            </tr>
            `;
	}

      }// termina el if modificar

       if (selecthtml == "Todos") {
      	//console.log("todos los registro");


tbody.innerHTML = "";
	if (respuesta.length > 0) {
		for (let registro of respuesta) {
			tbody.innerHTML += `
         <tr>
         <th class="text-center">${registro.CodigoBitacora}</th>
         <td class="text-center">${registro.CodigoPersona}</td>
         <td class="text-center">${registro.Fecha}</td>
         <td class="text-center">${registro.ActividadRealizada}</td>
         <td class="text-center">${registro.InformacionActual}</td>
         </tr>
         `;
		}
	} else {
		tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.</th>
            </td>
            </tr>
            `;
	}

      }// termina el if todos



      //console.log(selecthtml);
	 })//fin del oncharge



//////////////////////------------------buscardor-----------------------------///////////////////////////////

$('#buscardatobitacora').focus()

  $('#buscardatobitacora').on('keyup', function(){
    let search = $('#buscardatobitacora').val()

    let buscardatosbitacora = respuesta.filter(respuesta => {
  let valores = Object.values(respuesta).join(" ").toLowerCase();
  return valores.includes(search);
});
    //console.log(buscaridbitacora);

    if (search == "") {

    	tbody.innerHTML = "";
	if (respuesta.length > 0) {
		for (let registro of respuesta) {
			tbody.innerHTML += `
         <tr>
         <th class="text-center">${registro.CodigoBitacora}</th>
         <td class="text-center">${registro.CodigoPersona}</td>
         <td class="text-center">${registro.Fecha}</td>
         <td class="text-center">${registro.ActividadRealizada}</td>
         <td class="text-center">${registro.InformacionActual}</td>
         </tr>
         `;
		}
	} else {
		tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.</th>
            </td>
            </tr>
            `;
	}

    }else{

    	tbody.innerHTML = "";
	if (buscardatosbitacora.length > 0) {
for (let registro of buscardatosbitacora) {
  tbody.innerHTML += `
    <tr>
      <th>${registro.CodigoBitacora}</th>
      <td>${registro.CodigoPersona}</td>
      <td>${registro.Fecha}</td>
      <td>${registro.ActividadRealizada}</td>
      <td>${registro.InformacionActual}</td>
      </tr>
  `;
}
	} else {
		tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros de movimientos.</th>
            </td>
            </tr>
            `;
	}

    }

    //console.log(search);
  })//fin buscar idbitacora



///////////////////---------------------finbuscador----------------------------/////////////////////////////////    


	//let approved = respuesta.filter(respuesta => respuesta.actividadrealizada == 'Se Actualizo una Persona');
	//console.log(approved);

	//let tbody = document.querySelector("#mismovimientos");
	


//$('#modaloffuser').modal("show");

	



})
.fail(function (resp) {
	// body...
	//console.log(resp.responseText);
	
	
})
.always(function () {
	// body...
	console.log("complete");
});



});



