<?php 

const SERVER="localhost";
const DB="sirceop";
const USER="root";
const PASS="";
const UTF8="utf8";

const SGBD="mysql:host=".SERVER.";dbname=".DB.";charset=".UTF8;

class dbconexion
{
    protected function conexion()
    {
        try {
            $con = new PDO(SGBD, USER, PASS);
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $con;
        } catch (PDOException $e) {
            echo "Conexion Fallida: " . $e->getMessage();
        }
    }

    public function getConexion() {
        return $this->conexion();
    }
}

$db = new dbconexion();
$conexion = $db->getConexion();
$sql = "SELECT * FROM bitacora WHERE idUsuario = :nameuser";
$stmt = $conexion->prepare($sql);
$stmt->execute(['nameuser' => @$_POST['nameuser']]);
$datosh = $stmt->fetchAll();

if(!empty($datosh)){
    echo json_encode($datosh);
}else{
    echo json_encode([]);
}

?>