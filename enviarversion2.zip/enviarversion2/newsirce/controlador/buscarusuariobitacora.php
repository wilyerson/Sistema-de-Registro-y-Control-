<?php 

//$conn = mysqli_connect("localhost","root","","newsirce"); 


function conexion(){
    return mysqli_connect("localhost","root","","newsirce"); 
}


$conexion = conexion();
$sql = "SELECT * FROM usuarios WHERE nombreusuario = '".@$_POST['buscarusuariobitacora']."' ";
$resultado = mysqli_query($conexion,$sql);
$datosh = mysqli_fetch_all($resultado,MYSQLI_ASSOC);

if(!empty($datosh)){
    
    echo json_encode($datosh);
}else{
    echo json_encode([]);
}



?>