<?php 

//$conn = mysqli_connect("localhost","root","","newsirce"); 


function conexion(){
    return mysqli_connect("localhost","root","","newsirce"); 
}


$conexion = conexion();
$sql = "SELECT CodigoPersona,checkcedufami,parentesco,cedulafam,nombrefam,apellidofam,fechanacimientofam,sexofam,estadocivilfam,telefonoprincipalfam,telefonohabitacionfam,direccionfam,pesofam,estaturafam,tallacamisafam,tallapantalonfam,tallacalzadofam FROM familia";
$resultado = mysqli_query($conexion,$sql);
$datosfe = mysqli_fetch_all($resultado,MYSQLI_ASSOC);

if(!empty($datosfe)){
    echo json_encode($datosfe);
}else{
    echo json_encode([]);
}



?>