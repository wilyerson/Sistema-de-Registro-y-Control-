<?php 

	require_once "ModeloConeccion.php";

	class Instituciones {

		private $nombre_institucion;
		private $codigo_registro;
		public $municipio_institucion;
		public $parroquia_institucion;
		public $sector_institucion;
		public $direccion_institucion;


		public function __construct(){


		}


		function registrar_institucion($nombre_institucion, $codigo_registro, $municipio_institucion, 
										$parroquia_institucion, $sector_institucion, $direccion_institucion)
		{

			$sql = "SELECT * FROM instituciones WHERE 	NombreInstitucion = $nombre_institucion  OR 
														CodigoRegistro = $codigo_registro";


		}

		function consultar_codigoynombre($nombre_institucion, $codigo_registro){

			$sql = "SELECT * FROM instituciones WHERE NombreInstitucion = $nombre_institucion OR $codigo"

		}

		function modificar_institucion($nombre_institucion, $codigo_registro, $municipio_institucion, 
										$parroquia_institucion, $sector_institucion, $direccion_institucion)
		{

			

		}

		function eliminar_institucion($nombre_institucion, $codigo_registro, $municipio_institucion, 
										$parroquia_institucion, $sector_institucion, $direccion_institucion)
		{

			

		}

		function mostrar_institucion($nombre_institucion, $codigo_registro, $municipio_institucion, 
										$parroquia_institucion, $sector_institucion, $direccion_institucion)
		{

			

		}

	}

 ?>