-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-01-2024 a las 20:19:04
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sirceop`
--

CREATE DATABASE sirceop;
USE sirceop;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `archivos`
--

CREATE TABLE `archivos` (
  `ArchivoRegistro` int(10) NOT NULL,
  `CodigoDocumento` int(10) NOT NULL,
  `idperarchivos` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargos`
--

CREATE TABLE `cargos` (
  `CodigoCargo` int(10) NOT NULL,
  `NombreCargo` varchar(40) NOT NULL,
  `TipoCargo` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documento`
--

CREATE TABLE `documento` (
  `CodigoDocumento` int(10) NOT NULL,
  `NombreDocumento` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `familiar`
--

CREATE TABLE `familiar` (
  `CodigoRegistroFamiliar` int(10) NOT NULL,
  `Trabajador` int(10) NOT NULL,
  `Familiar` int(10) NOT NULL,
  `Parentesco` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historico`
--

CREATE TABLE `historico` (
  `CodigoHistorico` int(10) NOT NULL,
  `Cargo` int(10) NOT NULL,
  `FechaInicio` date NOT NULL,
  `FechaCulminacion` date NOT NULL,
  `Obervacion` varchar(120) NOT NULL,
  `InstitucionHistorico` int(10) NOT NULL,
  `trabajador` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `instituciones`
--

CREATE TABLE `instituciones` (
  `CodigoInstituciones` int(10) NOT NULL,
  `NombreInstitucion` varchar(50) NOT NULL,
  `CodigoRegistro` varchar(50) NOT NULL,
  `Direccion` varchar(50) NOT NULL,
  `ParroquiaInstitucion` int(10) NOT NULL,
  `MunicipioInstitucion` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `instituciones`
--

INSERT INTO `instituciones` (`CodigoInstituciones`, `NombreInstitucion`, `CodigoRegistro`, `Direccion`, `ParroquiaInstitucion`, `MunicipioInstitucion`) VALUES
(1, 'La Inmaculada', 'C126', 'Avenida Carupano', 9, 9),
(2, 'La Inmaculada 2', 'C1223', 'Avenida Carupano2', 41, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipio`
--

CREATE TABLE `municipio` (
  `CodigoMunicipio` int(10) NOT NULL,
  `NombreMunicipio` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `municipio`
--

INSERT INTO `municipio` (`CodigoMunicipio`, `NombreMunicipio`) VALUES
(1, 'Andrés Eloy Blanco'),
(2, 'Andrés Mata'),
(3, 'Arismendi'),
(4, 'Benítez'),
(5, 'Bermúdez'),
(6, 'Bolívar'),
(7, 'Cajigal'),
(8, 'Cruz Salmerón Acosta'),
(9, 'Libertador'),
(10, 'Mariño'),
(11, 'Mejía'),
(12, 'Montes'),
(13, 'Ribero'),
(14, 'Sucre'),
(15, 'Valdez');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parroquia`
--

CREATE TABLE `parroquia` (
  `CodigoParroquia` int(10) NOT NULL,
  `NombreParroquia` varchar(50) NOT NULL,
  `MunicipioParroquia` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `parroquia`
--

INSERT INTO `parroquia` (`CodigoParroquia`, `NombreParroquia`, `MunicipioParroquia`) VALUES
(1, 'Mariño', 1),
(2, 'Rómulo Gallegos', 1),
(3, 'San José de Areocuar', 2),
(4, 'Tavera Acosta', 2),
(5, 'Río Caribe', 3),
(6, 'Antonio José de Sucre', 3),
(7, 'El Morro de Puerto Santo', 3),
(8, 'Puerto Santo', 3),
(9, 'San Juan de las Galdonas', 3),
(10, 'El Pilar', 4),
(11, 'El Rincón', 4),
(12, 'General Francisco Antonio Vázquez', 4),
(13, 'Guaraúnos', 4),
(14, 'Tunapuicito', 4),
(15, 'Unión', 4),
(16, 'Santa Catalina', 5),
(17, 'Santa Rosa', 5),
(18, 'Santa Teresa', 5),
(19, 'Bolívar', 5),
(20, 'Maracapana', 5),
(21, 'Divina Misericordia', 5),
(22, 'Nuestra Señora De Lourdes', 5),
(23, 'Marigüitar', 6),
(24, 'Libertad', 7),
(25, 'El Paujil', 7),
(26, 'Yaguaraparo', 7),
(27, 'Araya', 8),
(28, 'Chacopata', 8),
(29, 'Manicuare', 8),
(30, 'Tunapuy', 9),
(31, 'Campo Elías', 9),
(32, 'Irapa', 10),
(33, 'Campo Claro', 10),
(34, 'Marabal', 10),
(35, 'San Antonio de Irapa', 10),
(36, 'Soro', 10),
(37, 'San Antonio del Golfo', 11),
(38, 'Cumanacoa', 12),
(39, 'Arenas', 12),
(40, 'Aricagua', 12),
(41, 'Cocollar', 12),
(42, 'San Fernando', 12),
(43, 'San Lorenzo', 12),
(44, 'Cariaco', 13),
(45, 'Catuaro', 13),
(46, 'Rendón', 13),
(47, 'Santa Cruz', 13),
(48, 'Santa María', 13),
(49, 'Altagracia', 14),
(50, 'Santa Inés', 14),
(51, 'Valentín Valiente', 14),
(52, 'Ayacucho', 14),
(53, 'San Juan', 14),
(54, 'Raúl Leoni', 14),
(55, 'Gran Mariscal', 14),
(56, 'Cristóbal Colón', 15),
(57, 'Bideau', 15),
(58, 'Punta de Piedras', 15),
(59, 'Güiria', 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `CodigoPersona` int(10) NOT NULL,
  `CedulaPersona` varchar(10) NOT NULL,
  `Nombres` varchar(50) NOT NULL,
  `Apellidos` varchar(50) NOT NULL,
  `Sexo` varchar(10) NOT NULL,
  `ParroquiaPersona` int(10) NOT NULL,
  `Sector` varchar(50) NOT NULL,
  `Direccion` varchar(120) NOT NULL,
  `TelefonoPrincipal` varchar(20) NOT NULL,
  `TelefonoHabitacion` varchar(20) NOT NULL,
  `Peso` varchar(10) NOT NULL,
  `Estatura` varchar(10) NOT NULL,
  `TallaCamisa` varchar(5) NOT NULL,
  `TallaPantalon` varchar(5) NOT NULL,
  `TallaCalzado` varchar(5) NOT NULL,
  `TipoPersona` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`CodigoPersona`, `CedulaPersona`, `Nombres`, `Apellidos`, `Sexo`, `ParroquiaPersona`, `Sector`, `Direccion`, `TelefonoPrincipal`, `TelefonoHabitacion`, `Peso`, `Estatura`, `TallaCamisa`, `TallaPantalon`, `TallaCalzado`, `TipoPersona`) VALUES
(1, '26293417', 'Endys Leonel', 'Rodriguez Rodriguez', 'Masculino', 51, 'Valentin Valiente', 'Urbanizacion Salvador allende, Torre 13, Piso 4, Apto n20', '04126949323', '04126949323', '74', '190', 'xl', '36', '44', 'trabajador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipocargos`
--

CREATE TABLE `tipocargos` (
  `CodigoTipoCargo` int(10) NOT NULL,
  `NombreTipoCargo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `CodigoUsuario` int(10) NOT NULL,
  `CodigoPersona` int(10) NOT NULL,
  `NombreUsuario` varchar(20) NOT NULL,
  `ConstraseñaUsuario` varchar(20) NOT NULL,
  `RolUsuario` varchar(20) NOT NULL,
  `EstatusUsuario` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`CodigoUsuario`, `CodigoPersona`, `NombreUsuario`, `ConstraseñaUsuario`, `RolUsuario`, `EstatusUsuario`) VALUES
(1, 1, 'APOLOENDYS', 'OROGZ.123*', 'administrador', 'usuarioactivo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `archivos`
--
ALTER TABLE `archivos`
  ADD PRIMARY KEY (`ArchivoRegistro`),
  ADD KEY `CodigoDocumento` (`CodigoDocumento`),
  ADD KEY `idperarchivos` (`idperarchivos`);

--
-- Indices de la tabla `cargos`
--
ALTER TABLE `cargos`
  ADD PRIMARY KEY (`CodigoCargo`),
  ADD UNIQUE KEY `NombreCargo` (`NombreCargo`),
  ADD KEY `TipoCargo` (`TipoCargo`);

--
-- Indices de la tabla `documento`
--
ALTER TABLE `documento`
  ADD PRIMARY KEY (`CodigoDocumento`),
  ADD UNIQUE KEY `NombreDocumento` (`NombreDocumento`);

--
-- Indices de la tabla `familiar`
--
ALTER TABLE `familiar`
  ADD PRIMARY KEY (`CodigoRegistroFamiliar`),
  ADD KEY `Trabajador` (`Trabajador`,`Familiar`),
  ADD KEY `familiar_ibfk_2` (`Familiar`);

--
-- Indices de la tabla `historico`
--
ALTER TABLE `historico`
  ADD PRIMARY KEY (`CodigoHistorico`),
  ADD KEY `Trabajador` (`Cargo`,`InstitucionHistorico`),
  ADD KEY `InstitucionHistorico` (`InstitucionHistorico`),
  ADD KEY `trabajador_2` (`trabajador`);

--
-- Indices de la tabla `instituciones`
--
ALTER TABLE `instituciones`
  ADD PRIMARY KEY (`CodigoInstituciones`),
  ADD UNIQUE KEY `NombreInstitucion` (`NombreInstitucion`),
  ADD KEY `ParroquiaInstitucion` (`ParroquiaInstitucion`),
  ADD KEY `MunicipioInstitucion` (`MunicipioInstitucion`);

--
-- Indices de la tabla `municipio`
--
ALTER TABLE `municipio`
  ADD PRIMARY KEY (`CodigoMunicipio`),
  ADD UNIQUE KEY `CodigoEstado` (`NombreMunicipio`),
  ADD KEY `NombreMunicipio` (`NombreMunicipio`);

--
-- Indices de la tabla `parroquia`
--
ALTER TABLE `parroquia`
  ADD PRIMARY KEY (`CodigoParroquia`),
  ADD UNIQUE KEY `NombreParroquia` (`NombreParroquia`),
  ADD KEY `MunicipioParroquia` (`MunicipioParroquia`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`CodigoPersona`),
  ADD UNIQUE KEY `CedulaPersona` (`CedulaPersona`),
  ADD KEY `ParroquiaPersona` (`ParroquiaPersona`);

--
-- Indices de la tabla `tipocargos`
--
ALTER TABLE `tipocargos`
  ADD PRIMARY KEY (`CodigoTipoCargo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`CodigoUsuario`),
  ADD UNIQUE KEY `IdPersona` (`CodigoPersona`,`NombreUsuario`),
  ADD KEY `IdPersona_2` (`CodigoPersona`),
  ADD KEY `codigopersona` (`CodigoPersona`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `archivos`
--
ALTER TABLE `archivos`
  MODIFY `ArchivoRegistro` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cargos`
--
ALTER TABLE `cargos`
  MODIFY `CodigoCargo` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `documento`
--
ALTER TABLE `documento`
  MODIFY `CodigoDocumento` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `familiar`
--
ALTER TABLE `familiar`
  MODIFY `CodigoRegistroFamiliar` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `historico`
--
ALTER TABLE `historico`
  MODIFY `CodigoHistorico` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `instituciones`
--
ALTER TABLE `instituciones`
  MODIFY `CodigoInstituciones` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `municipio`
--
ALTER TABLE `municipio`
  MODIFY `CodigoMunicipio` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `parroquia`
--
ALTER TABLE `parroquia`
  MODIFY `CodigoParroquia` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT de la tabla `persona`
--
ALTER TABLE `persona`
  MODIFY `CodigoPersona` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `tipocargos`
--
ALTER TABLE `tipocargos`
  MODIFY `CodigoTipoCargo` int(10) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `archivos`
--
ALTER TABLE `archivos`
  ADD CONSTRAINT `archivos_ibfk_1` FOREIGN KEY (`CodigoDocumento`) REFERENCES `documento` (`CodigoDocumento`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `archivos_ibfk_2` FOREIGN KEY (`idperarchivos`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `cargos`
--
ALTER TABLE `cargos`
  ADD CONSTRAINT `cargos_ibfk_1` FOREIGN KEY (`TipoCargo`) REFERENCES `tipocargos` (`CodigoTipoCargo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `familiar`
--
ALTER TABLE `familiar`
  ADD CONSTRAINT `familiar_ibfk_1` FOREIGN KEY (`Trabajador`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `familiar_ibfk_2` FOREIGN KEY (`Familiar`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `historico`
--
ALTER TABLE `historico`
  ADD CONSTRAINT `historico_ibfk_2` FOREIGN KEY (`Cargo`) REFERENCES `cargos` (`CodigoCargo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `historico_ibfk_3` FOREIGN KEY (`InstitucionHistorico`) REFERENCES `instituciones` (`CodigoInstituciones`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `historico_ibfk_4` FOREIGN KEY (`trabajador`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `instituciones`
--
ALTER TABLE `instituciones`
  ADD CONSTRAINT `instituciones_ibfk_1` FOREIGN KEY (`ParroquiaInstitucion`) REFERENCES `parroquia` (`CodigoParroquia`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `instituciones_ibfk_2` FOREIGN KEY (`MunicipioInstitucion`) REFERENCES `municipio` (`CodigoMunicipio`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `parroquia`
--
ALTER TABLE `parroquia`
  ADD CONSTRAINT `parroquia_ibfk_1` FOREIGN KEY (`MunicipioParroquia`) REFERENCES `municipio` (`CodigoMunicipio`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `persona_ibfk_1` FOREIGN KEY (`ParroquiaPersona`) REFERENCES `parroquia` (`CodigoParroquia`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`codigopersona`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`CodigoPersona`) REFERENCES `persona` (`CodigoPersona`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
