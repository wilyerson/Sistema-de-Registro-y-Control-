jQuery(document).on('submit','#formtraerdatosuser', function(event){
	event.preventDefault();

	
	let nameuserr = localStorage.getItem("nameusuario");
	//console.log(cedulauser);

	document.getElementById("nameuser").value = nameuserr;

	console.log(nameuserr);
jQuery.ajax({
	url: '../controlador/traerdatosuserbitacora.php',
	type: 'POST',
	dataType: 'json',
	data: $(this).serialize(),
	beforeSend: function () {
		// body...

	}
})
.done(function (respuesta) {
	// body...
	console.log(respuesta);

	let nombredelusuario = document.querySelector("#nombredeusuario");
	nombredelusuario.innerHTML = "";
		if (respuesta.length > 0) {
		for (let registro of respuesta) {
			nombredelusuario.innerHTML = `

          <h5>${registro.usuariosistema}</h5>

         `;
		}
	}


let tbody = document.querySelector("#mismovimientosusuario");
	tbody.innerHTML = "";
	if (respuesta.length > 0) {
		for (let registro of respuesta) {
			tbody.innerHTML += `
         <tr>
         <th class="text-center">${registro.idbitacora}</th>
         <td class="text-center">${registro.codigopersona}</td>
         <td class="text-center">${registro.fecha}</td>
         <td class="text-center">${registro.actividadrealizada}</td>
         <td class="text-center">${registro.informacionactual}</td>
         </tr>


         `;
		}
	} else {
		tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${respuesta}</th>
            </td>
            </tr>
            `;
	}


//$('#modaloffuser').modal("show");

	



})
.fail(function (resp) {
	// body...
	//console.log(resp.responseText);
	
	
})
.always(function () {
	// body...
	console.log("complete");
});



});