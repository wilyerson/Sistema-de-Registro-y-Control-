const formdata = document.getElementById("formup");

formdata.addEventListener("submit", (e) => {
	e.preventDefault();

	const datos = new FormData(formdata);

	//console.log(datos);
	console.log(datos.get("Cedulapersona"));

	//let url = "../vista/controller.php?op=guardar";
	
		fetch("../vista/controller.php?op=guardar", {
			method: "POST",
			body: datos
		})
			.then(res => res.json())
			.then(data => {
				//console.log(`Success: ${JSON.stringify(data)}`);
				console.log(res);
				//formdatap.reset();

			})
			.catch((error) => console.log(`error: ${error}`));
	
});