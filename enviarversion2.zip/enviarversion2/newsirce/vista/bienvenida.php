<?php 

$conn = mysqli_connect("localhost","root","","newsirce"); 



session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}

?>

<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SIRCE</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
  

  <style>

    @font-face{
      font-family: opensan;
      src: url(fonts/googlesansnormal.woff2);

    }

    body{
      font-family: opensan;
      
    }



    #nombreusuario{
      animation: animacionletrabienvenida 1.7s linear  ;
position: relative;
    left: 55%;
    top: 23%;    transform: translate(-50%, -50%);
    }



    @keyframes animacionletrabienvenida { 
      0%{color: white;}
      /*50%{background-position:96% 100%}*/
      100%{color: black;}
    }

    @keyframes gradient {
  0% {
    box-shadow: 0 0px 0px 0px rgba(0, 0, 0, 0);
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 0%, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0) 100%);
  }
  05% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 04%, rgba(255, 255, 255, 0) 05%, rgba(255, 255, 255, 0) 100%);
  }
  10% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 09%, rgba(255, 255, 255, 0) 10%, rgba(255, 255, 255, 0) 100%);
  }
  15% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 14%, rgba(255, 255, 255, 0) 15%, rgba(255, 255, 255, 0) 100%);
  }
  20% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 19%, rgba(255, 255, 255, 0) 20%, rgba(255, 255, 255, 0) 100%);
  }
  25% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 24%, rgba(255, 255, 255, 0) 25%, rgba(255, 255, 255, 0) 100%);
  }
   30% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 29%, rgba(255, 255, 255, 0) 30%, rgba(255, 255, 255, 0) 100%);
  }
   35% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 34%, rgba(255, 255, 255, 0) 35%, rgba(255, 255, 255, 0) 100%);
  }
   40% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 24%, rgba(255, 255, 255, 0) 40%, rgba(255, 255, 255, 0) 100%);
  }
   45% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 44%, rgba(255, 255, 255, 0) 45%, rgba(255, 255, 255, 0) 100%);
  }
  50% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 49%, rgba(255, 255, 255, 0) 50%, rgba(255, 255, 255, 0) 100%);
  }
    55% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 54%, rgba(255, 255, 255, 0) 55%, rgba(255, 255, 255, 0) 100%);
  }
    60% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 59%, rgba(255, 255, 255, 0) 60%, rgba(255, 255, 255, 0) 100%);
  }
    65% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 64%, rgba(255, 255, 255, 0) 65%, rgba(255, 255, 255, 0) 100%);
  }
    70% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 69%, rgba(255, 255, 255, 0) 70%, rgba(255, 255, 255, 0) 100%);
  }
  75% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 74%, rgba(255, 255, 255, 0) 75%, rgba(255, 255, 255, 0) 100%);
  }
    80% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 79%, rgba(255, 255, 255, 0) 80%, rgba(255, 255, 255, 0) 100%);
  }
    85% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 84%, rgba(255, 255, 255, 0) 85%, rgba(255, 255, 255, 0) 100%);
  }
    90% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 89%, rgba(255, 255, 255, 0) 90%, rgba(255, 255, 255, 0) 100%);
  }
    95% {
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 94%, rgba(255, 255, 255, 0) 95%, rgba(255, 255, 255, 0) 100%);
  }
      98% {
        box-shadow: 0 0px 0px 0px rgba(0, 0, 0, 0);
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 97%, rgba(255, 255, 255, 0) 98%, rgba(255, 255, 255, 0) 100%);
  }

  100% {
    /*background: white;*/
    background: radial-gradient(circle at top, rgba( 255, 255 , 255, 1 ) 100%, #fff 100%, #fff 100%);
    box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
  }
}
    #zonanombreusuario{
        animation: gradient 0.5s linear forwards;
      border-radius: 17px;
       position: absolute;
    left: 50%;
    top: 7%;
    height: 23%; 
    width: 77%;
    max-width: 1000px; 
    margin-top: 100px;
    margin-bottom: 20px;
   transform: translate(-50%, -27%);
   will-change: background-image;
   z-index:100;
    }


   #footersirce{
    position: absolute;
    left: 46.5%;
    top: 97%;
    transform: translate(-37%, -30%);
   }


#zonafooterdecoracion{
        position: absolute;
    left: 50%;
    top: 96.5%;
    width: 100%;
    height: 7%;
    transform: translate(-50%, -50%);
    border-style: none;
    border-radius: none;
    display: none;
}

#mostrarcedulauser{
     animation: animacionletrabienvenida 1.7s linear  ;
        position: relative;
    left: 55%;
    top: 31%;
    transform: translate(-50%, -50%);
}

#mostrarnombreapellidouser{
     animation: animacionletrabienvenida 1.7s linear  ;
    position: relative;
    left: 55%;
    top: 37%;
    transform: translate(-50%, -50%);
}


  </style>

</head>
<body class="bg-gray">

    

 <?php include"componentes/nav.php" ?>

   <div  id="zonanombreusuario" >

    <h5 id="nombreusuario" >Bienvenido(a): MANUEL ALVAREZ </h5> 
    
  </div>

  



   <footer>

    <div id="zonafooterdecoracion"></div>

      <p id="footersirce">SIRCE.  Sistema de Registro y Control de Expedientes </p> 
   </footer>

<script type="text/javascript">
/*let students = [
  {
    name: 'Alvaro',
    score: 10,
  },
  {
    name: 'Daniel',
    score: 16,
  },
  {
    name: 'Alexys',
    score: 12,
  },
  {
    name: 'Rafa',
    score: 17,
  },
  {
    name: 'Alejandro',
    score: 8,
  },
  {
    name: 'Sofia',
    score: 9,
  }
]

let approved = students.filter(student => student.score >= 11);

console.log(approved);*/

let students = [
  {
    name: 'Alvaro',
    score: 10,
  },
  {
    name: 'Daniel',
    score: 16,
  },
  {
    name: 'Alexys',
    score: 12,
  },
  {
    name: 'Rafa',
    score: 17,
  },
  {
    name: 'Alejandro',
    score: 8,
  },
  {
    name: 'Sofia',
    score: 9,
  }
]

let approved = students.filter(student => student.name == "Rafa");

console.log(approved);
</script>

</body>
</html>