jQuery(document).on('submit','#formup', function(event){
	event.preventDefault();

	
	

jQuery.ajax({
	url: '../vista/controller.php?op=guardar',
	type: 'POST',
	dataType: 'json',
	data: $(this).serialize(),
	beforeSend: function () {
		// body...

	}
})
.done(function (respuesta) {
	// body...
	console.log(respuesta);


//$('#modaloffuser').modal("show");

	



})
.fail(function (resp) {
	// body...
	console.log(resp.responseText);
	
	
})
.always(function () {
	// body...
	console.log("completemodificar");
});



});