<style type="text/css">
    
  @font-face{
  font-family: opensan;
  src: url(fonts/googlesansnormal.woff2);

}
    
body{
  font-family: opensan;
  /*background-color: #edf2f7;*/
  /*background-color: #e4faf8;*/
     background-image: linear-gradient(120deg, #c9eff5 0%, #f3f3f3 100%);
  

}



      #zonanombreusuario{
    /*    box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);
    -moz-box-shadow: 0 5px 10px 0px rgba(0, 0, 0, 0.1);*/
  }


   #navestilo{



     box-shadow: rgb(0 154 255 / 47%) 0.3981px -0.6019px 14.562989px 1.0625px, rgba(9, 172, 255, 0.49) 1.20725px 1.20725px 1.70731px -1.875px, rgba(9, 172, 255, 0.42) 3.19133px 3.19133px 4.51322px -2.8125px, rgba(9, 172, 255, 0.176) 10px 10px 14.1421px -3.75px;

     background-color: #009aff;
     /*animation: aninav 4s ease-in-out ;*/


   } 


   @keyframes aninav { 
    0%{background-color: white;}
    
    100%{background-color: #009aff;}
}


#bottonhamburguesa{

    border-style: none;

    background: linear-gradient(102deg, rgb(255 242 0) 0%, rgb(255 247 0) 100%);
    height: 70%;
    width: 5.9%;
    border-radius: 12px;
    box-shadow: rgba(9, 172, 255, 0.518) 0.3981px 0.3981px 0.56299px -0.9375px, rgba(9, 172, 255, 0.49) 1.20725px 1.20725px 1.70731px -1.875px, rgba(9, 172, 255, 0.42) 3.19133px 3.19133px 4.51322px -2.8125px, rgba(9, 172, 255, 0.176) 10px 10px 14.1421px -3.75px;

            box-shadow: 0 5px 10px 0px rgba(0 0 0 / 49%);
    -moz-box-shadow: 0 5px 10px 0px rgba(0 0 0 / 49%);

    transition: box-shadow 0.2s linear 0.1s;
  }

    #bottonhamburguesa:hover {
 
      box-shadow: 0 5px 17px 0px rgb(238 255 102 / 75%);
  
}

.decoracionopcionmenu{
  text-align: left;
  border-radius: 15px;
padding-left: 50px;
    padding-bottom: 15px;
    padding-top: 15px;
    transition: 0.25s ease;
}

    .decoracionopcionmenu:hover {
  background-color: #009aff; 
  color: white;
  box-shadow: 0 5px 17px 0px rgb(0 140 186);
 transition: 0.25s ease;
 
}

/*.decoracionopcionmenu{
  text-align: left;
  border-radius: 15px;
padding-left: 50px;
    padding-bottom: 15px;
    padding-top: 15x;
    transition: 0.25s ease;
}

    .decoracionopcionmenu:hover {
  background-color: #008CBA; 
  border-radius: 15px;
 padding-left: 50px;
    padding-bottom: 15px;
    padding-top: 15px;
  color: white;
  box-shadow: 0 5px 17px 0px rgb(0 140 186);
 transition: 0.25s ease;
 
}*/

nav{
  animation: animacionbarranav 1.5s ease-in-out ;
}

  #botoniniciosirce{
    color: #fff;

 
  }

  #botoniniciosirce:hover{
    background-color: #fd1767;
    border-radius: 7px;
    width: 20%;
    padding-left: 3.9%;
    padding-top: 1.5%;
    padding-bottom: 1.5%;
    margin-left: -3.9%;
    /*color: #000000;*/
    /*box-shadow: 0px 17px 21px -3px #fd1767e0;*/
    box-shadow: 0px 22px 19px -8px rgba(199, 0, 105, 0.5);

 
  }

  </style>

 <nav id="navestilo" class="navbar fixed-top" >
      <div class="container p-0" style="width: 900px; height: 65px;">
        <a id="botoniniciosirce" class="navbar-brand d-flex align-baseline" href="bienvenida.php"><img id="housesolid" src="../icons/housesolid.svg" style="color: white; height: 27px;
    position: relative;left: -17px;top: -2px;"><H4 style=" margin-bottom: 0px;" >S I R C E</H4></a>
        
        <button id="bottonhamburguesa"  type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end " tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Usuario : <?php echo $_SESSION['usuarioad'];?></h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link decoracionopcionmenu" aria-current="page" href="bienvenida.php"><img id="icononosmenu" src="../icons/house-solidmenu.svg" style="position: relative; width: 7%; left: -2%; top: 50%; transform: translate(-50%, -15%);">Inicio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link decoracionopcionmenu" aria-current="page" href="inicio.php"><img id="icononosmenu" src="../icons/search-solidmenu.svg" style="position: relative; width: 7%; left: -2%; top: 50%; transform: translate(-50%, -15%);">Buscar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link decoracionopcionmenu" aria-current="page" href="registro-persona.php"><img id="icononosmenu" src="../icons/user-registersolidmenu.svg" style="position: relative; width: 7%; left: -2%; top: 50%; transform: translate(-50%, -15%);">Registrar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link decoracionopcionmenu" aria-current="page" href="control-usuarios-sistema.php"><img id="icononosmenu" src="../icons/user-configsolidmenu.svg" style="position: relative; width: 7%; left: -2%; top: 50%; transform: translate(-50%, -15%);">Gestionar Usuarios del Sistema</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle decoracionopcionmenu" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true"><img id="icononosmenu" src="../icons/config-solidmenu.svg" style="position: relative; width: 7%; left: -2%; top: 50%; transform: translate(-50%, -15%);">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item " href="registro-cargos.php">Agregar Cargos</a></li>
                <li><a class="dropdown-item " href="registro-institucion.php">Añadir Instituciones</a></li>
                <li><a class="dropdown-item " href="ver-instituciones.php">Ver Instituciones</a></li>
              </ul>
            </li>
            <li class="nav-item" >
              <a class="nav-link decoracionopcionmenu" aria-current="page" href="reportesvista.php"><img id="icononosmenu" src="../icons/file-reportssolidmenu.svg" style="position: relative; width: 7%; left: -2%; top: 50%; transform: translate(-50%, -15%);">Generar Reportes</a>
            </li>
            <li class="nav-item" >
              <a class="nav-link decoracionopcionmenu" aria-current="page" href="modificar-contrasena-usuario.php"><img id="icononosmenu" src="../icons/key-solidmenu.svg" style="position: relative; width: 7%; left: -2%; top: 50%; transform: translate(-50%, -15%);">Cambiar Contraseña</a>
            </li>
            <li class="nav-item" >
              <a class="nav-link decoracionopcionmenu" aria-current="page" href="bitacora.php"><img id="icononosmenu" src="../icons/bitacora-solidmenu.svg" style="position: relative; width: 7%; left: -2%; top: 50%; transform: translate(-50%, -15%);">bitacora</a>
            </li>
             <li class="nav-item">
              <a class="nav-link decoracionopcionmenu" aria-current="page" href="../controlador/cierre.php"><img id="icononosmenu" src="../icons/logout-solidmenu.svg" style="position: relative; width: 7%; left: -2%; top: 50%; transform: translate(-50%, -15%);">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
</nav>


