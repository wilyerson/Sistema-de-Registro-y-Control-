jQuery(document).on('submit','#formumismostrarusuariosbitacora', function(event){
	event.preventDefault();

	
	let nameuserr = localStorage.getItem("nameusuario");
	//console.log(cedulauser);

	document.getElementById("nameuser").value = nameuserr;

	console.log(nameuserr);
jQuery.ajax({
	url: '../controlador/mostrarusuariosbitacora.php',
	type: 'POST',
	dataType: 'json',
	data: $(this).serialize(),
	beforeSend: function () {
		// body...

	}
})
.done(function (respuesta) {
	// body...
	console.log(respuesta);

	document.getElementById("listadeusuarios").style.display="block";

	let tbody = document.querySelector("#mostrarusuarios");
	tbody.innerHTML = "";
	if (respuesta.length > 0) {
		for (let registro of respuesta) {
			tbody.innerHTML += `
         <tr>
         <th class="text-center">${registro.codigousuario}</th>
         <td class="text-center">${registro.nombreusuario}</td>
         <td class="text-center">${registro.rolusuario}</td>
         <td class="text-center">${registro.estatususuario}</td>
         <td class="text-center">
         <form id="formtraerdatosuser" method="post">
         <input type="hidden" id="usersistema" name="usersistema" value="${registro.nombreusuario}">
   <button type="submit" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#mostrarmovimientosuser" >Ver Movimientos</button>

</form>
         
         </td>
         </tr>


         `;
		}
	} else {
		tbody.innerHTML += `
            <tr>
            <th class="text-center" colspan="5" >No hay Registros en la Base de datos.${respuesta}</th>
            </td>
            </tr>
            `;
	}


//$('#modaloffuser').modal("show");

	



})
.fail(function (resp) {
	// body...
	//console.log(resp.responseText);
	
	
})
.always(function () {
	// body...
	console.log("complete");
});



});