<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

//$id = $_GET['id'];
//$usuarios = "SELECT * FROM persona WHERE idpersona = '$id'";

session_start();

if(!isset($_SESSION['usuarioad']))
{
  header("Location: ../index.php");
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="estiloregistropersona.css" rel="stylesheet" type="text/css"/>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

  <style>

    @font-face{
      font-family: opensan;
      src: url(fonts/googlesansnormal.woff2);

    }

    body{
      font-family: opensan;
    }

    /* The Modal (background) */
    .modal2 {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 1; /* Sit on top */
      padding-top: 100px; /* Location of the box */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
    }

/* Modal Content */
.modal-content2 {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close2 {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close2:hover,
.close2:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

.menumenu{
  margin: 0 auto;
  width: 900px;
}
.articulo{
  margin: 100px auto 0;
  max-width: 900px;
}
.nuevo-trb{
  text-decoration: none;
  color: white;
}
.linka{
  color: black;
}

.inputcedulaestilo{
  display: none;
}

.formu-control.success input {
  border-color: #2ecc71;
}

.formu-control.error input {
  border-color: #e74c3c;
}

.formu-control.success select {
  border-color: #2ecc71;
}

.formu-control.error select {
  border-color: #e74c3c;
}

.formu-control .fas {
  visibility: hidden;
  /*position: absolute;
  top: 40px;
  right: 10px;*/
}

.formu-control.success .fas.fa-check-circle {
  color: #2ecc71;
  visibility: visible;
}

.formu-control.error .fas.fa-exclamation-circle {
  color: #e74c3c;
  visibility: visible;
}

.formu-control small {
  color: #e74c3c;
  /*position: absolute;
  bottom: 0;
  left: 0;*/
  visibility: hidden;
}

.formu-control.error small {
  visibility: visible;
  
}

#iconomunero1{
  position: relative;
  width: 5%;
  top: -118px;
  left: 10%;
  cursor: pointer;
}

#iconomunero2{
  position: relative;
  width: 5%;
  top: -118px;
  left: 27%;
  cursor: pointer;
}

#iconomunero3{
  position: relative;
  width: 5%;
  top: -118px;
  left: 47%;
  cursor: pointer;
}

#iconomunero4{
  position: relative;
  width: 5%;
  top: -118px;
  left: 67%;
  cursor: pointer;
}

#linea{
  position: relative;
  top: -78px;
}

#letranumero1{
  position: relative;
  width: 5%;
  top: -114px;
  left: 10%;
}

#letranumero2{
  position: relative;
  width: 5%;
  top: -178px;
  left: 30%;
}

#letranumero3{
  position: relative;
  width: 5%;
  top: -215px;
  left: 57%;
}

#letranumero4{
  position: relative;
  width: 5%;
  top: -254px;
  left: 82%;
}

#multiregister{
  margin: 0px 0px -198px;
}

</style>

</head>
<body class="bg-gray">
  <?php include"componentes/nav.php" ?>


  <div class="container rounded border py-3 bg-white" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px;
  ">

  <!--  CONTENIDO  -->


  <!-- TAB-PERFIL  -->



  <!-- TAB-DOCUMENTOS  -->
  <!-- TAB-HISTORICO  -->
  <div class="articulo tab-pane " id="nav-historico" role="tabpanel" aria-labelledby="nav-historico-tab">

    <div class="col col-sm-12 d-block justify-content-center">

      <div id="multiregister" class="col col-sm-12">

        <hr id="linea"></hr>
        <img id="iconomunero1" src="../iconos/numero-1inicio.png">
        <img id="iconomunero2" src="../iconos/numero-2inicio.png">
        <img id="iconomunero3" src="../iconos/numero-3.png">
        <img id="iconomunero4" src="../iconos/numero-4inicio.png">


        <p id="letranumero1" >datos basicos</p>
        <p id="letranumero2">documentos</p>
        <p id="letranumero3">historico</p>
        <p id="letranumero4">familiares</p>

      </div>

      <table class="table">
        <thead>
          <tr>

            <th scope="col">Institución</th>
            <th scope="col">Cargo</th>
            <th scope="col">Fecha Ingreso</th>
            <th scope="col">Fecha Culminación</th>
            <th scope="col"><img src="../icons/buscar.png" width="20px"></th>

          </tr>
        </thead>
        <tbody id='cuerpo'>

        </tbody>
      </table>

    </div> 

    <!-- Button de modal -->
    <div class="row">

      <div class="col-sm-6">

        <button type="button" id="botonirafamiliar" class="btn btn-primary justify-content-center">
          ir a Familiar
        </button>

      </div>

      <div class="col-sm-6 d-flex justify-content-end">
        

        <button type="button" class="btn btn-primary d-flex justify-content-center" data-bs-toggle="modal" data-bs-target="#registrohistorico">
                Registrar Historial
        </button>
      
      </div>

    </div>

        <!-- ////////////////////////////////////////////////////////////////////////////////////////// -->


        <div class="modal fade" id="registrohistorico" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
              <div class="modal-header" style="background: #009aff;">
                <div class="modal-title" id="registro-historicoLabel"><span class="text-white">Nuevo Registro Historico</span></div>
                <button type="button" data-bs-dismiss="modal" aria-label="Close" class="btn-close"></button>
              </div>

              <form id="formuh" action="formuh">
                
                <div class="modal-body">
                  
                  <div class="row">
                    
                    <div class="col col-sm-12" id="inputcedula"></div>

                  </div>

                  <div class="row">
                    <div class="col col-sm-12">
                      <select name="estatuscargo" id="estatuscargo" class="form-select">
                        <option selected disabled value="">Seleccione Estatus</option>
                        <option value="Activo">Activo</option>
                        <option value="Inactivo">Inactivo</option>
                      </select>
                    </div>
                  </div>

                  <row class="d-flex mt-4">
                    <div class="col col-sm-12">
                      <p>Ingrese Institución</p>
                    </div>
                  </row>

                  <div class="row">
                    <div class="col col-sm-9 ">
                      <div class="formucontrol">
                        <select name="institucionhistorico" class="form-control" id="institucionhistorico">
                          <option selected disabled value="">Seleccione Institución</option>
                          <option value="institucion1">institucion1</option>
                        <option value="institucion2">institucion2</option>
                        </select>
                      </div>                      
                    </div>


                    <div class="col col-sm-3">

                      <a id="myBtn2" class="btn btn-primary">Añadir institucion</a>
                      <div id="myModal2" class="modal2">
                        <div class="modal-content">
                          <span class="close2">&times;</span>
                          <div class="container border rounded py-3 bg-white" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px; ">
                            
                          </div>
                          <div class="row mb-4 mt-2">       
                            <div class="col col-sm-12"><h5 class="text-right">Registro de Institución</h5></div>
                          </div>
                          <div class="row mb-4 align-baseline">

                            <div class="col col-sm-3 ">
                              <p class="text-end">Nombre de la Institución</p>
                            </div>

                            <div class="col col-sm-9">
                              <input type="text" class="form-control" placeholder="Nombre de la Institución" style="text-transform: uppercase;" aria-label="Nombre de la Institución" aria-describedby="basic-addon1">
                            </div>

                          </div>

                          <div class="row mb-4 align-baseline">

                            <div class="col col-sm-3 ">
                              <p class="text-end">Código de registro</p>
                            </div>

                            <div class="col col-sm-9">
                              <input type="text" class="form-control" placeholder="Ingrese Código" style="text-transform: uppercase;" aria-label="Ingrese Código" aria-describedby="basic-addon1">
                            </div>

                          </div>

                          <div class="row mb-4 align-baseline">

                            <div class="col col-sm-3 ">
                              <p class="text-end">Municipio</p>
                            </div>

                            <div class="col col-sm-9">
                              <select class="form-select" aria-label="Default select example">
                                <option selected>Seleccione Municipio</option>
                                <option value="1">Uno</option>
                                <option value="2">Dos</option>
                                <option value="3">Tres</option>
                              </select>
                            </div>

                          </div>

                          <div class="row mb-4 align-baseline">

                            <div class="col col-sm-3 ">
                              <p class="text-end">Parroquia</p>
                            </div>

                            <div class="col col-sm-9">
                              <select class="form-select" aria-label="Default select example">
                                <option selected>seleccione Parroquia</option>
                                <option value="1">Uno</option>
                                <option value="2">Dos</option>
                                <option value="3">Tres</option>
                              </select>
                            </div>

                          </div>

                          <div class="row mb-4 align-baseline">

                            <div class="col col-sm-3 ">
                              <p class="text-end">Sector</p>
                            </div>

                            <div class="col col-sm-9">
                              <select class="form-select" aria-label="Default select example">
                                <option selected>Seleccione Sector</option>
                                <option value="1">Uno</option>
                                <option value="2">Dos</option>
                                <option value="3">Tres</option>
                              </select>
                            </div>

                          </div>

                          <div class="row mb-4 align-baseline">

                            <div class="col col-sm-3 ">
                              <p class="text-end">Dirección</p>
                            </div>

                            <div class="col col-sm-9">
                              <input type="text" class="form-control" placeholder="Ingrese la Dirección" aria-label="Ingrese la Dirección" aria-describedby="basic-addon1">
                            </div>

                          </div>

                          <div class="row mb-4">
                            <div class="col col-sm-6 d-flex justify-content-end">
                              <button class="btn btn-secondary" type="reset">Limpiar</button>
                            </div>
                            <div class="col col-sm-6">
                              <button class="btn btn-info ml" >Registrar Institución</button>            
                            </div>
                          </div>
                      </div>
                    </div>
                  </div>

                  <div class="row mt-4">
                    
                    <div class="col col-sm-12 formu-control">

                      <label for="cargo" class="form-label">Cargo</label>

                      <select name="cargohistorico" class="form-select" style="text-transform: uppercase;" id="cargohistorico" aria-label="Seleccione">
                        <option selected disabled value="">Seleccione un cargo</option>
                        <option value="BACHILLER I">BACHILLER I</option>
                        <option value="BACHILLER II">BACHILLER II</option>
                        <option value="BACHILLER III">BACHILLER III</option>
                        <option value="TSU I">TSU I</option>
                        <option value="TSU II">TSU II</option>
                        <option value="PROFESIONAL I">PROFESIONAL I</option>
                        <option value="PROFESIONAL II">PROFESIONAL II</option>
                        <option value="PROFESIONAL III">PROFESIONAL III</option>
                        <option value="OBRERO GRADO 1">OBRERO GRADO 1</option>
                        <option value="OBRERO GRADO 2">OBRERO GRADO 2</option>
                        <option value="OBRERO GRADO 3">OBRERO GRADO 3</option>
                        <option value="OBRERO GRADO 4">OBRERO GRADO 4</option>
                        <option value="OBRERO GRADO 5">OBRERO GRADO 5</option>
                        <option value="OBRERO GRADO 6">OBRERO GRADO 6</option>
                        <option value="OBRERO GRADO 7">OBRERO GRADO 7</option>
                        <option value="OBRERO GRADO 8">OBRERO GRADO 8</option>
                        <option value="OBRERO GRADO 9">OBRERO GRADO 9</option>
                        <option value="OBRERO GRADO 10">OBRERO GRADO 10</option>
                      </select>

                    </div>

                  </div>

                  <div class="row mt-4">

                    <div class="col col-sm-6 formu-control">
                      <label for="fecha-inicio" class="form-label">Fecha de Inicio</label>
                      <input type="date" name="fechainiciohistorico" class="form-control" id="fechainiciohistorico">
                      <small>Error message</small>
                    </div>
                    <div class="col-6 col-sm-6 formu-control">
                      <label for="fecha-culminacion" class="form-label">Fecha de Culminación</label>
                      <input type="date" name="fechaculminacionhistotico" class="form-control" id="fechaculminacionhistotico">
                      <small>Error message</small>
                    </div>

                  </div>

                  <div class="col col-sm-12 mt-4 formu-control">
                    <label for="observacion" class="form-label">Observación</label>
                    <input type="text" name="observacionhistorico" class="form-control" id="observacionhistorico">
                    <small>Error message</small>
                  </div>

                </div><!-- finalmodalbody -->

                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                  <button type="submit" id="Guardard" name="Guardard" class="btn btn-primary">Registrar</button>
                </div>

              </form>

            </div>
          </div>
        </div>


        <!-- ////////////////////////////////////////////////////////////////////////////////////////// -->



        <!-- ////////////////////////////////////////////////////////////////////////////////////////// -->

        <div class="modal fade" id="modalregistrarrellenecampos" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">

                <div class="row">


                  <div class="col col-sm-6">
                    <p>rellener todos los campos</p>
                  </div>


                </div>

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

              </div>
            </div>
          </div>
        </div>


        <div class="modal fade" id="modalregistrarexitoso" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->

              </div>
              <div class="modal-body">

                <div class="row">


                  <div class="col col-sm-6">

                    <p>historico registrado con exito</p>
                  </div>


                </div>

              </div>
              <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="botonrecargarhistoricos">Cerrar</button>

             </div>
           </div>
         </div>
        </div>

        <div class="modal fade" id="modalagregarinstitucion" tabindex="-1" aria-labelledby="ModalLabelagregarinstitucion" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->

              </div>
              <div class="modal-body">

                <div class="row">


                  <div class="col col-sm-6">

                    <p>historico registrado con existo</p>
                  </div>


                </div>

              </div>
              <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="botonrecargarhistoricos">Cerrar</button>

             </div>
           </div>
         </div>
        </div>


        <div class="modal fade" id="modalmensajeagregueundocumento" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <!--<h5 class="modal-title" id="exampleModalLabel">mensaje de registro</h5>-->
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">

                <div class="row">


                  <div class="col col-sm-6">
                    <p>agregue un historial de trabajo</p>
                  </div>


                </div>

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Cerrar</button>
                <!--<button type="button" name="Guardard" class="btn btn-primary">Guardar</button>-->

              </div>
            </div>
          </div>
        </div>

        <!-- ////////////////////////////////////////////////////////////////////////////////////////// -->


<!-- TAB-HISTORICO  -->
<!-- TAB-FAMILIARES  -->


<!--  CONTENIDO  -->

<script src="jquery.min.js"></script>
<script src="registrohistorico.js"></script>
<script type="text/javascript">
  const botonirpersona = document.getElementById("iconomunero1");
  const botonirdocumento = document.getElementById("iconomunero2");
  const botonirhistorico = document.getElementById("iconomunero3");
  const botonirfamiliar = document.getElementById("iconomunero4");

  botonirpersona.onclick = function() {

    window.location.href ='registro-persona.php';


  }

  botonirdocumento.onclick = function() {

    window.location.href ='registrodocumentosprincipal.php';


  }

  botonirhistorico.onclick = function() {

    window.location.href ='registrohistoricoprincipal.php';


  }

  botonirfamiliar.onclick = function() {

    window.location.href ='registrofamiliarprincipal.php';


  }


</script>

</body>
</html>