<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Instituciones</title>	
	<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>

	<style type="text/css">

		@font-face{
			font-family: opensan;
			src: url(fonts/googlesansnormal.woff2);

		}

		body{
			font-family: opensan;
		}
		
		input{
			text-transform: uppercase;
		}

		select{
			text-transform: uppercase;
		}
	</style>
</head>

<?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>

<body class="bg-gray">

	<?php include"componentes/nav.php";	?>

	<div class="container border rounded py-3 bg-white" style="max-width: 1000px; margin-top: 100px; margin-bottom: 20px; ">

		<div class="row py-3"> 
			<h4 class="text-center">Registro de Institución</h4>
		</div>

		<form id="formulariogeistroinstitucion">

			<div class="row" id="salida"></div>

			<div class="row py-3">

				<div class="col col-sm-3 d-flex justify-content-end align-items-center">
					<p class="m-0">Nombre de la Institución</p>
				</div>

				<div class="col col-sm-9">
					<input type="text" name="nombreinstitucion" class="form-control" placeholder="Nombre de la Institución" aria-label="Nombre de la Institución" aria-describedby="basic-addon1" required>
				</div>

			</div>

			<div class="row mb-4 align-baseline">

				<div class="col col-sm-3 d-flex justify-content-end align-items-center">
					<p class="m-0 ">Código de registro</p>
				</div>

				<div class="col col-sm-9">
					<input type="text" name="codigodeinstitucion" id="codigoregistroinstitucion" class="form-control" placeholder="Ingrese Código" aria-label="Ingrese Código" aria-describedby="basic-addon1">
				</div>

			</div>

			<div class="row mb-4 align-baseline">

				<div class="col col-sm-3 d-flex justify-content-end align-items-center">
					<p class="m-0">Municipio</p>
				</div>

				<div class="col col-sm-9">
					<select class="form-select" name="municipioreg" id="municipioinstitucion" aria-label="Default select example">
						<option selected disabled>Seleccione Municipio</option>
						<?php 

						require "../controlador/municipiosfetch.php";

						foreach ($municipio as $municipio) {
							echo '<option value="'.$municipio['CodigoMunicipio'].'">'.$municipio['NombreMunicipio'].'</option>';
							}
						?>
					</select>
				</div>

			</div>

			<div class="row mb-4 align-baseline">

				<div class="col col-sm-3 d-flex justify-content-end align-items-center">
					<p class="m-0">Parroquia</p>
				</div>

				<div class="col col-sm-9">
					<select class="form-select" name="parroquiareg" id="parroquiainstitucion" aria-label="Default select example">
						<option selected disabled>seleccione Parroquia</option>
						
					</select>
				</div>
				<script>
					document.querySelector('#municipioinstitucion').addEventListener('change', event => {
						console.log(event.target.value);
						fetch('../controlador/parroquiasfetch.php?municipioinstitucion='+event.target.value)
						.then(res => {
							if(!res.ok){
								throw new Error('error en la respuesta');
							}
							return res.json();
						})
						.then(datos => {
							let html = '<option value="">Seleccione Parroquia</option>';
							if(datos.data.length > 0){
								for(let i = 0; i < datos.data.length; i++){
									html += `<option value="${datos.data[i].CodigoParroquia}">${datos.data[i].NombreParroquia}</option>`; 
								}
							}
							document.querySelector('#parroquiainstitucion').innerHTML = html;
						})
						.catch(error => {
							console.error('ocurrio un error '+error);
						});	
					});
				</script>

			</div>

			<div class="row mb-4 align-baseline">

				<div class="col col-sm-3 d-flex justify-content-end align-items-center">
					<p class="m-0 ">Sector</p>
				</div>

				<div class="col col-sm-9">
					<input type="text" name="sectorreg" id="sectorinstitucion" class="form-control" placeholder="Sector de la Institución" aria-label="Sector de la Institución" aria-describedby="basic-addon1">
				</div>

			</div>

			<div class="row mb-4 align-baseline">

				<div class="col col-sm-3 d-flex justify-content-end align-items-center">
					<p class="m-0 ">Dirección</p>
				</div>

				<div class="col col-sm-9">
					<input type="text" name="direccionreg" id="direccioninstitucion" class="form-control" placeholder="Ingrese la Dirección" aria-label="Ingrese la Dirección" aria-describedby="basic-addon1">
				</div>

			</div>

			<div class="row mb-4">
				<div class="col col-sm-6 d-flex justify-content-end">
					<button class="btn btn-secondary" type="reset">Limpiar</button>
				</div>
				<div class="col col-sm-6">
					<button class="btn btn-primary ml" type="submit">Registrar Institución</button>  					
				</div>
			</div>

		</form>					

	</div>


	<script src="../controlador/registroinstitucion.js"></script>

</body>
</html>