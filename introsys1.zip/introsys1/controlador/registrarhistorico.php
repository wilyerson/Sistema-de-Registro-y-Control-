<?php 


$conn = mysqli_connect("localhost","root","","sirce"); 





if(isset($_POST['Guardar'])){
  
    $trabajador = $_POST['trabajador'];
    $cargo = $_POST['cargo'];
    $fechainicio = $_POST['fechainicio'];
    $fechaculminacion = $_POST['fechaculminacion'];
    $observacion = $_POST['observacion'];
   


         $query = "INSERT INTO historico(trabajador,cargo,fechainicio,fechaculminacion,observacion) values('$trabajador','$cargo','$fechainicio','$fechaculminacion','$observacion')";


         $resultado = mysqli_query($conn,$query);
         if($resultado == 1){
               header('location:../vista/ingreso.php');
         }


       }
    


?>