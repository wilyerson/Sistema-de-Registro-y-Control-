<?php

  $conn = mysqli_connect("localhost","root","","newsirce");


$query = ("SELECT cedulapersona, estatususuario FROM usuarios WHERE cedulapersona = '".@$_POST['buscarusuariodesactivar']."' ");

$result = mysqli_query($conn,$query);

if (mysqli_num_rows($result) == 1):

  
  $datos = $result->fetch_assoc();
  echo json_encode(array('error' => false, 'estatus' => $datos['estatususuario']));
else:
    echo json_encode(array('error' => true));
  endif;

  //$mysqli->close();
  // code...





?>