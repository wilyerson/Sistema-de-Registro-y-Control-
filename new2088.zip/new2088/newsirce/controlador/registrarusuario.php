<?php 

//include './controlador/controladorregistratrabajador.php';
$conn = mysqli_connect("localhost","root","","newsirce"); 

class Usuarios
{

 
 public $cedulausuario;
  public $nombreusuario;
  public $passwordusuario;
  public $rolusuario;
  public $estatususuario;
  
 

  
 

 public function registrar($datosd){

  $conn = mysqli_connect("localhost","root","","newsirce"); 

//$this->imagen = $imagen;




         $query = "INSERT INTO usuarios(Cedulapersona,nombreusuario,passwordusuario,rolusuario,estatususuario) values('$datosd[0]','$datosd[1]','$datosd[2]','$datosd[3]','$datosd[4]')";


         $resultado = mysqli_query($conn,$query);
         if($resultado == 1){
            

             //$query = "INSERT INTO documento(Nombredocumento) values('$datosp[15]')";

            //resultado2 = mysqli_query($conn,$query);

            //modal de si desea registras mas documentos
              
              echo "Registrado";


         }else{
            echo "error error";
            // $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
             //$_SESSION['tipo'] = 'danger';
         }


       }
    }



  



   $cedulausuario = @$_POST['cedulausuario'];
    $nombreusuario = @$_POST['nombreusuario'];
    $passwordusuario = @$_POST['passwordusuario'];
    $rolusuario = @$_POST['rolusuario'];
    $estatususuario = @$_POST['estatususuario'];
   
  
   

    
    
    $datosd = array($cedulausuario, $nombreusuario, $passwordusuario, $rolusuario,$estatususuario);


 $objetoUsuarios = new Usuarios();
 
 if (!($objetoUsuarios->registrar($datosd))) {
   
   //header('location:../vista/ingreso.php');
    //@header('location:../vista/inicio.php');
 }else{ 
 
//echo "jodiste";

 }


?>