<!DOCTYPE html>
<html lang="es">
<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio Sirce</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
  
</head>

<body class="bg-light">

  <?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php");} ?>
  
  <nav class="navbar fixed-top" style="background-color: #950014FF;">
      <div class="container" style="width: 900px;">
        <div>
          <h5 style="color: white;">Modificar Datos de Usuario</h5>
        </div>
        <button class="navbar-toggler bg-p bg-light" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Nombre Usuario :<?php echo $_SESSION['usuarioad']; ?></h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Inicio</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Control de Usuarios de Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Asignar Usuarios de Sistema</a></li>
                <li><a class="dropdown-item" href="#">Eliminar Usuarios del Sistema</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="#">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="#">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
  </nav>
  
  <div class="container border bg-white border-1" style="max-width: 1000px; padding: 10px; margin-top: 80px; margin-bottom: 20px;">
    <form action="#" method="POST">
    
    <div class="row d-flex justify-content-center" style="margin: 5px auto 5px;">
      
      <div class="col col-sm-6" style="width: 35%;">
        <img class="rounded mx-auto d-block rounded-circle" id="img-perfil" src="../icons/perfil_usuario.png" width="150px">
        <p class="text-center">Nombre Usuario Apellido</p>
        <p class="text-center">Tipo de Usuario</p>
      </div>

      <div class="col col-sm-6" style="width: 65%;">
<form method="post" action="../controlador/actualizarpassadmin.php" >
        <div class="row p-3">
          <h5 >Nombre de Usuario: <?php echo $_SESSION['usuarioad']; ?></h5>
        </div>

        

        <div class="row">
          <div class="input-group flex-nowrap pb-4">
            
            <input type="text" class="form-control" name="pass" placeholder="Nueva Contraseña" aria-label="Nombre de usuario" aria-describedby="addon-wrapping">
          </div>
        </div>

        <div class="row">
          <div class="input-group flex-nowrap pb-4">
          
            <input type="text" class="form-control" name="pass2" placeholder="Repita Nueva Contraseña" aria-label="Nombre de usuario" aria-describedby="addon-wrapping">
          </div>
        </div>

        <div class="row">
          <div class="col col-sm-12 d-flex justify-content-center">
            <button type="submit" name="submit" class="btn btn-primary">Guardar Cambios</button>
          </div>
        </div>

        </form>

      </div>

    </div>

    
    </form>
  </div>


</body>