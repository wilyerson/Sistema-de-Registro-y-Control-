<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bienvenido(a)</title>
  <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
  
</head>
<body class="bg-light">

    <?php session_start(); if(!isset($_SESSION['usuarioad'])) {header("Location: ../index.php"); } ?>

 <nav class="navbar fixed-top" style="background-color: #950014FF;">
      <div class="container p-0" style="width: 900px;">
        <a class="navbar-brand d-flex align-baseline" href="bienvenida.php"><img src="../icons/inicio-blanco.png" style="color: white; height: 30px;"><H4 style="color:white; margin-bottom: 0px;" >S I R C E</H4></a>
        <button class="navbar-toggler bg-p bg-light" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end " tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
          <div class="offcanvas-header">
           <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Usuario : <?php echo $_SESSION['usuarioad'];?></h5>
           <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
         </div>
         <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="inicio.php">Buscar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="registro-persona.php">Registrar Trabajador</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="control-usuarios-sistema.php">Control de Usuarios del Sistema</a>
            </li>
            <li class="nav-item" >
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Gestión de Usuario
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="modificar-contrasena-usuario.php">Cambio de Contraseña</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                Configuracion del Sistema
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="registro-cargos.php">Agregar Cargos</a></li>
                <li><a class="dropdown-item" href="registro-institucion.php">Añadir Instituciones</a></li>
              </ul>
            </li>
             <li class="nav-item">
              <a class="nav-link" aria-current="page" href="../controlador/cierre.php">Cerrar Sesión</a>
             </li>
            </ul>
          </div>
        </div>
      </div>
</nav>

  <div class="container rounded border py-3 bg-white" 
        style="max-width: 1000px; 
              margin-top: 100px;
              margin-bottom: 20px;">

    <h5>Bienvenido(a): <?php echo $_SESSION['usuarioad'];?> </h5>      

  </div>

</body>
</html>