<?php


session_start();

if(!isset($_SESSION['usuarioad']))
{
    header("Location: ../index.php");
}

ob_start();



?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php 


$conn = mysqli_connect("localhost","root","","newsirce"); 

$id = $_GET['id'];

$documentos = "SELECT * FROM documento   WHERE Cedulapersona = '$id'";

?>

	 <table class="table table-bordered">
                   <tr>
                     <td>nombre documento</td>
                     <td>fotodocumento</td>
                   </tr>


             <?php $resultado2 = mysqli_query($conn, $documentos);

              while ($row=mysqli_fetch_assoc($resultado2)) { ?>

                <input type="hidden" value="<?php echo $row['Cedulapersona']; ?>" name="id">

                <tr>
                  <td><?php echo $row['Nombredocumento']; ?></td>
                  <td> <img class="documentosimages" src="http://<?php echo $_SERVER['HTTP_HOST'];?>/newsirce/controlador/imagenes/<?php echo $row['fotodocumento']; ?>" width="500"> </td>
                </tr>

                <?php } mysqli_free_result($resultado2); ?>
                </table>

</body>
</html>


<?php 

$html = ob_get_clean();
//echo $html;

require_once '../librerias/dompdf/autoload.inc.php';
use Dompdf\Dompdf;
$dompdf = new Dompdf();

$options = $dompdf->getOptions();
$options->set(array('isRemoteEnabled' => true));
$dompdf->setOptions($options);

$dompdf->loadHtml($html);
$dompdf->setPaper('letter');

$dompdf->render();
$dompdf->stream("archivo.pdf", array("Attachment" => false));

?>





