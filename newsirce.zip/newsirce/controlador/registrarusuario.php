<?php 

//include './controlador/controladorregistratrabajador.php';
$conn = mysqli_connect("localhost","root","","newsirce"); 

class Usuarios
{

 
  public $Nombredocumento;
  public $fotodocumento;

  
 

 public function registrar($datosd){

  $conn = mysqli_connect("localhost","root","","newsirce"); 

//$this->imagen = $imagen;




         $query = "INSERT INTO usuarios(Cedulapersona,nombreusuario,passwordusuario,rolusuario) values('$datosd[0]','$datosd[1]','$datosd[2]','$datosd[3]')";


         $resultado2 = mysqli_query($conn,$query);
         if($resultado2 == 1){
            

             //$query = "INSERT INTO documento(Nombredocumento) values('$datosp[15]')";

            //resultado2 = mysqli_query($conn,$query);

            //modal de si desea registras mas documentos
              
              


         }else{
            // $_SESSION['mensaje'] = 'ocurrio un error en el servidor';
             //$_SESSION['tipo'] = 'danger';
         }


       }
    }



  



   $Cedulapersonad = @$_POST['Cedulapersonad'];
    $Nombredocumento = @$_POST['nombreusuario'];
    $passwordusuario = @$_POST['passwordusuario'];
   $rolusuario = @$_POST['rolusuario'];
   
  
   

    
    
    $datosd = array($Cedulapersonad, $Nombredocumento, $passwordusuario, $rolusuario);


 $objetoUsuarios = new Usuarios();
 
 if (!($objetoUsuarios->registrar($datosd))) {
   
   //header('location:../vista/ingreso.php');
    //@header('location:../vista/inicio.php');
 }else{ 
 
//echo "jodiste";

 }


?>