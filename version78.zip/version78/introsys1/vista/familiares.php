<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Historico Laboral</title>
	<link rel="stylesheet" href="familiares.css">
	<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
</head>
<body>
	
	<header>
		<div class="headersuperior">
			<div class="logo_sistema">
				<a href="ingreso.php">SirceSyst</a>
			</div>
			<div class="menu_lista">
				<nav>
					<ul>
						<li><a href="perfiltrabajador.php">Datos Personales</a>
							<ul>
								<li><a href="modificar_trabajador.php">Modificar Datos Personales</a></li>
							</ul>
						</li>
						<li><a href="documentos_trabajador.php">Documentos</a>
							<ul>
								<li><a href="#">Añadir Documentos</a></li>
								<li><a href="#">Modificar Documentos</a></li>
							</ul>
						</li>
						<li><a href="familiares.php">Familiares</a>
							<ul>
								<li><a href="#">Añadir Familiar</a></li>
								<li><a href="#">Modificar Familiar</a></li>
							</ul>
						</li>
						<li><a href="historicolaboral.php">Histórico Laboral</a>
							<ul>
								<li><a href="#">Añadir Historico</a></li>
								<li><a href="#">Modificar Historico</a></li>
							</ul>
						</li>
					</ul>
				</nav>
			</div>
		</div>
	</header>

	<div class="articulo">
		<div class="botonagg">
			<div class="boton-modal">
				<label for="btn-modal">
					Agregar Nuevo Familiar	
				</label>
			</div>
		</div>

		<div class="tabla">
			<table>
				<thead>
					<tr>
						<th class="numero" >Cedula</th>
						<th class="documento" >Nombres</th>
						<th class="fechaing">Apellido</th>
						<th class="fechaculm">Edad</th>
						<th class="accion" >Editar</th>
						<th class="accion" >Eliminar</th>
						<th class="docs">Documentos</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>12.123.123</td>
						<td>Nombres123</td>
						<td>Apelidos123</td>
						<td>xx</td>
						<td><button class="editar">Edit</button></td>
						<td><button class="eliminar">Elim</button></td>
						<td><button class="docss">Ver</button></td>
					</tr>
				</tbody>
			</table>			
		</div>
	</div>

	<input type="checkbox" id="btn-modal">

		<!-- INICIO DEL MODAL -->

	<div class="container-modal">

		<div class="contenido-modal">

			<form action="post" id="reg-hist">

				<div class="tituloagregar">

					<div class="titulo11">
						<h2>Registrar Nuevo Familiar</h2>
					</div>

					<div class="btn-cerrar">
						<label for="btn-modal">Cerrar</label>
					</div>

				</div>
					
				<!--CONTENIDO DEL REGISTRO DE NUEVOS FAMILIARES-->

				<div class="secc-princ">
					
					<img src="../perfil_usuario.png">
					<input type="file" value="Buscar Imagen">

				</div>

				<div class="seccion seccion-ch">
					<div class="pt">
						<p><input type="checkbox" id="chch"> &nbsp; No Posee Cédula de Identidad</p>
					</div>
				</div>

				<div class="seccion seccion-1">

					<div class="pt">
						<p>Cédula</p>
						<select>
							<option value="vnzl">V</option>
							<option value="extr">E</option>
						</select>
						<input type="number" id="cici">
					</div>
					<div class="pt" >
						<p>Estado Civil</p>
						<select name="edo-civil" id="edo-civil">
							<option value="none">Seleccione</option>
							<option value="1">1</option>
							<option value="2">2</option>
						</select>
					</div>
				</div>
				<div class="seccion seccion-2">
					<div class="pt">
						<p>Nombres</p>
						<input type="text" placeholder="Ingrese sus Nombres">
					</div>
					<div class="pt">
						<p>Apellidos</p>
						<input type="text" placeholder="Ingrese sus Apellidos">
					</div>
				</div>
				<div class="seccion seccion-3">
					<div class="pt">
						<p>Número Principal</p>
						<input type="number" placeholder="Ingrese su Número Principal">
					</div>
					<div class="pt">
						<p>Número de habitacións</p>
						<input type="number" placeholder="Ingrese su Número de habitacións">
					</div>
				</div>
				<div class="seccion seccion-4">
					<div class="pt">
						<p>Municipio</p>
						<select name="" id="">
							<option value="none">Seleccione</option>
							<option value="1">1</option>
							<option value="2">2</option>
						</select>
					</div>
					<div class="pt">
						<p>Parroquia</p>
						<select name="" id="">
							<option value="none">Seleccione</option>
							<option value="1">1</option>
							<option value="2">2</option>
						</select>
					</div>
				</div>
				<div class=" seccion seccion-8">
					<div class="pt">
						<p>Sector</p>
						<select name="" id="">
							<option value="none">Seleccione</option>
							<option value="1">1</option>
							<option value="2">2</option>
						</select>
					</div>
				</div>
				<div class="seccion seccion-5">
					<div class="pt-dir">
						<p>Dirección</p>
						<input type="text" placeholder="Ingrese la Dirección">
					</div>
				</div>
				<div class="seccion seccion-6">
					<div class="pt">
						<p>Peso</p>
						<input type="text" placeholder="">
					</div>
					<div class="pt">
						<p>Estatura</p>
						<input type="text" placeholder="">
					</div>
				</div>
				<div class="seccion seccion-7">
					<div class="pt">
						<p>Talla Calzado</p>
						<input type="number">
					</div>
					<div class="pt">
						<p>Talla Camisa</p>
						<input type="text">
					</div>
					<div class="pt">
						<p>Talla Pantalón</p>
						<input type="number">
					</div>
				</div>	

				<div class="btnguardar">
					<input type="submit" value="Guardar"> 
				</div>

			</form>

		</div>
	</div>


</body>
</html>